import argparse
import csv
import json
import os
import re
import xml.etree.ElementTree as element_tree
from collections import Counter
from pathlib import Path


IMPORT_RE = re.compile(r"(?m)^\s*import\s+(?:static\s+)?([\w.*]+)\s*;")
PACKAGE_RE = re.compile(r"(?m)^\s*package\s+([\w.]+)\s*;")
MAVEN_DEP_RE = re.compile(
    r"<dependency>\s*.*?<groupId>\s*([^<\s]+)\s*</groupId>\s*.*?"
    r"<artifactId>\s*([^<\s]+)\s*</artifactId>\s*.*?"
    r"(?:<version>\s*([^<\s]+)\s*</version>)?.*?</dependency>",
    re.DOTALL,
)
GRADLE_DEP_RE = re.compile(
    r"""(?m)^\s*(?:implementation|api|compileOnly|runtimeOnly|testImplementation|testCompile)\s*
        (?:\(\s*)?["']([^:"']+):([^:"']+)(?::([^"')\s]+))?["']""",
    re.VERBOSE,
)

PLATFORM_PREFIXES = (
    "java.",
    "javax.",
    "jakarta.",
    "jdk.",
    "sun.",
    "com.sun.",
    "org.w3c.",
    "org.xml.sax.",
)
BUILD_FILE_NAMES = ("pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts")
SKIPPED_SOURCE_DIRS = {".git", ".gradle", ".idea", "build", "target", "out", "node_modules"}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if line.strip():
                rows.append((line_no, json.loads(line)))
    return rows


def clean_relative_path(value):
    return str(value or "").replace("\\", "/").lstrip("./")


def first_package_prefix(text):
    match = PACKAGE_RE.search(text or "")
    if not match:
        return ""
    parts = match.group(1).split(".")
    return ".".join(parts[:2]) if len(parts) >= 2 else match.group(1)


def import_paths(text):
    return sorted(set(IMPORT_RE.findall(text or "")))


def is_platform_import(import_path):
    return import_path.startswith(PLATFORM_PREFIXES)


def import_root(import_path):
    parts = import_path.rstrip(".*").split(".")
    if len(parts) >= 2:
        return ".".join(parts[:2])
    return import_path.rstrip(".*")


def is_project_like_import(import_path, project_prefix):
    return bool(project_prefix) and import_path.startswith(project_prefix + ".")


def candidate_suffixes(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    suffixes = []
    for end in range(len(parts), 1, -1):
        suffixes.append("/".join(parts[:end]) + ".java")
    return suffixes


def read_package_declaration(path):
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""
    match = PACKAGE_RE.search(text)
    return match.group(1) if match else ""


def index_project_sources(project_root):
    index = {
        "java_files": [],
        "packages": set(),
        "java_file_count": 0,
    }
    if not project_root.exists():
        return index

    for root, dirnames, filenames in os.walk(project_root, onerror=lambda _exc: None):
        dirnames[:] = [name for name in dirnames if name not in SKIPPED_SOURCE_DIRS]
        for filename in filenames:
            if not filename.endswith(".java"):
                continue
            path = Path(root) / filename
            try:
                relative_path = path.relative_to(project_root).as_posix()
            except ValueError:
                continue
            index["java_files"].append(relative_path)
            index["java_file_count"] += 1
            package_name = read_package_declaration(path)
            if package_name:
                index["packages"].add(package_name)
    return index


def is_project_source_import(import_path, project_index):
    for suffix in candidate_suffixes(import_path):
        if any(path.endswith(suffix) for path in project_index.get("java_files", [])):
            return True, suffix

    cleaned = import_path.rstrip(".*")
    if import_path.endswith(".*") and cleaned in project_index.get("packages", set()):
        return True, cleaned

    return False, ""


def classify_import_context(import_path, project_prefix, project_index):
    if is_platform_import(import_path):
        return "platform_import", ""
    found, matched = is_project_source_import(import_path, project_index)
    if found:
        return "project_source_import", matched
    if is_project_like_import(import_path, project_prefix):
        return "project_namespace_import_without_source_match", ""
    return "external_dependency_import", ""


def simple_name(import_path):
    cleaned = import_path.rstrip(".*")
    return cleaned.rsplit(".", 1)[-1] if cleaned else ""


def imports_used_in_fragment(imports, fragment):
    used = []
    for import_path in imports:
        name = simple_name(import_path)
        if name and name != "*" and re.search(rf"\b{re.escape(name)}\b", fragment or ""):
            used.append(import_path)
    return used


def source_set_for(file_path):
    normalized = "/" + clean_relative_path(file_path) + "/"
    if "/src/test/java/" in normalized:
        return "test"
    if "/src/main/java/" in normalized:
        return "main"
    return "unknown"


def build_files_for(source_file, project_root):
    if not project_root.exists():
        return []

    found = []
    current = source_file.parent if source_file.exists() else project_root
    try:
        current.relative_to(project_root)
    except ValueError:
        current = project_root

    while True:
        for name in BUILD_FILE_NAMES:
            candidate = current / name
            if candidate.exists() and candidate.is_file():
                found.append(candidate)
        if current == project_root:
            break
        current = current.parent

    if found:
        return sorted(set(found))

    root_builds = []
    for name in BUILD_FILE_NAMES:
        root_builds.extend(project_root.glob(name))
    return sorted(set(root_builds))


def local_name(element):
    return element.tag.rsplit("}", 1)[-1]


def child_text(element, name):
    for child in element:
        if local_name(child) == name:
            return (child.text or "").strip()
    return ""


def parse_pom_dependencies(path):
    try:
        root = element_tree.parse(path).getroot()
    except (OSError, element_tree.ParseError):
        return []

    coordinates = []
    for node in root.iter():
        if local_name(node) != "dependency":
            continue
        group_id = child_text(node, "groupId")
        artifact_id = child_text(node, "artifactId")
        version = child_text(node, "version")
        if group_id and artifact_id:
            coordinates.append(":".join(value for value in (group_id, artifact_id, version) if value))
    return sorted(set(coordinates))


def parse_gradle_dependencies(path):
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    return sorted(
        {
            ":".join(value for value in match.groups() if value)
            for match in GRADLE_DEP_RE.finditer(text)
        }
    )


def build_dependency_coordinates(build_files):
    coordinates = []
    for build_file in build_files:
        if build_file.name == "pom.xml":
            coordinates.extend(parse_pom_dependencies(build_file))
        elif build_file.name.startswith("build.gradle"):
            coordinates.extend(parse_gradle_dependencies(build_file))
    return sorted(set(coordinates))


def task_row(row, apihul_root, project_index_cache):
    prompt = row.get("prompt", "")
    project_root = apihul_root / clean_relative_path(row.get("project_path", ""))
    source_file = apihul_root / clean_relative_path(row.get("file_path", ""))
    source_exists = source_file.exists() and source_file.is_file()
    current_prefix = ""
    incomplete_fragment = ""

    current_marker = "Current file prefix:\n```java\n"
    incomplete_marker = "Incomplete function prefix:\n```java\n"
    if current_marker in prompt:
        current_prefix = prompt.split(current_marker, 1)[1].split("\n```", 1)[0]
    if incomplete_marker in prompt:
        incomplete_fragment = prompt.split(incomplete_marker, 1)[1].split("\n```", 1)[0]

    project_prefix = first_package_prefix(current_prefix)
    imports = import_paths(current_prefix)
    heuristic_external = [
        value
        for value in imports
        if not is_platform_import(value) and not is_project_like_import(value, project_prefix)
    ]
    if project_root not in project_index_cache:
        project_index_cache[project_root] = index_project_sources(project_root)
    project_index = project_index_cache[project_root]

    import_classifications = []
    context_groups = {
        "platform_import": [],
        "project_source_import": [],
        "project_namespace_import_without_source_match": [],
        "external_dependency_import": [],
    }
    matched_project_sources = {}
    for import_path in imports:
        status, matched = classify_import_context(import_path, project_prefix, project_index)
        context_groups.setdefault(status, []).append(import_path)
        if matched:
            matched_project_sources[import_path] = matched
        import_classifications.append(f"{import_path}={status}")

    external = context_groups["external_dependency_import"]
    used_imports = imports_used_in_fragment(imports, incomplete_fragment)
    used_external = [value for value in external if value in used_imports]

    build_files = build_files_for(source_file, project_root)
    coordinates = build_dependency_coordinates(build_files)
    build_kinds = sorted(
        {
            "maven" if path.name == "pom.xml" else "gradle"
            for path in build_files
            if path.name == "pom.xml" or path.name.startswith("build.gradle")
        }
    )
    has_build = bool(build_kinds)
    eligible_context = source_exists and has_build and bool(external)
    dependency_critical_seed = source_exists and has_build and bool(used_external)

    reasons = []
    if source_exists:
        reasons.append("source_exists")
    if has_build:
        reasons.append("build_context")
    if external:
        reasons.append("external_import_context")
    if used_external:
        reasons.append("external_import_used_in_fragment")

    return {
        "record_id": row.get("record_id", ""),
        "dataset": row.get("dataset", ""),
        "split": row.get("split", ""),
        "source_line": row.get("source_line", ""),
        "project_path": row.get("project_path", ""),
        "file_path": row.get("file_path", ""),
        "source_set": source_set_for(row.get("file_path", "")),
        "source_file_exists": source_exists,
        "project_root_exists": project_root.exists(),
        "project_source_java_file_count": project_index.get("java_file_count", 0),
        "project_package_prefix": project_prefix,
        "build_kinds": ";".join(build_kinds),
        "build_file_count": len(build_files),
        "build_files": ";".join(str(path.relative_to(apihul_root)).replace("\\", "/") for path in build_files),
        "build_dependency_count": len(coordinates),
        "build_dependency_coordinates": ";".join(coordinates[:120]),
        "import_count": len(imports),
        "heuristic_external_import_count": len(heuristic_external),
        "heuristic_external_imports": ";".join(heuristic_external),
        "platform_import_count": len(context_groups["platform_import"]),
        "project_source_import_count": len(context_groups["project_source_import"]),
        "project_namespace_import_without_source_match_count": len(context_groups["project_namespace_import_without_source_match"]),
        "external_import_count": len(external),
        "external_imports": ";".join(external),
        "external_import_roots": ";".join(sorted({import_root(value) for value in external})),
        "import_context_classifications": ";".join(import_classifications),
        "matched_project_source_suffixes": ";".join(
            f"{import_path}->{matched_project_sources[import_path]}"
            for import_path in sorted(matched_project_sources)
        ),
        "imports_used_in_fragment_count": len(used_imports),
        "external_imports_used_in_fragment_count": len(used_external),
        "external_imports_used_in_fragment": ";".join(used_external),
        "eligible_dependency_context": eligible_context,
        "dependency_critical_seed": dependency_critical_seed,
        "selection_reasons": ";".join(reasons),
    }


def write_markdown(path, output):
    summary = output["summary"]
    lines = [
        "# Java Dependency-Critical Task Inventory",
        "",
        f"- Input prompts: `{output['input_prompts']}`",
        f"- APIHulBench root: `{output['apihul_root']}`",
        f"- Total records: `{summary['records']}`",
        f"- Records with source file: `{summary['source_file_exists']}`",
        f"- Records with Maven/Gradle context: `{summary['build_context']}`",
        f"- Records with heuristic external imports: `{summary['heuristic_external_import_context']}`",
        f"- Records with source-indexed external dependency imports: `{summary['external_import_context']}`",
        f"- Dependency-context eligible records: `{summary['eligible_dependency_context']}`",
        f"- Dependency-critical seeds (external import referenced in incomplete fragment): `{summary['dependency_critical_seed']}`",
        "",
        "## Split Counts",
        "",
        "| Split | Records | Eligible context | Critical seeds |",
        "|---|---:|---:|---:|",
    ]
    for split, counts in sorted(output["by_split"].items()):
        lines.append(
            f"| {split} | {counts['records']} | {counts['eligible_dependency_context']} | {counts['dependency_critical_seed']} |"
        )

    lines.extend(["", "## Source Set Counts", "", "| Source set | Records | Eligible context | Critical seeds |", "|---|---:|---:|---:|"])
    for source_set, counts in sorted(output["by_source_set"].items()):
        lines.append(
            f"| {source_set} | {counts['records']} | {counts['eligible_dependency_context']} | {counts['dependency_critical_seed']} |"
        )

    lines.extend(
        [
            "",
            "## Import Classification Totals",
            "",
            "| Import context | Count |",
            "|---|---:|",
        ]
    )
    for status, count in output["import_context_counts"]:
        lines.append(f"| `{status}` | {count} |")

    lines.extend(["", "## External Import Roots", "", "| Root | Count |", "|---|---:|"])
    for root, count in output["top_external_import_roots"][:30]:
        lines.append(f"| `{root}` | {count} |")

    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "A dependency-context eligible record has a resolved source file, at least one Maven or Gradle build descriptor, and at least one source-indexed external dependency import.",
            "A dependency-critical seed additionally references such an external dependency import by simple class name in the incomplete fragment. These seeds are candidates for source-grounded dependency-repair task construction, but are not yet a final benchmark.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    apihul_root = Path(args.apihul_root)
    prompts = [row for _, row in read_jsonl(Path(args.prompts_jsonl))]
    project_index_cache = {}
    rows = [task_row(row, apihul_root, project_index_cache) for row in prompts]

    fieldnames = list(rows[0]) if rows else []
    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "records": len(rows),
        "source_file_exists": sum(bool(row["source_file_exists"]) for row in rows),
        "build_context": sum(bool(row["build_kinds"]) for row in rows),
        "heuristic_external_import_context": sum(bool(row["heuristic_external_import_count"]) for row in rows),
        "external_import_context": sum(bool(row["external_import_count"]) for row in rows),
        "eligible_dependency_context": sum(bool(row["eligible_dependency_context"]) for row in rows),
        "dependency_critical_seed": sum(bool(row["dependency_critical_seed"]) for row in rows),
        "project_roots_indexed": len(project_index_cache),
        "project_source_java_files_indexed": sum(index.get("java_file_count", 0) for index in project_index_cache.values()),
    }
    by_split = {}
    for split in sorted({row["split"] for row in rows}):
        split_rows = [row for row in rows if row["split"] == split]
        by_split[split] = {
            "records": len(split_rows),
            "eligible_dependency_context": sum(bool(row["eligible_dependency_context"]) for row in split_rows),
            "dependency_critical_seed": sum(bool(row["dependency_critical_seed"]) for row in split_rows),
        }

    by_source_set = {}
    for source_set in sorted({row["source_set"] for row in rows}):
        source_rows = [row for row in rows if row["source_set"] == source_set]
        by_source_set[source_set] = {
            "records": len(source_rows),
            "eligible_dependency_context": sum(bool(row["eligible_dependency_context"]) for row in source_rows),
            "dependency_critical_seed": sum(bool(row["dependency_critical_seed"]) for row in source_rows),
        }

    root_counts = Counter()
    import_context_counts = Counter()
    for row in rows:
        for root in filter(None, row["external_import_roots"].split(";")):
            root_counts[root] += 1
        import_context_counts["platform_import"] += int(row["platform_import_count"])
        import_context_counts["project_source_import"] += int(row["project_source_import_count"])
        import_context_counts["project_namespace_import_without_source_match"] += int(row["project_namespace_import_without_source_match_count"])
        import_context_counts["external_dependency_import"] += int(row["external_import_count"])

    output = {
        "input_prompts": args.prompts_jsonl,
        "apihul_root": args.apihul_root,
        "summary": summary,
        "by_split": by_split,
        "by_source_set": by_source_set,
        "import_context_counts": import_context_counts.most_common(),
        "top_external_import_roots": root_counts.most_common(),
        "rows": rows,
    }
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), output)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
