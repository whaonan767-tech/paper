#!/usr/bin/env python3
"""Create source- and build-grounded truth for an external import pilot."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


SUSPICIOUS = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts-jsonl", type=Path, required=True)
    parser.add_argument("--mapping-json", type=Path, required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--work-root", type=Path, required=True)
    parser.add_argument("--maven-settings", type=Path, required=True)
    parser.add_argument("--maven-repository", type=Path, required=True)
    parser.add_argument("--java-home", type=Path, required=True)
    parser.add_argument("--java-version", default="17")
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--record-id", action="append", default=[])
    parser.add_argument("--force-root-build", action="store_true")
    return parser.parse_args()


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def insert_import(source: str, import_path: str) -> tuple[str, bool]:
    existing = set(re.findall(r"(?m)^\s*import\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;", source))
    if import_path in existing:
        return source, False
    insertion = f"import {import_path};\n"
    package_match = re.search(r"(?m)^\s*package\s+[A-Za-z_][\w.]*\s*;\s*(?:\r?\n)?", source)
    if package_match:
        return source[: package_match.end()] + insertion + source[package_match.end() :], True
    return insertion + source, True


def nearest_module(project_root: Path, file_path: Path) -> Path:
    current = file_path.parent
    while current != project_root:
        if (current / "pom.xml").exists():
            return current
        current = current.parent
    return project_root


def command_for(args: argparse.Namespace, project_root: Path, module_root: Path) -> list[str]:
    wrapper = project_root / "mvnw.cmd"
    toolchains = project_root / ".codex-toolchains.xml"
    toolchains.write_text(
        "<toolchains><toolchain><type>jdk</type><provides>"
        f"<version>{args.java_version}</version>"
        "</provides><configuration>"
        f"<jdkHome>{args.java_home.resolve()}</jdkHome>"
        "</configuration></toolchain></toolchains>\n",
        encoding="utf-8",
    )
    command = [
        str(wrapper) if wrapper.exists() else "mvn.cmd",
        "-t", str(toolchains),
        "-s", str(args.maven_settings.resolve()),
        f"-Dmaven.repo.local={args.maven_repository.resolve()}",
        "-q",
        "-DskipTests",
        "-DskipITs",
        "-Dcheckstyle.skip=true",
        "-Dspotbugs.skip=true",
        "-Dpmd.skip=true",
        "-Dspotless.check.skip=true",
        "-Dspotless.apply.skip=true",
        "-Dmaven.javadoc.skip=true",
    ]
    if module_root != project_root:
        command.extend(["-pl", module_root.relative_to(project_root).as_posix(), "-am"])
    command.extend(["clean", "test-compile"])
    return command


def run_maven(command: list[str], cwd: Path, args: argparse.Namespace, log_path: Path) -> dict:
    environment = os.environ.copy()
    java_home = args.java_home.resolve()
    environment["JAVA_HOME"] = str(java_home)
    environment["PATH"] = str(java_home / "bin") + os.pathsep + environment.get("PATH", "")
    locale = "-Duser.language=en -Duser.country=US -Dfile.encoding=UTF-8"
    environment["MAVEN_OPTS"] = (environment.get("MAVEN_OPTS", "") + " " + locale).strip()
    started = time.perf_counter()
    timed_out = False
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=environment,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=args.timeout,
            check=False,
        )
        output = completed.stdout or ""
        return_code = completed.returncode
    except subprocess.TimeoutExpired as error:
        timed_out = True
        output = (error.stdout or "") if isinstance(error.stdout, str) else ""
        return_code = None
    duration = time.perf_counter() - started
    log_path.write_text(output, encoding="utf-8")
    return {
        "return_code": return_code,
        "timed_out": timed_out,
        "duration_seconds": round(duration, 3),
        "log_path": log_path.name,
        "tail": "\n".join(output.splitlines()[-80:]),
        "pass": return_code == 0 and not timed_out,
    }


def failure_mentions_candidate(output: str, import_path: str) -> bool:
    lowered = output.lower()
    parts = import_path.split(".")
    package = ".".join(parts[:-1]).lower()
    class_name = parts[-1].lower()
    return import_path.lower() in lowered or package in lowered or class_name in lowered


def metrics(rows: list[dict]) -> dict:
    evaluable = [row for row in rows if row["truth"] in {"valid", "invalid"}]
    tp = sum(row["detector_suspicious"] and row["truth"] == "invalid" for row in evaluable)
    fp = sum(row["detector_suspicious"] and row["truth"] == "valid" for row in evaluable)
    fn = sum(not row["detector_suspicious"] and row["truth"] == "invalid" for row in evaluable)
    tn = sum(not row["detector_suspicious"] and row["truth"] == "valid" for row in evaluable)
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    return {"evaluable": len(evaluable), "tp": tp, "fp": fp, "fn": fn, "tn": tn, "precision": precision, "recall": recall, "f1": f1}


def main() -> None:
    args = parse_args()
    workspace = args.workspace.resolve()
    output_dir = args.output_dir.resolve()
    work_root = args.work_root.resolve()
    if output_dir.exists() or work_root.exists():
        raise SystemExit(f"Output/work path exists: {output_dir} or {work_root}")
    output_dir.mkdir(parents=True)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir()
    work_root.mkdir(parents=True)
    prompts = {row["record_id"]: row for row in read_jsonl(args.prompts_jsonl.resolve())}
    mapping_payload = json.loads(args.mapping_json.resolve().read_text(encoding="utf-8"))
    mapped = [
        row for row in mapping_payload["mapped"]
        if not args.record_id or row.get("original_record_id") in set(args.record_id)
    ]
    results = []
    try:
        for index, row in enumerate(mapped, start=1):
            record_id = row["original_record_id"]
            prompt = prompts[record_id]
            candidate = row["import_path"]
            exact = candidate == prompt["ground_truth_import"]
            result = {
                "record_id": record_id,
                "project_id": prompt["project_id"],
                "project_commit": prompt["project_commit"],
                "project_path": prompt["project_path"],
                "file_path": prompt["file_path"],
                "ground_truth_import": prompt["ground_truth_import"],
                "candidate_import": candidate,
                "exact_ground_truth": exact,
                "mapping_status": row.get("mapping_status", ""),
                "import_classification": row.get("import_classification", ""),
                "detector_suspicious": row.get("mapping_status", "") in SUSPICIOUS,
                "baseline": None,
                "candidate_build": None,
            }
            if exact:
                result.update({"truth": "valid", "truth_evidence": "original_source_exact_import"})
                results.append(result)
                continue

            source_project = workspace / prompt["project_path"]
            copied_project = work_root / f"r{index:03d}"
            shutil.copytree(source_project, copied_project, ignore=shutil.ignore_patterns("target", ".git", "build", ".gradle"))
            source_file = workspace / prompt["file_path"]
            target_file = copied_project / source_file.relative_to(source_project)
            original_source = target_file.read_text(encoding="utf-8", errors="replace")
            module_root = nearest_module(copied_project, target_file)
            if args.force_root_build:
                module_root = copied_project
            command = command_for(args, copied_project, module_root)
            baseline_log = logs_dir / f"{record_id}_baseline.log"
            baseline = run_maven(command, copied_project, args, baseline_log)
            result["baseline"] = {**baseline, "command": " ".join(command), "module": module_root.relative_to(copied_project).as_posix()}
            if not baseline["pass"]:
                result.update({"truth": "uncertain", "truth_evidence": "baseline_build_failed"})
                results.append(result)
                shutil.rmtree(copied_project)
                continue

            mutated, inserted = insert_import(original_source, candidate)
            if not inserted:
                result.update({"truth": "valid", "truth_evidence": "candidate_already_in_original_source"})
                results.append(result)
                shutil.rmtree(copied_project)
                continue
            target_file.write_text(mutated, encoding="utf-8", newline="\n")
            candidate_log = logs_dir / f"{record_id}_candidate.log"
            candidate_build = run_maven(command, copied_project, args, candidate_log)
            result["candidate_build"] = {**candidate_build, "command": " ".join(command), "mentions_candidate": failure_mentions_candidate(candidate_build["tail"], candidate)}
            if candidate_build["pass"]:
                result.update({"truth": "valid", "truth_evidence": "candidate_resolved_by_project_test_compile"})
            elif result["candidate_build"]["mentions_candidate"]:
                result.update({"truth": "invalid", "truth_evidence": "candidate_rejected_and_named_by_project_test_compile"})
            else:
                result.update({"truth": "uncertain", "truth_evidence": "candidate_build_failed_without_candidate_specific_diagnostic"})
            results.append(result)
            shutil.rmtree(copied_project)
    finally:
        if work_root.exists():
            shutil.rmtree(work_root)

    metric = metrics(results)
    summary = {
        "responses": len(prompts),
        "candidate_rows": len(results),
        "projects": len({row["project_id"] for row in results}),
        "exact_recoveries": sum(row["exact_ground_truth"] for row in results),
        "truth_counts": dict(Counter(row["truth"] for row in results)),
        "evidence_counts": dict(Counter(row["truth_evidence"] for row in results)),
        "baseline_build_passes": sum(bool(row["baseline"] and row["baseline"]["pass"]) for row in results),
        "candidate_build_passes": sum(bool(row["candidate_build"] and row["candidate_build"]["pass"]) for row in results),
        "detector": metric,
    }
    payload = {
        "artifact": "prospective_external_candidate_build_truth",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "protocol": "Exact hidden-import recovery is source-valid. Every nonexact candidate is added to the unchanged original file; only baseline-passing Maven units are interpreted. A passing candidate build is valid, a failing build with a candidate-specific diagnostic is invalid, and other failures are uncertain.",
        "claim_boundary": "Build/source-grounded prospective pilot on a constrained one-import protocol; not independently human-annotated general-purpose detector performance.",
        "inputs": {
            "prompts_sha256": sha256(args.prompts_jsonl.resolve()),
            "mapping_sha256": sha256(args.mapping_json.resolve()),
            "script_sha256": sha256(Path(__file__).resolve()),
        },
        "results": results,
    }
    (output_dir / "external_candidate_build_truth.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["record_id", "project_id", "project_commit", "project_path", "file_path", "ground_truth_import", "candidate_import", "exact_ground_truth", "mapping_status", "import_classification", "detector_suspicious", "truth", "truth_evidence", "baseline", "candidate_build"]
    with (output_dir / "external_candidate_build_truth.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in results:
            writer.writerow({**row, "baseline": json.dumps(row["baseline"], ensure_ascii=False), "candidate_build": json.dumps(row["candidate_build"], ensure_ascii=False)})
    lines = [
        "# Prospective External Candidate Build Truth",
        "",
        f"- Responses / candidates / projects: `{summary['responses']}` / `{summary['candidate_rows']}` / `{summary['projects']}`.",
        f"- Exact hidden-import recoveries: `{summary['exact_recoveries']}/{summary['responses']}`.",
        f"- Truth counts: `{summary['truth_counts']}`.",
        f"- Interpretable detector confusion TP/FP/FN/TN: `{metric['tp']}/{metric['fp']}/{metric['fn']}/{metric['tn']}` over `{metric['evaluable']}` candidates.",
        f"- Precision / recall / F1: `{metric['precision']}` / `{metric['recall']}` / `{metric['f1']}`.",
        "",
        payload["claim_boundary"],
    ]
    (output_dir / "external_candidate_build_truth.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
