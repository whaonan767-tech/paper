import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path


CURRENT_MARKER = "Current file prefix:\n```java\n"
INCOMPLETE_MARKER = "Incomplete function prefix:\n```java\n"
IMPORT_LINE_RE = re.compile(r"^\s*import\s+(?:static\s+)?([\w.*]+)\s*;\s*$")


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def bool_field(value):
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def split_list(value):
    return [item for item in str(value or "").split(";") if item]


def clipped(text, max_chars):
    text = text or ""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n/* ... clipped ... */"


def extract_section(prompt, marker):
    if marker not in prompt:
        return ""
    return prompt.split(marker, 1)[1].split("\n```", 1)[0]


def extract_project_description(prompt):
    marker = "Project description:\n"
    stop = "\n\nCurrent file path:"
    if marker not in prompt:
        return ""
    text = prompt.split(marker, 1)[1]
    if stop in text:
        text = text.split(stop, 1)[0]
    return text.strip()


def remove_target_import_lines(current_prefix, target_imports):
    targets = set(target_imports)
    output = []
    removed = []
    inserted_marker = False
    for line in current_prefix.splitlines():
        match = IMPORT_LINE_RE.match(line)
        if match and match.group(1) in targets:
            removed.append(match.group(1))
            if not inserted_marker:
                output.append("// One or more third-party import declarations were removed here for evaluation.")
                inserted_marker = True
            continue
        output.append(line)
    return "\n".join(output), removed


def dependency_roots(imports):
    roots = []
    for import_path in imports:
        parts = [part for part in import_path.rstrip(".*").split(".") if part]
        if len(parts) >= 3 and parts[:3] == ["org", "junit", "jupiter"]:
            roots.append(".".join(parts[:3]))
        elif len(parts) >= 2:
            roots.append(".".join(parts[:2]))
        elif parts:
            roots.append(parts[0])
    return sorted(set(roots))


def render_prompt(base_row, inventory_row, masked_current_prefix, max_project_chars, max_file_chars, max_function_chars):
    original_prompt = base_row.get("prompt", "")
    project_description = clipped(extract_project_description(original_prompt), max_project_chars)
    current_file = clipped(masked_current_prefix, max_file_chars)
    incomplete_function = clipped(extract_section(original_prompt, INCOMPLETE_MARKER), max_function_chars)
    file_path = base_row.get("file_path", "")

    return (
        "You are working inside a Java project. The current file prefix below is intentionally incomplete: "
        "one or more third-party import declarations needed by the incomplete fragment were removed.\n\n"
        "Complete the Java code and recover only the dependency evidence needed for the completion.\n\n"
        "Return your answer in this exact structure:\n"
        "1. Java code block with the completed code or method body.\n"
        "2. Dependencies section with bullet rows in this format:\n"
        "   - Maven: groupId:artifactId:version | reason\n"
        "   - Gradle: implementation 'groupId:artifactId:version' | reason\n"
        "   - Import: fully.qualified.ImportName | reason\n"
        "   - Project-local: fully.qualified.ProjectClass | reason\n"
        "   - JDK: fully.qualified.JdkClass | reason\n\n"
        "Rules:\n"
        "1. List every non-JDK import or dependency that your completed code needs but that is not present in the current file prefix.\n"
        "2. Use Project-local only for symbols that clearly belong to the project source tree; do not turn project classes into Maven dependencies.\n"
        "3. Do not invent a Maven or Gradle coordinate. If you know the external import but not the exact coordinate, list the Import row and write no coordinate for it.\n"
        "4. If no external dependency is needed, the Dependencies section must be exactly: No external dependency.\n\n"
        f"Project description:\n{project_description}\n\n"
        f"Current file path:\n{file_path}\n\n"
        f"Current file prefix:\n```java\n{current_file}\n```\n\n"
        f"Incomplete function prefix:\n```java\n{incomplete_function}\n```\n"
    )


def build_rows(prompts, inventory_rows, args):
    prompts_by_id = {row.get("record_id", ""): row for row in prompts}
    selected_inventory = [
        row
        for row in inventory_rows
        if bool_field(row.get("dependency_critical_seed"))
        and row.get("split", "") in set(args.splits)
    ]

    if args.source_sets:
        allowed_source_sets = set(args.source_sets)
        selected_inventory = [row for row in selected_inventory if row.get("source_set", "") in allowed_source_sets]

    selected_inventory.sort(key=lambda row: (row.get("split", ""), row.get("source_set", ""), row.get("record_id", "")))
    if args.max_records > 0:
        selected_inventory = selected_inventory[: args.max_records]

    output_rows = []
    skipped = []
    for inventory_row in selected_inventory:
        record_id = inventory_row.get("record_id", "")
        base_row = prompts_by_id.get(record_id)
        if not base_row:
            skipped.append({"record_id": record_id, "reason": "missing_base_prompt"})
            continue

        current_prefix = extract_section(base_row.get("prompt", ""), CURRENT_MARKER)
        target_imports = split_list(inventory_row.get("external_imports_used_in_fragment", ""))
        if any(
            import_path.startswith(prefix)
            for import_path in target_imports
            for prefix in args.exclude_import_prefixes
        ):
            skipped.append({"record_id": record_id, "reason": "excluded_import_prefix"})
            continue
        masked_current_prefix, removed = remove_target_import_lines(current_prefix, target_imports)
        if not removed:
            skipped.append({"record_id": record_id, "reason": "no_target_import_line_removed"})
            continue

        out = dict(base_row)
        out.pop("_line_no", None)
        out.update(
            {
                "base_task": base_row.get("task", ""),
                "task": "java_dependency_critical_masked_import_repair",
                "source_set": inventory_row.get("source_set", ""),
                "masked_external_imports": removed,
                "masked_external_import_count": len(removed),
                "masked_external_import_roots": dependency_roots(removed),
                "strict_external_imports": split_list(inventory_row.get("external_imports", "")),
                "build_kinds": inventory_row.get("build_kinds", ""),
                "build_dependency_count": int(inventory_row.get("build_dependency_count") or 0),
                "build_dependency_coordinates_hidden_gold": split_list(inventory_row.get("build_dependency_coordinates", "")),
                "prompt": render_prompt(
                    base_row,
                    inventory_row,
                    masked_current_prefix,
                    args.max_project_chars,
                    args.max_file_chars,
                    args.max_function_chars,
                ),
            }
        )
        output_rows.append(out)

    return output_rows, skipped


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")


def write_markdown(path, rows, skipped, args):
    split_counts = Counter(row.get("split", "") for row in rows)
    source_set_counts = Counter(row.get("source_set", "") for row in rows)
    root_counts = Counter(root for row in rows for root in row.get("masked_external_import_roots", []))
    masked_count_hist = Counter(str(row.get("masked_external_import_count", 0)) for row in rows)

    lines = [
        "# Java Dependency-Critical Masked-Import Prompt Set",
        "",
        f"- Base prompts: `{args.prompts_jsonl}`",
        f"- Inventory: `{args.inventory_csv}`",
        f"- Output prompts: `{args.output_jsonl}`",
        f"- Records: `{len(rows)}`",
        f"- Skipped records: `{len(skipped)}`",
        f"- Splits: `{', '.join(args.splits)}`",
        f"- Source sets: `{', '.join(args.source_sets) if args.source_sets else 'all'}`",
        f"- Excluded import prefixes: `{', '.join(args.exclude_import_prefixes) if args.exclude_import_prefixes else 'none'}`",
        "",
        "## Selection Rule",
        "",
        "A record is selected only when the source file exists, Maven/Gradle context exists, a source-indexed external dependency import exists, and the incomplete fragment references that import by simple class name. The selected import line is removed from the prompt; the removed import remains hidden metadata for evaluation.",
        "",
        "## Split Counts",
        "",
        "| Split | Prompts |",
        "|---|---:|",
    ]
    for split, count in sorted(split_counts.items()):
        lines.append(f"| {split} | {count} |")

    lines.extend(["", "## Source Set Counts", "", "| Source set | Prompts |", "|---|---:|"])
    for source_set, count in sorted(source_set_counts.items()):
        lines.append(f"| {source_set} | {count} |")

    lines.extend(["", "## Masked Import Count Per Prompt", "", "| Masked imports | Prompts |", "|---|---:|"])
    for masked_count, count in sorted(masked_count_hist.items(), key=lambda item: int(item[0])):
        lines.append(f"| {masked_count} | {count} |")

    lines.extend(["", "## Masked Import Roots", "", "| Root | Count |", "|---|---:|"])
    for root, count in root_counts.most_common(30):
        lines.append(f"| `{root}` | {count} |")

    if skipped:
        lines.extend(["", "## Skipped", "", "| Record | Reason |", "|---|---|"])
        for row in skipped[:50]:
            lines.append(f"| `{row.get('record_id', '')}` | `{row.get('reason', '')}` |")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--inventory-csv", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--splits", nargs="+", choices=["F", "M"], default=["F", "M"])
    parser.add_argument("--source-sets", nargs="*", choices=["main", "test", "unknown"], default=[])
    parser.add_argument("--exclude-import-prefixes", nargs="*", default=[])
    parser.add_argument("--max-records", type=int, default=0)
    parser.add_argument("--max-project-chars", type=int, default=900)
    parser.add_argument("--max-file-chars", type=int, default=1800)
    parser.add_argument("--max-function-chars", type=int, default=900)
    args = parser.parse_args()

    prompts = read_jsonl(Path(args.prompts_jsonl))
    inventory_rows = read_csv(Path(args.inventory_csv))
    rows, skipped = build_rows(prompts, inventory_rows, args)
    write_jsonl(Path(args.output_jsonl), rows)
    write_markdown(Path(args.output_md), rows, skipped, args)
    print(json.dumps({"prompts": len(rows), "skipped": len(skipped)}, indent=2))


if __name__ == "__main__":
    main()
