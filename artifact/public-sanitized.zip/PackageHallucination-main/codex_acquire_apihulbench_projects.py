#!/usr/bin/env python3
"""Acquire the official APIHulBench project archive and verify paper snapshots."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OFFICIAL_REPOSITORY = "https://github.com/yujiachen99/APIMitigation"
OFFICIAL_ARCHIVE_ID = "12c46In9w9fqJyU-qAAKccMSVycFIszOz"
OFFICIAL_ARCHIVE_URL = f"https://drive.google.com/file/d/{OFFICIAL_ARCHIVE_ID}/view?usp=sharing"
DEFAULT_MANIFEST = ROOT / "Tests" / "Java_APIHulBench_BuildProvenance_Run20260804" / "java_build_provenance.json"
IGNORED_DIRS = {".git", ".gradle", ".idea", "node_modules", "target", "build", "dist", "out"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repositories-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--report", type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def tree_sha256(project_root: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    files = 0
    candidates = sorted(
        (
            path
            for path in project_root.rglob("*")
            if path.is_file()
            and not any(part.lower() in IGNORED_DIRS for part in path.relative_to(project_root).parts)
        ),
        key=lambda path: path.relative_to(project_root).as_posix(),
    )
    for path in candidates:
        relative = path.relative_to(project_root).as_posix()
        file_hash = sha256(path)
        size = path.stat().st_size
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(size).encode("ascii"))
        digest.update(b"\0")
        digest.update(file_hash.encode("ascii"))
        digest.update(b"\n")
        files += 1
    return (digest.hexdigest().upper() if files else ""), files


def expected_projects(manifest_path: Path) -> dict[str, dict[str, object]]:
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected: dict[str, dict[str, object]] = {}
    for unit in payload["units"]:
        project_id = unit["project_id"]
        current = expected.setdefault(
            project_id,
            {
                "tree_sha256": unit["content_addressed_revision"],
                "files_hashed": unit["snapshot_files_hashed"],
            },
        )
        if current["tree_sha256"] != unit["content_addressed_revision"]:
            raise ValueError(f"Conflicting expected revisions for {project_id}")
    return expected


def download_archive(archive: Path) -> None:
    try:
        import gdown
    except ImportError as error:
        raise SystemExit("Download mode requires `pip install gdown`; verification uses only the standard library.") from error
    archive.parent.mkdir(parents=True, exist_ok=True)
    result = gdown.download(id=OFFICIAL_ARCHIVE_ID, output=str(archive), quiet=False)
    if not result or not archive.is_file():
        raise SystemExit(f"Official archive download failed: {OFFICIAL_ARCHIVE_URL}")


def find_repository_root(extracted: Path, expected_ids: set[str]) -> Path:
    candidates = [extracted]
    candidates.extend(path for path in extracted.rglob("*") if path.is_dir() and len(path.relative_to(extracted).parts) <= 2)
    scored = [(sum((path / project_id).is_dir() for project_id in expected_ids), path) for path in candidates]
    matched, root = max(scored, key=lambda item: item[0])
    if matched != len(expected_ids):
        raise SystemExit(f"Official archive exposes only {matched}/{len(expected_ids)} expected project folders")
    return root


def extract_archive(archive: Path, repositories_dir: Path, expected_ids: set[str]) -> None:
    if repositories_dir.exists():
        raise SystemExit(f"Refusing to overwrite existing directory: {repositories_dir}")
    repositories_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="apihulbench_extract_", dir=repositories_dir.parent) as temporary:
        extracted = Path(temporary)
        shutil.unpack_archive(str(archive), str(extracted))
        source_root = find_repository_root(extracted, expected_ids)
        shutil.copytree(source_root, repositories_dir)


def verify(repositories_dir: Path, expected: dict[str, dict[str, object]]) -> dict[str, object]:
    rows = []
    for project_id, target in sorted(expected.items()):
        project_root = repositories_dir / project_id
        if not project_root.is_dir():
            rows.append({"project_id": project_id, "status": "missing"})
            continue
        observed_hash, files = tree_sha256(project_root)
        hash_match = observed_hash == target["tree_sha256"]
        files_match = files == target["files_hashed"]
        rows.append(
            {
                "project_id": project_id,
                "status": "pass" if hash_match and files_match else "mismatch",
                "expected_tree_sha256": target["tree_sha256"],
                "observed_tree_sha256": observed_hash,
                "expected_files": target["files_hashed"],
                "observed_files": files,
            }
        )
    passed = sum(row["status"] == "pass" for row in rows)
    result = {
        "status": "pass" if passed == len(expected) else "fail",
        "official_repository": OFFICIAL_REPOSITORY,
        "official_archive_url": OFFICIAL_ARCHIVE_URL,
        "official_archive_id": OFFICIAL_ARCHIVE_ID,
        "projects_expected": len(expected),
        "projects_verified": passed,
        "projects": rows,
    }
    return result


def main() -> None:
    args = parse_args()
    manifest = args.manifest.resolve()
    repositories_dir = args.repositories_dir.resolve()
    expected = expected_projects(manifest)
    if not args.verify_only:
        if args.archive is None:
            raise SystemExit("Acquisition requires --archive; add --download to retrieve the official Google Drive file.")
        archive = args.archive.resolve()
        if args.download:
            download_archive(archive)
        if not archive.is_file():
            raise SystemExit(f"Missing archive: {archive}")
        extract_archive(archive, repositories_dir, set(expected))
    result = verify(repositories_dir, expected)
    output = json.dumps(result, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output + "\n", encoding="utf-8")
    print(f"{result['status'].upper()} {result['projects_verified']}/{result['projects_expected']} project snapshots")
    print(f"Official archive: {OFFICIAL_ARCHIVE_URL}")
    if result["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
