#!/usr/bin/env python3
"""Build gold code after inserting only Qwen's parseable import evidence."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import codex_java_masked_baseline_audit as baseline
import codex_java_masked_necessity_probe as necessity


PACKAGE_ROOT = Path(__file__).resolve().parent
WORKSPACE = PACKAGE_ROOT.parents[1]
PROMPTS = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730"
    / "prompts.jsonl"
)
MODEL_RUN = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_Qwen7B_DepCriticalMasked_Strict_Full117_Run20260730"
)
RESPONSES = MODEL_RUN / "responses.jsonl"
CANDIDATES = MODEL_RUN / "candidates.csv"
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
BASELINE = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803"
    / "masked_baseline_audit.json"
)
NECESSITY = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedSemanticBuild_NecessityFull83_TestCompile_Run20260803"
    / "masked_necessity_probe.json"
)
DEFAULT_WORK_ROOT = WORKSPACE / "vw" / "masked_evidence"
DEFAULT_OUTPUT_ROOT = PACKAGE_ROOT / "Tests"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--responses", type=Path, default=RESPONSES)
    parser.add_argument("--candidates", type=Path, default=CANDIDATES)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--necessity", type=Path, default=NECESSITY)
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-status", action="append", default=[])
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def load_model_imports(responses_path: Path, candidates_path: Path) -> dict[str, list[str]]:
    responses = baseline.read_jsonl(responses_path)
    by_line: dict[int, list[str]] = defaultdict(list)
    with candidates_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("kind") != "java_import" or not row.get("import_path"):
                continue
            line = int(row["source_line"])
            value = row["import_path"]
            if value not in by_line[line]:
                by_line[line].append(value)
    return {
        response["record_id"]: by_line.get(index, [])
        for index, response in enumerate(responses, start=1)
    }


def insert_imports(source: str, imports: list[str]) -> tuple[str, list[str]]:
    existing = set(
        re.findall(
            r"(?m)^\s*import\s+(?:static\s+)?([A-Za-z_][\w$]*(?:\.[A-Za-z_*][\w$*]*)+)\s*;",
            source,
        )
    )
    additions = [value for value in imports if value not in existing]
    if not additions:
        return source, []
    insertion = "".join(f"import {value};\n" for value in additions)
    package_match = re.search(
        r"(?m)^\s*package\s+[A-Za-z_][\w.]*\s*;\s*(?:\r?\n)?", source
    )
    if package_match:
        position = package_match.end()
        return source[:position] + insertion + source[position:], additions
    return insertion + source, additions


def prepare_records(
    prompts: list[dict],
    audit_by_key: dict[str, dict],
    baseline_payload: dict,
    necessity_payload: dict,
    model_imports: dict[str, list[str]],
) -> tuple[list[dict], dict[str, str | None]]:
    base_records, jdk_homes = necessity.load_records(
        prompts, audit_by_key, baseline_payload
    )
    necessary_ids = {
        row["record_id"]
        for row in necessity_payload["results"]
        if row["target_failure_evidence"]
    }
    records = []
    for row in base_records:
        if row["record_id"] not in necessary_ids:
            continue
        generated = list(model_imports.get(row["record_id"], []))
        targets = row["masked_imports"]
        recovered = [value for value in targets if value in generated]
        records.append(
            {
                **row,
                "generated_imports": generated,
                "exact_recovered_imports": recovered,
                "all_targets_exact": len(recovered) == len(targets),
                "any_target_exact": bool(recovered),
            }
        )
    records.sort(key=lambda row: row["record_id"])
    return records, jdk_homes


def summarize(records: list[dict], results: list[dict]) -> dict:
    pass_rows = [row for row in results if row["status"] == "pass"]
    all_exact_rows = [row for row in results if row["all_targets_exact"]]
    not_all_exact_rows = [row for row in results if not row["all_targets_exact"]]
    return {
        "eligible_records": len(records),
        "eligible_projects": len({row["project_path"] for row in records}),
        "eligible_hidden_imports": sum(len(row["masked_imports"]) for row in records),
        "completed_records": len(results),
        "exact_recovered_hidden_imports": sum(row["exact_recovered_count"] for row in results),
        "records_any_exact": sum(row["any_target_exact"] for row in results),
        "records_all_exact": len(all_exact_rows),
        "evidence_build_pass_records": len(pass_rows),
        "evidence_build_pass_projects": len({row["project_path"] for row in pass_rows}),
        "all_exact_build_pass": sum(row["status"] == "pass" for row in all_exact_rows),
        "all_exact_build_fail": sum(row["status"] != "pass" for row in all_exact_rows),
        "not_all_exact_build_pass": sum(row["status"] == "pass" for row in not_all_exact_rows),
        "not_all_exact_build_fail": sum(row["status"] != "pass" for row in not_all_exact_rows),
        "target_failure_records": sum(row["target_failure_evidence"] for row in results),
        "other_failure_records": sum(
            row["status"] not in {"pass", "mutation_error"}
            and not row["target_failure_evidence"]
            for row in results
        ),
        "mutation_error_records": sum(row["status"] == "mutation_error" for row in results),
        "status_counts": dict(Counter(row["status"] for row in results)),
        "failure_detail_counts": dict(
            Counter(row["failure_detail"] for row in results if row["status"] != "pass")
        ),
        "duration_seconds": round(sum(float(row["duration_seconds"]) for row in results), 3),
    }


def write_outputs(
    output_dir: Path,
    run_name: str,
    records: list[dict],
    results: list[dict],
    metadata: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(records, results)
    payload = {
        "run_name": run_name,
        "phase": "gold_code_plus_qwen_parseable_import_evidence",
        "summary": summary,
        "metadata": metadata,
        "results": results,
    }
    (output_dir / "masked_evidence_build.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    fields = [
        "record_id",
        "source_set",
        "project_path",
        "file_path",
        "build_key",
        "selected_java_home",
        "masked_import_count",
        "masked_imports",
        "generated_import_count",
        "generated_imports",
        "inserted_import_count",
        "inserted_imports",
        "exact_recovered_count",
        "exact_recovered_imports",
        "any_target_exact",
        "all_targets_exact",
        "status",
        "failure_detail",
        "target_failure_evidence",
        "target_evidence_imports",
        "target_resolution",
        "return_code",
        "timed_out",
        "duration_seconds",
        "command",
        "log_path",
    ]
    with (output_dir / "masked_evidence_build.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    lines = [
        "# Gold-Code Build with Qwen Parseable Import Evidence",
        "",
        f"- Eligible records: `{summary['eligible_records']}`.",
        f"- Eligible projects: `{summary['eligible_projects']}`.",
        f"- Eligible hidden imports: `{summary['eligible_hidden_imports']}`.",
        f"- Completed builds: `{summary['completed_records']}`.",
        f"- Exact recovered hidden imports: `{summary['exact_recovered_hidden_imports']}`.",
        f"- Records with any exact recovery: `{summary['records_any_exact']}`.",
        f"- Records with all hidden imports exactly recovered: `{summary['records_all_exact']}`.",
        f"- Evidence build passes: `{summary['evidence_build_pass_records']}`.",
        f"- Projects with an evidence build pass: `{summary['evidence_build_pass_projects']}`.",
        "",
        "## Exact-Recovery x Build Outcome",
        "",
        "| Exact evidence | Build pass | Build fail |",
        "|---|---:|---:|",
        f"| All hidden imports exact | {summary['all_exact_build_pass']} | {summary['all_exact_build_fail']} |",
        f"| Not all hidden imports exact | {summary['not_all_exact_build_pass']} | {summary['not_all_exact_build_fail']} |",
        "",
        "## Status Counts",
        "",
        "| Status | Records |",
        "|---|---:|",
    ]
    for status, count in sorted(summary["status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(
        [
            "",
            "## Per-Record Results",
            "",
            "| Record | Hidden | Exact | Generated | JDK | Status | Target failure |",
            "|---|---:|---:|---:|---|---|---|",
        ]
    )
    for row in results:
        lines.append(
            f"| `{row['record_id']}` | {row['masked_import_count']} | "
            f"{row['exact_recovered_count']} | {row['generated_import_count']} | "
            f"`{row['selected_java_home']}` | `{row['status']}` | "
            f"`{str(row['target_failure_evidence']).lower()}` |"
        )
    (output_dir / "masked_evidence_build.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve())
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    necessity_payload = json.loads(args.necessity.resolve().read_text(encoding="utf-8"))
    model_imports = load_model_imports(
        args.responses.resolve(), args.candidates.resolve()
    )
    all_records, jdk_homes = prepare_records(
        prompts, audit_by_key, baseline_payload, necessity_payload, model_imports
    )
    records = all_records[: args.limit] if args.limit else all_records

    run_name = args.run_name or datetime.now().strftime(
        "Java_APIHulBench_MaskedSemanticBuild_Evidence_Run%Y%m%d_%H%M%S"
    )
    output_dir = args.output_root.resolve() / run_name
    output_json = output_dir / "masked_evidence_build.json"
    short_work_name = "run_" + hashlib.sha256(run_name.encode("utf-8")).hexdigest()[:10]
    work_root = args.work_root.resolve() / short_work_name
    if args.resume:
        if not output_json.exists():
            raise SystemExit(f"Cannot resume; output is missing: {output_json}")
        previous = json.loads(output_json.read_text(encoding="utf-8"))
        results = previous.get("results", [])
        if args.retry_status:
            retry_statuses = set(args.retry_status)
            results = [row for row in results if row["status"] not in retry_statuses]
    else:
        if output_dir.exists() or work_root.exists():
            raise SystemExit(f"Run path already exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True)
    work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = work_root / "tmp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(temp_dir)
    os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (
        os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}"
    ).strip()

    metadata = {
        "prompts_sha256": baseline.sha256(args.prompts.resolve()),
        "responses_sha256": baseline.sha256(args.responses.resolve()),
        "candidates_sha256": baseline.sha256(args.candidates.resolve()),
        "baseline_sha256": baseline.sha256(args.baseline.resolve()),
        "necessity_sha256": baseline.sha256(args.necessity.resolve()),
        "script_sha256": baseline.sha256(Path(__file__).resolve()),
        "timeout_seconds": args.timeout,
        "work_root": str(work_root),
        "temporary_files_on_d_drive": True,
        "workdirs_retained": args.keep_workdirs,
        "all_eligible_records": len(all_records),
        "selected_records": len(records),
        "jdk_homes": jdk_homes,
    }
    write_outputs(output_dir, run_name, records, results, metadata)
    completed = {row["record_id"] for row in results}

    for index, record in enumerate(records, start=1):
        if record["record_id"] in completed:
            print(f"[{index}/{len(records)}] SKIP COMPLETED {record['record_id']}", flush=True)
            continue
        original_project = validation.normalize_workspace_path(record["project_path"])
        original_target = validation.normalize_workspace_path(record["file_path"])
        copied_project = work_root / f"r{index:03d}"
        copy_log = logs_dir / f"record_{index:03d}_copy.log"
        print(f"[{index}/{len(records)}] COPY {record['record_id']}", flush=True)
        copied, copy_error = validation.copy_project_tree(
            original_project, copied_project, copy_log
        )
        plan = {}
        command: list[str] = []
        inserted: list[str] = []
        evidence_imports: list[str] = []
        target_failure = False
        target_resolution = ""
        if not copied:
            outcome = {
                "return_code": "",
                "timed_out": False,
                "duration_seconds": 0.0,
                "status": "project_copy_failed",
                "failure_detail": "project_copy_failed",
                "log_path": validation.display_path(copy_log),
                "tail": copy_error,
            }
        else:
            copied_target, target_resolution = necessity.locate_target_file(
                copied_project, original_project, original_target
            )
            try:
                source = copied_target.read_text(encoding="utf-8", errors="strict")
                masked, removed = necessity.remove_imports(
                    source, record["masked_imports"]
                )
                if len(removed) != len(record["masked_imports"]):
                    missing = sorted(set(record["masked_imports"]) - set(removed))
                    raise ValueError(f"imports not removed exactly: {missing}")
                mutated, inserted = insert_imports(
                    masked, record["generated_imports"]
                )
                copied_target.write_text(mutated, encoding="utf-8", newline="")
                plan = validation.build_plan(record["audit"], copied_project)
                command = baseline.clean_build_command(plan["command"])
                java_value = jdk_homes[record["selected_java_home"]]
                java_home = Path(java_value) if java_value else None
                log_path = logs_dir / f"record_{index:03d}_strict_evidence.log"
                print(f"[{index}/{len(records)}] BUILD {record['selected_java_home']}", flush=True)
                outcome = validation.run_build(
                    command, plan["cwd"], args.timeout, log_path, java_home
                )
                if "maven" in record["build_system"] and validation.should_retry_local_maven(outcome):
                    retry_plan = validation.build_plan(
                        record["audit"], copied_project, force_local=True
                    )
                    retry_command = baseline.clean_build_command(retry_plan["command"])
                    if retry_command != command or retry_plan["cwd"] != plan["cwd"]:
                        retry_log = logs_dir / f"record_{index:03d}_strict_evidence_local_retry.log"
                        print(
                            f"[{index}/{len(records)}] RETRY LOCAL {record['selected_java_home']}",
                            flush=True,
                        )
                        outcome = validation.run_build(
                            retry_command,
                            retry_plan["cwd"],
                            args.timeout,
                            retry_log,
                            java_home,
                        )
                        plan = retry_plan
                        command = retry_command
                        log_path = retry_log
                full_output = Path(log_path).read_text(encoding="utf-8", errors="replace")
                evidence_imports = necessity.target_evidence(
                    full_output, record["masked_imports"]
                )
                target_failure = (
                    outcome["status"] == "source_compile_failure" and bool(evidence_imports)
                )
            except Exception as error:
                outcome = {
                    "return_code": "",
                    "timed_out": False,
                    "duration_seconds": 0.0,
                    "status": "mutation_error",
                    "failure_detail": str(error),
                    "log_path": "",
                    "tail": "",
                }

        results.append(
            {
                "record_id": record["record_id"],
                "source_set": record["source_set"],
                "project_path": record["project_path"],
                "file_path": record["file_path"],
                "build_key": record["build_key"],
                "selected_java_home": record["selected_java_home"],
                "masked_import_count": len(record["masked_imports"]),
                "masked_imports": ";".join(record["masked_imports"]),
                "generated_import_count": len(record["generated_imports"]),
                "generated_imports": ";".join(record["generated_imports"]),
                "inserted_import_count": len(inserted),
                "inserted_imports": ";".join(inserted),
                "exact_recovered_count": len(record["exact_recovered_imports"]),
                "exact_recovered_imports": ";".join(record["exact_recovered_imports"]),
                "any_target_exact": record["any_target_exact"],
                "all_targets_exact": record["all_targets_exact"],
                "target_failure_evidence": target_failure,
                "target_evidence_imports": ";".join(evidence_imports),
                "target_resolution": target_resolution,
                "command": " ".join(command),
                **outcome,
            }
        )
        write_outputs(output_dir, run_name, records, results, metadata)
        if not args.keep_workdirs and copied_project.exists():
            baseline.safe_remove_tree(copied_project, work_root)

    if not args.keep_workdirs and temp_dir.exists():
        baseline.safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
