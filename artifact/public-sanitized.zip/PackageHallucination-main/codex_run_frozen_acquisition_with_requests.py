#!/usr/bin/env python3
"""Run the frozen V3 acquisition logic with a retrying HTTP transport adapter."""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import codex_acquire_external_java_v3 as frozen


retry = Retry(total=4, connect=4, read=4, backoff_factor=1, status_forcelist=(429, 500, 502, 503, 504), allowed_methods=("GET",))
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=retry))


def headers(accept: str = "application/octet-stream") -> dict[str, str]:
    result = {"Accept": accept, "User-Agent": "dependency-audit-research-v3-transport-adapter"}
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if token:
        result["Authorization"] = f"Bearer {token}"
    return result


def request_bytes(url: str, timeout: float) -> bytes:
    parsed = urllib.parse.urlparse(url)
    request_url = url
    accept = "application/octet-stream"
    if parsed.netloc == "raw.githubusercontent.com":
        owner, repo, branch, *parts = parsed.path.lstrip("/").split("/")
        content_path = "/".join(parts)
        request_url = (
            f"https://api.github.com/repos/{owner}/{repo}/contents/"
            f"{urllib.parse.quote(content_path, safe='/')}?ref={urllib.parse.quote(branch, safe='')}"
        )
        accept = "application/vnd.github.raw+json"
    try:
        response = session.get(request_url, headers=headers(accept), timeout=timeout)
        response.raise_for_status()
        return response.content
    except requests.RequestException as exc:
        raise urllib.error.URLError(str(exc)) from exc


def request_json(url: str, timeout: float) -> dict:
    commit_match = re.fullmatch(r"https://api\.github\.com/repos/([^/]+/[^/]+)/commits/(.+)", url)
    if commit_match:
        full_name, encoded_branch = commit_match.groups()
        branch = urllib.parse.unquote(encoded_branch)
        atom_url = f"https://github.com/{full_name}/commits/{urllib.parse.quote(branch, safe='')}.atom"
        try:
            response = session.get(atom_url, headers=headers("application/atom+xml"), timeout=timeout)
            response.raise_for_status()
            match = re.search(r"(?:Commit/|/commit/)([0-9a-f]{40})", response.text, re.IGNORECASE)
            if not match:
                raise ValueError(f"No commit SHA in {atom_url}")
            return {"sha": match.group(1).lower()}
        except (requests.RequestException, ValueError) as exc:
            raise urllib.error.URLError(str(exc)) from exc
    try:
        response = session.get(url, headers=headers("application/vnd.github+json"), timeout=timeout)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        raise urllib.error.URLError(str(exc)) from exc


def download_file(url: str, path: Path, timeout: float, attempts: int = 4) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".part")
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            partial.unlink(missing_ok=True)
            response = session.get(url, headers=headers(), timeout=timeout, stream=True)
            response.raise_for_status()
            with response, partial.open("wb") as handle:
                for chunk in response.iter_content(1024 * 1024):
                    if chunk:
                        handle.write(chunk)
            partial.replace(path)
            return
        except (requests.RequestException, OSError) as exc:
            last_error = exc
            partial.unlink(missing_ok=True)
            if attempt < attempts:
                time.sleep(2 ** (attempt - 1))
    raise urllib.error.URLError(f"download failed after {attempts} attempts: {last_error}")


def root_pom_exists(full_name: str, branch: str, timeout: float) -> bool:
    url = f"https://github.com/{full_name}/raw/refs/heads/{urllib.parse.quote(branch, safe='')}/pom.xml"
    try:
        response = session.get(url, headers=headers(), timeout=timeout, allow_redirects=False)
        return response.status_code in {200, 301, 302, 307, 308}
    except requests.RequestException:
        return False


frozen.request_bytes = request_bytes
frozen.request_json = request_json
frozen.download_file = download_file
frozen.root_pom_exists = root_pom_exists


if __name__ == "__main__":
    frozen.main()
