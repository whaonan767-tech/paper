#!/usr/bin/env python3
"""Analyze paired masked-import build outcomes with project-clustered intervals."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TESTS = ROOT / "Tests"
DEFAULT_NECESSITY = (
    TESTS
    / "Java_APIHulBench_MaskedSemanticBuild_NecessityFull83_TestCompile_Run20260803"
    / "masked_necessity_probe.json"
)
DEFAULT_EVIDENCE = (
    TESTS
    / "Java_APIHulBench_MaskedSemanticBuild_EvidenceFull83_Run20260803"
    / "masked_evidence_build.json"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--necessity", type=Path, default=DEFAULT_NECESSITY)
    parser.add_argument("--evidence", type=Path, default=DEFAULT_EVIDENCE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_EVIDENCE.parent)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20_260_803)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def clustered_bootstrap(
    rows: list[dict],
    numerator,
    denominator,
    repetitions: int,
    seed: int,
) -> dict:
    clusters: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        clusters[row["project_path"]].append(row)
    project_ids = sorted(clusters)
    rng = random.Random(seed)
    estimates = []
    for _ in range(repetitions):
        sampled = [rng.choice(project_ids) for _ in project_ids]
        sampled_rows = [row for project in sampled for row in clusters[project]]
        total = sum(denominator(row) for row in sampled_rows)
        if total:
            estimates.append(sum(numerator(row) for row in sampled_rows) / total)
    observed_total = sum(denominator(row) for row in rows)
    observed = sum(numerator(row) for row in rows) / observed_total
    return {
        "estimate": observed,
        "ci_low": percentile(estimates, 0.025),
        "ci_high": percentile(estimates, 0.975),
        "method": "project-clustered percentile bootstrap",
        "repetitions": repetitions,
        "seed": seed,
        "resampling_unit": "project_path",
        "clusters": len(project_ids),
    }


def exact_mcnemar_p(b: int, c: int) -> float:
    discordant = b + c
    if discordant == 0:
        return 1.0
    lower_tail = sum(math.comb(discordant, k) for k in range(min(b, c) + 1))
    return min(1.0, 2.0 * lower_tail / (2**discordant))


def exact_project_sign_flip(rows: list[dict]) -> dict:
    project_differences: dict[str, int] = defaultdict(int)
    for row in rows:
        project_differences[row["project_path"]] += int(row["paired_difference"])
    nonzero = [value for value in project_differences.values() if value]
    if len(nonzero) > 20:
        raise ValueError("Exact sign-flip enumeration is limited to 20 nonzero clusters")
    observed = abs(sum(nonzero))
    assignments = 1 << len(nonzero)
    extreme = 0
    for mask in range(assignments):
        statistic = sum(
            value if mask & (1 << index) else -value
            for index, value in enumerate(nonzero)
        )
        if abs(statistic) >= observed:
            extreme += 1
    return {
        "projects": len(project_differences),
        "nonzero_project_differences": len(nonzero),
        "observed_record_sum": sum(nonzero),
        "exact_two_sided_p": extreme / assignments if assignments else 1.0,
        "assignments": assignments,
        "method": "exact project-cluster sign-flip permutation",
    }


def cohen_kappa(left: list[bool], right: list[bool]) -> float:
    observed = sum(a == b for a, b in zip(left, right)) / len(left)
    left_yes = sum(left) / len(left)
    right_yes = sum(right) / len(right)
    expected = left_yes * right_yes + (1 - left_yes) * (1 - right_yes)
    return (observed - expected) / (1 - expected) if expected != 1 else 1.0


def percent(value: float) -> str:
    return f"{100 * value:.1f}%"


def interval(result: dict) -> str:
    return (
        f"{percent(result['estimate'])} "
        f"[{percent(result['ci_low'])}, {percent(result['ci_high'])}]"
    )


def main() -> None:
    args = parse_args()
    necessity_path = args.necessity.resolve()
    evidence_path = args.evidence.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    necessity = json.loads(necessity_path.read_text(encoding="utf-8"))
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    necessity_by_id = {row["record_id"]: row for row in necessity["results"]}
    evidence_by_id = {row["record_id"]: row for row in evidence["results"]}
    if set(necessity_by_id) != set(evidence_by_id):
        only_v1 = sorted(set(necessity_by_id) - set(evidence_by_id))
        only_v2 = sorted(set(evidence_by_id) - set(necessity_by_id))
        raise SystemExit(f"Record mismatch: only V1={only_v1}; only V2={only_v2}")

    rows = []
    for record_id in sorted(evidence_by_id):
        v1 = necessity_by_id[record_id]
        v2 = evidence_by_id[record_id]
        v1_pass = v1["status"] == "pass"
        v2_pass = v2["status"] == "pass"
        exact = bool(v2["all_targets_exact"])
        if exact and v2_pass:
            case = "exact_and_build_valid"
        elif exact:
            case = "exact_but_build_invalid"
        elif v2_pass:
            case = "nonexact_but_build_valid"
        else:
            case = "nonexact_and_build_invalid"
        rows.append(
            {
                **v2,
                "v1_pass": v1_pass,
                "v2_pass": v2_pass,
                "case": case,
                "paired_difference": int(v2_pass) - int(v1_pass),
            }
        )

    repetitions = args.bootstrap_repetitions
    seed = args.seed
    build_valid_rate = clustered_bootstrap(
        rows, lambda row: int(row["v2_pass"]), lambda row: 1, repetitions, seed
    )
    paired_risk_difference = clustered_bootstrap(
        rows,
        lambda row: row["paired_difference"],
        lambda row: 1,
        repetitions,
        seed + 1,
    )
    all_exact_rate = clustered_bootstrap(
        rows,
        lambda row: int(row["all_targets_exact"]),
        lambda row: 1,
        repetitions,
        seed + 2,
    )
    import_exact_rate = clustered_bootstrap(
        rows,
        lambda row: int(row["exact_recovered_count"]),
        lambda row: int(row["masked_import_count"]),
        repetitions,
        seed + 3,
    )

    v1_passes = sum(row["v1_pass"] for row in rows)
    v2_passes = sum(row["v2_pass"] for row in rows)
    v1_only = sum(row["v1_pass"] and not row["v2_pass"] for row in rows)
    v2_only = sum(row["v2_pass"] and not row["v1_pass"] for row in rows)
    exact_only = sum(row["all_targets_exact"] and not row["v2_pass"] for row in rows)
    build_only = sum(row["v2_pass"] and not row["all_targets_exact"] for row in rows)
    case_counts = Counter(row["case"] for row in rows)
    build_units = {row["build_key"] for row in rows}
    passing_build_units = {row["build_key"] for row in rows if row["v2_pass"]}
    projects = {row["project_path"] for row in rows}
    passing_projects = {row["project_path"] for row in rows if row["v2_pass"]}
    source_counts = Counter(row["source_set"] for row in rows)
    source_pass_counts = Counter(row["source_set"] for row in rows if row["v2_pass"])
    project_sign_flip = exact_project_sign_flip(rows)

    summary = {
        "records": len(rows),
        "projects": len(projects),
        "build_units": len(build_units),
        "hidden_imports": sum(int(row["masked_import_count"]) for row in rows),
        "v1_masked_gold_passes": v1_passes,
        "v2_generated_evidence_passes": v2_passes,
        "v2_passing_projects": len(passing_projects),
        "v2_passing_build_units": len(passing_build_units),
        "source_counts": dict(source_counts),
        "source_pass_counts": dict(source_pass_counts),
        "case_counts": dict(case_counts),
        "build_valid_rate": build_valid_rate,
        "all_targets_exact_rate": all_exact_rate,
        "import_exact_recovery_rate": import_exact_rate,
        "v1_to_v2_paired_risk_difference": paired_risk_difference,
        "v1_to_v2_descriptive_discordance": {
            "v1_only": v1_only,
            "v2_only": v2_only,
        },
        "v1_to_v2_project_sign_flip": project_sign_flip,
        "exact_label_vs_build": {
            "exact_only": exact_only,
            "build_only": build_only,
            "agreement": sum(bool(row["all_targets_exact"]) == row["v2_pass"] for row in rows)
            / len(rows),
            "cohen_kappa": cohen_kappa(
                [bool(row["all_targets_exact"]) for row in rows],
                [row["v2_pass"] for row in rows],
            ),
        },
    }
    payload = {
        "analysis": "masked_import_build_valid_recovery",
        "inputs": {
            "necessity": str(necessity_path),
            "necessity_sha256": sha256(necessity_path),
            "evidence": str(evidence_path),
            "evidence_sha256": sha256(evidence_path),
        },
        "bootstrap": {
            "repetitions": repetitions,
            "seed": seed,
            "resampling_unit": "project_path",
            "interval": "two-sided 95% percentile",
        },
        "summary": summary,
    }
    (output_dir / "masked_build_analysis.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    fields = [
        "record_id",
        "project_path",
        "build_key",
        "source_set",
        "masked_import_count",
        "masked_imports",
        "generated_import_count",
        "generated_imports",
        "exact_recovered_count",
        "exact_recovered_imports",
        "all_targets_exact",
        "v1_pass",
        "v2_pass",
        "case",
        "status",
        "failure_detail",
        "target_failure_evidence",
        "log_path",
    ]
    with (output_dir / "masked_build_cases.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        "# Masked-Import Test-Compile-Valid Recovery Analysis",
        "",
        "## Cohort",
        "",
        f"- Records: `{len(rows)}` from `{len(projects)}` projects and `{len(build_units)}` build units.",
        f"- Hidden imports: `{summary['hidden_imports']}`.",
        f"- Source sets: main `{source_counts.get('main', 0)}`, test `{source_counts.get('test', 0)}`.",
        "- V0 eligibility: every included original build passed under the selected JDK.",
        f"- V1 necessity: `{v1_passes}/{len(rows)}` passed after removing hidden imports.",
        "",
        "## Main Results",
        "",
        f"- V2 test-compile-valid recovery: `{v2_passes}/{len(rows)}`; project-clustered 95% CI {interval(build_valid_rate)}.",
        f"- Passing coverage: `{len(passing_projects)}/{len(projects)}` projects and `{len(passing_build_units)}/{len(build_units)}` build units.",
        f"- Record-level exact-all recovery: `{sum(row['all_targets_exact'] for row in rows)}/{len(rows)}`; project-clustered 95% CI {interval(all_exact_rate)}.",
        f"- Import-level exact recovery (descriptive numerator/denominator): `{sum(int(row['exact_recovered_count']) for row in rows)}/{summary['hidden_imports']}`; project-clustered 95% CI {interval(import_exact_rate)}.",
        f"- Paired V1-to-V2 risk difference: {interval(paired_risk_difference)}; exact project-cluster sign-flip p=`{project_sign_flip['exact_two_sided_p']:.6g}` across `{project_sign_flip['nonzero_project_differences']}` nonzero projects ({v2_only} V2-only passes, {v1_only} V1-only passes).",
        "",
        "## Exact-Match versus Build Outcome",
        "",
        "| Classification | Records |",
        "|---|---:|",
        f"| Exact and test-compile-valid | {case_counts['exact_and_build_valid']} |",
        f"| Exact but test-compile-invalid | {case_counts['exact_but_build_invalid']} |",
        f"| Non-exact but test-compile-valid | {case_counts['nonexact_but_build_valid']} |",
        f"| Non-exact and test-compile-invalid | {case_counts['nonexact_and_build_invalid']} |",
        "",
        f"Exact-all and test-compile-valid labels agree descriptively on `{summary['exact_label_vs_build']['agreement'] * 100:.1f}%` of records (Cohen's kappa `{summary['exact_label_vs_build']['cohen_kappa']:.3f}`), but disagree in both directions (`{exact_only}` exact-only; `{build_only}` compilation-only). No record-level independence test is used.",
        "",
        "## Discordant Cases",
        "",
        "| Record | Case | Gold hidden import(s) | Generated import(s) | Failure |",
        "|---|---|---|---|---|",
    ]
    for row in rows:
        if row["case"] not in {"exact_but_build_invalid", "nonexact_but_build_valid"}:
            continue
        lines.append(
            f"| `{row['record_id']}` | `{row['case']}` | "
            f"`{row['masked_imports']}` | `{row['generated_imports']}` | "
            f"`{row['failure_detail'] if not row['v2_pass'] else 'none'}` |"
        )
    lines.extend(
        [
            "",
            "## Reproducibility",
            "",
            f"- Bootstrap repetitions: `{repetitions}`.",
            f"- Random seed: `{seed}` (derived analyses use sequential seed offsets).",
            "- Resampling unit: project path; two-sided 95% percentile intervals.",
            f"- Paired test: exact project-cluster sign-flip over `{project_sign_flip['assignments']}` assignments.",
            f"- Necessity input SHA-256: `{payload['inputs']['necessity_sha256']}`.",
            f"- Evidence input SHA-256: `{payload['inputs']['evidence_sha256']}`.",
        ]
    )
    (output_dir / "masked_build_analysis.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(f"WROTE {output_dir / 'masked_build_analysis.json'}")
    print(f"WROTE {output_dir / 'masked_build_analysis.md'}")
    print(f"WROTE {output_dir / 'masked_build_cases.csv'}")


if __name__ == "__main__":
    main()
