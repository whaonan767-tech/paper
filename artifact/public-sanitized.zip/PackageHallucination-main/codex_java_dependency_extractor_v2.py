#!/usr/bin/env python3
"""Occurrence-preserving Java dependency mention extractor (frozen V2 candidate)."""

from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


IMPORT_RE = re.compile(
    r"(?im)(?<![\w.])import[ \t]+(?P<static>static[ \t]+)?"
    r"(?P<value>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$*][\w$*]*)+)"
    r"[ \t]*(?P<semicolon>;)?"
)
DEPENDENCY_BLOCK_RE = re.compile(
    r"(?is)<dependency\b[^>]*>(?P<body>.*?)(?:</dependency\s*>|(?=```|\Z))"
)
TAG_RE_TEMPLATE = r"(?is)<{tag}\b[^>]*>\s*([^<\r\n]+?)(?:\s*</{tag}\s*>|\r?$|\n)"
GRADLE_STRING_RE = re.compile(
    r"(?im)\b(?:api|implementation|compileOnly|runtimeOnly|annotationProcessor|testImplementation)\s*"
    r"(?:\(\s*)?[\"'](?P<group>[A-Za-z][\w.-]*):(?P<artifact>[A-Za-z0-9][\w.-]*)"
    r"(?::(?P<version>[^\"'\s)]+))?[\"']\s*\)?"
)
GRADLE_MAP_RE = re.compile(
    r"(?im)\b(?:api|implementation|compileOnly|runtimeOnly|annotationProcessor|testImplementation)\s*"
    r"(?:\(\s*)?(?:group\s*[:=]\s*[\"'](?P<group>[^\"']+)[\"']\s*,\s*)"
    r"(?:name\s*[:=]\s*[\"'](?P<artifact>[^\"']+)[\"'])"
    r"(?:\s*,\s*version\s*[:=]\s*[\"'](?P<version>[^\"']+)[\"'])?"
)
COORDINATE_RE = re.compile(
    r"(?<![\w.-])(?P<group>[A-Za-z][A-Za-z0-9_.-]*\.[A-Za-z0-9_.-]+):"
    r"(?P<artifact>[A-Za-z0-9][A-Za-z0-9_.-]*)"
    r"(?::(?P<version>[A-Za-z0-9][A-Za-z0-9_.+/${}-]*))?(?![\w.-])"
)
PROSE_FQN_RE = re.compile(
    r"(?<![\w.])(?P<value>[a-z][A-Za-z0-9_$]*(?:\.[A-Za-z_$][\w$]*){2,})(?![\w.])"
)
PROSE_TOKEN_RE = re.compile(
    r"(?i)\b(?:dependency|library|artifact|package)\b"
    r"(?:\s+(?:is|named|called|on|for|to|of|:|-)){0,3}\s*[`\"']?"
    r"(?P<value>[A-Za-z][A-Za-z0-9_.-]*(?:[:./-][A-Za-z0-9_.-]+)+)[`\"']?"
)
CUE_RE = re.compile(
    r"(?i)\b(?:add|use|using|require|requires|required|dependency|library|artifact|package|"
    r"maven|gradle|import|coordinate)\b"
)
STOPWORDS = {
    "java.lang", "src.main.java", "pom.xml", "build.gradle", "gradle.kts",
    "missing.import", "fully.qualified", "code.fence",
}


@dataclass
class Candidate:
    record_id: str
    candidate_id: str
    occurrence_index: int
    source_line: int
    dataset: str
    task: str
    project_path: str
    file_path: str
    kind: str
    surface: str
    parse_rule: str
    start_offset: int
    end_offset: int
    raw_mention: str
    normalized_mention: str
    coordinate: str = ""
    group_id: str = ""
    artifact_id: str = ""
    version: str = ""
    import_path: str = ""
    import_root: str = ""
    malformed_hint: bool = False


@dataclass
class Hit:
    start: int
    end: int
    kind: str
    value: str
    rule: str
    group_id: str = ""
    artifact_id: str = ""
    version: str = ""
    malformed_hint: bool = False


def clean(value: object) -> str:
    return re.sub(r"\s+", " ", "" if value is None else str(value)).strip()


def normalize_import(value: str) -> str:
    return value.strip().strip("`'\";,.)]")


def normalize_coordinate(group: str, artifact: str, version: str = "") -> str:
    normalized = (
        clean(group).rstrip(".,;)]}"),
        clean(artifact).rstrip(".,;)]}"),
        clean(version).rstrip(".,;)]}"),
    )
    return ":".join(part for part in normalized if part)


def import_root(value: str) -> str:
    parts = value.split(".")
    if len(parts) >= 3 and parts[0] in {"com", "org", "net", "io", "dev", "ai"}:
        return ".".join(parts[:3])
    return ".".join(parts[:2]) if len(parts) >= 2 else value


def fence_regions(text: str) -> tuple[list[tuple[int, int]], bool]:
    markers = list(re.finditer(r"(?m)^\s*```[^\r\n]*", text))
    regions: list[tuple[int, int]] = []
    for index in range(0, len(markers) - 1, 2):
        regions.append((markers[index].end(), markers[index + 1].start()))
    broken = len(markers) % 2 == 1
    if broken:
        regions.append((markers[-1].end(), len(text)))
    return regions, broken


def in_region(start: int, regions: list[tuple[int, int]]) -> bool:
    return any(left <= start < right for left, right in regions)


def overlaps(start: int, end: int, hits: list[Hit]) -> bool:
    return any(start < hit.end and end > hit.start for hit in hits)


def tag_value(body: str, tag: str) -> str:
    match = re.search(TAG_RE_TEMPLATE.format(tag=re.escape(tag)), body)
    return clean(match.group(1)) if match else ""


def extract_hits(text: str) -> list[Hit]:
    hits: list[Hit] = []

    for match in DEPENDENCY_BLOCK_RE.finditer(text):
        body = match.group("body")
        group = tag_value(body, "groupId")
        artifact = tag_value(body, "artifactId")
        version = tag_value(body, "version")
        if group or artifact:
            malformed = not (group and artifact) or "</dependency" not in match.group(0).lower()
            hits.append(Hit(match.start(), match.end(), "maven_xml", normalize_coordinate(group, artifact, version), "maven_xml_block", group, artifact, version, malformed))

    for pattern, kind, rule in (
        (GRADLE_STRING_RE, "gradle_string", "gradle_string_notation"),
        (GRADLE_MAP_RE, "gradle_map", "gradle_map_notation"),
    ):
        for match in pattern.finditer(text):
            group = clean(match.group("group"))
            artifact = clean(match.group("artifact"))
            version = clean(match.groupdict().get("version"))
            hits.append(Hit(match.start(), match.end(), kind, normalize_coordinate(group, artifact, version), rule, group, artifact, version, not bool(version)))

    for match in IMPORT_RE.finditer(text):
        value = normalize_import(match.group("value"))
        hits.append(Hit(match.start(), match.end(), "java_import", value, "java_import_tolerant", malformed_hint=not bool(match.group("semicolon"))))

    for match in COORDINATE_RE.finditer(text):
        if overlaps(match.start(), match.end(), hits):
            continue
        context = text[max(0, match.start() - 100): min(len(text), match.end() + 40)]
        if not CUE_RE.search(context) and not re.search(r"[`\"']", context):
            continue
        group = clean(match.group("group"))
        artifact = clean(match.group("artifact"))
        version = clean(match.group("version"))
        hits.append(Hit(match.start(), match.end(), "raw_maven_coordinate", normalize_coordinate(group, artifact, version), "coordinate_in_dependency_context", group, artifact, version, not bool(version)))

    for match in PROSE_TOKEN_RE.finditer(text):
        start, end = match.span("value")
        value = normalize_import(match.group("value"))
        if value.lower() in STOPWORDS or overlaps(start, end, hits):
            continue
        hits.append(Hit(start, end, "prose_dependency", value, "prose_dependency_cue"))

    for match in PROSE_FQN_RE.finditer(text):
        start, end = match.span("value")
        value = normalize_import(match.group("value"))
        if value.lower() in STOPWORDS or overlaps(start, end, hits):
            continue
        context = text[max(0, start - 90):start]
        if not CUE_RE.search(context):
            continue
        hits.append(Hit(start, end, "prose_fqn", value, "prose_fqn_with_cue"))

    hits.sort(key=lambda hit: (hit.start, hit.end, hit.rule))
    return hits


def surface_for(hit: Hit, regions: list[tuple[int, int]], broken_fence: bool) -> str:
    if hit.malformed_hint:
        return "malformed"
    if in_region(hit.start, regions):
        return "broken_fence" if broken_fence and regions and hit.start >= regions[-1][0] else "code"
    if hit.kind.startswith("prose"):
        return "prose"
    return "code"


def extract_candidates(text: str, metadata: dict[str, object] | None = None) -> list[dict[str, object]]:
    metadata = metadata or {}
    record_id = clean(metadata.get("record_id")) or "record"
    regions, broken = fence_regions(text or "")
    rows: list[Candidate] = []
    for index, hit in enumerate(extract_hits(text or ""), 1):
        coordinate = hit.value if hit.kind in {"maven_xml", "gradle_string", "gradle_map", "raw_maven_coordinate"} else ""
        import_path = hit.value if hit.kind in {"java_import", "prose_fqn"} else ""
        rows.append(Candidate(
            record_id=record_id,
            candidate_id=f"{record_id}:m{index:03d}",
            occurrence_index=index,
            source_line=int(metadata.get("source_line") or 0),
            dataset=clean(metadata.get("dataset")),
            task=clean(metadata.get("task")),
            project_path=clean(metadata.get("project_path")),
            file_path=clean(metadata.get("file_path")),
            kind=hit.kind,
            surface=surface_for(hit, regions, broken),
            parse_rule=hit.rule,
            start_offset=hit.start,
            end_offset=hit.end,
            raw_mention=(text or "")[hit.start:hit.end],
            normalized_mention=hit.value,
            coordinate=coordinate,
            group_id=hit.group_id,
            artifact_id=hit.artifact_id,
            version=hit.version,
            import_path=import_path,
            import_root=import_root(import_path) if import_path else "",
            malformed_hint=hit.malformed_hint,
        ))
    return [asdict(row) for row in rows]


def read_jsonl(path: Path, field: str) -> Iterable[tuple[dict[str, object], str]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            row.setdefault("source_line", line_no)
            yield row, clean(row.get(field))


def write_outputs(rows: list[dict[str, object]], output_json: Path, output_csv: Path) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = list(Candidate.__dataclass_fields__)
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-jsonl", type=Path)
    parser.add_argument("--field", default="response")
    parser.add_argument("--text-file", type=Path)
    parser.add_argument("--record-id", default="text_file")
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    args = parser.parse_args()
    if bool(args.input_jsonl) == bool(args.text_file):
        raise SystemExit("Choose exactly one of --input-jsonl or --text-file")
    rows: list[dict[str, object]] = []
    if args.input_jsonl:
        for metadata, text in read_jsonl(args.input_jsonl, args.field):
            rows.extend(extract_candidates(text, metadata))
    else:
        rows.extend(extract_candidates(args.text_file.read_text(encoding="utf-8"), {"record_id": args.record_id}))
    write_outputs(rows, args.output_json, args.output_csv)
    unique = {(row["record_id"], row["normalized_mention"]) for row in rows}
    print(json.dumps({"occurrences": len(rows), "answer_deduplicated_mentions": len(unique)}, indent=2))


if __name__ == "__main__":
    main()
