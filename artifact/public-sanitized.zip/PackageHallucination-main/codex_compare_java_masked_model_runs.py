import argparse
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def fmt_rate(num, den):
    if not den:
        return "--"
    pct = (Decimal(num) * Decimal(100) / Decimal(den)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{num}/{den} ({pct}%)"


def row(label, summary_path, raw_path, coordinate_note):
    summary = read_json(summary_path)
    raw = read_json(raw_path)
    kinds = summary.get("candidate_kind_counts", {})
    maven_counts = summary.get("maven_validation_status_counts", {})
    return {
        "model": label,
        "records": summary["records"],
        "candidate_rows": summary["candidate_rows"],
        "java_import_rows": kinds.get("java_import", 0),
        "coordinate_rows": kinds.get("raw_maven_coordinate", 0) + kinds.get("gradle_string", 0),
        "masked_imports": summary["masked_imports"],
        "strict_exact_recovered": summary["exact_target_import_recovered"],
        "raw_exact_mentions": raw["raw_exact_mentions"],
        "invalid_coordinate_rows": summary["invalid_coordinate_rows"],
        "suspicious_import_rows": summary["suspicious_import_rows"],
        "evidence_records": summary["records_with_detector_evidence"],
        "maven_status_counts": maven_counts,
        "coordinate_note": coordinate_note,
    }


def write_md(path, rows):
    lines = [
        "# Java Dependency-Critical Masked-Import Model Comparison",
        "",
        "| Model | Records | Candidates | Coord. rows | Import rows | Strict exact import recovery | Raw exact import mentions | Invalid coord. | Susp. imports | Evidence records |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in rows:
        lines.append(
            "| {model} | {records} | {candidate_rows} | {coordinate_rows} | {java_import_rows} | {strict} | {raw} | {invalid_coordinate_rows} | {suspicious_import_rows} | {evidence_records} |".format(
                **r,
                strict=fmt_rate(r["strict_exact_recovered"], r["masked_imports"]),
                raw=fmt_rate(r["raw_exact_mentions"], r["masked_imports"]),
            )
        )
    lines.extend(["", "## Coordinate Validation Notes", ""])
    for r in rows:
        lines.append(f"- `{r['model']}`: {r['coordinate_note']}")
    lines.extend(["", "## Maven / Offline Validation Status Counts", ""])
    for r in rows:
        lines.append(f"### {r['model']}")
        lines.append("")
        lines.append("| Status | Count |")
        lines.append("|---|---:|")
        for key, value in sorted(r["maven_status_counts"].items()):
            lines.append(f"| `{key}` | {value} |")
        lines.append("")
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--qwen-summary-json", required=True)
    parser.add_argument("--qwen-raw-json", required=True)
    parser.add_argument("--deepseek-summary-json", required=True)
    parser.add_argument("--deepseek-raw-json", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    rows = [
        row(
            "Qwen2.5-Coder-7B-Instruct",
            args.qwen_summary_json,
            args.qwen_raw_json,
            "Maven Central validation was run for generated coordinate rows; not_found counts are registry-backed.",
        ),
        row(
            "DeepSeek-Coder-6.7B-Instruct",
            args.deepseek_summary_json,
            args.deepseek_raw_json,
            "External registry querying was not run for this model after privacy review; only local-Maven-cache hits and obvious placeholder/missing coordinates are labeled.",
        ),
    ]
    output = {"rows": rows}
    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_md(args.output_md, rows)
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
