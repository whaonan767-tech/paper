import argparse
import csv
import json
import re
from pathlib import Path


PLATFORM_PREFIXES = ("java.", "javax.", "jdk.", "sun.")
KNOWN_EXTERNAL_PREFIXES = {
    "org.junit.": "known_external_dependency:junit",
    "org.apache.commons.": "known_external_dependency:apache-commons",
    "org.apache.zookeeper.": "known_external_dependency:zookeeper",
    "org.apache.logging.log4j.": "known_external_dependency:log4j",
    "org.json.": "known_external_dependency:json-java",
    "org.opencv.": "known_external_dependency:opencv",
    "org.slf4j.": "known_external_dependency:slf4j",
    "org.springframework.": "known_external_dependency:spring",
    "com.fasterxml.jackson.": "known_external_dependency:jackson",
    "com.google.common.": "known_external_dependency:guava",
    "lombok.": "known_external_dependency:lombok",
    "ai.timefold.solver.": "known_external_dependency:timefold",
}
HALLUCINATED_EXTERNAL_PREFIXES = {
    "org.apache.nacos.discovery.": "hallucinated_external_dependency:nacos",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def normalize_relative(value):
    value = (value or "").replace("\\", "/").strip()
    if value.startswith("./"):
        value = value[2:]
    return value


def resolve_project_root(apihul_root, project_path):
    normalized = normalize_relative(project_path)
    path = Path(normalized)
    if path.is_absolute():
        return path
    return apihul_root / Path(*normalized.split("/"))


def index_java_files(project_root):
    if not project_root.exists():
        return []
    files = []
    for path in project_root.rglob("*.java"):
        try:
            files.append(path.relative_to(project_root).as_posix())
        except ValueError:
            continue
    return files


def candidate_suffixes(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    suffixes = []
    for end in range(len(parts), 1, -1):
        suffixes.append("/".join(parts[:end]) + ".java")
    return suffixes


def is_project_local(import_path, java_files):
    suffixes = candidate_suffixes(import_path)
    for suffix in suffixes:
        if any(path.endswith(suffix) for path in java_files):
            return True, suffix
    return False, ""


def project_package_prefix(prompt_text):
    match = re.search(r"\bpackage\s+([A-Za-z_][\w.]*)\s*;", prompt_text)
    if not match:
        return ""
    parts = match.group(1).split(".")
    return ".".join(parts[:2]) if len(parts) >= 2 else match.group(1)


def provided_context_text(prompt_text):
    if "Original answer:" in prompt_text:
        return prompt_text.split("Original answer:", 1)[0]
    return prompt_text


def classify_import(import_path, prompt_text, java_files, package_prefix):
    if not import_path:
        return "missing_import", ""
    if import_path in provided_context_text(prompt_text):
        return "provided_context_import", ""
    if import_path.startswith(PLATFORM_PREFIXES):
        return "platform_import", ""
    for prefix, label in KNOWN_EXTERNAL_PREFIXES.items():
        if import_path.startswith(prefix):
            return label, ""
    for prefix, label in HALLUCINATED_EXTERNAL_PREFIXES.items():
        if import_path.startswith(prefix):
            return label, ""
    found, suffix = is_project_local(import_path, java_files)
    if found:
        return "project_local_import", suffix
    if package_prefix and import_path.startswith(package_prefix + "."):
        return "project_namespace_hallucinated_import", ""
    return "unresolved_external_or_hallucinated", ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates-csv", required=True)
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    apihul_root = Path(args.apihul_root)
    responses = {row["_line_no"]: row for row in read_jsonl(Path(args.responses_jsonl))}
    prompts = {row["record_id"]: row for row in read_jsonl(Path(args.prompts_jsonl))}
    candidates = list(csv.DictReader(Path(args.candidates_csv).open("r", encoding="utf-8")))

    project_index_cache = {}
    classified = []
    counts = {}
    for row in candidates:
        out = dict(row)
        import_path = row.get("import_path", "")
        response = responses.get(int(row.get("source_line") or 0), {})
        prompt_record = prompts.get(response.get("record_id", ""), {})
        prompt_text = prompt_record.get("prompt", response.get("prompt", ""))
        package_prefix = project_package_prefix(prompt_text)
        project_root = resolve_project_root(apihul_root, prompt_record.get("project_path", ""))
        if project_root not in project_index_cache:
            project_index_cache[project_root] = index_java_files(project_root)
        status, matched_suffix = classify_import(
            import_path,
            prompt_text,
            project_index_cache[project_root],
            package_prefix,
        )
        out.update(
            {
                "original_record_id": response.get("record_id", ""),
                "project_path": prompt_record.get("project_path", ""),
                "file_path": response.get("file_path", prompt_record.get("file_path", "")),
                "project_package_prefix": package_prefix,
                "import_classification": status,
                "matched_project_suffix": matched_suffix,
            }
        )
        counts[status] = counts.get(status, 0) + 1
        classified.append(out)

    fieldnames = sorted({key for row in classified for key in row})
    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(classified)

    summary = {
        "rows": len(classified),
        "status_counts": counts,
        "classified": classified,
    }
    Path(args.output_json).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = [
        "# Java Import Classification",
        "",
        f"- Candidates: `{len(classified)}`",
        "",
        "| Classification | Count |",
        "|---|---:|",
    ]
    for status, count in sorted(counts.items()):
        lines.append(f"| {status} | {count} |")
    suspicious = [
        row
        for row in classified
        if "hallucinated" in row.get("import_classification", "")
        or row.get("import_classification") == "unresolved_external_or_hallucinated"
    ]
    if suspicious:
        lines.extend(
            [
                "",
                "## Suspicious Imports",
                "",
                "| Import | Classification | Record | File |",
                "|---|---|---|---|",
            ]
        )
        for row in suspicious[:50]:
            lines.append(
                f"| `{row.get('import_path', '')}` | `{row.get('import_classification', '')}` | "
                f"`{row.get('original_record_id', '')}` | `{row.get('file_path', '')}` |"
            )
    Path(args.output_md).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(classified), "status_counts": counts}, indent=2))


if __name__ == "__main__":
    main()
