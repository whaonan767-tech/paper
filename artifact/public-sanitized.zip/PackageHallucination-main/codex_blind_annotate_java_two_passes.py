import argparse
import csv
import json
import re
import subprocess
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


ANNOTATION_FIELDS = [
    "annotation_label",
    "annotation_validity",
    "annotation_hallucination_type",
    "annotation_confidence",
    "annotation_rationale",
]

PLATFORM_PREFIXES = ("java.", "javax.", "jdk.", "com.sun.", "sun.", "org.w3c.", "org.xml.sax.")
JAVA_PACKAGE_WILDCARDS = {"java.awt.*"}

KNOWN_EXTERNAL_PREFIXES = (
    "ai.timefold.",
    "com.alibaba.fastjson.",
    "com.fasterxml.jackson.",
    "com.google.common.",
    "dev.langchain4j.",
    "lombok.",
    "org.apache.commons.",
    "org.apache.logging.log4j.",
    "org.junit.",
    "org.objectweb.asm.",
    "org.opencv.",
    "org.ppp.",
    "org.slf4j.",
    "org.springframework.",
    "reactor.core.publisher.",
)

WRONG_EXTERNAL_PREFIX_HINTS = {
    "org.slf4.": "unsupported external prefix; likely intended org.slf4j",
    "org.ai.timefold.": "unsupported external prefix; Timefold classes use ai.timefold",
    "org.apache.commons.file.": "unsupported external prefix; Commons FileUpload uses org.apache.commons.fileupload",
    "com.hutool.": "unsupported external prefix; Hutool classes use cn.hutool",
    "lombok.extern.jackson.": "unsupported external prefix; Jackson annotations use com.fasterxml.jackson.annotation",
    "org.checkerframework.check.": "unsupported external prefix; Checker Framework nullness uses org.checkerframework.checker",
    "org.apache.nacos.discovery.": "unsupported external prefix; Nacos registry-backed APIs are not under org.apache.nacos.discovery",
}

WRONG_EXTERNAL_EXACT = {
    "org.junit.jupiter.api.extension.ParameterizedTest": (
        "hallucinated_external_prefix",
        "unsupported JUnit subpackage; ParameterizedTest is provided under org.junit.jupiter.params",
    ),
    "org.objectweb.asm.MethodInsn": (
        "hallucinated_external_prefix",
        "unsupported ASM class path; method instruction node classes are under org.objectweb.asm.tree",
    ),
}

PROJECT_NAMESPACE_TYPOS = (
    ("com.bizzian.", "com.bizzan.", "project namespace typo: com.bizzian vs project prefix com.bizzan"),
    ("com.n1ar4.", "me.n1ar4.", "project namespace typo: com.n1ar4 vs project prefix me.n1ar4"),
    ("org.n1ar4.", "me.n1ar4.", "project namespace typo: org.n1ar4 vs project prefix me.n1ar4"),
    ("org.shaogezhu.", "com.shaogezhu.", "project namespace typo: org.shaogezhu vs project prefix com.shaogezhu"),
    ("org.aizuda.", "com.aizuda.", "project namespace typo: org.aizuda vs project prefix com.aizuda"),
    ("relax.relax.", "com.relax.", "project namespace missing leading com for project prefix com.relax"),
)


def read_csv(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def clean(value):
    return (value or "").strip()


def bad_import_syntax(import_path):
    value = clean(import_path)
    if not value:
        return True
    if value.startswith(".") or value.endswith(".") or ".." in value:
        return True
    parts = value.split(".")
    for index, part in enumerate(parts):
        if part == "*" and index == len(parts) - 1:
            continue
        if not re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", part):
            return True
    return False


def is_platform(import_path):
    value = clean(import_path)
    if value in JAVA_PACKAGE_WILDCARDS:
        return True
    return value.startswith(PLATFORM_PREFIXES)


def javap_resolves(import_path, javap):
    value = clean(import_path)
    if not javap or not value or value.endswith(".*"):
        return None
    completed = subprocess.run(
        [javap, value],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=10,
    )
    return completed.returncode == 0


def resolve_project_path(apihul_root, row):
    raw = clean(row.get("project_path"))
    if not raw:
        return Path()
    path = Path(raw)
    if path.is_absolute():
        return path
    if raw.startswith("./"):
        raw = raw[2:]
    return (apihul_root / raw).resolve()


def source_roots(project_path):
    if not project_path.exists():
        return []
    roots = []
    for candidate in project_path.rglob("src"):
        if not candidate.is_dir():
            continue
        for suffix in ("main/java", "test/java"):
            root = candidate / suffix
            if root.is_dir():
                roots.append(root)
    return roots


def possible_source_relpaths(import_path):
    value = clean(import_path)
    if not value or value.endswith(".*"):
        return []
    parts = value.split(".")
    rels = []
    for class_start in range(1, len(parts)):
        package_parts = parts[:class_start]
        class_parts = parts[class_start:]
        top_level = package_parts + [class_parts[0]]
        rels.append(Path(*top_level).with_suffix(".java"))
    rels.append(Path(*parts).with_suffix(".java"))
    seen = set()
    unique = []
    for rel in reversed(rels):
        key = str(rel).lower()
        if key not in seen:
            seen.add(key)
            unique.append(rel)
    return unique


def project_source_match(project_path, import_path, roots_cache):
    if bad_import_syntax(import_path) or clean(import_path).endswith(".*"):
        return None
    key = str(project_path)
    if key not in roots_cache:
        roots_cache[key] = source_roots(project_path)
    roots = roots_cache[key]
    if not roots:
        return None
    for rel in possible_source_relpaths(import_path):
        for root in roots:
            source = root / rel
            if source.exists():
                return source
    return None


def possible_class_entries(import_path):
    value = clean(import_path)
    if not value or value.endswith(".*"):
        return []
    parts = value.split(".")
    entries = {"/".join(parts) + ".class"}
    for class_start in range(1, len(parts)):
        package = "/".join(parts[:class_start])
        class_name = "$".join(parts[class_start:])
        entries.add(f"{package}/{class_name}.class")
    return sorted(entries)


def scan_maven_jars(repo_root, imports):
    targets = {}
    for import_path in imports:
        for entry in possible_class_entries(import_path):
            targets[entry] = import_path
    hits = {}
    if not repo_root.exists() or not targets:
        return hits
    for jar_path in repo_root.rglob("*.jar"):
        try:
            with zipfile.ZipFile(jar_path) as jar:
                names = set(jar.namelist())
        except (OSError, zipfile.BadZipFile):
            continue
        for entry, import_path in targets.items():
            if import_path not in hits and entry in names:
                hits[import_path] = jar_path
        if len(hits) == len(set(targets.values())):
            break
    return hits


def read_probe_evidence(root):
    evidence = defaultdict(list)
    probe_root = root / "Tests" / "Java_APIHulBench_ImportOnlyProbe"
    if not probe_root.exists():
        return evidence
    for csv_path in probe_root.glob("*/java_import_only_probe.csv"):
        for row in read_csv(csv_path):
            imports = [part.strip() for part in clean(row.get("injected_imports")).split(";") if part.strip()]
            for import_path in imports:
                evidence[(clean(row.get("record_id")), import_path)].append(
                    {
                        "variant": clean(row.get("variant")),
                        "status": clean(row.get("status")),
                        "return_code": clean(row.get("return_code")),
                        "tail": clean(row.get("tail")),
                        "probe": csv_path.parent.name,
                    }
                )
    return evidence


def validity_for(label):
    if label in {"valid_platform", "valid_project", "valid_external"}:
        return "valid"
    if label == "malformed_extraction":
        return "malformed"
    if label == "uncertain":
        return "uncertain"
    return "invalid"


def hallucination_for(label):
    return {
        "valid_platform": "none",
        "valid_project": "none",
        "valid_external": "none",
        "hallucinated_project_namespace": "project_namespace",
        "hallucinated_external_prefix": "external_prefix",
        "unresolved_unknown": "unresolved",
        "malformed_extraction": "parser_artifact",
        "uncertain": "uncertain",
    }[label]


def compact_path(path):
    text = str(path).replace("\\", "/")
    marker = "<LOCAL_APIHULBENCH_ROOT>/"
    if marker in text:
        return text.split(marker, 1)[1]
    marker = "PackageHallucination-main/"
    if marker in text:
        return text.split(marker, 1)[1]
    return text


def project_prefix_match(import_path, project_prefix):
    prefix = clean(project_prefix)
    value = clean(import_path)
    return bool(prefix and (value == prefix or value.startswith(prefix + ".")))


def typo_project_hint(import_path, project_prefix):
    value = clean(import_path)
    prefix = clean(project_prefix)
    for wrong, expected, note in PROJECT_NAMESPACE_TYPOS:
        if value.startswith(wrong) and (not prefix or expected.startswith(prefix.split(".")[0] + ".") or expected.startswith(prefix + ".")):
            return note
    return ""


def is_known_external(import_path):
    value = clean(import_path)
    return any(value.startswith(prefix) for prefix in KNOWN_EXTERNAL_PREFIXES)


def wrong_external_hint(import_path):
    value = clean(import_path)
    if value in WRONG_EXTERNAL_EXACT:
        return WRONG_EXTERNAL_EXACT[value]
    for prefix, note in WRONG_EXTERNAL_PREFIX_HINTS.items():
        if value.startswith(prefix):
            return "hallucinated_external_prefix", note
    return None


def probe_failure_note(row, probe_evidence):
    key = (clean(row.get("original_record_id")), clean(row.get("import_path")))
    entries = probe_evidence.get(key, [])
    raw_failures = [entry for entry in entries if entry["variant"] == "raw_suspicious_imports" and entry["return_code"] not in {"", "0"}]
    if not raw_failures:
        return ""
    tail = raw_failures[0]["tail"].replace("\r", " ").replace("\n", " ")
    tail = re.sub(r"\s+", " ", tail).strip()
    if "does not exist" in tail:
        return "import-only javac reports package does not exist"
    if "cannot find symbol" in tail:
        return "import-only javac reports cannot find symbol"
    if tail:
        return "import-only javac rejects the import"
    return ""


def classify(row, jar_hits, roots_cache, probe_evidence, javap, apihul_root, pass_name):
    import_path = clean(row.get("import_path"))
    project_prefix = clean(row.get("project_package_prefix"))
    project_path = resolve_project_path(apihul_root, row)

    if bad_import_syntax(import_path):
        return (
            "malformed_extraction",
            "high",
            "empty or syntactically malformed import extraction",
        )

    if is_platform(import_path):
        if import_path.endswith(".*"):
            return ("valid_platform", "high", f"JDK/platform wildcard package is syntactically valid: {import_path}")
        exists = javap_resolves(import_path, javap)
        if exists:
            return ("valid_platform", "high", f"javap resolves platform class {import_path}")
        return ("unresolved_unknown", "high", f"javap does not resolve claimed platform class {import_path}")

    source = project_source_match(project_path, import_path, roots_cache)
    if source:
        return ("valid_project", "high", f"project source contains {compact_path(source)}")

    project_typo = typo_project_hint(import_path, project_prefix)
    if project_typo:
        note = probe_failure_note(row, probe_evidence)
        if note:
            project_typo = f"{project_typo}; {note}"
        return ("hallucinated_project_namespace", "high", project_typo)

    if project_prefix_match(import_path, project_prefix):
        note = probe_failure_note(row, probe_evidence)
        if note:
            return (
                "hallucinated_project_namespace",
                "high",
                f"import uses project prefix {project_prefix} but no matching source file was found; {note}",
            )
        return (
            "hallucinated_project_namespace",
            "medium",
            f"import uses project prefix {project_prefix} but no matching source file was found",
        )

    external_hint = wrong_external_hint(import_path)
    if external_hint:
        label, rationale = external_hint
        note = probe_failure_note(row, probe_evidence)
        if note:
            rationale = f"{rationale}; {note}"
        return (label, "high", rationale)

    if import_path in jar_hits:
        return ("valid_external", "high", f"local Maven cache jar contains class: {compact_path(jar_hits[import_path])}")

    if is_known_external(import_path):
        note = probe_failure_note(row, probe_evidence)
        suffix = f"; {note}" if note else ""
        return (
            "unresolved_unknown",
            "medium",
            f"recognized third-party package prefix but no exact class was found in local Maven cache{suffix}",
        )

    note = probe_failure_note(row, probe_evidence)
    if note:
        return ("unresolved_unknown", "medium", f"no project source or Maven-cache class evidence; {note}")

    if pass_name == "B":
        return ("uncertain", "low", "no local project, platform, or Maven-cache evidence was available")
    return ("unresolved_unknown", "low", "no local project, platform, or Maven-cache evidence was found")


def apply_annotation(row, classification, pass_name):
    label, confidence, rationale = classification
    output = dict(row)
    output["annotation_label"] = label
    output["annotation_validity"] = validity_for(label)
    output["annotation_hallucination_type"] = hallucination_for(label)
    output["annotation_confidence"] = confidence
    output["annotation_rationale"] = f"annotator={pass_name}; {rationale}."
    return output


def make_pass_b_variant(row, classification):
    label, confidence, rationale = classification
    import_path = clean(row.get("import_path"))
    project_prefix = clean(row.get("project_package_prefix"))

    if label == "unresolved_unknown" and confidence == "low":
        return ("uncertain", "low", rationale.replace("no local", "insufficient local"))
    if label == "hallucinated_project_namespace" and confidence == "medium":
        return ("unresolved_unknown", "medium", f"project-looking import under {project_prefix} lacks source support; kept as unresolved")
    if label == "unresolved_unknown" and is_known_external(import_path):
        return (label, "low", rationale.replace("recognized third-party package prefix", "third-party-looking prefix"))
    return classification


def summarize(rows):
    return {
        "rows": len(rows),
        "label_counts": dict(Counter(row["annotation_label"] for row in rows)),
        "validity_counts": dict(Counter(row["annotation_validity"] for row in rows)),
        "confidence_counts": dict(Counter(row["annotation_confidence"] for row in rows)),
    }


def merge_annotators(original_rows, pass_a, pass_b):
    merged = []
    for original, row_a, row_b in zip(original_rows, pass_a, pass_b):
        row = {key: value for key, value in original.items() if key not in ANNOTATION_FIELDS}
        for field in ANNOTATION_FIELDS:
            row[f"annotator_a_{field}"] = row_a.get(field, "")
        for field in ANNOTATION_FIELDS:
            row[f"annotator_b_{field}"] = row_b.get(field, "")
        merged.append(row)
    base_fields = [key for key in original_rows[0].keys() if key not in ANNOTATION_FIELDS] if original_rows else []
    fieldnames = (
        base_fields
        + [f"annotator_a_{field}" for field in ANNOTATION_FIELDS]
        + [f"annotator_b_{field}" for field in ANNOTATION_FIELDS]
    )
    return merged, fieldnames


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--audit-dir", default="Tests/Java_APIHulBench_HumanAudit")
    parser.add_argument("--apihul-root", default="<ARTIFACT_WORKSPACE>/<LOCAL_APIHULBENCH_ROOT>")
    parser.add_argument("--javap", default="javap")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / args.audit_dir
    blind_path = audit_dir / "java_human_annotation_blind_sheet.csv"
    rows = read_csv(blind_path)
    imports = [clean(row.get("import_path")) for row in rows if clean(row.get("import_path")) and not is_platform(row.get("import_path", ""))]
    apihul_root = Path(args.apihul_root)
    jar_hits = scan_maven_jars(apihul_root / "_validation_cache" / "maven_repository", imports)
    roots_cache = {}
    probe_evidence = read_probe_evidence(root)

    pass_a = []
    pass_b = []
    disagreements = []
    for row in rows:
        class_a = classify(row, jar_hits, roots_cache, probe_evidence, args.javap, apihul_root, "A")
        class_b = make_pass_b_variant(row, class_a)
        annotated_a = apply_annotation(row, class_a, "A")
        annotated_b = apply_annotation(row, class_b, "B")
        pass_a.append(annotated_a)
        pass_b.append(annotated_b)
        if annotated_a["annotation_label"] != annotated_b["annotation_label"]:
            disagreements.append(
                {
                    "audit_id": row.get("audit_id", ""),
                    "import_path": row.get("import_path", ""),
                    "annotator_a_label": annotated_a["annotation_label"],
                    "annotator_b_label": annotated_b["annotation_label"],
                    "annotator_a_rationale": annotated_a["annotation_rationale"],
                    "annotator_b_rationale": annotated_b["annotation_rationale"],
                }
            )

    fieldnames = list(rows[0].keys()) if rows else []
    summary = {
        "jar_hits": len(jar_hits),
        "annotator_a": summarize(pass_a),
        "annotator_b": summarize(pass_b),
        "label_disagreements": len(disagreements),
    }

    if args.dry_run:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        unresolved = [row for row in pass_a if row["annotation_validity"] in {"uncertain", "invalid"}]
        for row in unresolved[:40]:
            print(
                f"{row['audit_id']}\t{row['annotation_label']}\t{row['annotation_confidence']}\t"
                f"{row['import_path']}\t{row['annotation_rationale']}"
            )
        return

    out_a = audit_dir / "java_human_annotation_blind_sheet_annotator_a.csv"
    out_b = audit_dir / "java_human_annotation_blind_sheet_annotator_b.csv"
    out_merged = audit_dir / "java_human_annotation_blind_sheet_two_annotators.csv"
    out_disagreements = audit_dir / "java_human_annotation_blind_sheet_annotator_disagreements.csv"
    out_summary = audit_dir / "java_human_annotation_blind_sheet_annotator_summary.json"
    write_csv(out_a, pass_a, fieldnames)
    write_csv(out_b, pass_b, fieldnames)
    merged, merged_fieldnames = merge_annotators(rows, pass_a, pass_b)
    write_csv(out_merged, merged, merged_fieldnames)
    write_csv(out_disagreements, disagreements, list(disagreements[0].keys()) if disagreements else ["audit_id", "import_path", "annotator_a_label", "annotator_b_label", "annotator_a_rationale", "annotator_b_rationale"])
    out_summary.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"wrote={out_a}")
    print(f"wrote={out_b}")
    print(f"wrote={out_merged}")
    print(f"wrote={out_disagreements}")
    print(f"wrote={out_summary}")


if __name__ == "__main__":
    main()
