import argparse
import csv
import difflib
import http.client
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path


MAVEN_SEARCH_URL = "https://search.maven.org/solrsearch/select"
PACKAGE_RE = re.compile(r"\bpackage\s+([A-Za-z_][\w.]*)\s*;")


KNOWN_PREFIX_MAPPINGS = [
    ("org.junit.jupiter.", "org.junit.jupiter", "junit-jupiter-api"),
    ("org.junit.", "junit", "junit"),
    ("org.apache.commons.lang3.", "org.apache.commons", "commons-lang3"),
    ("org.apache.commons.math3.", "org.apache.commons", "commons-math3"),
    ("org.apache.commons.beanutils.", "commons-beanutils", "commons-beanutils"),
    ("org.apache.commons.collections4.", "org.apache.commons", "commons-collections4"),
    ("org.aspectj.", "org.aspectj", "aspectjrt"),
    ("org.apache.kafka.", "org.apache.kafka", "kafka-clients"),
    ("org.apache.zookeeper.", "org.apache.zookeeper", "zookeeper"),
    ("org.apache.logging.log4j.", "org.apache.logging.log4j", "log4j-api"),
    ("org.json.", "org.json", "json"),
    ("org.opencv.", "org.openpnp", "opencv"),
    ("org.slf4j.", "org.slf4j", "slf4j-api"),
    ("org.springframework.context.", "org.springframework", "spring-context"),
    ("org.springframework.beans.", "org.springframework", "spring-beans"),
    ("org.springframework.", "org.springframework", "spring-core"),
    ("com.fasterxml.jackson.databind.", "com.fasterxml.jackson.core", "jackson-databind"),
    ("com.fasterxml.jackson.core.", "com.fasterxml.jackson.core", "jackson-core"),
    ("com.alibaba.fastjson2.", "com.alibaba.fastjson2", "fastjson2"),
    ("com.alibaba.fastjson.", "com.alibaba", "fastjson"),
    ("com.google.common.", "com.google.guava", "guava"),
    ("com.google.protobuf.", "com.google.protobuf", "protobuf-java"),
    ("com.mongodb.", "org.mongodb", "mongodb-driver-core"),
    ("org.bson.", "org.mongodb", "bson"),
    ("org.mongodb.client.", "org.mongodb", "mongodb-driver-sync"),
    ("org.mockito.", "org.mockito", "mockito-core"),
    ("cn.hutool.", "cn.hutool", "hutool-core"),
    ("io.quarkus.runtime.", "io.quarkus", "quarkus-core"),
    ("javafx.fxml.", "org.openjfx", "javafx-fxml"),
    ("javafx.scene.", "org.openjfx", "javafx-graphics"),
    ("javafx.stage.", "org.openjfx", "javafx-graphics"),
    ("lombok.", "org.projectlombok", "lombok"),
    ("ai.timefold.solver.", "ai.timefold.solver", "timefold-solver-core"),
    ("org.optaplanner.", "org.optaplanner", "optaplanner-core"),
]


HALLUCINATED_PREFIX_SUGGESTIONS = [
    ("org.slf4.", "org.slf4j.", "org.slf4j", "slf4j-api"),
    ("org.ai.timefold.", "ai.timefold.solver.", "ai.timefold.solver", "timefold-solver-core"),
    ("com.hutool.", "cn.hutool.", "cn.hutool", "hutool-core"),
    ("org.apache.nacos.discovery.", "com.alibaba.nacos.api.naming.", "com.alibaba.nacos", "nacos-client"),
]


def load_cache(path):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def save_cache(path, cache):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")


def query_maven(params, timeout):
    url = f"{MAVEN_SEARCH_URL}?{urllib.parse.urlencode(params)}"
    request = urllib.request.Request(url, headers={"User-Agent": "codex-package-hallucination-study"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    response = payload.get("response", {})
    return {
        "url": url,
        "num_found": int(response.get("numFound", 0)),
        "docs": response.get("docs", []),
    }


def cached_query(cache, key, params, timeout, sleep_s, retry_errors):
    if key not in cache or (retry_errors and not cache.get(key, {}).get("ok")):
        try:
            cache[key] = {"ok": True, "result": query_maven(params, timeout)}
            if sleep_s:
                time.sleep(sleep_s)
        except (
            urllib.error.URLError,
            TimeoutError,
            socket.timeout,
            http.client.HTTPException,
            OSError,
            json.JSONDecodeError,
        ) as exc:
            cache[key] = {"ok": False, "error": repr(exc)}
    return cache[key]


def coordinate_query_key(group_id, artifact_id):
    return f"coord::{group_id}::{artifact_id}"


def class_query_key(import_path):
    return f"class::{import_path}"


def normalize_relative(value):
    value = (value or "").replace("\\", "/").strip()
    if value.startswith("./"):
        value = value[2:]
    return value


def resolve_project_root(apihul_root, project_path):
    if not apihul_root:
        return None
    normalized = normalize_relative(project_path)
    if not normalized:
        return None
    path = Path(normalized)
    if path.is_absolute():
        return path
    return apihul_root / Path(*normalized.split("/"))


def read_package_declaration(path):
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""
    match = PACKAGE_RE.search(text)
    return match.group(1) if match else ""


def package_prefixes(package_name):
    parts = [part for part in package_name.split(".") if part]
    prefixes = []
    for index in range(2, len(parts) + 1):
        prefixes.append(".".join(parts[:index]))
    return prefixes


def index_project_symbols(project_root):
    symbols = {
        "packages": set(),
        "package_prefixes": set(),
        "class_fqns": defaultdict(list),
    }
    if not project_root or not project_root.exists():
        return symbols
    for path in project_root.rglob("*.java"):
        package_name = read_package_declaration(path)
        if not package_name:
            continue
        symbols["packages"].add(package_name)
        symbols["package_prefixes"].update(package_prefixes(package_name))
        symbols["class_fqns"][path.stem].append(f"{package_name}.{path.stem}")
    return symbols


def import_package(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    if len(parts) <= 1:
        return ""
    return ".".join(parts[:-1])


def import_class_name(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    return parts[-1] if parts else ""


def similarity(left, right):
    if not left or not right:
        return 0.0
    return difflib.SequenceMatcher(None, left, right).ratio()


def best_project_prefix(import_pkg, symbols):
    best_prefix = ""
    best_score = 0.0
    for prefix in symbols.get("package_prefixes", set()):
        score = similarity(import_pkg, prefix)
        if score > best_score:
            best_prefix = prefix
            best_score = score
    return best_prefix, best_score


def best_project_import(import_path, symbols):
    class_name = import_class_name(import_path)
    exact = symbols.get("class_fqns", {}).get(class_name, [])
    if exact:
        best = max(exact, key=lambda candidate: similarity(import_path, candidate))
        return best, similarity(import_path, best), "exact class name found in project"
    return "", 0.0, ""


def project_namespace_hint(import_path, row, symbols):
    hint = {
        "suggested_project_import": "",
        "suggested_project_prefix": "",
        "project_suggestion_confidence": "",
        "project_suggestion_reason": "",
    }
    import_pkg = import_package(import_path)
    if not import_pkg or not symbols:
        return hint

    suggested_import, import_score, import_reason = best_project_import(import_path, symbols)
    suggested_prefix, prefix_score = best_project_prefix(import_pkg, symbols)
    row_prefix = row.get("project_package_prefix", "")
    row_prefix_score = similarity(".".join(import_path.split(".")[:2]), row_prefix) if row_prefix else 0.0

    if suggested_import and import_score >= 0.64:
        hint.update(
            {
                "suggested_project_import": suggested_import,
                "suggested_project_prefix": import_package(suggested_import),
                "project_suggestion_confidence": f"{import_score:.3f}",
                "project_suggestion_reason": import_reason,
            }
        )
        return hint

    if suggested_prefix and prefix_score >= 0.86:
        hint.update(
            {
                "suggested_project_prefix": suggested_prefix,
                "project_suggestion_confidence": f"{prefix_score:.3f}",
                "project_suggestion_reason": "closest project package prefix",
            }
        )
        return hint

    if row_prefix and row_prefix_score >= 0.72:
        hint.update(
            {
                "suggested_project_prefix": row_prefix,
                "project_suggestion_confidence": f"{row_prefix_score:.3f}",
                "project_suggestion_reason": "close to current file package prefix",
            }
        )
        return hint

    return hint


def validate_coordinate(cache, group_id, artifact_id, timeout, sleep_s, retry_errors):
    params = {
        "q": f'g:"{group_id}" AND a:"{artifact_id}"',
        "rows": "5",
        "wt": "json",
    }
    cached = cached_query(
        cache,
        coordinate_query_key(group_id, artifact_id),
        params,
        timeout,
        sleep_s,
        retry_errors,
    )
    if not cached.get("ok"):
        return {"coordinate_status": "query_error", "maven_num_found": "", "latest_version": "", "error": cached.get("error", "")}
    result = cached["result"]
    docs = result.get("docs", [])
    latest = ""
    if docs:
        latest = docs[0].get("latestVersion") or docs[0].get("v") or ""
    return {
        "coordinate_status": "valid_coordinate" if int(result.get("num_found", 0)) > 0 else "coordinate_not_found",
        "maven_num_found": int(result.get("num_found", 0)),
        "latest_version": latest,
        "maven_url": result.get("url", ""),
        "error": "",
    }


def search_by_fully_qualified_class(cache, import_path, timeout, sleep_s, retry_errors):
    params = {
        "q": f'fc:"{import_path}"',
        "rows": "5",
        "wt": "json",
    }
    cached = cached_query(
        cache,
        class_query_key(import_path),
        params,
        timeout,
        sleep_s,
        retry_errors,
    )
    if not cached.get("ok"):
        return None, {"class_search_status": "query_error", "error": cached.get("error", "")}
    result = cached["result"]
    docs = result.get("docs", [])
    if not docs:
        return None, {"class_search_status": "class_not_found", "class_search_num_found": 0, "class_search_url": result.get("url", "")}
    doc = docs[0]
    group_id = doc.get("g", "")
    artifact_id = doc.get("a", "")
    latest = doc.get("latestVersion") or doc.get("v") or ""
    return (
        (group_id, artifact_id),
        {
            "class_search_status": "class_found",
            "class_search_num_found": int(result.get("num_found", 0)),
            "class_search_url": result.get("url", ""),
            "latest_version": latest,
        },
    )


def known_mapping(import_path):
    for prefix, group_id, artifact_id in KNOWN_PREFIX_MAPPINGS:
        if import_path.startswith(prefix):
            return prefix, group_id, artifact_id
    return "", "", ""


def hallucinated_prefix_suggestion(import_path):
    for bad_prefix, suggested_prefix, group_id, artifact_id in HALLUCINATED_PREFIX_SUGGESTIONS:
        if import_path.startswith(bad_prefix):
            return bad_prefix, suggested_prefix, group_id, artifact_id
    return "", "", "", ""


def maybe_validate_coordinate(cache, group_id, artifact_id, timeout, sleep_s, retry_errors, skip_coordinate_validation):
    if skip_coordinate_validation:
        return {"coordinate_status": "not_checked", "maven_num_found": "", "latest_version": "", "error": ""}
    return validate_coordinate(cache, group_id, artifact_id, timeout, sleep_s, retry_errors)


def map_row(
    row,
    cache,
    timeout,
    sleep_s,
    retry_errors,
    enable_class_search,
    project_symbols=None,
    skip_coordinate_validation=False,
):
    import_path = row.get("import_path", "").strip()
    classification = row.get("import_classification", "")
    out = dict(row)
    out.update(
        {
            "mapping_status": "",
            "mapped_group_id": "",
            "mapped_artifact_id": "",
            "mapped_coordinate": "",
            "suggested_import_prefix": "",
            "mapping_reason": "",
            "suggested_project_import": "",
            "suggested_project_prefix": "",
            "project_suggestion_confidence": "",
            "project_suggestion_reason": "",
        }
    )

    if not import_path:
        out["mapping_status"] = "missing_import"
        out["mapping_reason"] = "No import path was extracted."
        return out
    if classification in {"provided_context_import", "platform_import", "project_local_import"}:
        out["mapping_status"] = "no_external_mapping_needed"
        out["mapping_reason"] = classification
        return out
    if "project_namespace_hallucinated_import" in classification:
        out.update(project_namespace_hint(import_path, row, project_symbols))
        out["mapping_status"] = "project_namespace_hallucination"
        reason = "Import uses the project namespace but no matching source file was found."
        if out.get("suggested_project_import"):
            reason += f" Closest project import: `{out['suggested_project_import']}`."
        elif out.get("suggested_project_prefix"):
            reason += f" Closest project prefix: `{out['suggested_project_prefix']}`."
        out["mapping_reason"] = reason
        return out

    bad_prefix, suggested_prefix, suggested_group, suggested_artifact = hallucinated_prefix_suggestion(import_path)
    if bad_prefix:
        out.update(
            {
                "mapping_status": "hallucinated_prefix_with_suggestion",
                "mapped_group_id": suggested_group,
                "mapped_artifact_id": suggested_artifact,
                "mapped_coordinate": f"{suggested_group}:{suggested_artifact}",
                "suggested_import_prefix": suggested_prefix,
                "mapping_reason": f"Matched suspicious prefix `{bad_prefix}`.",
            }
        )
        out.update(
            maybe_validate_coordinate(
                cache,
                suggested_group,
                suggested_artifact,
                timeout,
                sleep_s,
                retry_errors,
                skip_coordinate_validation,
            )
        )
        return out

    prefix, group_id, artifact_id = known_mapping(import_path)
    if prefix:
        out.update(
            {
                "mapping_status": "mapped_known_prefix",
                "mapped_group_id": group_id,
                "mapped_artifact_id": artifact_id,
                "mapped_coordinate": f"{group_id}:{artifact_id}",
                "mapping_reason": f"Matched known import prefix `{prefix}`.",
            }
        )
        out.update(
            maybe_validate_coordinate(
                cache,
                group_id,
                artifact_id,
                timeout,
                sleep_s,
                retry_errors,
                skip_coordinate_validation,
            )
        )
        return out

    if enable_class_search and classification == "unresolved_external_or_hallucinated":
        found, search_info = search_by_fully_qualified_class(cache, import_path, timeout, sleep_s, retry_errors)
        out.update(search_info)
        if found:
            group_id, artifact_id = found
            out.update(
                {
                    "mapping_status": "mapped_maven_class_search",
                    "mapped_group_id": group_id,
                    "mapped_artifact_id": artifact_id,
                    "mapped_coordinate": f"{group_id}:{artifact_id}",
                    "mapping_reason": "Maven Central fully-qualified class search found a candidate artifact.",
                }
            )
            out.update(
                maybe_validate_coordinate(
                    cache,
                    group_id,
                    artifact_id,
                    timeout,
                    sleep_s,
                    retry_errors,
                    skip_coordinate_validation,
                )
            )
            return out

        out.update(project_namespace_hint(import_path, row, project_symbols))
        if out.get("suggested_project_import") or out.get("suggested_project_prefix"):
            out["mapping_status"] = "project_namespace_typo_hallucination"
            if out.get("suggested_project_import"):
                out["mapping_reason"] = (
                    "No Maven class-search hit, but a close project class was found: "
                    f"`{out['suggested_project_import']}`."
                )
            else:
                out["mapping_reason"] = (
                    "No Maven class-search hit, but the import is close to a project package prefix: "
                    f"`{out['suggested_project_prefix']}`."
                )
            return out

    out["mapping_status"] = "unresolved_after_mapping"
    out["mapping_reason"] = f"No known mapping or Maven class-search hit for `{import_path}`."
    return out


def write_csv(path, rows):
    fieldnames = sorted({key for row in rows for key in row})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def count_by(rows, key):
    counts = {}
    for row in rows:
        value = row.get(key, "")
        counts[value] = counts.get(value, 0) + 1
    return counts


def write_markdown(path, output):
    rows = output["mapped"]
    lines = [
        "# Java Import to Maven Mapping",
        "",
        f"- Rows: `{len(rows)}`",
        "",
        "## Mapping Status",
        "",
        "| Status | Count |",
        "|---|---:|",
    ]
    for status, count in sorted(output["mapping_status_counts"].items()):
        lines.append(f"| {status} | {count} |")

    lines.extend(["", "## Coordinate Status", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(output["coordinate_status_counts"].items()):
        label = status or "(not applicable)"
        lines.append(f"| {label} | {count} |")

    interesting = [
        row
        for row in rows
        if row.get("mapping_status")
        in {
            "project_namespace_hallucination",
            "hallucinated_prefix_with_suggestion",
            "unresolved_after_mapping",
            "mapped_maven_class_search",
            "project_namespace_typo_hallucination",
        }
    ]
    if interesting:
        lines.extend(
            [
                "",
                "## Audit Rows",
                "",
                "| Import | Mapping | Coordinate | Suggestion | Project suggestion | Record |",
                "|---|---|---|---|---|---|",
            ]
        )
        for row in interesting[:80]:
            project_suggestion = row.get("suggested_project_import") or row.get("suggested_project_prefix") or ""
            lines.append(
                "| `{import_path}` | `{mapping_status}` | `{coord}` | `{suggestion}` | `{project_suggestion}` | `{record}` |".format(
                    import_path=row.get("import_path", ""),
                    mapping_status=row.get("mapping_status", ""),
                    coord=row.get("mapped_coordinate", ""),
                    suggestion=row.get("suggested_import_prefix", ""),
                    project_suggestion=project_suggestion,
                    record=row.get("original_record_id", ""),
                )
            )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--cache-json", default="Tests/java_import_maven_cache.json")
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--sleep", type=float, default=0.05)
    parser.add_argument("--retry-errors", action="store_true")
    parser.add_argument("--disable-class-search", action="store_true")
    parser.add_argument("--skip-coordinate-validation", action="store_true")
    parser.add_argument("--apihul-root", default="")
    args = parser.parse_args()

    input_csv = Path(args.input_csv)
    cache_path = Path(args.cache_json)
    cache = load_cache(cache_path)
    rows = list(csv.DictReader(input_csv.open("r", encoding="utf-8")))
    project_index_cache = {}
    apihul_root = Path(args.apihul_root) if args.apihul_root else None
    mapped = []
    for row in rows:
        project_symbols = None
        project_root = resolve_project_root(apihul_root, row.get("project_path", ""))
        if project_root:
            if project_root not in project_index_cache:
                project_index_cache[project_root] = index_project_symbols(project_root)
            project_symbols = project_index_cache[project_root]
        mapped.append(
            map_row(
                row,
                cache,
                args.timeout,
                args.sleep,
                args.retry_errors,
                enable_class_search=not args.disable_class_search,
                project_symbols=project_symbols,
                skip_coordinate_validation=args.skip_coordinate_validation,
            )
        )
    save_cache(cache_path, cache)

    output = {
        "input_csv": str(input_csv),
        "rows": len(rows),
        "mapping_status_counts": count_by(mapped, "mapping_status"),
        "coordinate_status_counts": count_by(mapped, "coordinate_status"),
        "mapped": mapped,
    }
    write_csv(Path(args.output_csv), mapped)
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), output)
    print(json.dumps({"rows": len(rows), "mapping_status_counts": output["mapping_status_counts"]}, indent=2))


if __name__ == "__main__":
    main()
