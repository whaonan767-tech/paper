#!/usr/bin/env python3
"""Strictly parse structured masked-import V3 responses."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path

import codex_java_masked_baseline_audit as baseline


ROOT = Path(__file__).resolve().parent
PROMPTS = ROOT / "Tests" / "Java_APIHulBench_MaskedV3StructuredPrompts_Corrected_Run20260804" / "prompts.jsonl"
PROMPT_AUDIT = PROMPTS.parent / "prompt_audit.json"
RESPONSES = ROOT / "Tests" / "Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804" / "responses.jsonl"
DEFAULT_OUTPUT = RESPONSES.parent
IMPORT_RE = re.compile(r"^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$*][\w$*]*)+$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--prompt-audit", type=Path, default=PROMPT_AUDIT)
    parser.add_argument("--responses", type=Path, default=RESPONSES)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def compact(value: str) -> str:
    return "".join(value.split())


def main() -> None:
    args = parse_args()
    prompts_path = args.prompts.resolve()
    responses_path = args.responses.resolve()
    prompt_audit = json.loads(args.prompt_audit.resolve().read_text(encoding="utf-8"))
    other_occurrences = {
        row["record_id"]: int(row["ground_truth_other_occurrences"])
        for row in prompt_audit["rows"]
    }
    prompts = baseline.read_jsonl(prompts_path)
    responses = baseline.read_jsonl(responses_path)
    prompts_by_id = {row["record_id"]: row for row in prompts}
    if len(responses) != len(prompts) or {row["record_id"] for row in responses} != set(prompts_by_id):
        raise SystemExit("Prompt/response record sets differ")

    rows = []
    for response in responses:
        record_id = response["record_id"]
        prompt = prompts_by_id[record_id]
        text = response["response"].strip()
        parsed = None
        parse_error = ""
        try:
            parsed = json.loads(text)
            if not isinstance(parsed, dict) or set(parsed) != {"replacement", "imports"}:
                raise ValueError("object must contain exactly replacement and imports")
            if not isinstance(parsed["replacement"], str):
                raise ValueError("replacement is not a string")
            if not isinstance(parsed["imports"], list) or not all(
                isinstance(value, str) for value in parsed["imports"]
            ):
                raise ValueError("imports is not a string list")
            invalid_imports = [value for value in parsed["imports"] if not IMPORT_RE.fullmatch(value)]
            if invalid_imports:
                raise ValueError(f"invalid import syntax: {invalid_imports}")
        except Exception as error:
            parse_error = str(error)
            parsed = None

        replacement = parsed["replacement"] if parsed else ""
        generated_imports = list(dict.fromkeys(parsed["imports"])) if parsed else []
        hidden_imports = prompt["masked_external_imports"]
        recovered = [value for value in hidden_imports if value in generated_imports]
        rows.append(
            {
                "record_id": record_id,
                "split": prompt["split"],
                "source_line": prompt["source_line"],
                "project_path": prompt["project_path"],
                "file_path": prompt["file_path"],
                "source_set": prompt["source_set"],
                "build_key": prompt["build_key"],
                "strict_json_valid": parsed is not None,
                "parse_error": parse_error,
                "replacement": replacement,
                "ground_truth": prompt["ground_truth"],
                "replacement_exact": parsed is not None and replacement == prompt["ground_truth"],
                "replacement_compact_exact": parsed is not None and compact(replacement) == compact(prompt["ground_truth"]),
                "ground_truth_other_occurrences": other_occurrences[record_id],
                "generated_imports": generated_imports,
                "hidden_imports": hidden_imports,
                "exact_recovered_imports": recovered,
                "all_hidden_imports_exact": len(recovered) == len(hidden_imports),
                "generated_token_count_including_eos": response.get("generated_token_count_including_eos"),
                "finish_reason": response.get("finish_reason", "historical_unrecorded"),
                "eos_emitted": response.get("eos_emitted"),
                "elapsed_ms": response["elapsed_ms"],
                "raw_response": text,
            }
        )

    valid = [row for row in rows if row["strict_json_valid"]]
    no_repeat = [row for row in valid if row["ground_truth_other_occurrences"] == 0]
    summary = {
        "records": len(rows),
        "strict_json_valid": len(valid),
        "replacement_exact": sum(row["replacement_exact"] for row in rows),
        "replacement_compact_exact": sum(row["replacement_compact_exact"] for row in rows),
        "replacement_compact_exact_no_other_occurrence": sum(
            row["replacement_compact_exact"] for row in no_repeat
        ),
        "no_other_occurrence_records": len(no_repeat),
        "all_hidden_imports_exact": sum(row["all_hidden_imports_exact"] for row in valid),
        "hidden_imports": sum(len(row["hidden_imports"]) for row in valid),
        "exact_recovered_hidden_imports": sum(len(row["exact_recovered_imports"]) for row in valid),
        "finish_reason_counts": dict(Counter(row["finish_reason"] for row in rows)),
        "parse_error_counts": dict(Counter(row["parse_error"] for row in rows if row["parse_error"])),
        "generated_tokens": {
            "min": min(row["generated_token_count_including_eos"] for row in rows),
            "max": max(row["generated_token_count_including_eos"] for row in rows),
            "mean": sum(row["generated_token_count_including_eos"] for row in rows) / len(rows),
        },
    }
    payload = {
        "analysis": "masked_v3_structured_parse",
        "prompts_sha256": baseline.sha256(prompts_path),
        "responses_sha256": baseline.sha256(responses_path),
        "summary": summary,
        "results": rows,
    }
    output_dir = args.output_dir.resolve()
    (output_dir / "parsed_v3.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    fields = [
        "record_id", "split", "source_line", "project_path", "file_path", "source_set",
        "build_key", "strict_json_valid", "parse_error", "replacement", "ground_truth",
        "replacement_exact", "replacement_compact_exact", "ground_truth_other_occurrences",
        "generated_imports", "hidden_imports", "exact_recovered_imports",
        "all_hidden_imports_exact", "generated_token_count_including_eos", "finish_reason",
        "eos_emitted", "elapsed_ms", "raw_response",
    ]
    csv_rows = []
    for row in rows:
        csv_rows.append(
            {
                **row,
                "generated_imports": ";".join(row["generated_imports"]),
                "hidden_imports": ";".join(row["hidden_imports"]),
                "exact_recovered_imports": ";".join(row["exact_recovered_imports"]),
            }
        )
    with (output_dir / "parsed_v3.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(csv_rows)
    lines = [
        "# Masked V3 Structured Parse",
        "",
        f"- Records: `{summary['records']}`.",
        f"- Strict JSON valid: `{summary['strict_json_valid']}/{summary['records']}`.",
        f"- Exact replacement: `{summary['replacement_exact']}/{summary['records']}`.",
        f"- Whitespace-insensitive exact replacement: `{summary['replacement_compact_exact']}/{summary['records']}`.",
        f"- Whitespace-insensitive exact replacement without another gold occurrence in context: `{summary['replacement_compact_exact_no_other_occurrence']}/{summary['no_other_occurrence_records']}`.",
        f"- Records recovering all hidden imports exactly: `{summary['all_hidden_imports_exact']}/{summary['strict_json_valid']}`.",
        f"- Hidden import exact recovery: `{summary['exact_recovered_hidden_imports']}/{summary['hidden_imports']}`.",
        f"- Finish reasons: `{summary['finish_reason_counts']}`.",
        f"- Generated token count: min `{summary['generated_tokens']['min']}`, mean `{summary['generated_tokens']['mean']:.1f}`, max `{summary['generated_tokens']['max']}`.",
    ]
    (output_dir / "parsed_v3.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir / 'parsed_v3.json'}")


if __name__ == "__main__":
    main()
