#!/usr/bin/env python3
"""Compute project-clustered validity-classification metrics for Java audit truth."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_TRUTH = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
    / "full598_final_human_truth.csv"
)
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_HumanTruthClusteredMetrics_Run20260804"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--truth-csv", type=Path, default=DEFAULT_TRUTH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20_260_804)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower, upper = math.floor(position), math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def confusion(rows: list[dict[str, str]]) -> dict[str, int]:
    counts = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for row in rows:
        predicted_invalid = row["detector_suspicious"].strip().lower() in {"1", "true", "yes"}
        actual_invalid = row["final_validity"].strip().lower() == "invalid"
        key = "tp" if predicted_invalid and actual_invalid else "fp" if predicted_invalid else "fn" if actual_invalid else "tn"
        counts[key] += 1
    return counts


def metrics(counts: dict[str, int]) -> dict[str, float]:
    tp, fp, fn = counts["tp"], counts["fp"], counts["fn"]
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else float("nan")
    return {"precision": precision, "recall": recall, "f1": f1}


def main() -> None:
    args = parse_args()
    truth_path = args.truth_csv.resolve()
    output_dir = args.output_dir.resolve()
    with truth_path.open("r", encoding="utf-8-sig", newline="") as handle:
        all_rows = list(csv.DictReader(handle))
    rows = [row for row in all_rows if row["final_validity"].strip().lower() in {"valid", "invalid"}]
    clusters: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        project = row["project_path"].strip()
        if not project:
            raise SystemExit("Every labeled row must have project_path for clustered resampling")
        clusters[project].append(row)

    projects = sorted(clusters)
    development_rows = [row for row in all_rows if row["audited_in_150_sample"].strip() == "1"]
    evaluation_rows = [row for row in all_rows if row["audited_in_150_sample"].strip() == "0"]
    development_projects = {row["project_path"].strip() for row in development_rows}
    evaluation_projects = {row["project_path"].strip() for row in evaluation_rows}
    overlapping_projects = development_projects & evaluation_projects
    observed_counts = confusion(rows)
    observed_metrics = metrics(observed_counts)
    rng = random.Random(args.seed)
    draws: list[dict[str, float | int]] = []
    for repetition in range(args.bootstrap_repetitions):
        sampled_projects = [rng.choice(projects) for _ in projects]
        sampled_rows = [row for project in sampled_projects for row in clusters[project]]
        sample_counts = confusion(sampled_rows)
        sample_metrics = metrics(sample_counts)
        draws.append({"replicate": repetition + 1, **sample_counts, **sample_metrics})

    intervals = {
        name: {
            "estimate": observed_metrics[name],
            "ci_low": percentile([float(draw[name]) for draw in draws], 0.025),
            "ci_high": percentile([float(draw[name]) for draw in draws], 0.975),
        }
        for name in ("precision", "recall", "f1")
    }
    payload = {
        "analysis": "post_extraction_validity_classification_project_clustered_metrics",
        "scope": "Rows extracted from 416 raw Java generations and assigned final valid/invalid human labels",
        "extraction_recall_evaluated": False,
        "all_extracted_rows": len(all_rows),
        "valid_invalid_rows": len(rows),
        "projects": len(projects),
        "annotation_partition": {
            "development_rows": len(development_rows),
            "development_projects": len(development_projects),
            "evaluation_rows": len(evaluation_rows),
            "evaluation_projects": len(evaluation_projects),
            "overlap_projects": len(overlapping_projects),
            "project_disjoint": not overlapping_projects,
            "interpretation": "annotation-held-out row-level evaluation",
        },
        "confusion": observed_counts,
        "metrics": intervals,
        "bootstrap": {
            "repetitions": args.bootstrap_repetitions,
            "seed": args.seed,
            "resampling_unit": "project_path",
            "interval": "two-sided 95% percentile",
            "ties": "all rows from each sampled project retained; repeated projects retain multiplicity",
        },
        "truth_csv_sha256": sha256(truth_path),
        "script_sha256": sha256(Path(__file__).resolve()),
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "java_human_truth_clustered_metrics.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with (output_dir / "java_human_truth_clustered_bootstrap.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(draws[0]))
        writer.writeheader()
        writer.writerows(draws)

    lines = [
        "# Project-Clustered Java Human-Truth Metrics",
        "",
        f"- Scope: `{len(rows)}` final valid/invalid extracted rows from `{len(projects)}` projects; `{len(all_rows)}` extracted rows total.",
        f"- Confusion: TP `{observed_counts['tp']}`, FP `{observed_counts['fp']}`, FN `{observed_counts['fn']}`, TN `{observed_counts['tn']}`.",
        f"- Annotation split: `{len(development_rows)}` rows / `{len(development_projects)}` projects for development and `{len(evaluation_rows)}` rows / `{len(evaluation_projects)}` projects for evaluation; `{len(overlapping_projects)}` projects overlap, so the evaluation is not project-disjoint.",
        f"- Bootstrap: `{args.bootstrap_repetitions}` project-level resamples, seed `{args.seed}`, two-sided percentile intervals.",
        "- Extraction recall over the 416 raw responses is not evaluated by this analysis.",
        "",
        "| Metric | Estimate | Project-clustered 95% CI |",
        "|---|---:|---:|",
    ]
    for name in ("precision", "recall", "f1"):
        item = intervals[name]
        lines.append(f"| {name.capitalize()} | {item['estimate']:.3f} | {item['ci_low']:.3f}--{item['ci_high']:.3f} |")
    (output_dir / "java_human_truth_clustered_metrics.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
