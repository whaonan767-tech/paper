import argparse
import csv
import json
from pathlib import Path


SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def clipped(text, max_chars):
    text = text or ""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n/* ... clipped ... */"


def extract_original_task_context(prompt_text):
    marker = "Original task context:\n"
    if marker not in prompt_text:
        return prompt_text
    context = prompt_text.rsplit(marker, 1)[1]
    for stop_marker in [
        "\n\nOriginal answer:",
        "\n\nForbidden import strings:",
        "\n\nSuspicious imports/dependencies:",
        "\n\nKnown valid external coordinates",
    ]:
        if stop_marker in context:
            context = context.split(stop_marker, 1)[0]
    return context.strip()


def group_mapping_rows(mapping_rows, statuses):
    grouped = {}
    for row in mapping_rows:
        if row.get("mapping_status") not in statuses:
            continue
        record_id = row.get("original_record_id", "")
        if not record_id:
            continue
        grouped.setdefault(record_id, []).append(row)
    return grouped


def valid_dependencies(mapping_rows, record_id):
    deps = []
    for row in mapping_rows:
        if row.get("original_record_id") != record_id:
            continue
        if row.get("mapping_status") not in {"mapped_known_prefix", "mapped_maven_class_search"}:
            continue
        coord = row.get("mapped_coordinate", "")
        if coord and coord not in deps:
            deps.append(coord)
    return deps


def render_feedback_rows(rows):
    lines = []
    for row in rows:
        import_path = row.get("import_path", "")
        status = row.get("mapping_status", "")
        suggestion = row.get("suggested_import_prefix", "")
        project_import = row.get("suggested_project_import", "")
        project_prefix = row.get("suggested_project_prefix", "")
        coordinate = row.get("mapped_coordinate", "")
        reason = row.get("mapping_reason", "")
        detail = f"- {import_path}: {status}"
        if suggestion:
            detail += f"; suggested import prefix: {suggestion}"
        if project_import:
            detail += f"; closest project import: {project_import}"
        elif project_prefix:
            detail += f"; closest project prefix: {project_prefix}"
        if coordinate:
            detail += f"; suggested Maven coordinate: {coordinate}"
        if reason:
            detail += f"; reason: {reason}"
        lines.append(detail)
    return "\n".join(lines)


def build_prompt(response_row, suspicious_rows, valid_coords, max_prompt_chars, max_response_chars):
    original_prompt = clipped(extract_original_task_context(response_row.get("prompt", "")), max_prompt_chars)
    original_response = clipped(response_row.get("response", ""), max_response_chars)
    invalid_block = render_feedback_rows(suspicious_rows)
    valid_block = "\n".join(f"- {coord}" for coord in valid_coords) if valid_coords else "- None identified"
    forbidden_block = "\n".join(f"- {row.get('import_path', '')}" for row in suspicious_rows)

    return (
        "You previously produced a Java completion and dependency list. A registry/project validation pass "
        "flagged some imports or dependencies as invalid or suspicious.\n\n"
        "Revise the answer using these rules:\n"
        "1. Do not repeat any forbidden import string anywhere in the revised answer.\n"
        "2. Remove project-namespace imports unless they match an existing project source file. If a closest project import or prefix is provided, use it only when it exactly fits the code need.\n"
        "3. If a suggested external import prefix and Maven coordinate are provided, use them only when the original code need requires that library.\n"
        "4. Prefer identifiers already present in the current file prefix. Do not add imports just to make the answer look complete.\n"
        "5. Return only the two-part structure: Java code block, then Dependencies section. No explanation.\n"
        "6. If no external dependency is needed, the Dependencies section must be exactly: No external dependency.\n\n"
        "Original task context:\n"
        f"{original_prompt}\n\n"
        "Original answer:\n"
        f"```text\n{original_response}\n```\n\n"
        "Forbidden import strings:\n"
        f"{forbidden_block}\n\n"
        "Suspicious imports/dependencies:\n"
        f"{invalid_block}\n\n"
        "Known valid external coordinates already found in this answer:\n"
        f"{valid_block}\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--max-prompt-chars", type=int, default=2500)
    parser.add_argument("--max-response-chars", type=int, default=1800)
    parser.add_argument("--statuses", nargs="*", default=sorted(SUSPICIOUS_STATUSES))
    args = parser.parse_args()

    responses = {row.get("record_id", ""): row for row in read_jsonl(Path(args.responses_jsonl))}
    mapping_rows = list(csv.DictReader(Path(args.mapping_csv).open("r", encoding="utf-8")))
    statuses = set(args.statuses)
    grouped = group_mapping_rows(mapping_rows, statuses)

    output_rows = []
    for record_id in sorted(grouped):
        response_row = responses.get(record_id)
        if not response_row:
            continue
        suspicious_rows = grouped[record_id]
        valid_coords = valid_dependencies(mapping_rows, record_id)
        output_rows.append(
            {
                "record_id": record_id,
                "dataset": response_row.get("dataset", ""),
                "split": response_row.get("split", ""),
                "source_line": response_row.get("source_line", ""),
                "project_path": response_row.get("project_path", ""),
                "file_path": response_row.get("file_path", ""),
                "ground_truth": response_row.get("ground_truth", ""),
                "task": "java_registry_feedback_repair",
                "suspicious_imports": [row.get("import_path", "") for row in suspicious_rows],
                "valid_maven_coordinates": valid_coords,
                "prompt": build_prompt(
                    response_row,
                    suspicious_rows,
                    valid_coords,
                    args.max_prompt_chars,
                    args.max_response_chars,
                ),
            }
        )

    output_jsonl = Path(args.output_jsonl)
    output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in output_rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")

    lines = [
        "# Java Registry Feedback Prompt Set",
        "",
        f"- Input responses: `{args.responses_jsonl}`",
        f"- Input mapping: `{args.mapping_csv}`",
        f"- Repair prompts: `{len(output_rows)}`",
        f"- Suspicious statuses: `{', '.join(sorted(statuses))}`",
        "",
        "| Record | Suspicious imports | Valid coordinates |",
        "|---|---:|---:|",
    ]
    for row in output_rows:
        lines.append(
            f"| `{row['record_id']}` | {len(row['suspicious_imports'])} | {len(row['valid_maven_coordinates'])} |"
        )
    Path(args.output_md).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(output_rows)} registry feedback prompts to {output_jsonl}")


if __name__ == "__main__":
    main()
