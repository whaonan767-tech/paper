import argparse
import json
import os
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


DATASETS = {
    "LLM_Recent": ("LLM_LY.json", "LLM_Recent_Master.json", "Prompts"),
    "LLM_All_Time": ("LLM_AT.json", "LLM_All_Time_Master.json", "Prompts"),
    "Stack_Overflow_Recent": ("SO_LY.json", "Stack_Overflow_Recent_Master.json", "Questions"),
    "Stack_Overflow_All_Time": ("SO_AT.json", "Stack_Overflow_All_Time_Master.json", "Questions"),
}


def read_prompt(value):
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return next(iter(value.values()))
    return str(value)


def read_jsonl_prompts(path, limit):
    prompts = []
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            prompts.append(read_prompt(json.loads(line)))
            if len(prompts) >= limit:
                break
    return prompts


def generate_package_list(tokenizer, model, text, language, mode, max_new_tokens):
    if mode == 1:
        user = (
            f"List the {language} packages required to run the following code or task. "
            f"Do not solve the task and do not write code. "
            f"Return only package names separated by commas, or None if no external package is needed.\n\n{text}"
        )
    else:
        user = (
            f"What {language} packages would be useful for solving the following programming problem? "
            f"Do not solve the problem and do not write code. "
            f"Return only package names separated by commas, or None if no external package is needed.\n\n{text}"
        )

    messages = [
        {
            "role": "system",
            "content": (
                "You recommend software package dependencies. "
                "Return only comma-separated package names. Do not return code or explanations."
            ),
        },
        {"role": "user", "content": user},
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    encoded = tokenizer(rendered, return_tensors="pt").to(model.device)
    input_ids = encoded["input_ids"]

    with torch.inference_mode():
        outputs = model.generate(
            **encoded,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            eos_token_id=tokenizer.eos_token_id,
            pad_token_id=tokenizer.eos_token_id,
        )
    text = tokenizer.decode(outputs[0, input_ids.shape[1] :], skip_special_tokens=True).strip()
    return text if text else "None"


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--language", default="Python")
    parser.add_argument("--limit-per-dataset", type=int, default=2)
    parser.add_argument("--max-new-tokens", type=int, default=48)
    parser.add_argument("--output-dir", default=os.path.join("Tests", "Qwen3B_Smoke_Python"))
    args = parser.parse_args()

    root = Path.cwd()
    data_path = root / "Data" / args.language
    output_dir = root / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    quantization_config = BitsAndBytesConfig(load_in_4bit=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map="auto",
        quantization_config=quantization_config,
        trust_remote_code=True,
    )

    for dataset_name, (input_file, master_file, prompt_column) in DATASETS.items():
        prompts = read_jsonl_prompts(data_path / input_file, args.limit_per_dataset)
        master_rows = []
        packages_1 = []
        packages_2 = []
        for prompt in prompts:
            if prompt_column == "Prompts":
                master_rows.append({"Prompts": prompt, "Answers": prompt})
            else:
                master_rows.append({"Questions": prompt, "Answers": prompt})
            packages_1.append(generate_package_list(tokenizer, model, prompt, args.language, 1, args.max_new_tokens))
            packages_2.append(generate_package_list(tokenizer, model, prompt, args.language, 2, args.max_new_tokens))

        write_jsonl(output_dir / master_file, master_rows)
        write_jsonl(output_dir / f"{dataset_name}_packages_1.json", packages_1)
        write_jsonl(output_dir / f"{dataset_name}_packages_2.json", packages_2)

    print(f"Wrote smoke package-query files to {output_dir}")


if __name__ == "__main__":
    main()
