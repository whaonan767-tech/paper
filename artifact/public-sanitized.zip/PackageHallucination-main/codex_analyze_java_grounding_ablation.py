#!/usr/bin/env python3
"""Ablate Java dependency-grounding sources against the frozen 598-row truth."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_TRUTH = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
    / "full598_final_human_truth.csv"
)
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_GroundingAblation_Run20260812"

VARIANTS = (
    "registry_only",
    "registry_platform",
    "registry_project_source",
    "registry_maven_class_search",
    "full_detector",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--truth-csv", type=Path, default=DEFAULT_TRUTH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20_260_812)
    return parser.parse_args()


def truthy(value: str) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(value for value in values if not math.isnan(value))
    if not ordered:
        return float("nan")
    position = (len(ordered) - 1) * probability
    lower, upper = math.floor(position), math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def predicts_invalid(row: dict[str, str], variant: str) -> bool:
    """Apply a source-availability screen, or retain the frozen full decision.

    The four partial variants start from registry-prefix evidence. Any import
    family not supported by an enabled source is screened as unsupported. This
    deliberately coverage-first policy exposes how each source prevents false
    alarms; it is not presented as a deployable conservative detector.
    """
    if variant == "full_detector":
        return truthy(row.get("detector_suspicious", ""))

    classification = row.get("import_classification", "").strip()
    status = row.get("mapping_status", "").strip()

    if status == "hallucinated_prefix_with_suggestion":
        return True
    if classification.startswith("known_external_dependency:") or status == "mapped_known_prefix":
        return False
    if variant == "registry_platform" and classification == "platform_import":
        return False
    if variant == "registry_project_source" and classification in {
        "provided_context_import",
        "project_local_import",
    }:
        return False
    if variant == "registry_maven_class_search" and status == "mapped_maven_class_search":
        return False
    return True


def confusion(rows: list[dict[str, str]], variant: str) -> dict[str, int]:
    counts = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for row in rows:
        predicted = predicts_invalid(row, variant)
        actual = row["final_validity"].strip().lower() == "invalid"
        key = "tp" if predicted and actual else "fp" if predicted else "fn" if actual else "tn"
        counts[key] += 1
    return counts


def metrics(counts: dict[str, int]) -> dict[str, float]:
    tp, fp, fn = counts["tp"], counts["fp"], counts["fn"]
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else float("nan")
    return {"precision": precision, "recall": recall, "f1": f1}


def source_effects(rows: list[dict[str, str]]) -> dict[str, dict[str, int]]:
    base_flags = {row["full598_index"] for row in rows if predicts_invalid(row, "registry_only")}
    effects: dict[str, dict[str, int]] = {}
    for variant in VARIANTS[1:4]:
        flags = {row["full598_index"] for row in rows if predicts_invalid(row, variant)}
        removed = base_flags - flags
        affected = [row for row in rows if row["full598_index"] in removed]
        effects[variant] = {
            "alerts_avoided": len(affected),
            "false_positives_avoided": sum(row["final_validity"] == "valid" for row in affected),
            "true_positives_lost": sum(row["final_validity"] == "invalid" for row in affected),
        }
    return effects


def project_exclusive_stress(all_rows: list[dict[str, str]]) -> dict[str, object]:
    development_projects = {
        row["project_path"].strip() for row in all_rows if row["audited_in_150_sample"].strip() == "1"
    }
    evaluation_projects = {
        row["project_path"].strip() for row in all_rows if row["audited_in_150_sample"].strip() == "0"
    }
    exclusive_projects = evaluation_projects - development_projects
    selected_all = [
        row
        for row in all_rows
        if row["audited_in_150_sample"].strip() == "0"
        and row["project_path"].strip() in exclusive_projects
    ]
    selected = [row for row in selected_all if row["final_validity"] in {"valid", "invalid"}]
    counts = confusion(selected, "full_detector")
    observed_metrics = metrics(counts)
    serializable_metrics = {
        name: None if math.isnan(value) else value for name, value in observed_metrics.items()
    }
    return {
        "projects": len(exclusive_projects),
        "all_rows": len(selected_all),
        "evaluable_rows": len(selected),
        "confusion": counts,
        "metrics": serializable_metrics,
        "selection_warning": (
            "Post hoc sensitivity subset only. The initial audit intentionally included every original-detector "
            "positive, leaving no detector-positive rows in the 448-row annotation holdout; this is not an "
            "independent classifier test set."
        ),
    }


def main() -> None:
    args = parse_args()
    truth_path = args.truth_csv.resolve()
    output_dir = args.output_dir.resolve()
    with truth_path.open("r", encoding="utf-8-sig", newline="") as handle:
        all_rows = list(csv.DictReader(handle))
    rows = [row for row in all_rows if row["final_validity"] in {"valid", "invalid"}]

    clusters: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        clusters[row["project_path"].strip()].append(row)
    projects = sorted(clusters)
    observed = {variant: confusion(rows, variant) for variant in VARIANTS}
    observed_metrics = {variant: metrics(observed[variant]) for variant in VARIANTS}

    rng = random.Random(args.seed)
    bootstrap: dict[str, dict[str, list[float]]] = {
        variant: {metric: [] for metric in ("precision", "recall", "f1")} for variant in VARIANTS
    }
    for _ in range(args.bootstrap_repetitions):
        sampled_projects = [rng.choice(projects) for _ in projects]
        sampled_rows = [row for project in sampled_projects for row in clusters[project]]
        for variant in VARIANTS:
            result = metrics(confusion(sampled_rows, variant))
            for metric, value in result.items():
                bootstrap[variant][metric].append(value)

    summaries: dict[str, dict[str, object]] = {}
    for variant in VARIANTS:
        summaries[variant] = {
            "confusion": observed[variant],
            "metrics": {
                metric: {
                    "estimate": observed_metrics[variant][metric],
                    "ci_low": percentile(bootstrap[variant][metric], 0.025),
                    "ci_high": percentile(bootstrap[variant][metric], 0.975),
                }
                for metric in ("precision", "recall", "f1")
            },
        }

    payload = {
        "analysis": "java_grounding_source_ablation",
        "scope": {
            "all_extracted_rows": len(all_rows),
            "valid_invalid_rows": len(rows),
            "projects": len(projects),
            "raw_response_extraction_recall_evaluated": False,
        },
        "design": (
            "Partial variants are coverage-first source-availability screens: an import not supported by an "
            "enabled source is flagged. The full row is the frozen conservative detector decision."
        ),
        "variants": summaries,
        "source_effects_relative_to_registry_only": source_effects(rows),
        "project_exclusive_posthoc_stress": project_exclusive_stress(all_rows),
        "bootstrap": {
            "repetitions": args.bootstrap_repetitions,
            "seed": args.seed,
            "resampling_unit": "project_path",
            "interval": "two-sided 95% percentile",
        },
        "truth_csv_sha256": sha256(truth_path),
        "script_sha256": sha256(Path(__file__).resolve()),
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "java_grounding_ablation.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    csv_rows = []
    for variant in VARIANTS:
        item = summaries[variant]
        row: dict[str, object] = {"variant": variant, **item["confusion"]}
        for metric, value in item["metrics"].items():
            row[metric] = value["estimate"]
            row[f"{metric}_ci_low"] = value["ci_low"]
            row[f"{metric}_ci_high"] = value["ci_high"]
        csv_rows.append(row)
    with (output_dir / "java_grounding_ablation.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(csv_rows[0]))
        writer.writeheader()
        writer.writerows(csv_rows)

    labels = {
        "registry_only": "Registry only",
        "registry_platform": "Registry + platform",
        "registry_project_source": "Registry + project source",
        "registry_maven_class_search": "Registry + Maven class search",
        "full_detector": "Full detector",
    }
    lines = [
        "# Java Grounding-Source Ablation",
        "",
        f"- Scope: `{len(rows)}` valid/invalid extracted rows from `{len(projects)}` projects.",
        "- Partial variants are coverage-first source-availability screens; the full row retains the frozen conservative detector decision.",
        "- This analysis begins after extraction and does not estimate raw-response extraction recall.",
        "",
        "| Variant | TP | FP | FN | TN | Precision | Recall | F1 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for variant in VARIANTS:
        item = summaries[variant]
        count = item["confusion"]
        metric = item["metrics"]
        lines.append(
            f"| {labels[variant]} | {count['tp']} | {count['fp']} | {count['fn']} | {count['tn']} | "
            f"{metric['precision']['estimate']:.3f} | {metric['recall']['estimate']:.3f} | "
            f"{metric['f1']['estimate']:.3f} |"
        )
    lines.extend(["", "## Independent Source Effects", "", "| Added source | FP avoided | TP lost |", "|---|---:|---:|"])
    for variant, effect in payload["source_effects_relative_to_registry_only"].items():
        lines.append(
            f"| {labels[variant]} | {effect['false_positives_avoided']} | {effect['true_positives_lost']} |"
        )
    stress = payload["project_exclusive_posthoc_stress"]
    stress_metrics = stress["metrics"]
    lines.extend(
        [
            "",
            "## Project-Exclusive Post Hoc Stress Subset",
            "",
            f"- `{stress['projects']}` evaluation-only projects, `{stress['evaluable_rows']}` evaluable rows.",
            f"- Confusion: `{stress['confusion']}`; recall `{stress_metrics['recall']:.3f}`; precision is undefined when no rows are flagged.",
            f"- Warning: {stress['selection_warning']}",
        ]
    )
    (output_dir / "java_grounding_ablation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
