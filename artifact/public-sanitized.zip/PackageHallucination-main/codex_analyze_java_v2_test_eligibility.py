#!/usr/bin/env python3
"""Cross-check V2 compilation passes against nonzero-test baseline units."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_V2 = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedSemanticBuild_EvidenceFull83_Run20260803"
    / "masked_evidence_build.json"
)
DEFAULT_TESTS = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedRealTestBaseline_Full58_Run20260804"
    / "masked_test_baseline.json"
)
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_V2RealTestEligibility_Run20260804"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--v2-json", type=Path, default=DEFAULT_V2)
    parser.add_argument("--test-baseline-json", type=Path, default=DEFAULT_TESTS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    args = parse_args()
    v2_path = args.v2_json.resolve()
    test_path = args.test_baseline_json.resolve()
    output_dir = args.output_dir.resolve()
    v2_payload = json.loads(v2_path.read_text(encoding="utf-8"))
    test_payload = json.loads(test_path.read_text(encoding="utf-8"))

    v2_passes = [row for row in v2_payload["results"] if int(row["return_code"]) == 0]
    eligible_units = [
        row
        for row in test_payload["results"]
        if int(row["return_code"]) == 0 and int(row["tests"]) > 0
    ]
    eligible_by_key = {row["build_key"]: row for row in eligible_units}
    rows = []
    for row in v2_passes:
        baseline = eligible_by_key.get(row["build_key"])
        rows.append(
            {
                "record_id": row["record_id"],
                "project_path": row["project_path"],
                "build_key": row["build_key"],
                "source_set": row["source_set"],
                "v2_test_compile_pass": True,
                "nonzero_test_baseline_eligible": baseline is not None,
                "baseline_tests": int(baseline["tests"]) if baseline else 0,
                "baseline_skipped": int(baseline["skipped"]) if baseline else 0,
            }
        )

    overlap = [row for row in rows if row["nonzero_test_baseline_eligible"]]
    summary = {
        "v2_test_compile_pass_records": len(v2_passes),
        "v2_test_compile_pass_build_units": len({row["build_key"] for row in v2_passes}),
        "v2_test_compile_pass_projects": len({row["project_path"] for row in v2_passes}),
        "passing_nonzero_test_baseline_units": len(eligible_units),
        "passing_nonzero_test_baseline_projects": len({row["project_path"] for row in eligible_units}),
        "overlap_records": len(overlap),
        "overlap_build_units": len({row["build_key"] for row in overlap}),
        "overlap_projects": len({row["project_path"] for row in overlap}),
        "v2_real_test_rate_estimable": bool(overlap),
    }
    payload = {
        "analysis": "v2_compilation_pass_nonzero_test_eligibility",
        "summary": summary,
        "interpretation": (
            "No V2 real-test rate is estimable because none of the V2 test-compilation-pass "
            "records belongs to a build unit with a passing nonzero-test baseline."
            if not overlap
            else "The overlap records require execution of their V2 variants before reporting test outcomes."
        ),
        "metadata": {
            "v2_json_sha256": sha256(v2_path),
            "test_baseline_json_sha256": sha256(test_path),
            "script_sha256": sha256(Path(__file__).resolve()),
        },
        "v2_pass_records": rows,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "v2_real_test_eligibility.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with (output_dir / "v2_real_test_eligibility.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        "# V2 Real-Test Eligibility",
        "",
        f"- V2 test-compilation passes: `{summary['v2_test_compile_pass_records']}` records, `{summary['v2_test_compile_pass_build_units']}` build units, `{summary['v2_test_compile_pass_projects']}` projects.",
        f"- Passing nonzero-test baselines: `{summary['passing_nonzero_test_baseline_units']}` build units, `{summary['passing_nonzero_test_baseline_projects']}` projects.",
        f"- Intersection: `{summary['overlap_records']}` records, `{summary['overlap_build_units']}` build units, `{summary['overlap_projects']}` projects.",
        f"- V2 real-test rate estimable: `{str(summary['v2_real_test_rate_estimable']).lower()}`.",
    ]
    if not overlap:
        lines.extend(["", "Neither the 14 V2 test-compilation-valid records nor the three structured end-to-end passes yields an eligible nonzero-test evaluation set."])
    (output_dir / "v2_real_test_eligibility.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
