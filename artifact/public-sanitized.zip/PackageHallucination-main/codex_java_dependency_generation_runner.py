import argparse
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedTokenizerFast

try:
    from transformers import BitsAndBytesConfig
except ImportError:  # pragma: no cover
    BitsAndBytesConfig = None


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def read_jsonl(path):
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                yield row


def write_jsonl_line(handle, value):
    json.dump(value, handle, ensure_ascii=False)
    handle.write("\n")
    handle.flush()


def load_tokenizer(args):
    if args.tokenizer_file_backend:
        model_path = Path(args.model_path)
        tokenizer_config_path = model_path / "tokenizer_config.json"
        tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=str(model_path / "tokenizer.json"),
            bos_token="<｜begin▁of▁sentence｜>",
            eos_token="<|EOT|>",
            pad_token="<｜end▁of▁sentence｜>",
        )
        if tokenizer_config_path.exists():
            config = json.loads(tokenizer_config_path.read_text(encoding="utf-8"))
            if config.get("chat_template"):
                tokenizer.chat_template = config["chat_template"]
        return tokenizer
    tokenizer_kwargs = {"trust_remote_code": args.trust_remote_code}
    if args.local_files_only:
        tokenizer_kwargs["local_files_only"] = True
    return AutoTokenizer.from_pretrained(args.model_path, **tokenizer_kwargs)


def load_model(args):
    tokenizer = load_tokenizer(args)
    model_kwargs = {
        "trust_remote_code": args.trust_remote_code,
    }
    if args.device_map:
        if args.device_map in {"cuda:0", "gpu0"}:
            model_kwargs["device_map"] = {"": 0}
        elif args.device_map == "none":
            pass
        else:
            model_kwargs["device_map"] = args.device_map
    if args.local_files_only:
        model_kwargs["local_files_only"] = True
    if args.low_cpu_mem_usage:
        model_kwargs["low_cpu_mem_usage"] = True
    if args.attn_implementation:
        model_kwargs["attn_implementation"] = args.attn_implementation
    if args.disable_mmap:
        model_kwargs["disable_mmap"] = True
    if args.use_safetensors:
        model_kwargs["use_safetensors"] = {"true": True, "false": False}[args.use_safetensors]
    if args.dtype:
        dtype_map = {
            "auto": "auto",
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
            "float32": torch.float32,
        }
        model_kwargs["dtype"] = dtype_map[args.dtype]
    if args.max_gpu_memory or args.max_cpu_memory:
        max_memory = {}
        if args.max_gpu_memory:
            max_memory[0] = args.max_gpu_memory
        if args.max_cpu_memory:
            max_memory["cpu"] = args.max_cpu_memory
        model_kwargs["max_memory"] = max_memory
    if args.load_in_4bit and args.load_in_8bit:
        raise RuntimeError("--load-in-4bit and --load-in-8bit are mutually exclusive")
    if args.load_in_4bit:
        if BitsAndBytesConfig is None:
            raise RuntimeError("BitsAndBytesConfig is unavailable but --load-in-4bit was set")
        quant_kwargs = {"load_in_4bit": True}
        if args.quant_compute_dtype:
            quant_kwargs["bnb_4bit_compute_dtype"] = {
                "bfloat16": torch.bfloat16,
                "float16": torch.float16,
                "float32": torch.float32,
            }[args.quant_compute_dtype]
        model_kwargs["quantization_config"] = BitsAndBytesConfig(**quant_kwargs)
    if args.load_in_8bit:
        if BitsAndBytesConfig is None:
            raise RuntimeError("BitsAndBytesConfig is unavailable but --load-in-8bit was set")
        model_kwargs["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)
    model = AutoModelForCausalLM.from_pretrained(args.model_path, **model_kwargs)
    return tokenizer, model


def render_messages(tokenizer, prompt, include_system_message=True):
    messages = []
    if include_system_message:
        messages.append(
            {
                "role": "system",
                "content": (
                    "You are a Java build and dependency assistant. Follow the requested output "
                    "structure and do not add unrelated prose."
                ),
            }
        )
    messages.append({"role": "user", "content": prompt})
    rendered = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    return tokenizer(rendered, return_tensors="pt")


def generation_args(args):
    if args.do_sample:
        return {
            "do_sample": True,
            "temperature": args.temperature,
            "top_p": args.top_p,
            "top_k": args.top_k,
        }
    return {"do_sample": False}


def generate_text(tokenizer, model, prompt, max_new_tokens, gen_args, include_system_message=True):
    encoded = render_messages(tokenizer, prompt, include_system_message=include_system_message).to(model.device)
    input_ids = encoded["input_ids"]
    start = time.perf_counter()
    with torch.inference_mode():
        output = model.generate(
            **encoded,
            max_new_tokens=max_new_tokens,
            eos_token_id=tokenizer.eos_token_id,
            pad_token_id=tokenizer.eos_token_id,
            return_dict_in_generate=True,
            **gen_args,
        )
    elapsed_ms = (time.perf_counter() - start) * 1000
    generated_ids = output.sequences[0, input_ids.shape[1] :]
    token_count = int(generated_ids.shape[0])
    eos_emitted = bool(
        token_count and int(generated_ids[-1].item()) == int(tokenizer.eos_token_id)
    )
    finish_reason = "eos" if eos_emitted else (
        "length" if token_count >= max_new_tokens else "other"
    )
    text = tokenizer.decode(generated_ids, skip_special_tokens=True).strip()
    return text, elapsed_ms, token_count, finish_reason, eos_emitted


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-jsonl", required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--model-label", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--max-new-tokens", type=int, default=384)
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--quant-compute-dtype", choices=["bfloat16", "float16", "float32"], default="")
    parser.add_argument("--dtype", choices=["auto", "bfloat16", "float16", "float32"], default="")
    parser.add_argument("--device-map", default="auto")
    parser.add_argument("--max-gpu-memory", default="")
    parser.add_argument("--max-cpu-memory", default="")
    parser.add_argument("--local-files-only", action="store_true")
    parser.add_argument("--trust-remote-code", action="store_true", default=True)
    parser.add_argument("--no-trust-remote-code", dest="trust_remote_code", action="store_false")
    parser.add_argument("--low-cpu-mem-usage", action="store_true")
    parser.add_argument("--disable-mmap", action="store_true")
    parser.add_argument("--use-safetensors", choices=["true", "false"], default="")
    parser.add_argument("--attn-implementation", default="")
    parser.add_argument("--no-system-message", action="store_true")
    parser.add_argument("--tokenizer-file-backend", action="store_true")
    parser.add_argument("--do-sample", action="store_true")
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--top-k", type=int, default=20)
    args = parser.parse_args()

    input_path = Path(args.input_jsonl)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_rows = list(read_jsonl(input_path))
    rows = all_rows[args.offset : args.offset + args.limit]
    metadata = {
        "started_at": utc_now(),
        "argv": sys.argv,
        "input_jsonl": str(input_path),
        "model_path": args.model_path,
        "model_label": args.model_label,
        "offset": args.offset,
        "limit": args.limit,
        "records": len(rows),
        "max_new_tokens": args.max_new_tokens,
        "load_in_4bit": args.load_in_4bit,
        "load_in_8bit": args.load_in_8bit,
        "quant_compute_dtype": args.quant_compute_dtype,
        "dtype": args.dtype,
        "device_map": args.device_map,
        "max_gpu_memory": args.max_gpu_memory,
        "max_cpu_memory": args.max_cpu_memory,
        "local_files_only": args.local_files_only,
        "trust_remote_code": args.trust_remote_code,
        "low_cpu_mem_usage": args.low_cpu_mem_usage,
        "disable_mmap": args.disable_mmap,
        "use_safetensors": args.use_safetensors,
        "attn_implementation": args.attn_implementation,
        "include_system_message": not args.no_system_message,
        "tokenizer_file_backend": args.tokenizer_file_backend,
        "generation": generation_args(args),
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    }
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    tokenizer, model = load_model(args)
    gen_args = generation_args(args)

    response_path = output_dir / "responses.jsonl"
    with response_path.open("w", encoding="utf-8", newline="\n") as handle:
        for index, row in enumerate(rows, 1):
            response, elapsed_ms, generated_token_count, finish_reason, eos_emitted = generate_text(
                tokenizer,
                model,
                row["prompt"],
                args.max_new_tokens,
                gen_args,
                include_system_message=not args.no_system_message,
            )
            out = {
                "record_id": row.get("record_id", f"row_{row['_line_no']}"),
                "source_line": row.get("source_line", row["_line_no"]),
                "dataset": row.get("dataset", ""),
                "split": row.get("split", ""),
                "task": row.get("task", ""),
                "project_path": row.get("project_path", ""),
                "project_id": row.get("project_id", ""),
                "project_owner": row.get("project_owner", ""),
                "project_commit": row.get("project_commit", ""),
                "file_path": row.get("file_path", ""),
                "project_relative_path": row.get("project_relative_path", ""),
                "relative_file_path": row.get("relative_file_path", ""),
                "module_pom": row.get("module_pom", ""),
                "target_api_family": row.get("target_api_family", ""),
                "ground_truth": row.get("ground_truth", ""),
                "ground_truth_import": row.get("ground_truth_import", ""),
                "source_sha256": row.get("source_sha256", ""),
                "prompt": row.get("prompt", ""),
                "response": response,
                "elapsed_ms": elapsed_ms,
                "generated_token_count_including_eos": generated_token_count,
                "finish_reason": finish_reason,
                "eos_emitted": eos_emitted,
            }
            write_jsonl_line(handle, out)
            print(f"{index}/{len(rows)} {out['record_id']} generated={elapsed_ms:.0f}ms")

    metadata["finished_at"] = utc_now()
    metadata["responses_jsonl"] = str(response_path)
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote Java dependency generations to {response_path}")


if __name__ == "__main__":
    main()
