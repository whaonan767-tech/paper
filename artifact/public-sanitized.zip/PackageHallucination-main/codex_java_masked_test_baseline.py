#!/usr/bin/env python3
"""Run real test baselines for V0-passing masked-import build units."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime
from pathlib import Path

import codex_java_masked_baseline_audit as baseline


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803" / "masked_baseline_audit.json"
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
DEFAULT_WORK = WORKSPACE / "vw" / "masked_test_baseline"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--output-root", type=Path, default=ROOT / "Tests")
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-status", action="append", default=[])
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def test_command(command: list[str]) -> list[str]:
    cleaned = [
        value for value in command
        if value not in {"-DskipTests", "-DskipTests=true", "-Dmaven.test.skip=true", "-Dmaven.test.skip=false"}
    ]
    cleaned.insert(1, "-Dmaven.test.skip=false")
    cleaned.insert(2, "-DskipTests=false")
    if cleaned[-1] == "test-compile":
        cleaned[-1] = "test"
    if cleaned[-1] == "test" and "clean" not in cleaned:
        cleaned.insert(len(cleaned) - 1, "clean")
    return cleaned


def count_tests(project: Path) -> dict:
    totals = Counter({"tests": 0, "failures": 0, "errors": 0, "skipped": 0, "unreadable_reports": 0})
    files = []
    for path in project.rglob("TEST-*.xml"):
        if path.parent.name != "surefire-reports":
            continue
        try:
            root = ET.parse(path).getroot()
            totals["tests"] += int(float(root.attrib.get("tests", 0)))
            totals["failures"] += int(float(root.attrib.get("failures", 0)))
            totals["errors"] += int(float(root.attrib.get("errors", 0)))
            totals["skipped"] += int(float(root.attrib.get("skipped", 0)))
            files.append(str(path.relative_to(project)).replace("\\", "/"))
        except (ET.ParseError, OSError, ValueError):
            totals["unreadable_reports"] += 1
    return {**totals, "report_files": files, "report_file_count": len(files)}


def summarize(units: list[dict], results: list[dict]) -> dict:
    with_tests = [row for row in results if row["status"] == "pass" and row["tests"] > 0]
    return {
        "eligible_units": len(units),
        "eligible_projects": len({row["project_path"] for row in units}),
        "completed_units": len(results),
        "build_pass_units": sum(row["status"] == "pass" for row in results),
        "pass_with_tests_units": len(with_tests),
        "pass_zero_tests_units": sum(row["status"] == "pass" and row["tests"] == 0 for row in results),
        "projects_with_executed_tests": len({row["project_path"] for row in with_tests}),
        "tests": sum(row["tests"] for row in with_tests),
        "failures": sum(row["failures"] for row in with_tests),
        "errors": sum(row["errors"] for row in with_tests),
        "skipped": sum(row["skipped"] for row in with_tests),
        "status_counts": dict(Counter(row["status"] for row in results)),
        "failure_detail_counts": dict(Counter(row["failure_detail"] for row in results if row["status"] != "pass")),
        "duration_seconds": round(sum(float(row["duration_seconds"]) for row in results), 3),
    }


def write_outputs(output_dir: Path, run_name: str, units: list[dict], results: list[dict], metadata: dict) -> None:
    summary = summarize(units, results)
    payload = {"run_name": run_name, "phase": "original_project_real_test_baseline", "summary": summary, "metadata": metadata, "results": results}
    (output_dir / "masked_test_baseline.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["build_key", "project_path", "build_root", "record_count", "record_ids", "selected_java_home", "status", "failure_detail", "tests", "failures", "errors", "skipped", "report_file_count", "report_files", "return_code", "timed_out", "duration_seconds", "command", "log_path"]
    csv_rows = [{**row, "record_ids": ";".join(row["record_ids"]), "report_files": ";".join(row["report_files"])} for row in results]
    with (output_dir / "masked_test_baseline.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(csv_rows)
    lines = [
        "# Real-Test Baseline for Masked-Import Build Units", "",
        f"- Eligible V0-passing units: `{summary['eligible_units']}` from `{summary['eligible_projects']}` projects.",
        f"- Completed: `{summary['completed_units']}`.",
        f"- Build passes: `{summary['build_pass_units']}/{summary['eligible_units']}`.",
        f"- Passes with at least one executed test: `{summary['pass_with_tests_units']}/{summary['eligible_units']}` across `{summary['projects_with_executed_tests']}` projects.",
        f"- Aggregate Surefire counts on those units: tests `{summary['tests']}`, failures `{summary['failures']}`, errors `{summary['errors']}`, skipped `{summary['skipped']}`.",
        f"- Passes with zero detected Surefire tests: `{summary['pass_zero_tests_units']}`.",
    ]
    (output_dir / "masked_test_baseline.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    baseline_path = args.baseline.resolve()
    payload = json.loads(baseline_path.read_text(encoding="utf-8"))
    passing = [row for row in payload["results"] if row["status"] == "pass"]
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_build = {validation.project_build_key(row): row for row in audit_payload["samples"]}
    units = []
    for row in passing:
        audit = audit_by_build[row["build_key"]]
        units.append({**row, "audit": audit, "record_ids": row["record_ids"].split(";")})
    units.sort(key=lambda row: row["build_key"])
    if args.limit:
        units = units[: args.limit]
    jdk_homes = {row["label"]: (None if row["home"] == "system" else row["home"]) for row in payload["metadata"]["java_matrix"]}
    run_name = args.run_name or datetime.now().strftime("Java_APIHulBench_MaskedRealTestBaseline_Run%Y%m%d_%H%M%S")
    output_dir = args.output_root.resolve() / run_name
    work_root = args.work_root.resolve() / ("run_" + hashlib.sha256(run_name.encode()).hexdigest()[:10])
    output_json = output_dir / "masked_test_baseline.json"
    if args.resume:
        previous = json.loads(output_json.read_text(encoding="utf-8")); results = previous.get("results", [])
        if args.retry_status:
            retry = set(args.retry_status); results = [row for row in results if row["status"] not in retry]
    else:
        if output_dir.exists() or work_root.exists(): raise SystemExit(f"Run path exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True); work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"; logs_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = work_root / "tmp"; temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(temp_dir); os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}").strip()
    metadata = {"baseline_sha256": baseline.sha256(baseline_path), "script_sha256": baseline.sha256(Path(__file__).resolve()), "timeout_seconds": args.timeout, "goal": "clean test", "tests_must_be_detected_for_semantic_denominator": True, "jdk_homes": jdk_homes}
    write_outputs(output_dir, run_name, units, results, metadata)
    completed = {row["build_key"] for row in results}
    for index, unit in enumerate(units, 1):
        if unit["build_key"] in completed: continue
        original_project = validation.normalize_workspace_path(unit["project_path"])
        copied_project = work_root / f"u{index:03d}"
        copy_log = logs_dir / f"unit_{index:03d}_copy.log"
        print(f"[{index}/{len(units)}] COPY {unit['build_key']}", flush=True)
        copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
        command = []; test_counts = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0, "report_file_count": 0, "report_files": []}
        if not copied:
            outcome = {"status": "project_copy_failed", "failure_detail": "project_copy_failed", "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": validation.display_path(copy_log), "tail": copy_error}
        else:
            try:
                plan = validation.build_plan(unit["audit"], copied_project)
                command = test_command(plan["command"])
                java_value = jdk_homes[unit["selected_java_home"]]; java_home = Path(java_value) if java_value else None
                log_path = logs_dir / f"unit_{index:03d}_test.log"
                print(f"[{index}/{len(units)}] TEST {unit['selected_java_home']}", flush=True)
                outcome = validation.run_build(command, plan["cwd"], args.timeout, log_path, java_home)
                if "maven" in unit["build_system"] and validation.should_retry_local_maven(outcome):
                    retry_plan = validation.build_plan(unit["audit"], copied_project, force_local=True)
                    retry_command = test_command(retry_plan["command"])
                    retry_log = logs_dir / f"unit_{index:03d}_test_local_retry.log"
                    outcome = validation.run_build(retry_command, retry_plan["cwd"], args.timeout, retry_log, java_home)
                    command, log_path = retry_command, retry_log
                test_counts = count_tests(copied_project)
            except Exception as error:
                outcome = {"status": "mutation_error", "failure_detail": str(error), "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
            if not args.keep_workdirs and copied_project.exists(): baseline.safe_remove_tree(copied_project, work_root)
        results.append({"build_key": unit["build_key"], "project_path": unit["project_path"], "build_root": unit["build_root"], "record_count": unit["record_count"], "record_ids": unit["record_ids"], "selected_java_home": unit["selected_java_home"], "command": " ".join(command), **test_counts, **outcome})
        write_outputs(output_dir, run_name, units, results, metadata)
    if not args.keep_workdirs and temp_dir.exists(): baseline.safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
