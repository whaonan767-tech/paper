#!/usr/bin/env python3
"""Run a bounded real-test behavior probe for detector-flagged imports."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import codex_java_masked_baseline_audit as baseline_audit
import codex_java_masked_test_baseline as test_baseline


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
DEFAULT_CANDIDATES = ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731" / "full598_final_human_truth.csv"
DEFAULT_BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedRealTestBaseline_Full58_Run20260804" / "masked_test_baseline.json"
DEFAULT_BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
DEFAULT_OUTPUT = ROOT / "Tests"
DEFAULT_WORK = WORKSPACE / "vw" / "sanitizer_real_test_probe"


def load_validation_module() -> object:
    module_path = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "experiments" / "validate_java_builds.py"
    spec = importlib.util.spec_from_file_location("validate_java_builds_real_test_probe", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates", type=Path, default=DEFAULT_CANDIDATES)
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--build-audit", type=Path, default=DEFAULT_BUILD_AUDIT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK)
    parser.add_argument("--run-name", required=True)
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--record-id", action="append", default=[])
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def sample_key(record_id: str) -> str:
    match = re.search(r"APIHulBench_([FM])_(\d+)$", record_id)
    if not match:
        raise ValueError(f"Cannot derive sample key from {record_id}")
    return f"{match.group(1)}:{int(match.group(2)) + 1}"


def insert_imports(source: str, imports: list[str]) -> tuple[str, list[str]]:
    existing = set(re.findall(r"(?m)^\s*import\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;", source))
    to_add = [value for value in imports if value and value not in existing]
    if not to_add:
        return source, []
    insertion = "".join(f"import {value};\n" for value in to_add)
    package_match = re.search(r"(?m)^\s*package\s+[A-Za-z_][\w.]*\s*;\s*(?:\r?\n)?", source)
    if package_match:
        return source[: package_match.end()] + insertion + source[package_match.end() :], to_add
    return insertion + source, to_add


def sanitize_source(source: str, imports: list[str]) -> tuple[str, list[dict]]:
    text = source
    actions = []
    for import_path in imports:
        pattern = re.compile(rf"(?m)^[ \t]*import\s+(static\s+)?{re.escape(import_path)}\s*;?[ \t]*(?:\r?\n|$)")
        text, removed = pattern.subn("", text)
        actions.append({"import_path": import_path, "removed_import_lines": removed, "residual_exact_string": import_path in text})
    return text, actions


def locate_target(copied_project: Path, original_project: Path, original_file: Path) -> Path:
    relative = original_file.relative_to(original_project)
    target = copied_project / relative
    if target.exists():
        return target
    matches = sorted(copied_project.rglob(original_file.name))
    if not matches:
        raise FileNotFoundError(target)
    return matches[0]


def count_tests(project: Path) -> dict:
    return test_baseline.count_tests(project)


def outcome_row(unit: dict, variant: str, result: dict, counts: dict, injected: list[str], actions: list[dict], command: list[str]) -> dict:
    return {
        "build_key": unit["build_key"],
        "project_path": unit["project_path"],
        "build_root": unit["build_root"],
        "record_ids": unit["record_ids"],
        "variant": variant,
        "injected_imports": injected,
        "sanitizer_actions": actions,
        "command": " ".join(command),
        **counts,
        **result,
    }


def main() -> None:
    args = parse_args()
    output_dir = (args.output_root.resolve() / args.run_name)
    work_root = args.work_root.resolve() / ("run_" + hashlib.sha256(args.run_name.encode()).hexdigest()[:10])
    if output_dir.exists() or work_root.exists():
        raise SystemExit(f"Run path exists: {output_dir} or {work_root}")
    output_dir.mkdir(parents=True)
    logs = output_dir / "logs"
    logs.mkdir()
    work_root.mkdir(parents=True)

    validation = load_validation_module()
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    baseline_rows = [row for row in baseline_payload["results"] if row.get("status") == "pass" and int(row.get("tests", 0)) > 0 and int(row.get("failures", 0)) == 0 and int(row.get("errors", 0)) == 0]
    baseline_by_key = {row["build_key"]: row for row in baseline_rows}
    build_audit = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_sample = {row["sample_key"]: row for row in build_audit["samples"]}

    selected = []
    with args.candidates.resolve().open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("detector_suspicious") != "1" or row.get("final_validity") != "invalid":
                continue
            if args.record_id and row.get("original_record_id") not in set(args.record_id):
                continue
            audit = audit_by_sample.get(sample_key(row["original_record_id"]))
            if not audit:
                continue
            build_key = validation.project_build_key(audit)
            if build_key not in baseline_by_key:
                continue
            selected.append({"candidate": row, "audit": audit, "baseline": baseline_by_key[build_key], "build_key": build_key})
    if not selected:
        raise SystemExit("No detector-invalid rows overlap passing nonzero-test baseline units")

    grouped = defaultdict(list)
    for row in selected:
        grouped[row["build_key"]].append(row)
    results = []
    unit_summaries = []
    for unit_index, (build_key, rows) in enumerate(sorted(grouped.items()), start=1):
        first = rows[0]
        audit = first["audit"]
        original_project = validation.normalize_workspace_path(audit["project_path"])
        copied_project = work_root / f"u{unit_index:03d}"
        copy_log = logs / f"unit_{unit_index:03d}_copy.log"
        copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
        if not copied:
            raise RuntimeError(f"Project copy failed for {build_key}: {copy_error}")
        plan = validation.build_plan(audit, copied_project)
        command = test_baseline.test_command(plan["command"])
        jdk_label = first["baseline"].get("selected_java_home", "")
        java_value = baseline_payload["metadata"].get("jdk_homes", {}).get(jdk_label)
        java_home = Path(java_value) if java_value else None
        unit_rows = []
        try:
            baseline_log = logs / f"unit_{unit_index:03d}_baseline.log"
            baseline_result = validation.run_build(command, plan["cwd"], args.timeout, baseline_log, java_home)
            baseline_counts = count_tests(copied_project)
            unit_rows.append(outcome_row({**audit, "build_key": build_key, "record_ids": first["baseline"].get("record_ids", [])}, "original_baseline", baseline_result, baseline_counts, [], [], command))
            for row_index, item in enumerate(rows, start=1):
                candidate = item["candidate"]
                original_file = validation.normalize_workspace_path(candidate["file_path"])
                target = locate_target(copied_project, original_project, original_file)
                original_source = target.read_text(encoding="utf-8", errors="replace")
                imports = [candidate["import_path"]]
                raw_source, injected = insert_imports(original_source, imports)
                sanitized_source, actions = sanitize_source(raw_source, injected)
                if sanitized_source != original_source:
                    raise AssertionError(f"Sanitizer did not restore original source for {candidate['original_record_id']}")
                for variant, source in (("raw_injected", raw_source), ("sanitized", sanitized_source)):
                    target.write_text(source, encoding="utf-8", newline="\n")
                    log_path = logs / f"unit_{unit_index:03d}_{row_index:02d}_{candidate['original_record_id']}_{variant}.log"
                    result = validation.run_build(command, plan["cwd"], args.timeout, log_path, java_home)
                    counts = count_tests(copied_project)
                    unit_rows.append(outcome_row({**audit, "build_key": build_key, "record_ids": [candidate["original_record_id"]]}, variant, result, counts, injected, actions if variant == "sanitized" else [], command))
                    target.write_text(original_source, encoding="utf-8", newline="\n")
            results.extend(unit_rows)
            unit_summaries.append({"build_key": build_key, "record_ids": [item["candidate"]["original_record_id"] for item in rows], "baseline": unit_rows[0], "raw_injected": [item for item in unit_rows if item["variant"] == "raw_injected"], "sanitized": [item for item in unit_rows if item["variant"] == "sanitized"]})
        finally:
            target_cleanup = copied_project
            if not args.keep_workdirs and target_cleanup.exists():
                baseline_audit.safe_remove_tree(target_cleanup, work_root)

    summary = {
        "selected_invalid_records": len(selected),
        "selected_build_units": len(grouped),
        "selected_projects": len({item["audit"]["project_path"] for item in selected}),
        "baseline_units_with_nonzero_tests": sum(1 for row in results if row["variant"] == "original_baseline" and row["status"] == "pass" and row["tests"] > 0 and row["failures"] == 0 and row["errors"] == 0),
        "raw_injected_failures": sum(1 for row in results if row["variant"] == "raw_injected" and row["status"] != "pass"),
        "sanitized_passes_with_nonzero_tests": sum(1 for row in results if row["variant"] == "sanitized" and row["status"] == "pass" and row["tests"] > 0 and row["failures"] == 0 and row["errors"] == 0),
        "sanitized_total_tests": sum(int(row["tests"]) for row in results if row["variant"] == "sanitized"),
        "sanitized_total_failures": sum(int(row["failures"]) for row in results if row["variant"] == "sanitized"),
        "sanitized_total_errors": sum(int(row["errors"]) for row in results if row["variant"] == "sanitized"),
        "raw_injected_total_tests": sum(int(row["tests"]) for row in results if row["variant"] == "raw_injected"),
    }
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": "Original baseline -> add one frozen detector-flagged invalid import -> run clean test -> remove exactly that import with the frozen sanitizer -> run clean test.",
        "candidate_sha256": sha256(args.candidates.resolve()),
        "baseline_sha256": sha256(args.baseline.resolve()),
        "build_audit_sha256": sha256(args.build_audit.resolve()),
        "script_sha256": sha256(Path(__file__).resolve()),
        "test_command_script_sha256": sha256(ROOT / "codex_java_masked_test_baseline.py"),
        "sanitizer_script_sha256": sha256(ROOT / "codex_apply_java_dependency_sanitizer.py"),
        "timeout_seconds": args.timeout,
        "selected_rows": [{"record_id": item["candidate"]["original_record_id"], "project_path": item["audit"]["project_path"], "build_key": item["build_key"], "import_path": item["candidate"]["import_path"]} for item in selected],
        "interpretation": "This is real-test behavior preservation for detector-flagged invalid imports, not evidence that generated replacement code is functionally correct.",
    }
    payload = {"run_name": args.run_name, "summary": summary, "metadata": metadata, "units": unit_summaries, "results": results}
    (output_dir / "sanitizer_real_test_probe.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with (output_dir / "sanitizer_real_test_probe.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["build_key", "project_path", "build_root", "record_ids", "variant", "injected_imports", "sanitizer_actions", "command", "status", "failure_detail", "return_code", "timed_out", "duration_seconds", "tests", "failures", "errors", "skipped", "report_file_count", "report_files", "log_path", "tail"]
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in results:
            writer.writerow({**row, "record_ids": ";".join(row.get("record_ids", [])), "injected_imports": ";".join(row.get("injected_imports", [])), "sanitizer_actions": json.dumps(row.get("sanitizer_actions", []), ensure_ascii=False), "report_files": ";".join(row.get("report_files", []))})
    lines = [
        "# Real-Test Sanitizer Behavior Probe",
        "",
        f"- Detector-invalid records overlapping passing nonzero-test units: `{summary['selected_invalid_records']}`.",
        f"- Build units / projects: `{summary['selected_build_units']}` / `{summary['selected_projects']}`.",
        f"- Raw injected variants failing: `{summary['raw_injected_failures']}`.",
        f"- Sanitized variants passing with nonzero tests: `{summary['sanitized_passes_with_nonzero_tests']}`.",
        f"- Sanitized tests / failures / errors: `{summary['sanitized_total_tests']}` / `{summary['sanitized_total_failures']}` / `{summary['sanitized_total_errors']}`.",
        "",
        "The sanitized variant restores the original source after removing exactly the frozen detector-flagged import. This supports bounded behavior-preservation evidence, not full generated-code functional correctness.",
    ]
    (output_dir / "sanitizer_real_test_probe.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "summary": summary}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
