#!/usr/bin/env python3
"""Conservative source/registry-grounded classifier for V2 dependency mentions."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path


PLATFORM_PREFIXES = ("java.", "javax.", "jakarta.", "jdk.", "sun.")
KNOWN_EXTERNAL_PREFIXES = (
    "org.junit.", "org.slf4j.", "org.apache.logging.log4j.", "org.springframework.",
    "com.fasterxml.jackson.", "com.google.common.", "lombok.",
)
FLAG_MAPPING_STATUSES = {
    "project_namespace_hallucination", "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
}
ALLOW_MAPPING_STATUSES = {
    "provided_context_import", "no_external_mapping_needed", "mapped_known_prefix",
    "mapped_maven_class_search",
}
PACKAGE_RE = re.compile(r"(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s*;")


def truthy(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def clean(value: object) -> str:
    return "" if value is None else str(value).strip()


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def load_csv(path: Path | None) -> list[dict[str, str]]:
    if path is None:
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def canonical(row: dict[str, object]) -> str:
    return clean(row.get("normalized_mention") or row.get("import_path") or row.get("coordinate")).lower()


def source_index(project_root: Path) -> tuple[set[str], set[str]]:
    fqns: set[str] = set()
    packages: set[str] = set()
    if not project_root.is_dir():
        return fqns, packages
    for path in project_root.rglob("*.java"):
        if any(part.lower() in {"target", "build", ".git"} for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")[:12000]
        except OSError:
            continue
        match = PACKAGE_RE.search(text)
        if not match:
            continue
        package = match.group(1)
        packages.add(package)
        fqns.add(f"{package}.{path.stem}")
    return fqns, packages


def project_local(value: str, fqns: set[str]) -> bool:
    if value in fqns:
        return True
    parts = value.split(".")
    return any(".".join(parts[:end]) in fqns for end in range(len(parts) - 1, 1, -1))


def package_prefix(prompt: str) -> str:
    match = PACKAGE_RE.search(prompt)
    if not match:
        return ""
    parts = match.group(1).split(".")
    return ".".join(parts[:3] if parts[0] in {"com", "org", "net", "io", "dev", "ai"} else parts[:2])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates-csv", type=Path, required=True)
    parser.add_argument("--prompts-jsonl", type=Path, required=True)
    parser.add_argument("--workspace-root", type=Path, required=True)
    parser.add_argument("--mapping-csv", type=Path)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()

    candidates = load_csv(args.candidates_csv)
    prompts = {row["record_id"]: row for row in read_jsonl(args.prompts_jsonl)}
    mappings = load_csv(args.mapping_csv)
    mapping_by_id = {row.get("candidate_id", ""): row for row in mappings if row.get("candidate_id")}
    mapping_by_key = {(row.get("record_id") or row.get("original_record_id", ""), canonical(row)): row for row in mappings}
    cache: dict[str, tuple[set[str], set[str]]] = {}
    output = []
    counts: dict[str, int] = {}

    for candidate in candidates:
        row = dict(candidate)
        record_id = clean(row.get("record_id"))
        prompt = prompts.get(record_id, {})
        project_rel = clean(prompt.get("project_path") or row.get("project_path"))
        project_root = args.workspace_root / Path(*project_rel.replace("\\", "/").split("/"))
        cache_key = str(project_root.resolve())
        if cache_key not in cache:
            cache[cache_key] = source_index(project_root)
        fqns, packages = cache[cache_key]
        value = clean(row.get("import_path") or row.get("normalized_mention"))
        coordinate = clean(row.get("coordinate"))
        mapping = mapping_by_id.get(clean(row.get("candidate_id"))) or mapping_by_key.get((record_id, canonical(row)), {})
        decision = "uncertain"
        reason = "insufficient_grounding"
        if truthy(row.get("malformed_hint")):
            decision, reason = "flag", "malformed_dependency_syntax"
        elif coordinate:
            status = clean(mapping.get("coordinate_status"))
            if status == "valid_coordinate":
                decision, reason = "allow", "maven_coordinate_found"
            elif status == "coordinate_not_found":
                decision, reason = "flag", "maven_coordinate_not_found"
            elif status == "query_error":
                decision, reason = "uncertain", "maven_query_error"
            else:
                decision, reason = "uncertain", "coordinate_not_registry_checked"
        elif value.startswith(PLATFORM_PREFIXES):
            decision, reason = "allow", "platform_import"
        elif project_local(value, fqns):
            decision, reason = "allow", "project_source_hit"
        elif value.startswith(KNOWN_EXTERNAL_PREFIXES):
            decision, reason = "allow", "frozen_known_external_prefix"
        else:
            mapping_status = clean(mapping.get("mapping_status"))
            if mapping_status in ALLOW_MAPPING_STATUSES:
                decision, reason = "allow", f"mapping:{mapping_status}"
            elif mapping_status in FLAG_MAPPING_STATUSES:
                decision, reason = "flag", f"mapping:{mapping_status}"
            elif mapping_status == "unresolved_after_mapping" and clean(mapping.get("class_search_status")) == "class_not_found":
                prefix = package_prefix(clean(prompt.get("prompt")))
                if prefix and value.startswith(prefix + "."):
                    decision, reason = "flag", "absent_project_namespace_after_class_search"
                else:
                    decision, reason = "uncertain", "external_class_not_found_but_not_project_owned"
            elif mapping_status and clean(mapping.get("error")):
                decision, reason = "uncertain", "mapping_query_error"
        row.update({
            "detector_version": "v2-conservative", "detector_decision": decision,
            "detector_flag": decision == "flag", "detector_reason": reason,
            "project_source_classes": len(fqns), "project_source_packages": len(packages),
        })
        output.append(row)
        counts[decision] = counts.get(decision, 0) + 1

    fields = sorted({key for row in output for key in row})
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output)
    summary = {"artifact": "external_java_v3_detector_v2", "rows": len(output), "decision_counts": counts, "rows_data": output}
    args.output_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(output), "decision_counts": counts}, indent=2))


if __name__ == "__main__":
    main()
