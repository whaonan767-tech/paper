﻿import argparse,csv,json
from collections import Counter
from pathlib import Path
FLAG={'project_namespace_hallucination','project_namespace_typo_hallucination','hallucinated_prefix_with_suggestion','unresolved_after_mapping','unresolved_external_or_hallucinated'}
ALLOW={'no_external_mapping_needed','mapped_known_prefix','mapped_maven_class_search'}
ap=argparse.ArgumentParser();ap.add_argument('--mapped-csv',required=True);ap.add_argument('--output-csv',required=True);ap.add_argument('--output-json',required=True);a=ap.parse_args()
with open(a.mapped_csv,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
if not rows:raise SystemExit('empty V1 mapped CSV')
fields=list(rows[0]);fields += [] if 'candidate_record_id' in fields else ['candidate_record_id'];fields += [] if 'detector_decision' in fields else ['detector_decision'];counts=Counter()
for r in rows:
 r['candidate_record_id']=r.get('record_id','');r['record_id']=r.get('original_record_id') or r.get('record_id','')
 s=(r.get('mapping_status') or r.get('import_classification') or '').strip().lower();d='flag' if s in FLAG else 'allow' if s in ALLOW else 'uncertain';r['detector_decision']=d;counts[d]+=1
Path(a.output_csv).parent.mkdir(parents=True,exist_ok=True)
with open(a.output_csv,'w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
Path(a.output_json).write_text(json.dumps({'artifact':'external_java_v3_v1_scoring','decision_counts':dict(counts),'rows':rows},indent=2),encoding='utf-8');print(json.dumps({'rows':len(rows),'decision_counts':dict(counts)},indent=2))