#!/usr/bin/env python3
"""Prepare and score a full raw-response dependency-mention audit.

Preparation creates two blind sheets plus a separate extractor key. Annotators
enumerate every dependency-bearing mention in the raw answer, including prose,
broken fences, malformed imports, and code outside parsed spans. Score mode
accepts a locked merged sheet with semicolon-separated mention strings.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_WINDOWS = (
    ("FM50", ROOT / "Tests/Java_APIHulBench_Qwen3B_FM50"),
    ("FM50_Offset50", ROOT / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50"),
    ("FM50_Offset100", ROOT / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100"),
    ("FM50_Offset150_tail", ROOT / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150"),
    ("F50_Offset200_tail", ROOT / "Tests/Java_APIHulBench_Qwen3B_F50_Offset200"),
)
DEFAULT_OUTPUT = ROOT / "Tests/Java_APIHulBench_RawMentionHumanAudit_Run20260813"
DEFAULT_TRUTH = (
    ROOT
    / "Tests/Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
    / "full598_final_human_truth.csv"
)

IMPORT_RE = re.compile(r"\bimport\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;?", re.MULTILINE)
COORD_RE = re.compile(r"\b[A-Za-z][A-Za-z0-9_.-]*:[A-Za-z0-9_.-]+(?::[^\s'\"`]+)?\b")
DEP_DECL_RE = re.compile(
    r"\b(?:implementation|api|compileOnly|runtimeOnly|testImplementation|annotationProcessor|compile|testCompile)\b[^\n]{0,240}",
    re.IGNORECASE,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_jsonl(path: Path) -> list[dict[str, object]]:
    rows = []
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_source_line"] = line_no
                rows.append(row)
    return rows


def load_rows() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    frozen_suspicious: set[tuple[str, str, str]] = set()
    with DEFAULT_TRUTH.open("r", encoding="utf-8-sig", newline="") as handle:
        for truth in csv.DictReader(handle):
            mention = truth.get("import_path", "") or truth.get("coordinate", "")
            if mention and truth.get("detector_suspicious", "") == "1":
                frozen_suspicious.add(
                    (truth.get("window_label", ""), truth.get("source_line", ""), normalize(mention))
                )
    for window, directory in DEFAULT_WINDOWS:
        responses = read_jsonl(directory / "responses.jsonl")
        candidate_mentions: dict[str, list[str]] = {}
        with (directory / "candidates.csv").open("r", encoding="utf-8-sig", newline="") as handle:
            for candidate in csv.DictReader(handle):
                source_line = str(candidate.get("source_line", ""))
                mention = candidate.get("import_path", "") or candidate.get("coordinate", "")
                if mention:
                    candidate_mentions.setdefault(source_line, []).append(mention)
        for response in responses:
            text = str(response.get("response", ""))
            source_line = str(response.get("_source_line", ""))
            rows.append(
                {
                    "audit_row_id": f"{window}:{source_line}",
                    "window_label": window,
                    "record_id": response.get("record_id", ""),
                    "original_record_id": response.get("original_record_id", response.get("record_id", "")),
                    "dataset": response.get("dataset", ""),
                    "source_line": response.get("_source_line", ""),
                    "project_path": response.get("project_path", ""),
                    "file_path": response.get("file_path", ""),
                    "raw_response": text,
                    "frozen_extracted_mentions": "; ".join(dict.fromkeys(candidate_mentions.get(source_line, []))),
                    "frozen_detector_suspicious_mentions": "; ".join(
                        mention
                        for mention in dict.fromkeys(candidate_mentions.get(source_line, []))
                        if (window, source_line, normalize(mention)) in frozen_suspicious
                    ),
                    "annotator_a_mentions": "",
                    "annotator_a_surface": "",
                    "annotator_a_notes": "",
                    "annotator_b_mentions": "",
                    "annotator_b_surface": "",
                    "annotator_b_notes": "",
                    "adjudicated_mentions": "",
                    "adjudicated_surface": "",
                    "adjudication_notes": "",
                }
            )
    return rows


def parse_mentions(value: str) -> list[str]:
    return [item.strip() for item in (value or "").split(";") if item.strip()]


def normalize(value: str) -> str:
    value = re.sub(r"\s+", " ", (value or "").strip().lower())
    return value.rstrip(";")


def normalized_list(value: str) -> list[str]:
    return [normalize(item) for item in parse_mentions(value)]


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower, upper = math.floor(position), math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def count_metrics(tp: int, fp: int, fn: int) -> dict[str, float | None]:
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision and recall else None
    return {"precision": precision, "recall": recall, "f1": f1}


def clustered_intervals(per_row: list[dict[str, object]], repetitions: int, seed: int) -> dict[str, object]:
    clusters: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in per_row:
        project = str(row["project_path"]).strip()
        if not project:
            raise SystemExit(f"{row['audit_row_id']}: project_path is required for clustered intervals")
        clusters[project].append(row)
    projects = sorted(clusters)
    project_counts = {}
    for project, project_rows in clusters.items():
        project_counts[project] = {
            key: sum(int(row[key]) for row in project_rows)
            for key in ("true_positive_count", "false_positive_count", "false_negative_count", "end_to_end_tp", "end_to_end_fp", "end_to_end_fn")
        }

    observed_extractor = count_metrics(
        sum(int(row["true_positive_count"]) for row in per_row),
        sum(int(row["false_positive_count"]) for row in per_row),
        sum(int(row["false_negative_count"]) for row in per_row),
    )
    observed_end_to_end = count_metrics(
        sum(int(row["end_to_end_tp"]) for row in per_row),
        sum(int(row["end_to_end_fp"]) for row in per_row),
        sum(int(row["end_to_end_fn"]) for row in per_row),
    )
    rng = random.Random(seed)
    draws = {"extractor": {name: [] for name in ("precision", "recall", "f1")}, "end_to_end": {name: [] for name in ("precision", "recall", "f1")}}
    for _ in range(repetitions):
        sampled = [rng.choice(projects) for _ in projects]
        totals = {
            key: sum(project_counts[project][key] for project in sampled)
            for key in ("true_positive_count", "false_positive_count", "false_negative_count", "end_to_end_tp", "end_to_end_fp", "end_to_end_fn")
        }
        extractor_metrics = count_metrics(totals["true_positive_count"], totals["false_positive_count"], totals["false_negative_count"])
        end_to_end_metrics = count_metrics(totals["end_to_end_tp"], totals["end_to_end_fp"], totals["end_to_end_fn"])
        for name, value in extractor_metrics.items():
            if value is not None:
                draws["extractor"][name].append(value)
        for name, value in end_to_end_metrics.items():
            if value is not None:
                draws["end_to_end"][name].append(value)

    def intervals(observed: dict[str, float | None], values: dict[str, list[float]]) -> dict[str, dict[str, float | None]]:
        return {
            name: {
                "estimate": observed[name],
                "ci_low": percentile(values[name], 0.025) if values[name] else None,
                "ci_high": percentile(values[name], 0.975) if values[name] else None,
            }
            for name in ("precision", "recall", "f1")
        }

    return {
        "method": "project-clustered percentile bootstrap",
        "projects": len(projects),
        "repetitions": repetitions,
        "seed": seed,
        "extractor": intervals(observed_extractor, draws["extractor"]),
        "end_to_end_invalid_or_malformed": intervals(observed_end_to_end, draws["end_to_end"]),
    }


def load_candidate_validity(
    path: Path, merged_rows: list[dict[str, str]]
) -> dict[tuple[str, str], str]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    required = {"window_label", "source_line", "import_path", "final_validity"}
    missing = required - set(rows[0]) if rows else required
    if missing:
        raise SystemExit(f"Candidate truth is missing columns: {sorted(missing)}")
    extracted_by_row = {
        row["audit_row_id"]: parse_mentions(row.get("frozen_extracted_mentions", ""))
        for row in merged_rows
    }
    validity: dict[tuple[str, str], str] = {}
    for row in rows:
        audit_row_id = f"{row['window_label']}:{row['source_line']}"
        try:
            candidate_index = int(row["record_id"].rsplit(":", 1)[1]) - 1
            extracted_value = extracted_by_row[audit_row_id][candidate_index]
        except (KeyError, IndexError, ValueError) as error:
            raise SystemExit(f"Cannot align candidate truth row {row.get('record_id', '')}") from error
        if row["import_path"].strip() and normalize(row["import_path"]) != normalize(extracted_value):
            raise SystemExit(
                f"Candidate truth/extractor mismatch for {audit_row_id} index {candidate_index + 1}"
            )
        key = (audit_row_id, normalize(extracted_value))
        label = row["final_validity"].strip().lower()
        if label not in {"valid", "invalid", "malformed", "uncertain"}:
            raise SystemExit(f"Candidate truth has unsupported validity label {label!r} for {key}")
        if key in validity and validity[key] != label:
            raise SystemExit(f"Candidate truth has conflicting labels for {key}")
        validity[key] = label
    if len(validity) != 598:
        raise SystemExit(f"Expected 598 unique candidate-truth rows, found {len(validity)}")
    return validity


def score_side(
    rows: list[dict[str, str]],
    column: str,
    surface_column: str,
    validity_column: str,
    candidate_validity: dict[tuple[str, str], str] | None = None,
) -> dict[str, object]:
    tp = fp = fn = 0
    e2e_tp = e2e_fp = e2e_fn = e2e_uncertain = 0
    candidate_overrides_applied = 0
    category_counts: Counter[str] = Counter()
    per_row = []
    for row in rows:
        extracted = {normalize(value) for value in parse_mentions(row.get("frozen_extracted_mentions", ""))}
        audited = {normalize(value) for value in parse_mentions(row.get(column, ""))}
        row_tp = extracted & audited
        row_fp = extracted - audited
        row_fn = audited - extracted
        tp += len(row_tp)
        fp += len(row_fp)
        fn += len(row_fn)
        audited_values = parse_mentions(row.get(column, ""))
        audited_surfaces = parse_mentions(row.get(surface_column, ""))
        audited_validities = [value.lower() for value in parse_mentions(row.get(validity_column, ""))]
        if len(audited_surfaces) != len(audited_values):
            raise SystemExit(
                f"{row.get('audit_row_id', '')}: {surface_column} must contain one label per audited mention"
            )
        if len(audited_validities) != len(audited_values):
            raise SystemExit(
                f"{row.get('audit_row_id', '')}: {validity_column} must contain one label per audited mention"
            )
        unsupported = sorted(set(audited_validities) - {"valid", "invalid", "malformed", "uncertain"})
        if unsupported:
            raise SystemExit(f"{row.get('audit_row_id', '')}: unsupported validity labels: {unsupported}")
        surface_by_value = {
            normalize(value): (audited_surfaces[index] if index < len(audited_surfaces) else "unknown")
            for index, value in enumerate(audited_values)
        }
        for value in row_fn:
            category_counts["unextracted_mention"] += 1
            category_counts[f"surface:{surface_by_value.get(value, 'unknown')}"] += 1
        validity_by_value = {
            normalize(value): audited_validities[index]
            for index, value in enumerate(audited_values)
        }
        if candidate_validity is not None:
            audit_row_id = row.get("audit_row_id", "")
            missing_candidate_values = [
                value for value in extracted if (audit_row_id, value) not in candidate_validity
            ]
            if missing_candidate_values:
                raise SystemExit(
                    f"{audit_row_id}: {len(missing_candidate_values)} extracted mentions lack candidate truth"
                )
            for value in extracted & audited:
                validity_by_value[value] = candidate_validity[(audit_row_id, value)]
                candidate_overrides_applied += 1
        audited_invalid = {
            value for value, validity in validity_by_value.items() if validity in {"invalid", "malformed"}
        }
        audited_valid = {value for value, validity in validity_by_value.items() if validity == "valid"}
        audited_uncertain = {value for value, validity in validity_by_value.items() if validity == "uncertain"}
        detector_suspicious = {
            normalize(value)
            for value in parse_mentions(row.get("frozen_detector_suspicious_mentions", ""))
        }
        row_e2e_tp = detector_suspicious & audited_invalid
        row_e2e_fp = (detector_suspicious & audited_valid) | (detector_suspicious - audited)
        row_e2e_uncertain = detector_suspicious & audited_uncertain
        row_e2e_fn = audited_invalid - detector_suspicious
        e2e_tp += len(row_e2e_tp)
        e2e_fp += len(row_e2e_fp)
        e2e_uncertain += len(row_e2e_uncertain)
        e2e_fn += len(row_e2e_fn)
        per_row.append(
            {
                "audit_row_id": row.get("audit_row_id", ""),
                "project_path": row.get("project_path", ""),
                "extracted_count": len(extracted),
                "audited_count": len(audited),
                "true_positive_count": len(row_tp),
                "false_positive_count": len(row_fp),
                "false_negative_count": len(row_fn),
                "invalid_or_malformed_count": len(audited_invalid),
                "detected_invalid_or_malformed_count": len(row_e2e_tp),
                "end_to_end_tp": len(row_e2e_tp),
                "end_to_end_fp": len(row_e2e_fp),
                "end_to_end_uncertain": len(row_e2e_uncertain),
                "end_to_end_fn": len(row_e2e_fn),
            }
        )
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision and recall else None
    e2e_precision = e2e_tp / (e2e_tp + e2e_fp) if e2e_tp + e2e_fp else None
    e2e_recall = e2e_tp / (e2e_tp + e2e_fn) if e2e_tp + e2e_fn else None
    return {
        "rows": len(rows),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "extractor_precision": precision,
        "extractor_recall": recall,
        "end_to_end_invalid_or_malformed_precision": e2e_precision,
        "end_to_end_invalid_or_malformed_recall": e2e_recall,
        "end_to_end_tp": e2e_tp,
        "end_to_end_fp": e2e_fp,
        "end_to_end_uncertain_predictions": e2e_uncertain,
        "end_to_end_fn": e2e_fn,
        "candidate_validity_overrides_applied": candidate_overrides_applied,
        "f1": f1,
        "unextracted_category_counts": dict(category_counts),
        "per_row": per_row,
    }


def prepare(output_dir: Path) -> None:
    rows = load_rows()
    output_dir.mkdir(parents=True, exist_ok=True)
    # Annotators receive raw answers and stable keys, but not frozen extractor output.
    blind_fields = [
        "audit_row_id", "window_label", "record_id", "original_record_id", "dataset",
        "source_line", "project_path", "file_path", "raw_response",
        "annotation_status", "annotator_mentions", "mention_surface", "mention_validity", "annotator_notes",
    ]
    for label in ("a", "b"):
        sheet = output_dir / f"raw_response_mention_audit_blind_{label}.csv"
        blind_rows = []
        for row in rows:
            blind_rows.append({
                **{key: row.get(key, "") for key in blind_fields if key not in {"annotation_status", "annotator_mentions", "mention_surface", "mention_validity", "annotator_notes"}},
                "annotation_status": "not_started",
                "annotator_mentions": "",
                "mention_surface": "",
                "mention_validity": "",
                "annotator_notes": "",
            })
        with sheet.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=blind_fields)
            writer.writeheader()
            writer.writerows(blind_rows)
    key_sheet = output_dir / "raw_response_mention_audit_extractor_key.csv"
    key_fields = ["audit_row_id", "window_label", "record_id", "source_line", "project_path", "file_path", "raw_response", "frozen_extracted_mentions", "frozen_detector_suspicious_mentions"]
    with key_sheet.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=key_fields)
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in key_fields} for row in rows)
    sheet = key_sheet
    guide = output_dir / "raw_response_mention_audit_guidelines.md"
    guide.write_text(
        """# Raw-response dependency mention audit

Enumerate every dependency-bearing mention in the complete raw response. Include Java imports, Maven/Gradle coordinates or declarations, dependency names in prose, imports in broken or unclosed code fences, and malformed import-like strings. Do not infer mentions from the frozen extractor column.

For each row, enter the unique normalized mention strings separated by semicolons in the annotator column. The counting unit is a normalized dependency mention within a response, not every repeated textual occurrence. Use one stable spelling per mention, preserving the full import or coordinate when present. Record one aligned surface category per mention using `code`, `prose`, `broken_fence`, `malformed`, or `other`, and one aligned validity label using `valid`, `invalid`, `malformed`, or `uncertain`. Empty mention, surface, and validity fields mean the answer contains no dependency-bearing mention; after adjudication, record `no_mentions` in the notes field so that scoring can distinguish a completed negative row from an unfinished row.

The adjudicated columns are completed only after both independent sheets are locked. This package contains no human labels.
""",
        encoding="utf-8",
    )
    summary = {
        "analysis": "raw_response_mention_audit_preparation",
        "annotation_mode": "independent_human",
        "raw_responses": len(rows),
        "windows": {window: sum(row["window_label"] == window for row in rows) for window, _ in DEFAULT_WINDOWS},
        "rows_with_frozen_extracted_mentions": sum(bool(row["frozen_extracted_mentions"]) for row in rows),
        "human_annotation_completed": False,
        "automated_preannotation_used": False,
        "detector_key_visible_to_annotators": False,
        "extractor_key_sha256": sha256(sheet),
        "blind_sheets": [f"raw_response_mention_audit_blind_{label}.csv" for label in ("a", "b")],
    }
    (output_dir / "raw_response_mention_audit_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


def merge(blind_a: Path, blind_b: Path, key: Path, output: Path) -> None:
    with blind_a.open("r", encoding="utf-8-sig", newline="") as handle:
        rows_a = {row["audit_row_id"]: row for row in csv.DictReader(handle)}
    with blind_b.open("r", encoding="utf-8-sig", newline="") as handle:
        rows_b = {row["audit_row_id"]: row for row in csv.DictReader(handle)}
    with key.open("r", encoding="utf-8-sig", newline="") as handle:
        rows_key = {row["audit_row_id"]: row for row in csv.DictReader(handle)}
    if set(rows_a) != set(rows_b) or set(rows_a) != set(rows_key):
        raise SystemExit("Blind sheets and extractor key do not contain the same audit_row_id set")
    incomplete_a = [audit_id for audit_id, row in rows_a.items() if row.get("annotation_status", "") != "complete"]
    incomplete_b = [audit_id for audit_id, row in rows_b.items() if row.get("annotation_status", "") != "complete"]
    if incomplete_a or incomplete_b:
        raise SystemExit(
            f"Blind annotation is incomplete (A={len(incomplete_a)}, B={len(incomplete_b)}); refuse to merge"
        )
    fields = [
        "audit_row_id", "window_label", "record_id", "original_record_id", "dataset", "source_line",
        "project_path", "file_path", "raw_response", "frozen_extracted_mentions", "frozen_detector_suspicious_mentions",
        "annotator_a_mentions", "annotator_a_surface", "annotator_a_validity", "annotator_a_notes",
        "annotator_b_mentions", "annotator_b_surface", "annotator_b_validity", "annotator_b_notes",
        "adjudicated_mentions", "adjudicated_surface", "adjudicated_validity", "adjudication_notes",
    ]
    merged = []
    disagreements = []
    for audit_id in sorted(rows_a):
        a, b, k = rows_a[audit_id], rows_b[audit_id], rows_key[audit_id]
        same_mentions = normalized_list(a.get("annotator_mentions", "")) == normalized_list(b.get("annotator_mentions", ""))
        same_surface = normalized_list(a.get("mention_surface", "")) == normalized_list(b.get("mention_surface", ""))
        same_validity = normalized_list(a.get("mention_validity", "")) == normalized_list(b.get("mention_validity", ""))
        row = {
            **{field: k.get(field, a.get(field, "")) for field in fields},
            "annotator_a_mentions": a.get("annotator_mentions", ""),
            "annotator_a_surface": a.get("mention_surface", ""),
            "annotator_a_validity": a.get("mention_validity", ""),
            "annotator_a_notes": a.get("annotator_notes", ""),
            "annotator_b_mentions": b.get("annotator_mentions", ""),
            "annotator_b_surface": b.get("mention_surface", ""),
            "annotator_b_validity": b.get("mention_validity", ""),
            "annotator_b_notes": b.get("annotator_notes", ""),
        }
        if same_mentions and same_surface and same_validity:
            row["adjudicated_mentions"] = a.get("annotator_mentions", "")
            row["adjudicated_surface"] = a.get("mention_surface", "")
            row["adjudicated_validity"] = a.get("mention_validity", "")
            row["adjudication_notes"] = "double_agreement" if row["adjudicated_mentions"] else "no_mentions"
        else:
            if same_mentions:
                row["adjudicated_mentions"] = a.get("annotator_mentions", "")
            if same_surface:
                row["adjudicated_surface"] = a.get("mention_surface", "")
            if same_validity:
                row["adjudicated_validity"] = a.get("mention_validity", "")
            disagreements.append(row)
        merged.append(row)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(merged)
    disagreement_output = output.with_name(output.stem + "_disagreements.csv")
    adjudication_fields = [
        "audit_row_id", "window_label", "record_id", "source_line", "raw_response", "adjudicated_mentions",
        "annotator_a_surface", "annotator_b_surface", "adjudicated_surface",
        "annotator_a_validity", "annotator_b_validity", "adjudicated_validity", "adjudication_notes",
        "annotator_a_notes", "annotator_b_notes", "project_path", "file_path",
        "annotator_a_mentions", "annotator_b_mentions",
    ]
    with disagreement_output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=adjudication_fields)
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in adjudication_fields} for row in disagreements)
    print(f"WROTE {output}")
    print(f"WROTE {disagreement_output} ({len(disagreements)} rows requiring adjudication)")


def apply_adjudication(merged_path: Path, adjudication_path: Path, output: Path) -> None:
    with merged_path.open("r", encoding="utf-8-sig", newline="") as handle:
        merged = list(csv.DictReader(handle))
    with adjudication_path.open("r", encoding="utf-8-sig", newline="") as handle:
        adjudicated = {row["audit_row_id"]: row for row in csv.DictReader(handle)}
    merged_ids = {row["audit_row_id"] for row in merged}
    unknown = sorted(set(adjudicated) - merged_ids)
    if unknown:
        raise SystemExit(f"Adjudication file contains {len(unknown)} unknown audit_row_id values")
    fields = list(merged[0])
    completed = []
    for row in merged:
        update = adjudicated.get(row["audit_row_id"])
        if update:
            for field in ("adjudicated_mentions", "adjudicated_surface", "adjudicated_validity", "adjudication_notes"):
                row[field] = update.get(field, "")
        completed.append(row)
    incomplete = []
    for row in completed:
        mentions = parse_mentions(row.get("adjudicated_mentions", ""))
        surfaces = [value.lower() for value in parse_mentions(row.get("adjudicated_surface", ""))]
        validities = [value.lower() for value in parse_mentions(row.get("adjudicated_validity", ""))]
        notes = row.get("adjudication_notes", "").strip()
        valid = (
            (bool(mentions) and len(mentions) == len(surfaces) == len(validities) and bool(notes))
            or (not mentions and notes == "no_mentions")
        )
        valid = valid and not (set(surfaces) - {"code", "prose", "broken_fence", "malformed", "other"})
        valid = valid and not (set(validities) - {"valid", "invalid", "malformed", "uncertain"})
        if not valid:
            incomplete.append(row["audit_row_id"])
    if incomplete:
        raise SystemExit(f"Adjudication remains incomplete for {len(incomplete)} rows; refuse to write final merged sheet")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(completed)
    print(f"WROTE {output}")


def score(
    input_csv: Path,
    output_dir: Path,
    bootstrap_repetitions: int,
    seed: int,
    candidate_truth_path: Path,
) -> None:
    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    missing = [row.get("audit_row_id", "") for row in rows if not row.get("adjudicated_mentions", "").strip() and not row.get("adjudication_notes", "").strip()]
    if missing:
        raise SystemExit(f"Adjudication is incomplete for {len(missing)} rows; refuse to score")
    candidate_validity = load_candidate_validity(candidate_truth_path, rows)
    raw_validity_sensitivity = score_side(
        rows, "adjudicated_mentions", "adjudicated_surface", "adjudicated_validity"
    )
    adjudicated = score_side(
        rows,
        "adjudicated_mentions",
        "adjudicated_surface",
        "adjudicated_validity",
        candidate_validity,
    )
    adjudicated["project_clustered_bootstrap"] = clustered_intervals(adjudicated["per_row"], bootstrap_repetitions, seed)
    disagreement_rows = sum(
        normalized_list(row.get("annotator_a_mentions", "")) != normalized_list(row.get("annotator_b_mentions", ""))
        or normalized_list(row.get("annotator_a_surface", "")) != normalized_list(row.get("annotator_b_surface", ""))
        or normalized_list(row.get("annotator_a_validity", "")) != normalized_list(row.get("annotator_b_validity", ""))
        for row in rows
    )
    exact_mention_agreement_rows = sum(
        normalized_list(row.get("annotator_a_mentions", "")) == normalized_list(row.get("annotator_b_mentions", ""))
        for row in rows
    )
    result = {
        "analysis": "raw_response_mention_extraction_audit",
        "rows": len(rows),
        "annotator_a": score_side(
            rows, "annotator_a_mentions", "annotator_a_surface", "annotator_a_validity", candidate_validity
        ),
        "annotator_b": score_side(
            rows, "annotator_b_mentions", "annotator_b_surface", "annotator_b_validity", candidate_validity
        ),
        "adjudicated": adjudicated,
        "raw_response_only_validity_sensitivity": raw_validity_sensitivity,
        "input_sha256": sha256(input_csv),
        "candidate_truth_sha256": sha256(candidate_truth_path),
        "human_annotation_completed": True,
        "annotation_protocol": {
            "annotators": 2,
            "independent_sheets": True,
            "cross_blind": True,
            "detector_key_visible_to_annotators": False,
            "automated_preannotation_used": False,
            "automated_preannotation_detector_blind": False,
            "from_scratch_blank_enumeration": True,
            "exact_mention_sequence_agreement_rows": exact_mention_agreement_rows,
            "disagreement_rows_adjudicated": disagreement_rows,
            "extracted_mention_validity_source": "project_registry_grounded_598_row_human_audit",
            "unextracted_mention_validity_source": "raw_response_blank_sheet_adjudication",
            "uncertain_labels_excluded_from_precision": True,
        },
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "raw_response_mention_audit_scored.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    bootstrap = adjudicated["project_clustered_bootstrap"]
    extractor_ci = bootstrap["extractor"]
    end_to_end_ci = bootstrap["end_to_end_invalid_or_malformed"]
    lines = [
        "# Raw-response Mention Audit",
        "",
        f"- Human annotation completed: `{result['human_annotation_completed']}`",
        f"- Raw responses: `{result['rows']}`",
        f"- Annotation protocol: two independent, cross-blind human blank-sheet enumerations; the frozen extractor/detector key was withheld.",
        f"- Exact mention-sequence agreement: `{exact_mention_agreement_rows}/{len(rows)}` responses.",
        f"- Rows requiring adjudication: `{disagreement_rows}`",
        f"- Validity grounding: extracted mentions use the independent project/registry-grounded 598-row audit; newly enumerated unextracted mentions use raw-response adjudication.",
        f"- Adjudicated human mentions: `{adjudicated['tp'] + adjudicated['fn']}`",
        f"- Frozen extractor mentions: `{adjudicated['tp'] + adjudicated['fp']}`",
        f"- Project-clustered bootstrap: `{bootstrap_repetitions}` repetitions, `{bootstrap['projects']}` projects, seed `{seed}`.",
        "",
        "| Metric | Confusion | Estimate | Project-clustered 95% CI |",
        "|---|---:|---:|---:|",
        f"| Extractor precision | TP {adjudicated['tp']}, FP {adjudicated['fp']} | {adjudicated['extractor_precision']:.3f} | {extractor_ci['precision']['ci_low']:.3f}--{extractor_ci['precision']['ci_high']:.3f} |",
        f"| Extractor recall | TP {adjudicated['tp']}, FN {adjudicated['fn']} | {adjudicated['extractor_recall']:.3f} | {extractor_ci['recall']['ci_low']:.3f}--{extractor_ci['recall']['ci_high']:.3f} |",
        f"| Extractor F1 | -- | {adjudicated['f1']:.3f} | {extractor_ci['f1']['ci_low']:.3f}--{extractor_ci['f1']['ci_high']:.3f} |",
        f"| End-to-end invalid/malformed precision | TP {adjudicated['end_to_end_tp']}, FP {adjudicated['end_to_end_fp']}; uncertain predictions {adjudicated['end_to_end_uncertain_predictions']} excluded | {adjudicated['end_to_end_invalid_or_malformed_precision']:.3f} | {end_to_end_ci['precision']['ci_low']:.3f}--{end_to_end_ci['precision']['ci_high']:.3f} |",
        f"| End-to-end invalid/malformed recall | TP {adjudicated['end_to_end_tp']}, FN {adjudicated['end_to_end_fn']} | {adjudicated['end_to_end_invalid_or_malformed_recall']:.3f} | {end_to_end_ci['recall']['ci_low']:.3f}--{end_to_end_ci['recall']['ci_high']:.3f} |",
        "",
        "## Raw-response-only Validity Sensitivity",
        "",
        f"- TP/FP/uncertain/FN: `{raw_validity_sensitivity['end_to_end_tp']}/{raw_validity_sensitivity['end_to_end_fp']}/{raw_validity_sensitivity['end_to_end_uncertain_predictions']}/{raw_validity_sensitivity['end_to_end_fn']}`.",
        f"- Known-label precision: `{raw_validity_sensitivity['end_to_end_invalid_or_malformed_precision']:.3f}`; recall: `{raw_validity_sensitivity['end_to_end_invalid_or_malformed_recall']:.3f}`.",
        "- This sensitivity analysis does not replace project/registry-grounded validity for extracted mentions.",
        "",
        "## Frozen Extractor Misses by Surface",
        "",
    ]
    for name, count in sorted(adjudicated["unextracted_category_counts"].items()):
        if name.startswith("surface:"):
            lines.append(f"- `{name.removeprefix('surface:')}`: `{count}`")
    (output_dir / "raw_response_mention_audit_scored.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    compact = {
        "rows": result["rows"],
        "human_annotation_completed": result["human_annotation_completed"],
        "annotation_protocol": result["annotation_protocol"],
        "adjudicated": {key: value for key, value in adjudicated.items() if key != "per_row"},
    }
    print(json.dumps(compact, indent=2, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--merge", nargs=4, metavar=("BLIND_A", "BLIND_B", "KEY", "OUTPUT"))
    parser.add_argument("--apply-adjudication", nargs=3, metavar=("MERGED", "ADJUDICATION", "OUTPUT"))
    parser.add_argument("--score", type=Path)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260814)
    parser.add_argument("--candidate-truth", type=Path, default=DEFAULT_TRUTH)
    args = parser.parse_args()
    modes = sum(bool(value) for value in (args.prepare, args.merge, args.apply_adjudication, args.score))
    if modes != 1:
        raise SystemExit("Choose exactly one of --prepare, --merge, --apply-adjudication, or --score")
    if args.prepare:
        prepare(args.output_dir.resolve())
    elif args.merge:
        merge(*(Path(value).resolve() for value in args.merge))
    elif args.apply_adjudication:
        apply_adjudication(*(Path(value).resolve() for value in args.apply_adjudication))
    else:
        score(
            args.score.resolve(),
            args.output_dir.resolve(),
            args.bootstrap_repetitions,
            args.seed,
            args.candidate_truth.resolve(),
        )


if __name__ == "__main__":
    main()
