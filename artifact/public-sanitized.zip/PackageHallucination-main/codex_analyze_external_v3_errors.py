#!/usr/bin/env python3
"""Produce annotation-flow and frozen V2 error-accounting diagnostics."""
import argparse,collections,csv,json,re
from pathlib import Path

def clean(v): return '' if v is None else str(v).strip()
def parts(v): return [x.strip() for x in clean(v).split(';') if x.strip()]
def norm(v):
 t=clean(v).strip("`'\" ");t=re.sub(r'(?i)^import\s+(?:static\s+)?','',t);t=re.sub(r'[;,.)\]}]+$','',t);return re.sub(r'\s+','',t).lower()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def value(r):return norm(r.get('normalized_mention') or r.get('import_path') or r.get('coordinate'))
def recid(r):return clean(r.get('record_id') or r.get('original_record_id'))
def precision(tp,fp):return tp/(tp+fp) if tp+fp else None

def truth_rows(merged,adj):
 out={}
 for r in merged:
  u=adj.get(r['record_id'],{});ms=parts(u.get('adjudicated_mentions') or r.get('adjudicated_mentions'));ls=[x.lower() for x in parts(u.get('adjudicated_validity') or r.get('adjudicated_validity'))];ss=[x.lower() for x in parts(u.get('adjudicated_surface') or r.get('adjudicated_surface'))]
  if not(len(ms)==len(ls)==len(ss)):raise SystemExit('unaligned '+r['record_id'])
  out[r['record_id']]=list(zip(map(norm,ms),ls,ss))
 return out

def annotation_flow(merged,adj):
 t=collections.Counter();loss=[]
 for r in merged:
  a=collections.Counter(map(norm,parts(r['annotator_a_mentions'])));b=collections.Counter(map(norm,parts(r['annotator_b_mentions'])));u=a|b;m=a&b;f=parts(adj.get(r['record_id'],r).get('adjudicated_mentions'))
  t.update(annotator_a=sum(a.values()),annotator_b=sum(b.values()),matched=sum(m.values()),only_a=sum((a-b).values()),only_b=sum((b-a).values()),union_max_multiplicity=sum(u.values()),final_inventory=len(f))
  d=sum(u.values())-len(f)
  if d:loss.append({'record_id':r['record_id'],'union':sum(u.values()),'final':len(f),'difference':d})
 t['union_to_final_difference']=t['union_max_multiplicity']-t['final_inventory']
 return {'totals':dict(t),'rows_with_difference':loss}

def outcomes(truth,cands):
 all_by=collections.defaultdict(list);flags=collections.defaultdict(list)
 for r in cands:
  if value(r):all_by[recid(r)].append(r)
  if value(r) and clean(r.get('detector_decision')).lower()=='flag':flags[recid(r)].append(r)
 out=[];fns=[];conditional_misses=[]
 for rid,ts in truth.items():
  q=collections.defaultdict(list)
  for v,l,s in ts:q[v].append((l,s))
  seen=collections.Counter()
  for r in flags.get(rid,[]):
   v=value(r);i=seen[v];seen[v]+=1;match=q[v][i] if i<len(q[v]) else None
   if match is None:o,l,s='fp_unmatched','unmatched','unmatched'
   else:
    l,s=match;o='tp' if l in {'invalid','malformed'} else 'uncertain' if l=='uncertain' else 'fp_valid'
   out.append({'record_id':rid,'normalized_mention':v,'outcome':o,'truth_label':l,'truth_surface':s,'candidate_kind':clean(r.get('kind') or r.get('candidate_kind') or 'unknown'),'extraction_rule':clean(r.get('extraction_rule') or r.get('parse_rule') or r.get('rule') or 'unknown'),'candidate_surface':clean(r.get('surface') or r.get('mention_surface') or 'unknown'),'mapping_status':clean(r.get('mapping_status') or r.get('detector_reason') or r.get('import_classification') or 'unknown')})
  extracted=collections.Counter(value(r) for r in all_by.get(rid,[]))
  for v,occ in q.items():
   flagged_count=sum(1 for r in flags.get(rid,[]) if value(r)==v)
   for i,(l,s) in enumerate(occ):
    if l in {'invalid','malformed'} and i>=flagged_count:
     row={'record_id':rid,'normalized_mention':v,'truth_label':l,'truth_surface':s,'miss_stage':'unextracted' if i>=extracted[v] else 'extracted_not_flagged'};fns.append(row)
     if i<extracted[v]:conditional_misses.append(row)
 return out,fns,conditional_misses

def grouped(rows,field):
 g=collections.defaultdict(collections.Counter)
 for r in rows:g[clean(r.get(field)) or 'unknown'][r['outcome']]+=1
 out=[]
 for k,c in sorted(g.items(),key=lambda x:(-(x[1]['fp_valid']+x[1]['fp_unmatched']),x[0])):
  tp=c['tp'];fp=c['fp_valid']+c['fp_unmatched'];out.append({field:k,'tp':tp,'fp_valid':c['fp_valid'],'fp_unmatched':c['fp_unmatched'],'fp_total':fp,'uncertain':c['uncertain'],'flag_precision_excluding_uncertain':precision(tp,fp)})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--merged-csv',type=Path,required=True);ap.add_argument('--adjudication-csv',type=Path,required=True);ap.add_argument('--v2-csv',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args()
 merged=read(a.merged_csv);adj={r['record_id']:r for r in read(a.adjudication_csv)};cands=read(a.v2_csv);truth=truth_rows(merged,adj);flow=annotation_flow(merged,adj);out,fns,conditional_misses=outcomes(truth,cands);summary=collections.Counter(r['outcome'] for r in out)
 payload={'artifact':'external_java_v3_error_analysis','detector_modified':False,'annotation_flow':flow,'v2_flag_outcomes':dict(summary),'invalid_or_malformed_false_negatives':len(fns),'conditional_false_negatives':len(conditional_misses),'by_extraction_rule':grouped(out,'extraction_rule'),'by_candidate_surface':grouped(out,'candidate_surface'),'by_candidate_kind':grouped(out,'candidate_kind'),'by_mapping_status':grouped(out,'mapping_status')};a.output_dir.mkdir(parents=True,exist_ok=True);(a.output_dir/'external_v3_error_analysis.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 for name,rows in [('v2_flag_outcomes.csv',out),('v2_false_negatives.csv',fns)]:
  if rows:
   with (a.output_dir/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps({'flow':flow['totals'],'outcomes':dict(summary),'false_negatives':len(fns)},indent=2))
if __name__=='__main__':main()