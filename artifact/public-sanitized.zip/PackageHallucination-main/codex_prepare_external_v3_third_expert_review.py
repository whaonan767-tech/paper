#!/usr/bin/env python3
"""Prepare a detector-blind third-expert review queue for external V3."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import re
from pathlib import Path


LABELS = {"valid", "invalid", "malformed", "uncertain"}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def split_list(value: str | None) -> list[str]:
    return [part.strip() for part in (value or "").split(";") if part.strip()]


def excerpt(text: str, mention: str, occurrence: int, radius: int = 260) -> str:
    matches = list(re.finditer(re.escape(mention), text, flags=re.IGNORECASE))
    if matches:
        match = matches[min(occurrence - 1, len(matches) - 1)]
        start = max(0, match.start() - radius)
        end = min(len(text), match.end() + radius)
        return text[start:end]
    return text[: radius * 2]


def stable_id(record_id: str, index: int, mention: str) -> str:
    digest = hashlib.sha256(f"{record_id}|{index}|{mention}".encode("utf-8")).hexdigest()[:10]
    return f"T3_{digest.upper()}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--merged", type=Path, required=True)
    parser.add_argument("--adjudication", type=Path, required=True)
    parser.add_argument("--responses", type=Path, required=True)
    parser.add_argument("--output-review", type=Path, required=True)
    parser.add_argument("--output-key", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260824)
    parser.add_argument("--controls-per-class", type=int, default=20)
    args = parser.parse_args()

    merged = {row["record_id"]: row for row in read_csv(args.merged)}
    updates = {row["record_id"]: row for row in read_csv(args.adjudication)}
    responses = {}
    with args.responses.open("r", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            responses[row["record_id"]] = row

    inventory = []
    for record_id, base in sorted(merged.items()):
        update = updates.get(record_id, {})
        mentions = split_list(update.get("adjudicated_mentions") or base.get("adjudicated_mentions"))
        surfaces = split_list(update.get("adjudicated_surface") or base.get("adjudicated_surface"))
        labels = [value.lower() for value in split_list(update.get("adjudicated_validity") or base.get("adjudicated_validity"))]
        if not (len(mentions) == len(surfaces) == len(labels)):
            raise SystemExit(f"Unaligned adjudication for {record_id}")
        if set(labels) - LABELS:
            raise SystemExit(f"Invalid label for {record_id}")
        source = responses[record_id]
        seen: dict[str, int] = {}
        for index, (mention, surface, label) in enumerate(zip(mentions, surfaces, labels), start=1):
            normalized = mention.casefold()
            seen[normalized] = seen.get(normalized, 0) + 1
            review_id = stable_id(record_id, index, mention)
            inventory.append({
                "review_id": review_id,
                "record_id": record_id,
                "mention_index": index,
                "occurrence_of_same_text": seen[normalized],
                "project_id": base["project_id"],
                "project_commit": source.get("project_commit", ""),
                "task": base["task"],
                "file_path": source.get("relative_file_path") or base["file_path"],
                "target_mention": mention,
                "surface_hint": surface,
                "context_excerpt": excerpt(base["raw_response"], mention, seen[normalized]),
                "prompt": base["prompt"],
                "raw_response": base["raw_response"],
                "current_label": label,
            })

    uncertain = [row for row in inventory if row["current_label"] == "uncertain"]
    valid = [row for row in inventory if row["current_label"] == "valid"]
    adverse = [row for row in inventory if row["current_label"] in {"invalid", "malformed"}]
    rng = random.Random(args.seed)
    controls = rng.sample(valid, args.controls_per_class) + rng.sample(adverse, args.controls_per_class)
    selected = [(row, "uncertain") for row in uncertain] + [(row, "control") for row in controls]
    rng.shuffle(selected)

    review_rows = []
    key_rows = []
    for order, (row, stratum) in enumerate(selected, start=1):
        review_rows.append({
            "review_order": order,
            **{key: value for key, value in row.items() if key != "current_label"},
            "expert_label": "",
            "evidence_type": "",
            "evidence_reference": "",
            "rationale": "",
            "confidence": "",
            "review_status": "pending",
        })
        key_rows.append({
            "review_order": order,
            "review_id": row["review_id"],
            "record_id": row["record_id"],
            "stratum": stratum,
            "frozen_label": row["current_label"],
        })

    args.output_review.parent.mkdir(parents=True, exist_ok=True)
    args.output_key.parent.mkdir(parents=True, exist_ok=True)
    args.output_review.write_text(json.dumps({
        "artifact": "external_v3_third_expert_review_queue",
        "detector_outputs_included": False,
        "annotator_labels_included": False,
        "seed": args.seed,
        "uncertain_occurrences": len(uncertain),
        "hidden_controls": len(controls),
        "rows": review_rows,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    args.output_key.write_text(json.dumps({
        "artifact": "external_v3_third_expert_qc_key",
        "keep_separate_from_reviewer": True,
        "seed": args.seed,
        "rows": key_rows,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"review_rows": len(review_rows), "uncertain": len(uncertain), "controls": len(controls)}, indent=2))


if __name__ == "__main__":
    main()
