#!/usr/bin/env python3
"""Benchmark frozen Java mapping with disabled, cold, and warm Maven class search."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-csv", type=Path, required=True)
    parser.add_argument("--apihul-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--sleep", type=float, default=0.05)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def cache_size(path: Path) -> int:
    if not path.exists():
        return 0
    payload = json.loads(path.read_text(encoding="utf-8"))
    return len(payload) if isinstance(payload, dict) else 0


def run_variant(args: argparse.Namespace, name: str, cache: Path, disable_class_search: bool) -> dict:
    variant_dir = args.output_dir / name
    variant_dir.mkdir(parents=True)
    before = cache_size(cache)
    command = [
        sys.executable,
        str(ROOT / "codex_map_java_imports_to_maven.py"),
        "--input-csv", str(args.input_csv.resolve()),
        "--output-csv", str(variant_dir / "mapping.csv"),
        "--output-json", str(variant_dir / "mapping.json"),
        "--output-md", str(variant_dir / "mapping.md"),
        "--cache-json", str(cache),
        "--timeout", str(args.timeout),
        "--sleep", str(args.sleep),
        "--apihul-root", str(args.apihul_root.resolve()),
    ]
    if disable_class_search:
        command.append("--disable-class-search")
    started = time.perf_counter()
    completed = subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True, check=False)
    duration = time.perf_counter() - started
    (variant_dir / "stdout.log").write_text(completed.stdout, encoding="utf-8")
    (variant_dir / "stderr.log").write_text(completed.stderr, encoding="utf-8")
    if completed.returncode != 0:
        raise RuntimeError(f"Mapper failed for {name}: {completed.stderr[-2000:]}")
    after = cache_size(cache)
    mapping = json.loads((variant_dir / "mapping.json").read_text(encoding="utf-8"))
    return {
        "name": name,
        "disable_class_search": disable_class_search,
        "duration_seconds": round(duration, 6),
        "rows": int(mapping["rows"]),
        "cache_keys_before": before,
        "cache_keys_after": after,
        "new_registry_query_keys": after - before,
        "mapping_status_counts": mapping["mapping_status_counts"],
        "coordinate_status_counts": mapping["coordinate_status_counts"],
        "output_json": str((variant_dir / "mapping.json").relative_to(args.output_dir)),
    }


def main() -> None:
    args = parse_args()
    args.output_dir = args.output_dir.resolve()
    if args.output_dir.exists():
        raise SystemExit(f"Output directory exists: {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    disabled_cache = args.output_dir / "disabled_cache.json"
    full_cache = args.output_dir / "full_cache.json"
    disabled = run_variant(args, "class_search_disabled", disabled_cache, True)
    cold = run_variant(args, "full_cold_cache", full_cache, False)
    warm = run_variant(args, "full_warm_cache", full_cache, False)
    query_keys_used = cold["cache_keys_after"]
    warm_hits = query_keys_used - warm["new_registry_query_keys"]
    warm_hit_rate = warm_hits / query_keys_used if query_keys_used else 1.0
    summary = {
        "rows": cold["rows"],
        "disabled_seconds": disabled["duration_seconds"],
        "cold_seconds": cold["duration_seconds"],
        "warm_seconds": warm["duration_seconds"],
        "cold_registry_requests": cold["new_registry_query_keys"],
        "warm_registry_requests": warm["new_registry_query_keys"],
        "warm_cache_hits": warm_hits,
        "warm_cache_hit_rate": warm_hit_rate,
        "maven_class_search_incremental_seconds": round(cold["duration_seconds"] - disabled["duration_seconds"], 6),
        "maven_class_search_incremental_query_keys": cold["new_registry_query_keys"] - disabled["new_registry_query_keys"],
        "cold_ms_per_row": 1000 * cold["duration_seconds"] / cold["rows"] if cold["rows"] else 0.0,
        "warm_ms_per_row": 1000 * warm["duration_seconds"] / warm["rows"] if warm["rows"] else 0.0,
    }
    payload = {
        "artifact": "java_mapping_practical_benchmark",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_csv": args.input_csv.resolve().name,
        "input_sha256": sha256(args.input_csv.resolve()),
        "mapper_sha256": sha256(ROOT / "codex_map_java_imports_to_maven.py"),
        "benchmark_script_sha256": sha256(Path(__file__).resolve()),
        "query_accounting": "With retry-errors disabled and an initially empty cache, every newly created cache key corresponds to one Maven Search request attempt. The warm run reuses the same keys and should create none.",
        "summary": summary,
        "variants": [disabled, cold, warm],
    }
    (args.output_dir / "mapping_practical_benchmark.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = [
        "# Java Mapping Practical Benchmark",
        "",
        f"- Candidate rows: `{summary['rows']}`.",
        f"- Class-search disabled / cold / warm: `{summary['disabled_seconds']:.3f}` / `{summary['cold_seconds']:.3f}` / `{summary['warm_seconds']:.3f}` seconds.",
        f"- Cold / warm registry requests: `{summary['cold_registry_requests']}` / `{summary['warm_registry_requests']}`.",
        f"- Warm cache hits / hit rate: `{summary['warm_cache_hits']}` / `{summary['warm_cache_hit_rate']:.3f}`.",
        f"- Maven class-search incremental time / query keys: `{summary['maven_class_search_incremental_seconds']:.3f}` seconds / `{summary['maven_class_search_incremental_query_keys']}`.",
        f"- Cold / warm milliseconds per row: `{summary['cold_ms_per_row']:.2f}` / `{summary['warm_ms_per_row']:.2f}`.",
    ]
    (args.output_dir / "mapping_practical_benchmark.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(args.output_dir), "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
