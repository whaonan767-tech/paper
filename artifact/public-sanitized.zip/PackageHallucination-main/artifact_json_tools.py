#!/usr/bin/env python3
"""Sanitize and validate JSON/JSONL files in the submission artifact."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


def parse_payload(path: Path) -> tuple[str, Any]:
    text = path.read_text(encoding="utf-8-sig")
    try:
        return "document", json.loads(text)
    except json.JSONDecodeError as document_error:
        rows = []
        try:
            for line_number, line in enumerate(text.splitlines(), 1):
                if line.strip():
                    rows.append(json.loads(line))
        except json.JSONDecodeError as line_error:
            raise ValueError(
                f"{path}: neither JSON document nor JSON-lines; "
                f"document={document_error}; line {line_number}={line_error}"
            ) from line_error
        return "lines", rows


def string_sanitizer(workspace: str, repo: str):
    local_user = "Admin" + "istrator"
    replacements = [
        (repo, "<ARTIFACT_REPO>"),
        (repo.replace("\\", "/"), "<ARTIFACT_REPO>"),
        (workspace, "<ARTIFACT_WORKSPACE>"),
        (workspace.replace("\\", "/"), "<ARTIFACT_WORKSPACE>"),
        ("PackageHallucination-main-extracted\\PackageHallucination-main", "PackageHallucination-main"),
        ("PackageHallucination-main-extracted/PackageHallucination-main", "PackageHallucination-main"),
        ("PackageHallucination-main-extracted", "PackageHallucination-source"),
        ("APIMitigation-main", "<LOCAL_APIHULBENCH_ROOT>"),
        ("hf_models", "<LOCAL_MODEL_CACHE>"),
        (local_user, "<LOCAL_USER>"),
        ("ADMINI" + "~1", "<LOCAL_USER>"),
        (".jdks", "<LOCAL_JDKS>"),
        ("codex-runtimes", "<LOCAL_RUNTIME_CACHE>"),
    ]
    drive_pattern = re.compile(r"(?i)(?<![A-Za-z0-9])[A-Z]:[\\/]")
    home_pattern = re.compile(r"(?i)/" + r"(?:home|Users)/[^/\\\s<>\"']+")

    def sanitize(value: str) -> str:
        clean = value
        for source, target in replacements:
            if source:
                clean = clean.replace(source, target)
        clean = drive_pattern.sub("<DRIVE>/", clean)
        return home_pattern.sub("<HOME>", clean)

    return sanitize


def transform(value: Any, sanitize) -> tuple[Any, int]:
    if isinstance(value, str):
        clean = sanitize(value)
        return clean, int(clean != value)
    if isinstance(value, list):
        output, changed = [], 0
        for item in value:
            clean, item_changed = transform(item, sanitize)
            output.append(clean)
            changed += item_changed
        return output, changed
    if isinstance(value, dict):
        output, changed = {}, 0
        for key, item in value.items():
            clean_key = sanitize(key)
            clean_item, item_changed = transform(item, sanitize)
            output[clean_key] = clean_item
            changed += int(clean_key != key) + item_changed
        return output, changed
    return value, 0


def iter_payloads(root: Path):
    yield from sorted([*root.rglob("*.json"), *root.rglob("*.jsonl")])


def iter_strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from iter_strings(item)
    elif isinstance(value, dict):
        for key, item in value.items():
            yield key
            yield from iter_strings(item)


def validate(root: Path) -> dict[str, int | str]:
    files = 0
    line_delimited = 0
    local_path_strings = 0
    username_strings = 0
    local_user = "Admin" + "istrator"
    short_user = "ADMINI" + "~1"
    drive_pattern = re.compile(r"(?i)(?<![A-Za-z0-9])[A-Z]:[\\/]")
    home_pattern = re.compile(r"(?i)/" + r"(?:home|Users)/[^/\\\s<>\"']+")
    for path in iter_payloads(root):
        mode, payload = parse_payload(path)
        files += 1
        line_delimited += int(mode == "lines")
        for value in iter_strings(payload):
            local_path_strings += int(bool(drive_pattern.search(value) or home_pattern.search(value)))
            username_strings += int(local_user.lower() in value.lower() or short_user.lower() in value.lower())
    return {
        "status": "pass",
        "files": files,
        "line_delimited_files": line_delimited,
        "local_path_strings": local_path_strings,
        "username_strings": username_strings,
    }


def sanitize(root: Path, workspace: str, repo: str) -> dict[str, int | str]:
    clean_string = string_sanitizer(workspace, repo)
    files = changed_files = changed_strings = line_delimited = 0
    for path in iter_payloads(root):
        mode, payload = parse_payload(path)
        clean, changed = transform(payload, clean_string)
        files += 1
        line_delimited += int(mode == "lines")
        if not changed:
            continue
        if mode == "document":
            output = json.dumps(clean, ensure_ascii=False, indent=2) + "\n"
        else:
            output = "\n".join(json.dumps(row, ensure_ascii=False) for row in clean) + "\n"
        path.write_text(output, encoding="utf-8")
        changed_files += 1
        changed_strings += changed
    result = validate(root)
    result.update({"changed_files": changed_files, "changed_strings": changed_strings})
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    validate_parser = subparsers.add_parser("validate")
    validate_parser.add_argument("--root", type=Path, required=True)
    sanitize_parser = subparsers.add_parser("sanitize")
    sanitize_parser.add_argument("--root", type=Path, required=True)
    sanitize_parser.add_argument("--workspace", required=True)
    sanitize_parser.add_argument("--repo", required=True)
    args = parser.parse_args()

    if args.command == "sanitize":
        result = sanitize(args.root.resolve(), args.workspace, args.repo)
    else:
        result = validate(args.root.resolve())
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
