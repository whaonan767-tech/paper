﻿import argparse,json,shutil,urllib.parse
from datetime import datetime,timezone
from pathlib import Path
from codex_acquire_external_java_pilot import download_file,safe_extract
from codex_acquire_external_java_v3 import ALLOWED_LICENSES,QUERY,project_families,request_json,root_pom_exists,sha256,verified_within
from codex_build_external_v3_exclusions import family,normalized_name,repository_key
ap=argparse.ArgumentParser();ap.add_argument('--existing-json',type=Path,required=True);ap.add_argument('--search-snapshot',type=Path,required=True);ap.add_argument('--exclusions',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--additions',type=int,default=15);ap.add_argument('--timeout',type=float,default=90);a=ap.parse_args()
old=json.loads(a.existing_json.read_text(encoding='utf-8'));snap=json.loads(a.search_snapshot.read_text(encoding='utf-8'));ex=json.loads(a.exclusions.read_text(encoding='utf-8'));items=snap['items'] if isinstance(snap,dict) else snap
start=max(int(x['rank']) for x in old['screened']); owners={x['owner'].lower() for x in old['selected']};families={f for x in old['selected'] for f in x.get('api_families',[])}
exnames=set(ex['repository_names_normalized']);exkeys=set(ex['repository_keys']);exfull=set(ex['full_names']);exowners=set(ex['owners']);exfamilies=set(ex['api_families'])
out=a.output_dir.resolve();archives=out/'archives';projects=out/'projects';screenroot=out/'screening';meta=out/'metadata'
for p in (archives,projects,screenroot,meta):p.mkdir(parents=True,exist_ok=True)
selected=[];screened=[]
for rank,item in enumerate(items,1):
 if rank<=start:continue
 if len(selected)>=a.additions:break
 full=str(item.get('full_name') or '')
 if '/' not in full:continue
 owner,repo=full.split('/',1);okey=owner.lower();row={'rank':rank,'full_name':full,'owner':owner,'repo_name':repo,'default_branch':item.get('default_branch') or 'main','license_spdx':(item.get('license') or {}).get('spdx_id') or '','size_kb':item.get('size'),'stars':item.get('stargazers_count')};reasons=[]
 if row['license_spdx'] not in ALLOWED_LICENSES:reasons.append('license')
 if normalized_name(repo) in exnames or repository_key(repo) in exkeys:reasons.append('known_repository_name')
 if full.lower() in exfull:reasons.append('known_full_name')
 if okey in exowners:reasons.append('known_owner')
 if okey in owners:reasons.append('duplicate_external_owner')
 if reasons:row.update(selected=False,rejection_reasons=reasons);screened.append(row);continue
 if not root_pom_exists(full,str(row['default_branch']),a.timeout):row.update(selected=False,rejection_reasons=['no_root_pom']);screened.append(row);continue
 commit=request_json(f"https://api.github.com/repos/{full}/commits/{urllib.parse.quote(str(row['default_branch']),safe='')}",a.timeout);sha=str(commit['sha']);slug=full.replace('/','_');archive=archives/f'rank{rank:04d}_{slug}_{sha[:12]}.zip'
 if not archive.exists():download_file(f'https://codeload.github.com/{full}/zip/{sha}',archive,a.timeout)
 temp=screenroot/f'rank{rank:04d}'
 if temp.exists():
  if not verified_within(temp,screenroot):raise RuntimeError('unsafe cleanup')
  shutil.rmtree(temp)
 safe_extract(archive,temp);fams=project_families(temp);overlap=sorted(set(fams)&(exfamilies|families))
 if overlap:row.update(selected=False,rejection_reasons=['api_family_overlap'],api_families=fams,overlap=overlap);screened.append(row);shutil.rmtree(temp);continue
 idx=31+len(selected);dest=projects/f'p{idx:03d}';temp.replace(dest);s={**row,'selected':True,'rejection_reasons':[],'commit_sha':sha,'commit_url':f'https://github.com/{full}/commit/{sha}','archive_url':f'https://codeload.github.com/{full}/zip/{sha}','archive_file':archive.name,'archive_sha256':sha256(archive),'project_dir':dest.name,'project_relative_path':dest.relative_to(out).as_posix(),'api_families':fams};selected.append(s);screened.append(s);owners.add(okey);families.update(fams);print(f'SELECTED {idx}/45 {full}@{sha[:12]}',flush=True)
payload={'artifact':'external_java_v3_engineering_extension','acquired_at_utc':datetime.now(timezone.utc).isoformat(),'continuation_after_frozen_rank':start,'selection_rule':old['selection_rule'],'original_selected_count':len(old['selected']),'selected':selected,'screened':screened};path=meta/'external_engineering_extension_v3.json';path.write_text(json.dumps(payload,indent=2),encoding='utf-8');print(json.dumps({'selected_additions':len(selected),'screened':len(screened),'output':str(path)},indent=2))
if len(selected)<a.additions:raise SystemExit(f'only {len(selected)} additions found')