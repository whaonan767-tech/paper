import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


def read_jsonl(path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def read_csv(path):
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def fmt_rate(num, den):
    if not den:
        return "--"
    pct = (Decimal(num) * Decimal(100) / Decimal(den)).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    return f"{num}/{den} ({pct}%)"


def simple_name(import_path):
    return import_path.rsplit(".", 1)[-1]


def package_name(import_path):
    parts = import_path.rsplit(".", 1)
    return parts[0] if len(parts) == 2 else ""


def has_java_identifier_token(text, token):
    if not token:
        return False
    pattern = re.compile(rf"(?<![A-Za-z0-9_$]){re.escape(token)}(?![A-Za-z0-9_$])")
    return bool(pattern.search(text))


def generated_imports_by_response_line(candidate_rows):
    grouped = defaultdict(set)
    for row in candidate_rows:
        if row.get("kind") == "java_import" and row.get("import_path"):
            grouped[str(row.get("source_line", ""))].add(row["import_path"])
    return grouped


def classify_target(target, text, generated_imports):
    strict = target in generated_imports
    raw = target in text
    simple = simple_name(target)
    package = package_name(target)
    simple_hit = has_java_identifier_token(text, simple)
    package_hit = package in text if package else False

    if strict:
        category = "strict_import_row_exact"
    elif raw:
        category = "raw_exact_unparseable"
    elif simple_hit:
        category = "simple_name_only"
    elif package_hit:
        category = "package_prefix_only"
    else:
        category = "omitted"

    return {
        "strict_import_row_exact": strict,
        "raw_exact_mention": raw,
        "simple_name_mention": simple_hit,
        "package_prefix_mention": package_hit,
        "evidence_category": category,
    }


def analyze_run(label, prompts_by_id, responses_jsonl, candidates_csv):
    responses = read_jsonl(responses_jsonl)
    candidates = read_csv(candidates_csv)
    imports_by_line = generated_imports_by_response_line(candidates)
    rows = []
    record_rollup = {}

    for response in responses:
        response_line = str(response["_line_no"])
        record_id = response.get("record_id", "")
        prompt = prompts_by_id.get(record_id, {})
        targets = prompt.get("masked_external_imports", [])
        text = response.get("response", "")
        generated_imports = sorted(imports_by_line.get(response_line, set()))
        target_rows = []
        for target in targets:
            classified = classify_target(target, text, set(generated_imports))
            row = {
                "model": label,
                "record_id": record_id,
                "split": response.get("split", prompt.get("split", "")),
                "source_set": prompt.get("source_set", ""),
                "target_import": target,
                "target_simple_name": simple_name(target),
                "target_package": package_name(target),
                "generated_import_count": len(generated_imports),
                "generated_imports": "; ".join(generated_imports),
                **classified,
            }
            rows.append(row)
            target_rows.append(row)

        strict_count = sum(1 for row in target_rows if row["strict_import_row_exact"])
        raw_count = sum(1 for row in target_rows if row["raw_exact_mention"])
        simple_count = sum(1 for row in target_rows if row["simple_name_mention"])
        record_rollup[record_id] = {
            "model": label,
            "record_id": record_id,
            "split": response.get("split", prompt.get("split", "")),
            "source_set": prompt.get("source_set", ""),
            "target_count": len(target_rows),
            "strict_count": strict_count,
            "raw_exact_count": raw_count,
            "simple_name_count": simple_count,
            "all_strict": bool(target_rows) and strict_count == len(target_rows),
            "any_strict": strict_count > 0,
            "all_raw_exact": bool(target_rows) and raw_count == len(target_rows),
            "any_raw_exact": raw_count > 0,
            "all_simple_name": bool(target_rows) and simple_count == len(target_rows),
            "any_simple_name": simple_count > 0,
        }

    category_counts = Counter(row["evidence_category"] for row in rows)
    target_total = len(rows)
    strict_total = category_counts.get("strict_import_row_exact", 0)
    raw_total = sum(1 for row in rows if row["raw_exact_mention"])
    simple_total = sum(1 for row in rows if row["simple_name_mention"])
    summary = {
        "model": label,
        "responses_jsonl": str(responses_jsonl),
        "candidates_csv": str(candidates_csv),
        "records": len(responses),
        "target_imports": target_total,
        "candidate_rows": len(candidates),
        "parseable_java_import_rows": sum(1 for row in candidates if row.get("kind") == "java_import"),
        "strict_import_row_exact": strict_total,
        "strict_dependency_evidence_non_recovery": target_total - strict_total,
        "raw_exact_mentions": raw_total,
        "full_fqn_omissions": target_total - raw_total,
        "simple_name_mentions": simple_total,
        "no_symbol_mentions": sum(1 for row in rows if row["evidence_category"] == "omitted"),
        "category_counts": dict(category_counts),
        "records_any_strict": sum(1 for row in record_rollup.values() if row["any_strict"]),
        "records_all_strict": sum(1 for row in record_rollup.values() if row["all_strict"]),
        "records_any_raw_exact": sum(1 for row in record_rollup.values() if row["any_raw_exact"]),
        "records_all_raw_exact": sum(1 for row in record_rollup.values() if row["all_raw_exact"]),
        "records_any_simple_name": sum(1 for row in record_rollup.values() if row["any_simple_name"]),
        "records_all_simple_name": sum(1 for row in record_rollup.values() if row["all_simple_name"]),
    }
    return summary, rows, list(record_rollup.values())


def write_target_csv(path, rows):
    fields = [
        "model",
        "record_id",
        "split",
        "source_set",
        "target_import",
        "target_simple_name",
        "target_package",
        "strict_import_row_exact",
        "raw_exact_mention",
        "simple_name_mention",
        "package_prefix_mention",
        "evidence_category",
        "generated_import_count",
        "generated_imports",
    ]
    with Path(path).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_record_csv(path, rows):
    fields = [
        "model",
        "record_id",
        "split",
        "source_set",
        "target_count",
        "strict_count",
        "raw_exact_count",
        "simple_name_count",
        "all_strict",
        "any_strict",
        "all_raw_exact",
        "any_raw_exact",
        "all_simple_name",
        "any_simple_name",
    ]
    with Path(path).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, summaries):
    lines = [
        "# Dependency-Evidence Non-Recovery on Masked External Imports",
        "",
        "A hidden import counts as strictly recovered only when the model emits a parseable `Import:` row whose fully qualified name exactly matches the masked external import. Hidden imports without such a row are reported as strict dependency-evidence non-recovery, not as direct hallucination labels. A raw exact mention is reported separately because it is present in the response text but not necessarily emitted as standardized dependency evidence. Simple-name mentions are symbol cues, not dependency evidence, because the incomplete code fragment can already expose simple class names.",
        "",
        "## Target-Level Evidence",
        "",
        "| Model | Hidden imports | Strict recovered | Strict non-recovery | Raw FQN mentions | FQN omissions | Raw-only FQN | Simple-name-only | Omitted |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for summary in summaries:
        counts = summary["category_counts"]
        raw_only = counts.get("raw_exact_unparseable", 0)
        simple_only = counts.get("simple_name_only", 0)
        omitted = counts.get("omitted", 0)
        lines.append(
            "| {model} | {targets} | {strict} | {fail} | {raw} | {fqn_omit} | {raw_only} | {simple_only} | {omitted} |".format(
                model=summary["model"],
                targets=summary["target_imports"],
                strict=fmt_rate(summary["strict_import_row_exact"], summary["target_imports"]),
                fail=fmt_rate(summary["strict_dependency_evidence_non_recovery"], summary["target_imports"]),
                raw=fmt_rate(summary["raw_exact_mentions"], summary["target_imports"]),
                fqn_omit=fmt_rate(summary["full_fqn_omissions"], summary["target_imports"]),
                raw_only=raw_only,
                simple_only=simple_only,
                omitted=omitted,
            )
        )

    lines.extend(
        [
            "",
            "## Record-Level Recovery",
            "",
            "| Model | Records | Any strict | All strict | Any raw FQN | All raw FQN | Any simple name | All simple names |",
            "|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for summary in summaries:
        records = summary["records"]
        lines.append(
            "| {model} | {records} | {any_strict} | {all_strict} | {any_raw} | {all_raw} | {any_simple} | {all_simple} |".format(
                model=summary["model"],
                records=records,
                any_strict=fmt_rate(summary["records_any_strict"], records),
                all_strict=fmt_rate(summary["records_all_strict"], records),
                any_raw=fmt_rate(summary["records_any_raw_exact"], records),
                all_raw=fmt_rate(summary["records_all_raw_exact"], records),
                any_simple=fmt_rate(summary["records_any_simple_name"], records),
                all_simple=fmt_rate(summary["records_all_simple_name"], records),
            )
        )

    lines.extend(
        [
            "",
            "## Category Counts",
            "",
            "| Model | strict_import_row_exact | raw_exact_unparseable | simple_name_only | package_prefix_only | omitted |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for summary in summaries:
        counts = summary["category_counts"]
        lines.append(
            "| {model} | {strict} | {raw_only} | {simple_only} | {package_only} | {omitted} |".format(
                model=summary["model"],
                strict=counts.get("strict_import_row_exact", 0),
                raw_only=counts.get("raw_exact_unparseable", 0),
                simple_only=counts.get("simple_name_only", 0),
                package_only=counts.get("package_prefix_only", 0),
                omitted=counts.get("omitted", 0),
            )
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_run_arg(value):
    parts = value.split("=", 1)
    if len(parts) != 2:
        raise argparse.ArgumentTypeError("run must be LABEL=RESPONSES_JSONL,CANDIDATES_CSV")
    label, rest = parts
    files = rest.split(",", 1)
    if len(files) != 2:
        raise argparse.ArgumentTypeError("run must be LABEL=RESPONSES_JSONL,CANDIDATES_CSV")
    return label, Path(files[0]), Path(files[1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--run", action="append", type=parse_run_arg, required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    prompts = {row.get("record_id", ""): row for row in read_jsonl(args.prompts_jsonl)}
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    summaries = []
    target_rows = []
    record_rows = []
    for label, responses_jsonl, candidates_csv in args.run:
        summary, per_target, per_record = analyze_run(label, prompts, responses_jsonl, candidates_csv)
        summaries.append(summary)
        target_rows.extend(per_target)
        record_rows.extend(per_record)

    output = {
        "prompts_jsonl": str(args.prompts_jsonl),
        "summaries": summaries,
        "target_rows": target_rows,
        "record_rows": record_rows,
    }
    (output_dir / "dependency_evidence_failure.json").write_text(
        json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    write_target_csv(output_dir / "dependency_evidence_failure_targets.csv", target_rows)
    write_record_csv(output_dir / "dependency_evidence_failure_records.csv", record_rows)
    write_markdown(output_dir / "dependency_evidence_failure.md", summaries)
    print(json.dumps({"summaries": summaries}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
