import argparse
import json
import re
from collections import Counter
from pathlib import Path


MASK_MARKER = "// One or more third-party import declarations were removed here for evaluation."
INCOMPLETE_MARKER = "Incomplete function prefix:\n```java\n"


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def incomplete_fragment(prompt):
    if INCOMPLETE_MARKER not in prompt:
        return ""
    return prompt.split(INCOMPLETE_MARKER, 1)[1].split("\n```", 1)[0]


def simple_name(import_path):
    cleaned = import_path.rstrip(".*")
    return cleaned.rsplit(".", 1)[-1] if cleaned else ""


def audit_rows(rows):
    issues = []
    split_counts = Counter()
    source_set_counts = Counter()
    masked_count_hist = Counter()
    root_counts = Counter()
    summary = Counter()

    for row in rows:
        record_id = row.get("record_id", f"line_{row.get('_line_no', '')}")
        prompt = row.get("prompt", "")
        masked_imports = row.get("masked_external_imports", [])
        summary["records"] += 1
        summary["masked_imports"] += len(masked_imports)
        split_counts[row.get("split", "")] += 1
        source_set_counts[row.get("source_set", "")] += 1
        masked_count_hist[str(len(masked_imports))] += 1
        for root in row.get("masked_external_import_roots", []):
            root_counts[root] += 1

        if MASK_MARKER in prompt:
            summary["mask_marker_present"] += 1
        else:
            issues.append({"record_id": record_id, "issue": "missing_mask_marker"})

        fragment = incomplete_fragment(prompt)
        if not fragment:
            issues.append({"record_id": record_id, "issue": "missing_incomplete_fragment"})

        for import_path in masked_imports:
            name = simple_name(import_path)
            if import_path in prompt:
                issues.append({"record_id": record_id, "issue": "exact_import_leak", "value": import_path})
            if not name or not re.search(rf"\b{re.escape(name)}\b", fragment):
                issues.append(
                    {
                        "record_id": record_id,
                        "issue": "simple_name_not_used_in_incomplete_fragment",
                        "value": import_path,
                        "simple_name": name,
                    }
                )

        for coord in row.get("build_dependency_coordinates_hidden_gold", []):
            if coord and coord in prompt:
                issues.append({"record_id": record_id, "issue": "hidden_coordinate_leak", "value": coord})

    return {
        "summary": dict(summary),
        "split_counts": dict(sorted(split_counts.items())),
        "source_set_counts": dict(sorted(source_set_counts.items())),
        "masked_count_histogram": dict(sorted(masked_count_hist.items(), key=lambda item: int(item[0]))),
        "top_masked_import_roots": root_counts.most_common(),
        "issues": issues,
    }


def write_markdown(path, audit, input_path):
    summary = audit["summary"]
    lines = [
        "# Java Dependency-Critical Prompt Audit",
        "",
        f"- Prompt file: `{input_path}`",
        f"- Records: `{summary.get('records', 0)}`",
        f"- Masked imports: `{summary.get('masked_imports', 0)}`",
        f"- Records with mask marker: `{summary.get('mask_marker_present', 0)}`",
        f"- Issues: `{len(audit['issues'])}`",
        "",
        "## Split Counts",
        "",
        "| Split | Records |",
        "|---|---:|",
    ]
    for split, count in audit["split_counts"].items():
        lines.append(f"| {split} | {count} |")

    lines.extend(["", "## Source Set Counts", "", "| Source set | Records |", "|---|---:|"])
    for source_set, count in audit["source_set_counts"].items():
        lines.append(f"| {source_set} | {count} |")

    lines.extend(["", "## Masked Import Count Per Prompt", "", "| Masked imports | Records |", "|---|---:|"])
    for masked_count, count in audit["masked_count_histogram"].items():
        lines.append(f"| {masked_count} | {count} |")

    lines.extend(["", "## Top Masked Import Roots", "", "| Root | Count |", "|---|---:|"])
    for root, count in audit["top_masked_import_roots"][:30]:
        lines.append(f"| `{root}` | {count} |")

    if audit["issues"]:
        lines.extend(["", "## Issues", "", "| Record | Issue | Value |", "|---|---|---|"])
        for issue in audit["issues"][:100]:
            lines.append(
                f"| `{issue.get('record_id', '')}` | `{issue.get('issue', '')}` | `{issue.get('value', '')}` |"
            )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    rows = read_jsonl(Path(args.prompts_jsonl))
    audit = audit_rows(rows)
    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), audit, args.prompts_jsonl)
    print(json.dumps({"records": audit["summary"].get("records", 0), "issues": len(audit["issues"])}, indent=2))


if __name__ == "__main__":
    main()
