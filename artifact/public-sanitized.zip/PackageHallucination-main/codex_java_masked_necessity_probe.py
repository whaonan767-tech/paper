#!/usr/bin/env python3
"""Test whether masked imports cause target-specific build failures."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

import codex_java_masked_baseline_audit as baseline


PACKAGE_ROOT = Path(__file__).resolve().parent
WORKSPACE = PACKAGE_ROOT.parents[1]
APIHUL_ROOT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>"
PROMPTS = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730"
    / "prompts.jsonl"
)
BUILD_AUDIT = APIHUL_ROOT / "outputs" / "build_validation_audit.json"
BASELINE = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803"
    / "masked_baseline_audit.json"
)
DEFAULT_WORK_ROOT = WORKSPACE / "vw" / "masked_semantic_necessity"
DEFAULT_OUTPUT_ROOT = PACKAGE_ROOT / "Tests"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--keep-workdirs", action="store_true")
    parser.add_argument("--retry-status", action="append", default=[])
    return parser.parse_args()


def remove_imports(source: str, imports: list[str]) -> tuple[str, list[str]]:
    updated = source
    removed = []
    for import_path in imports:
        pattern = re.compile(
            rf"(?m)^[ \t]*import[ \t]+(?:static[ \t]+)?{re.escape(import_path)}[ \t]*;[ \t]*(?:\r?\n)?"
        )
        updated, count = pattern.subn("", updated)
        if count == 1:
            removed.append(import_path)
        elif count > 1:
            raise ValueError(f"duplicate import matches for {import_path}: {count}")
    return updated, removed


def target_evidence(output: str, imports: list[str]) -> list[str]:
    lowered = output.lower()
    found = []
    for import_path in imports:
        simple = import_path.rsplit(".", 1)[-1]
        package = import_path.rsplit(".", 1)[0] if "." in import_path else ""
        simple_pattern = re.compile(
            rf"(?<![A-Za-z0-9_$]){re.escape(simple.lower())}(?![A-Za-z0-9_$])"
        )
        if import_path.lower() in lowered or (
            package and package.lower() in lowered
        ) or simple_pattern.search(lowered):
            found.append(import_path)
    return found


def suffix_score(path: Path, expected_relative: Path) -> int:
    score = 0
    for actual, expected in zip(reversed(path.parts), reversed(expected_relative.parts)):
        if actual.lower() != expected.lower():
            break
        score += 1
    return score


def locate_target_file(
    copied_project: Path, original_project: Path, original_target: Path
) -> tuple[Path, str]:
    expected_relative = original_target.relative_to(original_project)
    exact = copied_project / expected_relative
    if exact.exists() and exact.is_file():
        return exact, "exact"
    try:
        matches = [
            path
            for path in copied_project.rglob(original_target.name)
            if path.exists() and path.is_file()
        ]
    except OSError:
        matches = []
    if matches:
        matches.sort(
            key=lambda path: suffix_score(path, expected_relative), reverse=True
        )
        return matches[0], "filename_fallback"
    return exact, "not_found"


def load_records(
    prompts: list[dict], audit_by_key: dict[str, dict], baseline_payload: dict
) -> tuple[list[dict], dict[str, str | None]]:
    passing = {
        row["build_key"]: row
        for row in baseline_payload["results"]
        if row["status"] == "pass"
    }
    jdk_homes = {
        row["label"]: (None if row["home"] == "system" else row["home"])
        for row in baseline_payload["metadata"]["java_matrix"]
    }
    records = []
    for prompt in prompts:
        key = baseline.sample_key(prompt)
        audit = audit_by_key[key]
        build_key = f"{audit['project_path']}::{audit['build_root']}::{audit['build_system']}"
        baseline_row = passing.get(build_key)
        if baseline_row is None:
            continue
        records.append(
            {
                "record_id": prompt["record_id"],
                "sample_key": key,
                "split": prompt["split"],
                "source_set": prompt["source_set"],
                "project_path": audit["project_path"],
                "file_path": audit["file_path"],
                "build_root": audit["build_root"],
                "build_system": audit["build_system"],
                "build_key": build_key,
                "masked_imports": list(prompt["masked_external_imports"]),
                "selected_java_home": baseline_row["selected_java_home"],
                "audit": audit,
            }
        )
    records.sort(key=lambda row: row["record_id"])
    return records, jdk_homes


def summarize(records: list[dict], results: list[dict]) -> dict:
    target_failures = [row for row in results if row["target_failure_evidence"]]
    return {
        "baseline_eligible_records": len(records),
        "baseline_eligible_projects": len({row["project_path"] for row in records}),
        "baseline_eligible_build_units": len({row["build_key"] for row in records}),
        "baseline_eligible_hidden_imports": sum(len(row["masked_imports"]) for row in records),
        "completed_records": len(results),
        "masked_pass_records": sum(row["status"] == "pass" for row in results),
        "target_failure_records": len(target_failures),
        "target_failure_projects": len({row["project_path"] for row in target_failures}),
        "target_failure_hidden_imports": sum(row["masked_import_count"] for row in target_failures),
        "non_target_failure_records": sum(
            row["status"] not in {"pass", "mutation_error"}
            and not row["target_failure_evidence"]
            for row in results
        ),
        "mutation_error_records": sum(row["status"] == "mutation_error" for row in results),
        "status_counts": dict(Counter(row["status"] for row in results)),
        "failure_detail_counts": dict(
            Counter(row["failure_detail"] for row in results if row["status"] != "pass")
        ),
        "duration_seconds": round(sum(float(row["duration_seconds"]) for row in results), 3),
    }


def write_outputs(
    output_dir: Path,
    run_name: str,
    records: list[dict],
    results: list[dict],
    metadata: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(records, results)
    payload = {
        "run_name": run_name,
        "phase": "masked_gold_code_necessity_probe",
        "summary": summary,
        "metadata": metadata,
        "results": results,
    }
    (output_dir / "masked_necessity_probe.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    fields = [
        "record_id",
        "sample_key",
        "source_set",
        "project_path",
        "file_path",
        "build_key",
        "selected_java_home",
        "masked_import_count",
        "masked_imports",
        "removed_import_count",
        "removed_imports",
        "target_resolution",
        "status",
        "failure_detail",
        "target_failure_evidence",
        "target_evidence_imports",
        "return_code",
        "timed_out",
        "duration_seconds",
        "command",
        "log_path",
    ]
    with (output_dir / "masked_necessity_probe.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    lines = [
        "# Masked-Import Necessity Probe",
        "",
        f"- Baseline-eligible records: `{summary['baseline_eligible_records']}`.",
        f"- Baseline-eligible projects: `{summary['baseline_eligible_projects']}`.",
        f"- Baseline-eligible build units: `{summary['baseline_eligible_build_units']}`.",
        f"- Baseline-eligible hidden imports: `{summary['baseline_eligible_hidden_imports']}`.",
        f"- Completed masked builds: `{summary['completed_records']}`.",
        f"- Masked variants that still pass: `{summary['masked_pass_records']}`.",
        f"- Target-evidenced masked failures: `{summary['target_failure_records']}`.",
        f"- Projects with target-evidenced failures: `{summary['target_failure_projects']}`.",
        f"- Non-target failures: `{summary['non_target_failure_records']}`.",
        f"- Mutation errors: `{summary['mutation_error_records']}`.",
        "",
        "## Status Counts",
        "",
        "| Status | Records |",
        "|---|---:|",
    ]
    for status, count in sorted(summary["status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(
        [
            "",
            "## Per-Record Results",
            "",
            "| Record | Source | Imports | JDK | Status | Target evidence | Seconds |",
            "|---|---|---:|---|---|---|---:|",
        ]
    )
    for row in results:
        lines.append(
            f"| `{row['record_id']}` | `{row['source_set']}` | {row['masked_import_count']} | "
            f"`{row['selected_java_home']}` | `{row['status']}` | "
            f"`{str(row['target_failure_evidence']).lower()}` | {row['duration_seconds']:.3f} |"
        )
    (output_dir / "masked_necessity_probe.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve())
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    all_records, jdk_homes = load_records(prompts, audit_by_key, baseline_payload)
    records = all_records[: args.limit] if args.limit else all_records

    run_name = args.run_name or datetime.now().strftime(
        "Java_APIHulBench_MaskedSemanticBuild_Necessity_Run%Y%m%d_%H%M%S"
    )
    output_dir = args.output_root.resolve() / run_name
    output_json = output_dir / "masked_necessity_probe.json"
    short_work_name = "run_" + hashlib.sha256(run_name.encode("utf-8")).hexdigest()[:10]
    work_root = args.work_root.resolve() / short_work_name
    if args.resume:
        if not output_json.exists():
            raise SystemExit(f"Cannot resume; output is missing: {output_json}")
        previous = json.loads(output_json.read_text(encoding="utf-8"))
        results = previous.get("results", [])
        if args.retry_status:
            retry_statuses = set(args.retry_status)
            results = [row for row in results if row["status"] not in retry_statuses]
    else:
        if output_dir.exists() or work_root.exists():
            raise SystemExit(f"Run path already exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True)
    work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = work_root / "tmp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(temp_dir)
    os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (
        os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}"
    ).strip()

    metadata = {
        "prompts": str(args.prompts.resolve()),
        "prompts_sha256": baseline.sha256(args.prompts.resolve()),
        "build_audit": str(args.build_audit.resolve()),
        "build_audit_sha256": baseline.sha256(args.build_audit.resolve()),
        "baseline": str(args.baseline.resolve()),
        "baseline_sha256": baseline.sha256(args.baseline.resolve()),
        "script_sha256": baseline.sha256(Path(__file__).resolve()),
        "timeout_seconds": args.timeout,
        "work_root": str(work_root),
        "temporary_files_on_d_drive": True,
        "workdirs_retained": args.keep_workdirs,
        "all_baseline_eligible_records": len(all_records),
        "selected_records": len(records),
        "jdk_homes": jdk_homes,
    }
    write_outputs(output_dir, run_name, records, results, metadata)
    completed = {row["record_id"] for row in results}

    for index, record in enumerate(records, start=1):
        if record["record_id"] in completed:
            print(f"[{index}/{len(records)}] SKIP COMPLETED {record['record_id']}", flush=True)
            continue
        original_project = validation.normalize_workspace_path(record["project_path"])
        original_target = validation.normalize_workspace_path(record["file_path"])
        copied_project = work_root / f"r{index:03d}"
        copy_log = logs_dir / f"record_{index:03d}_copy.log"
        print(f"[{index}/{len(records)}] COPY {record['record_id']}", flush=True)
        copied, copy_error = validation.copy_project_tree(
            original_project, copied_project, copy_log
        )
        plan = {}
        command: list[str] = []
        removed: list[str] = []
        evidence_imports: list[str] = []
        target_failure = False
        target_resolution = ""
        if not copied:
            outcome = {
                "return_code": "",
                "timed_out": False,
                "duration_seconds": 0.0,
                "status": "project_copy_failed",
                "failure_detail": "project_copy_failed",
                "log_path": validation.display_path(copy_log),
                "tail": copy_error,
            }
        else:
            copied_target, target_resolution = locate_target_file(
                copied_project, original_project, original_target
            )
            try:
                source = copied_target.read_text(encoding="utf-8", errors="strict")
                mutated, removed = remove_imports(source, record["masked_imports"])
                if len(removed) != len(record["masked_imports"]):
                    missing = sorted(set(record["masked_imports"]) - set(removed))
                    raise ValueError(f"imports not removed exactly: {missing}")
                copied_target.write_text(mutated, encoding="utf-8", newline="")
                plan = validation.build_plan(record["audit"], copied_project)
                command = baseline.clean_build_command(plan["command"])
                java_value = jdk_homes[record["selected_java_home"]]
                java_home = Path(java_value) if java_value else None
                log_path = logs_dir / f"record_{index:03d}_masked_gold.log"
                print(f"[{index}/{len(records)}] BUILD {record['selected_java_home']}", flush=True)
                outcome = validation.run_build(
                    command, plan["cwd"], args.timeout, log_path, java_home
                )
                if "maven" in record["build_system"] and validation.should_retry_local_maven(outcome):
                    retry_plan = validation.build_plan(
                        record["audit"], copied_project, force_local=True
                    )
                    retry_command = baseline.clean_build_command(retry_plan["command"])
                    if retry_command != command or retry_plan["cwd"] != plan["cwd"]:
                        retry_log = logs_dir / f"record_{index:03d}_masked_gold_local_retry.log"
                        print(
                            f"[{index}/{len(records)}] RETRY LOCAL {record['selected_java_home']}",
                            flush=True,
                        )
                        outcome = validation.run_build(
                            retry_command,
                            retry_plan["cwd"],
                            args.timeout,
                            retry_log,
                            java_home,
                        )
                        plan = retry_plan
                        command = retry_command
                        log_path = retry_log
                full_output = Path(log_path).read_text(encoding="utf-8", errors="replace")
                evidence_imports = target_evidence(full_output, record["masked_imports"])
                target_failure = (
                    outcome["status"] == "source_compile_failure" and bool(evidence_imports)
                )
            except Exception as error:
                outcome = {
                    "return_code": "",
                    "timed_out": False,
                    "duration_seconds": 0.0,
                    "status": "mutation_error",
                    "failure_detail": str(error),
                    "log_path": "",
                    "tail": "",
                }

        results.append(
            {
                "record_id": record["record_id"],
                "sample_key": record["sample_key"],
                "source_set": record["source_set"],
                "project_path": record["project_path"],
                "file_path": record["file_path"],
                "build_key": record["build_key"],
                "selected_java_home": record["selected_java_home"],
                "masked_import_count": len(record["masked_imports"]),
                "masked_imports": ";".join(record["masked_imports"]),
                "removed_import_count": len(removed),
                "removed_imports": ";".join(removed),
                "target_resolution": target_resolution,
                "target_failure_evidence": target_failure,
                "target_evidence_imports": ";".join(evidence_imports),
                "command": " ".join(command),
                **outcome,
            }
        )
        write_outputs(output_dir, run_name, records, results, metadata)
        if not args.keep_workdirs and copied_project.exists():
            baseline.safe_remove_tree(copied_project, work_root)

    if not args.keep_workdirs and temp_dir.exists():
        baseline.safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
