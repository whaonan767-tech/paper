import argparse
import ast
import json
from pathlib import Path

import pandas as pd

from codex_analyze_hallucinated_packages import is_artifact_like


DATASET_ORDER = ["LLM_LY", "LLM_AT", "SO_LY", "SO_AT"]


def parse_list(value):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return []
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    except Exception:
        pass
    return [text]


def rate(valid, hallucinated):
    denom = valid + hallucinated
    return hallucinated / denom if denom else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output-prefix", default="filtered_rates")
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    metadata = json.loads((run_dir / "metadata.json").read_text(encoding="utf-8"))
    limit = int(metadata["limit_per_dataset"])
    df = pd.read_csv(run_dir / "PACKAGE_NAMES.csv")

    rows = []
    totals = {
        "valid_1": 0,
        "raw_hallucinated_1": 0,
        "filtered_hallucinated_1": 0,
        "valid_2": 0,
        "raw_hallucinated_2": 0,
        "filtered_hallucinated_2": 0,
        "removed_1": 0,
        "removed_2": 0,
    }

    for dataset_idx, dataset_name in enumerate(DATASET_ORDER):
        start = dataset_idx * limit
        end = start + limit
        subset = df.iloc[start:end]
        valid_1 = sum(len(parse_list(value)) for value in subset["valid_1"])
        valid_2 = sum(len(parse_list(value)) for value in subset["valid_2"])
        raw_h1_items = [item for value in subset["hallucinated_1"] for item in parse_list(value)]
        raw_h2_items = [item for value in subset["hallucinated_2"] for item in parse_list(value)]
        filtered_h1_items = [item for item in raw_h1_items if not is_artifact_like(item)]
        filtered_h2_items = [item for item in raw_h2_items if not is_artifact_like(item)]

        row = {
            "dataset": dataset_name,
            "valid_1": valid_1,
            "raw_hallucinated_1": len(raw_h1_items),
            "raw_rate_1": rate(valid_1, len(raw_h1_items)),
            "filtered_hallucinated_1": len(filtered_h1_items),
            "filtered_rate_1": rate(valid_1, len(filtered_h1_items)),
            "removed_1": len(raw_h1_items) - len(filtered_h1_items),
            "valid_2": valid_2,
            "raw_hallucinated_2": len(raw_h2_items),
            "raw_rate_2": rate(valid_2, len(raw_h2_items)),
            "filtered_hallucinated_2": len(filtered_h2_items),
            "filtered_rate_2": rate(valid_2, len(filtered_h2_items)),
            "removed_2": len(raw_h2_items) - len(filtered_h2_items),
        }
        rows.append(row)
        for key in totals:
            totals[key] += row[key]

    totals["raw_rate_1"] = rate(totals["valid_1"], totals["raw_hallucinated_1"])
    totals["filtered_rate_1"] = rate(totals["valid_1"], totals["filtered_hallucinated_1"])
    totals["raw_rate_2"] = rate(totals["valid_2"], totals["raw_hallucinated_2"])
    totals["filtered_rate_2"] = rate(totals["valid_2"], totals["filtered_hallucinated_2"])

    output = {
        "run_dir": str(run_dir),
        "limit_per_dataset": limit,
        "rows": rows,
        "totals": totals,
    }
    out_json = run_dir / f"{args.output_prefix}.json"
    out_md = run_dir / f"{args.output_prefix}.md"
    out_csv = run_dir / f"{args.output_prefix}.csv"

    out_json.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    pd.DataFrame(rows + [{"dataset": "Totals", **totals}]).to_csv(out_csv, index=False)

    lines = [
        "# Artifact-Filtered Hallucination Rates",
        "",
        f"- Run directory: `{run_dir}`",
        f"- Limit per dataset: `{limit}`",
        "",
        "| Dataset | Raw Q1 | Filtered Q1 | Removed Q1 | Raw Q2 | Filtered Q2 | Removed Q2 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {dataset} | {raw_hallucinated_1}/{den1_raw} ({raw_rate_1:.3f}) | "
            "{filtered_hallucinated_1}/{den1_filtered} ({filtered_rate_1:.3f}) | {removed_1} | "
            "{raw_hallucinated_2}/{den2_raw} ({raw_rate_2:.3f}) | "
            "{filtered_hallucinated_2}/{den2_filtered} ({filtered_rate_2:.3f}) | {removed_2} |".format(
                den1_raw=row["valid_1"] + row["raw_hallucinated_1"],
                den1_filtered=row["valid_1"] + row["filtered_hallucinated_1"],
                den2_raw=row["valid_2"] + row["raw_hallucinated_2"],
                den2_filtered=row["valid_2"] + row["filtered_hallucinated_2"],
                **row,
            )
        )
    lines.append(
        "| **Totals** | {raw_hallucinated_1}/{den1_raw} ({raw_rate_1:.3f}) | "
        "{filtered_hallucinated_1}/{den1_filtered} ({filtered_rate_1:.3f}) | {removed_1} | "
        "{raw_hallucinated_2}/{den2_raw} ({raw_rate_2:.3f}) | "
        "{filtered_hallucinated_2}/{den2_filtered} ({filtered_rate_2:.3f}) | {removed_2} |".format(
            den1_raw=totals["valid_1"] + totals["raw_hallucinated_1"],
            den1_filtered=totals["valid_1"] + totals["filtered_hallucinated_1"],
            den2_raw=totals["valid_2"] + totals["raw_hallucinated_2"],
            den2_filtered=totals["valid_2"] + totals["filtered_hallucinated_2"],
            **totals,
        )
    )
    out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {out_json}, {out_md}, and {out_csv}")


if __name__ == "__main__":
    main()
