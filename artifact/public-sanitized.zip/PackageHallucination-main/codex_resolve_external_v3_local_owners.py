#!/usr/bin/env python3
"""Resolve unmapped local repository owners using frozen GitHub search snapshots."""

from __future__ import annotations

import argparse
import json
import os
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from codex_build_external_v3_exclusions import repository_key


def request_json(url: str, timeout: float) -> dict:
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "dependency-audit-research-v3-owner-resolution"}
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exclusions", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--sleep", type=float, default=7.0)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    boundary = json.loads(args.exclusions.read_text(encoding="utf-8"))
    output = args.output_dir
    snapshots = output / "snapshots"
    snapshots.mkdir(parents=True, exist_ok=True)
    rows = []
    pending = [row for row in boundary["local_projects"] if not row.get("inferred_full_names")]
    for index, row in enumerate(pending, 1):
        folder = row["project_folder"]
        key = repository_key(folder)
        snapshot_path = snapshots / f"{index:03d}_{key or 'unknown'}.json"
        if args.resume and snapshot_path.is_file():
            payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
        else:
            query = f"{key} in:name language:Java"
            url = "https://api.github.com/search/repositories?" + urllib.parse.urlencode({"q": query, "sort": "stars", "order": "desc", "per_page": 10})
            payload = request_json(url, args.timeout)
            snapshot_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            if index < len(pending):
                time.sleep(args.sleep)
        exact = sorted({item["full_name"] for item in payload.get("items", []) if repository_key(item.get("name", "")) == key})
        rows.append({
            "project_folder": folder, "repository_key": key, "candidate_full_names": exact,
            "resolution_status": "exact_unique" if len(exact) == 1 else "exact_multiple" if exact else "unresolved",
            "search_total_count": payload.get("total_count", 0), "snapshot_file": snapshot_path.name,
        })
        print(f"OWNER {index}/{len(pending)} {folder}: {rows[-1]['resolution_status']} {','.join(exact)}", flush=True)
    result = {
        "artifact": "external_java_v3_local_owner_resolution", "resolved_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_unmapped_projects": len(pending), "resolved_projects": sum(bool(row["candidate_full_names"]) for row in rows),
        "unresolved_projects": sum(not row["candidate_full_names"] for row in rows),
        "policy": "Accept only GitHub search results whose normalized version-stripped repository name exactly matches the frozen local folder key; exclude all owners when multiple exact-name repositories exist.",
        "rows": rows,
    }
    (output / "local_owner_resolution.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (output / "local_owner_resolution.md").write_text("# External V3 Local Owner Resolution\n\n" + f"- Input unmapped projects: `{result['input_unmapped_projects']}`.\n- Resolved projects: `{result['resolved_projects']}`.\n- Unresolved projects: `{result['unresolved_projects']}`.\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("input_unmapped_projects", "resolved_projects", "unresolved_projects")}, indent=2))


if __name__ == "__main__":
    main()
