import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


DATASETS = {
    "LLM_Recent": {
        "master_file": "LLM_Recent_Master.json",
        "packages_1_file": "LLM_Recent_packages_1.json",
        "packages_2_file": "LLM_Recent_packages_2.json",
    },
    "LLM_All_Time": {
        "master_file": "LLM_All_Time_Master.json",
        "packages_1_file": "LLM_All_Time_packages_1.json",
        "packages_2_file": "LLM_All_Time_packages_2.json",
    },
    "Stack_Overflow_Recent": {
        "master_file": "Stack_Overflow_Recent_Master.json",
        "packages_1_file": "Stack_Overflow_Recent_packages_1.json",
        "packages_2_file": "Stack_Overflow_Recent_packages_2.json",
    },
    "Stack_Overflow_All_Time": {
        "master_file": "Stack_Overflow_All_Time_Master.json",
        "packages_1_file": "Stack_Overflow_All_Time_packages_1.json",
        "packages_2_file": "Stack_Overflow_All_Time_packages_2.json",
    },
}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def load_metadata(run_dir):
    path = run_dir / "metadata.json"
    if not path.exists():
        raise FileNotFoundError(f"Missing metadata: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def nonempty_lines(path):
    with path.open("r", encoding="utf-8") as handle:
        return [line.rstrip("\n") for line in handle if line.strip()]


def write_lines(path, lines):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def validate_compatible(metas):
    first = metas[0]
    comparable_keys = [
        "model_path",
        "model_label",
        "language",
        "datasets",
        "max_code_tokens",
        "max_package_tokens",
        "load_in_4bit",
        "generation",
    ]
    for meta in metas[1:]:
        for key in comparable_keys:
            if meta.get(key) != first.get(key):
                raise ValueError(f"Incompatible metadata for key `{key}`")

    ordered = sorted(metas, key=lambda item: int(item.get("offset", 0)))
    expected = int(ordered[0].get("offset", 0))
    for meta in ordered:
        offset = int(meta.get("offset", 0))
        limit = int(meta.get("limit_per_dataset", 0))
        if offset != expected:
            raise ValueError(f"Runs are not contiguous: expected offset {expected}, got {offset}")
        expected += limit
    return ordered


def copy_if_exists(src, dst):
    if src.exists():
        shutil.copy2(src, dst)


def merge_dataset_files(run_dirs, output_dir, datasets):
    counts = {}
    for dataset in datasets:
        spec = DATASETS[dataset]
        dataset_counts = {}
        for key in ["master_file", "packages_1_file", "packages_2_file"]:
            merged_lines = []
            per_run_counts = []
            for run_dir in run_dirs:
                path = run_dir / spec[key]
                lines = nonempty_lines(path)
                merged_lines.extend(lines)
                per_run_counts.append({"run_dir": str(run_dir), "rows": len(lines)})
            write_lines(output_dir / spec[key], merged_lines)
            dataset_counts[key] = {
                "rows": len(merged_lines),
                "per_run": per_run_counts,
            }
        row_counts = {value["rows"] for value in dataset_counts.values()}
        if len(row_counts) != 1:
            raise ValueError(f"Mismatched merged row counts for dataset `{dataset}`: {dataset_counts}")
        counts[dataset] = dataset_counts
    return counts


def merge_raw_generations(run_dirs, output_dir):
    merged_path = output_dir / "raw_generations.jsonl"
    with merged_path.open("w", encoding="utf-8", newline="\n") as out:
        for run_dir in run_dirs:
            raw_path = run_dir / "raw_generations.jsonl"
            with raw_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if line.strip():
                        out.write(line.rstrip("\n") + "\n")
    return merged_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", action="append", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--copy-logs", action="store_true")
    args = parser.parse_args()

    run_dirs = [Path(value) for value in args.run_dir]
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    metas_by_path = [(run_dir, load_metadata(run_dir)) for run_dir in run_dirs]
    ordered_metas = validate_compatible([meta for _, meta in metas_by_path])
    offset_to_dir = {int(meta.get("offset", 0)): run_dir for run_dir, meta in metas_by_path}
    ordered_run_dirs = [offset_to_dir[int(meta.get("offset", 0))] for meta in ordered_metas]

    datasets = ordered_metas[0].get("datasets", list(DATASETS))
    missing = sorted(set(datasets) - set(DATASETS))
    if missing:
        raise ValueError(f"Unknown dataset(s) in metadata: {missing}")

    counts = merge_dataset_files(ordered_run_dirs, output_dir, datasets)
    raw_generations = merge_raw_generations(ordered_run_dirs, output_dir)

    total_limit = sum(int(meta.get("limit_per_dataset", 0)) for meta in ordered_metas)
    merged_metadata = dict(ordered_metas[0])
    merged_metadata.update(
        {
            "merged_at": utc_now(),
            "merged_from": [
                {
                    "run_dir": str(run_dir),
                    "offset": int(meta.get("offset", 0)),
                    "limit_per_dataset": int(meta.get("limit_per_dataset", 0)),
                    "started_at": meta.get("started_at"),
                    "finished_at": meta.get("finished_at"),
                }
                for run_dir, meta in zip(ordered_run_dirs, ordered_metas)
            ],
            "offset": int(ordered_metas[0].get("offset", 0)),
            "limit_per_dataset": total_limit,
            "raw_generations": str(raw_generations),
            "merge_counts": counts,
        }
    )
    (output_dir / "metadata.json").write_text(
        json.dumps(merged_metadata, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    if args.copy_logs:
        log_dir = output_dir / "source_logs"
        log_dir.mkdir(exist_ok=True)
        for run_dir in ordered_run_dirs:
            for log_name in ["runner.stdout.log", "runner.stderr.log", "run_runner.cmd"]:
                copy_if_exists(run_dir / log_name, log_dir / f"{run_dir.name}_{log_name}")

    print(f"Merged {len(ordered_run_dirs)} runs into {output_dir}")
    print(f"Total limit per dataset: {total_limit}")


if __name__ == "__main__":
    main()
