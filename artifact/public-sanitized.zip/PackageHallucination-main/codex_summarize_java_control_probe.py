import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


def read_csv(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pct(num, den):
    if den == 0:
        return None
    return num / den


def fmt(value):
    if value is None:
        return "n/a"
    return f"{100 * value:.1f}%"


def compact(value, limit=180):
    value = (value or "").replace("\r\n", " ").replace("\n", " ").strip()
    value = re.sub(r"\s+", " ", value)
    if len(value) <= limit:
        return value
    return value[: limit - 15].rstrip() + " ...[truncated]"


def failure_category(tail):
    text = tail or ""
    lowered = text.lower()
    if "package " in lowered and " does not exist" in lowered:
        return "package_missing_or_classpath_absent"
    if "cannot find symbol" in lowered:
        return "cannot_find_symbol"
    if "';' expected" in lowered or "<identifier> expected" in lowered or "illegal start of" in lowered:
        return "malformed_import_syntax"
    if "static import only from classes and interfaces" in lowered:
        return "static_member_import_not_represented"
    if not text.strip():
        return "no_compiler_output"
    return "other_javac_failure"


def unique_join(values):
    seen = []
    for value in values:
        if value and value not in seen:
            seen.append(value)
    return ";".join(seen)


def build_metadata(audit_rows):
    by_record = defaultdict(list)
    for row in audit_rows:
        by_record[row.get("original_record_id", "")].append(row)
    metadata = {}
    for record_id, rows in by_record.items():
        metadata[record_id] = {
            "sample_groups": unique_join(row.get("sample_group", "") for row in rows),
            "negative_buckets": unique_join(row.get("negative_bucket", "") for row in rows),
            "mapping_statuses": unique_join(row.get("mapping_status", "") for row in rows),
            "candidate_rows": len(rows),
            "imports": unique_join(row.get("import_path", "") for row in rows),
        }
    return metadata


def summarize(audit_sheet, probe_json):
    audit_rows = read_csv(audit_sheet)
    probe = read_json(probe_json)
    metadata = build_metadata(audit_rows)

    rows_by_variant = defaultdict(list)
    for row in probe.get("results", []):
        rows_by_variant[row.get("variant", "")].append(row)

    raw_rows = rows_by_variant.get("raw_suspicious_imports", [])
    empty_rows = rows_by_variant.get("sanitized_removed_imports", [])
    raw_by_id = {row.get("record_id", ""): row for row in raw_rows}
    empty_by_id = {row.get("record_id", ""): row for row in empty_rows}

    annotated_rows = []
    for record_id, raw in sorted(raw_by_id.items()):
        meta = metadata.get(record_id, {})
        empty = empty_by_id.get(record_id, {})
        annotated_rows.append(
            {
                "record_id": record_id,
                "candidate_rows": meta.get("candidate_rows", 0),
                "negative_buckets": meta.get("negative_buckets", ""),
                "mapping_statuses": raw.get("mapping_statuses", meta.get("mapping_statuses", "")),
                "raw_status": raw.get("status", ""),
                "empty_import_status": empty.get("status", ""),
                "failure_category": "" if raw.get("status") == "pass" else failure_category(raw.get("tail", "")),
                "imports": raw.get("injected_imports", meta.get("imports", "")),
                "compiler_evidence": raw.get("log_mentions_injected_import", ""),
                "log_path": raw.get("log_path", ""),
                "compiler_tail_excerpt": compact(raw.get("tail", "")),
            }
        )

    by_bucket = defaultdict(Counter)
    by_mapping = defaultdict(Counter)
    by_failure = Counter()
    for row in annotated_rows:
        status = row["raw_status"]
        by_bucket[row["negative_buckets"]][status] += 1
        by_mapping[row["mapping_statuses"]][status] += 1
        if status != "pass":
            by_failure[row["failure_category"]] += 1

    raw_pass = sum(row["raw_status"] == "pass" for row in annotated_rows)
    raw_fail = sum(row["raw_status"] != "pass" for row in annotated_rows)
    empty_pass = sum(row["empty_import_status"] == "pass" for row in annotated_rows)
    empty_fail = sum(row["empty_import_status"] != "pass" for row in annotated_rows)
    negative_audit_rows = [row for row in audit_rows if row.get("sample_group") == "negative_control_unflagged"]

    return {
        "run_name": probe.get("run_name", ""),
        "probe_json": str(Path(probe_json).resolve()),
        "negative_control_candidate_rows": len(negative_audit_rows),
        "negative_control_records": len(annotated_rows),
        "raw_candidate_import_records_pass": raw_pass,
        "raw_candidate_import_records_fail": raw_fail,
        "raw_candidate_import_records_pass_rate": pct(raw_pass, len(annotated_rows)),
        "empty_import_baseline_records_pass": empty_pass,
        "empty_import_baseline_records_fail": empty_fail,
        "empty_import_baseline_records_pass_rate": pct(empty_pass, len(annotated_rows)),
        "status_by_negative_bucket": {key: dict(value) for key, value in sorted(by_bucket.items())},
        "status_by_mapping_statuses": {key: dict(value) for key, value in sorted(by_mapping.items())},
        "failure_categories": dict(by_failure.most_common()),
        "records": annotated_rows,
    }


def probe_simple_summary(probe_json):
    probe = read_json(probe_json)
    summary = probe.get("summary", {})
    raw = summary.get("variants", {}).get("raw_suspicious_imports", {})
    empty = summary.get("variants", {}).get("sanitized_removed_imports", {})
    records = summary.get("target_records", 0)
    return {
        "run_name": probe.get("run_name", ""),
        "probe_json": str(Path(probe_json).resolve()),
        "candidate_import_rows": summary.get("suspicious_import_rows", 0),
        "records": records,
        "candidate_import_records_pass": raw.get("pass", 0),
        "candidate_import_records_fail": raw.get("fail", 0),
        "candidate_import_records_pass_rate": pct(raw.get("pass", 0), records),
        "empty_import_baseline_pass": empty.get("pass", 0),
        "empty_import_baseline_fail": empty.get("fail", 0),
        "empty_import_baseline_pass_rate": pct(empty.get("pass", 0), records),
    }


def write_csv(path, rows):
    if not rows:
        return
    fieldnames = [
        "record_id",
        "candidate_rows",
        "negative_buckets",
        "mapping_statuses",
        "raw_status",
        "empty_import_status",
        "failure_category",
        "imports",
        "compiler_evidence",
        "log_path",
        "compiler_tail_excerpt",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, payload):
    lines = [
        "# Java Unflagged-Control Import-Only Probe",
        "",
        "This control probe reruns the import-only javac sentinel on the stratified unflagged-control records from the human-audit sample.",
        "The result should be interpreted as a limitation check for the import-only probe, not as ground truth for dependency validity.",
        "",
        "## Key Outcomes",
        "",
        f"- Negative-control candidate rows: `{payload['negative_control_candidate_rows']}`",
        f"- Negative-control records: `{payload['negative_control_records']}`",
        f"- Candidate-import sentinel pass: `{payload['raw_candidate_import_records_pass']} / {payload['negative_control_records']}` ({fmt(payload['raw_candidate_import_records_pass_rate'])})",
        f"- Empty-import baseline pass: `{payload['empty_import_baseline_records_pass']} / {payload['negative_control_records']}` ({fmt(payload['empty_import_baseline_records_pass_rate'])})",
        "",
    ]

    flagged = payload.get("flagged_detector_probe")
    if flagged:
        lines.extend(
            [
                "## Flagged vs. Unflagged Same-Protocol Comparison",
                "",
                "| Group | Candidate rows | Records | Candidate-import pass | Empty-import baseline pass |",
                "|---|---:|---:|---:|---:|",
                f"| Detector-flagged imports | {flagged['candidate_import_rows']} | {flagged['records']} | {flagged['candidate_import_records_pass']} / {flagged['records']} ({fmt(flagged['candidate_import_records_pass_rate'])}) | {flagged['empty_import_baseline_pass']} / {flagged['records']} ({fmt(flagged['empty_import_baseline_pass_rate'])}) |",
                f"| Unflagged controls | {payload['negative_control_candidate_rows']} | {payload['negative_control_records']} | {payload['raw_candidate_import_records_pass']} / {payload['negative_control_records']} ({fmt(payload['raw_candidate_import_records_pass_rate'])}) | {payload['empty_import_baseline_records_pass']} / {payload['negative_control_records']} ({fmt(payload['empty_import_baseline_records_pass_rate'])}) |",
                "",
            ]
        )

    lines.extend(
        [
            "## Record Outcomes by Negative Bucket",
        "",
        "| Negative bucket set | Pass | Fail |",
        "|---|---:|---:|",
        ]
    )
    for bucket, counts in payload["status_by_negative_bucket"].items():
        passed = counts.get("pass", 0)
        failed = sum(count for status, count in counts.items() if status != "pass")
        lines.append(f"| `{bucket}` | {passed} | {failed} |")

    lines.extend(
        [
            "",
            "## Record Outcomes by Mapping Status Set",
            "",
            "| Mapping status set | Pass | Fail |",
            "|---|---:|---:|",
        ]
    )
    for status, counts in payload["status_by_mapping_statuses"].items():
        passed = counts.get("pass", 0)
        failed = sum(count for key, count in counts.items() if key != "pass")
        lines.append(f"| `{status}` | {passed} | {failed} |")

    lines.extend(
        [
            "",
            "## Failure Categories",
            "",
            "| Category | Records |",
            "|---|---:|",
        ]
    )
    for category, count in payload["failure_categories"].items():
        lines.append(f"| `{category}` | {count} |")

    lines.extend(
        [
            "",
            "## Interpretation for the Paper",
            "",
            "- The empty-import baseline passing for all records shows that the generated sentinel shell itself is compilable.",
            "- The low pass rate for unflagged-control imports shows that import-only javac checks are sensitive to missing project/external classpaths and to unflagged invalid imports.",
            "- Therefore import-only results should be reported as minimal import-resolution evidence, while detector accuracy claims should rely on human annotation and build-level controls.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-sheet", required=True)
    parser.add_argument("--probe-json", required=True)
    parser.add_argument("--flagged-probe-json", default="")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = summarize(args.audit_sheet, args.probe_json)
    if args.flagged_probe_json:
        payload["flagged_detector_probe"] = probe_simple_summary(args.flagged_probe_json)
    (output_dir / "java_unflagged_control_probe_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_csv(output_dir / "java_unflagged_control_probe_records.csv", payload["records"])
    write_markdown(output_dir / "java_unflagged_control_probe_summary.md", payload)
    print(json.dumps({key: payload[key] for key in [
        "negative_control_candidate_rows",
        "negative_control_records",
        "raw_candidate_import_records_pass",
        "raw_candidate_import_records_fail",
        "empty_import_baseline_records_pass",
        "empty_import_baseline_records_fail",
    ]}, indent=2))


if __name__ == "__main__":
    main()
