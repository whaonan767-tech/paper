#!/usr/bin/env python3
"""Run paired real tests for build-valid structured V3 completions."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from collections import Counter
from pathlib import Path

import codex_java_masked_baseline_audit as baseline
import codex_java_masked_evidence_build as evidence
import codex_java_masked_necessity_probe as necessity
import codex_java_masked_test_baseline as testbase


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
OLD_PROMPTS = ROOT / "Tests" / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730" / "prompts.jsonl"
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
COMPILE_BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803" / "masked_baseline_audit.json"
PARSED = ROOT / "Tests" / "Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804" / "parsed_v3.json"
V3_BUILD = ROOT / "Tests" / "Java_APIHulBench_MaskedV3Build_Corrected_Full83_Run20260804" / "masked_v3_build.json"
TEST_BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedRealTestBaseline_Full58_Run20260804" / "masked_test_baseline.json"
DEFAULT_WORK = WORKSPACE / "vw" / "masked_v3_test"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=OLD_PROMPTS)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--compile-baseline", type=Path, default=COMPILE_BASELINE)
    parser.add_argument("--parsed", type=Path, default=PARSED)
    parser.add_argument("--v3-build", type=Path, default=V3_BUILD)
    parser.add_argument("--test-baseline", type=Path, default=TEST_BASELINE)
    parser.add_argument("--output-root", type=Path, default=ROOT / "Tests")
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK)
    parser.add_argument("--run-name", default="Java_APIHulBench_MaskedV3RealTest_Run20260804")
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve())
    prompt_by_id = {row["record_id"]: row for row in prompts}
    samples = validation.load_samples()
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    compile_payload = json.loads(args.compile_baseline.resolve().read_text(encoding="utf-8"))
    jdk_homes = {row["label"]: (None if row["home"] == "system" else row["home"]) for row in compile_payload["metadata"]["java_matrix"]}
    parsed = {row["record_id"]: row for row in json.loads(args.parsed.resolve().read_text(encoding="utf-8"))["results"]}
    build_payload = json.loads(args.v3_build.resolve().read_text(encoding="utf-8"))
    build_passes = [row for row in build_payload["results"] if row["status"] == "pass"]
    test_baseline_payload = json.loads(args.test_baseline.resolve().read_text(encoding="utf-8"))
    test_baselines = {row["build_key"]: row for row in test_baseline_payload["results"]}

    run_name = args.run_name
    output_dir = args.output_root.resolve() / run_name
    work_root = args.work_root.resolve() / ("run_" + hashlib.sha256(run_name.encode()).hexdigest()[:10])
    if output_dir.exists() or work_root.exists(): raise SystemExit(f"Run path exists: {run_name}")
    output_dir.mkdir(parents=True); work_root.mkdir(parents=True)
    logs_dir = output_dir / "logs"; logs_dir.mkdir()
    temp_dir = work_root / "tmp"; temp_dir.mkdir()
    os.environ["TEMP"] = str(temp_dir); os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}").strip()
    results = []
    for index, build_row in enumerate(build_passes, 1):
        record_id = build_row["record_id"]
        prompt = prompt_by_id[record_id]
        parsed_row = parsed[record_id]
        sample_key = baseline.sample_key(prompt)
        audit = audit_by_key[sample_key]
        base_test = test_baselines[build_row["build_key"]]
        eligible = build_row["source_set"] == "main" and base_test["status"] == "pass" and int(base_test["tests"]) > 0
        common = {
            "record_id": record_id, "source_set": build_row["source_set"], "project_path": build_row["project_path"],
            "file_path": build_row["file_path"], "build_key": build_row["build_key"],
            "selected_java_home": build_row["selected_java_home"], "replacement": parsed_row["replacement"],
            "ground_truth": parsed_row["ground_truth"], "replacement_compact_exact": parsed_row["replacement_compact_exact"],
            "generated_imports": parsed_row["generated_imports"], "masked_imports": parsed_row["hidden_imports"],
            "baseline_test_status": base_test["status"], "baseline_tests": int(base_test["tests"]),
            "baseline_failures": int(base_test["failures"]), "baseline_errors": int(base_test["errors"]),
            "semantic_test_eligible": eligible,
        }
        command = []; counts = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0, "report_file_count": 0, "report_files": []}
        if not eligible:
            reason = "target_is_test_source" if build_row["source_set"] != "main" else ("baseline_test_failed" if base_test["status"] != "pass" else "baseline_zero_tests")
            outcome = {"status": "not_test_eligible", "failure_detail": reason, "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
        else:
            original_project = validation.normalize_workspace_path(build_row["project_path"])
            original_target = validation.normalize_workspace_path(build_row["file_path"])
            copied_project = work_root / f"r{index:03d}"
            copy_log = logs_dir / f"record_{index:03d}_copy.log"
            print(f"[{index}/{len(build_passes)}] COPY {record_id}", flush=True)
            copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
            if not copied:
                outcome = {"status": "project_copy_failed", "failure_detail": "project_copy_failed", "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": validation.display_path(copy_log), "tail": copy_error}
            else:
                try:
                    copied_target, _ = necessity.locate_target_file(copied_project, original_project, original_target)
                    source = copied_target.read_text(encoding="utf-8", errors="strict")
                    sample = samples[sample_key]
                    patched, _ = validation.patch_ground_truth(source, sample["incomplete_function"], sample["ground_truth"], parsed_row["replacement"])
                    masked, removed = necessity.remove_imports(patched, parsed_row["hidden_imports"])
                    if len(removed) != len(parsed_row["hidden_imports"]): raise ValueError("hidden imports were not removed exactly")
                    mutated, _ = evidence.insert_imports(masked, parsed_row["generated_imports"])
                    copied_target.write_text(mutated, encoding="utf-8", newline="")
                    plan = validation.build_plan(audit, copied_project)
                    command = testbase.test_command(plan["command"])
                    java_value = jdk_homes[build_row["selected_java_home"]]; java_home = Path(java_value) if java_value else None
                    log_path = logs_dir / f"record_{index:03d}_test.log"
                    print(f"[{index}/{len(build_passes)}] TEST {record_id}", flush=True)
                    outcome = validation.run_build(command, plan["cwd"], args.timeout, log_path, java_home)
                    if "maven" in audit["build_system"] and validation.should_retry_local_maven(outcome):
                        retry_plan = validation.build_plan(audit, copied_project, force_local=True)
                        retry_command = testbase.test_command(retry_plan["command"])
                        retry_log = logs_dir / f"record_{index:03d}_test_local_retry.log"
                        outcome = validation.run_build(retry_command, retry_plan["cwd"], args.timeout, retry_log, java_home)
                        command, log_path = retry_command, retry_log
                    counts = testbase.count_tests(copied_project)
                except Exception as error:
                    outcome = {"status": "mutation_error", "failure_detail": str(error), "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
                if not args.keep_workdirs and copied_project.exists(): baseline.safe_remove_tree(copied_project, work_root)
        results.append({**common, "command": " ".join(command), **counts, **outcome})
    if temp_dir.exists() and not args.keep_workdirs: baseline.safe_remove_tree(temp_dir, work_root)

    eligible_rows = [row for row in results if row["semantic_test_eligible"]]
    summary = {
        "v3_build_pass_records": len(build_passes),
        "v3_build_pass_projects": len({row["project_path"] for row in build_passes}),
        "semantic_test_eligible_records": len(eligible_rows),
        "real_test_pass_records": sum(row["status"] == "pass" and row["tests"] > 0 for row in eligible_rows),
        "real_test_fail_records": sum(row["status"] != "pass" for row in eligible_rows),
        "eligible_zero_variant_tests": sum(row["status"] == "pass" and row["tests"] == 0 for row in eligible_rows),
        "not_test_eligible_records": sum(row["status"] == "not_test_eligible" for row in results),
        "status_counts": dict(Counter(row["status"] for row in results)),
    }
    payload = {"run_name": run_name, "phase": "paired_real_test_for_build_valid_v3", "summary": summary, "metadata": {"v3_build_sha256": baseline.sha256(args.v3_build.resolve()), "test_baseline_sha256": baseline.sha256(args.test_baseline.resolve()), "script_sha256": baseline.sha256(Path(__file__).resolve()), "tests_must_execute": True, "test_source_excluded_from_semantic_denominator": True}, "results": results}
    (output_dir / "masked_v3_test.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["record_id", "source_set", "project_path", "build_key", "replacement", "ground_truth", "replacement_compact_exact", "semantic_test_eligible", "baseline_test_status", "baseline_tests", "status", "failure_detail", "tests", "failures", "errors", "skipped", "return_code", "timed_out", "duration_seconds", "command", "log_path"]
    with (output_dir / "masked_v3_test.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore"); writer.writeheader(); writer.writerows(results)
    lines = ["# Paired Real-Test Validation for Build-Valid V3 Completions", "", f"- V3 build-pass records: `{summary['v3_build_pass_records']}` across `{summary['v3_build_pass_projects']}` projects.", f"- Main-source records with passing nonzero-test baselines: `{summary['semantic_test_eligible_records']}`.", f"- Real-test passes with tests executed: `{summary['real_test_pass_records']}`.", f"- Real-test failures: `{summary['real_test_fail_records']}`.", f"- Not test-eligible: `{summary['not_test_eligible_records']}`."]
    (output_dir / "masked_v3_test.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
