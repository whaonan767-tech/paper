#!/usr/bin/env python3
"""Acquire a deterministic owner/name/API-family-disjoint external Java V3 corpus."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

from codex_acquire_external_java_pilot import download_file, safe_extract
from codex_build_external_v3_exclusions import family, normalized_name, repository_key


QUERY = "language:Java fork:false archived:false stars:100..2000 size:<15000"
ALLOWED_LICENSES = {"Apache-2.0", "MIT", "BSD-2-Clause", "BSD-3-Clause", "EPL-2.0", "MPL-2.0", "LGPL-2.1", "LGPL-3.0"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-json", type=Path, required=True)
    parser.add_argument("--exclusions", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--projects", type=int, default=30)
    parser.add_argument("--pages", type=int, default=5)
    parser.add_argument("--search-size", type=int, default=100)
    parser.add_argument("--search-snapshot", type=Path)
    parser.add_argument("--timeout", type=float, default=90.0)
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def request_json(url: str, timeout: float) -> dict:
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "dependency-audit-research-v3"}
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def request_bytes(url: str, timeout: float) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "dependency-audit-research-v3"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def root_pom_exists(full_name: str, branch: str, timeout: float) -> bool:
    url = f"https://raw.githubusercontent.com/{full_name}/{urllib.parse.quote(branch, safe='')}/pom.xml"
    try:
        data = request_bytes(url, timeout)
        return b"<project" in data
    except (urllib.error.URLError, TimeoutError):
        return False


def project_families(project: Path) -> list[str]:
    counts: collections.Counter[str] = collections.Counter()
    for pom in list(project.rglob("pom.xml"))[:200]:
        try:
            root = ET.parse(pom).getroot()
        except (ET.ParseError, OSError):
            continue
        namespace = root.tag.partition("}")[0] + "}" if "}" in root.tag else ""
        for value in (root.findtext(f"{namespace}groupId"), root.findtext(f"{namespace}parent/{namespace}groupId")):
            key = family(value or "")
            if key:
                counts[key] += 1
    package_re = re.compile(r"(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s*;")
    checked = 0
    for java in project.rglob("*.java"):
        if checked >= 600:
            break
        if not any(part.lower() == "main" for part in java.parts):
            continue
        checked += 1
        try:
            match = package_re.search(java.read_text(encoding="utf-8", errors="ignore")[:8000])
        except OSError:
            continue
        if match:
            key = family(match.group(1))
            if key:
                counts[key] += 1
    return [name for name, _ in counts.most_common(4)]


def verified_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archives = output / "archives"
    projects_root = output / "projects"
    screening_root = output / "screening"
    metadata_root = output / "metadata"
    for path in (archives, projects_root, screening_root, metadata_root):
        path.mkdir(parents=True, exist_ok=True)

    freeze = json.loads(args.freeze_json.read_text(encoding="utf-8"))
    exclusions = json.loads(args.exclusions.read_text(encoding="utf-8"))
    excluded_names = set(exclusions["repository_names_normalized"])
    excluded_keys = set(exclusions["repository_keys"])
    excluded_full = set(exclusions["full_names"])
    excluded_owners = set(exclusions["owners"])
    excluded_families = set(exclusions["api_families"])

    if args.search_snapshot:
        snapshot = json.loads(args.search_snapshot.read_text(encoding="utf-8"))
        items = snapshot["items"] if isinstance(snapshot, dict) else snapshot
    else:
        items = []
        pages = []
        for page in range(1, args.pages + 1):
            url = "https://api.github.com/search/repositories?" + urllib.parse.urlencode({
                "q": QUERY, "sort": "updated", "order": "desc", "per_page": args.search_size, "page": page,
            })
            payload = request_json(url, args.timeout)
            pages.append({"page": page, "items": payload.get("items", [])})
            items.extend(payload.get("items", []))
        snapshot = {"query": QUERY, "captured_at_utc": datetime.now(timezone.utc).isoformat(), "pages": pages, "items": items}
        (metadata_root / "github_search_snapshot_v3.json").write_text(json.dumps(snapshot, indent=2) + "\n", encoding="utf-8")

    selected = []
    screening = []
    selected_owners: set[str] = set()
    selected_families: set[str] = set()
    for rank, item in enumerate(items, 1):
        if len(selected) >= args.projects:
            break
        full_name = str(item.get("full_name") or "")
        if "/" not in full_name:
            continue
        owner, repo = full_name.split("/", 1)
        owner_key = owner.lower()
        row = {
            "rank": rank, "full_name": full_name, "owner": owner, "repo_name": repo,
            "default_branch": item.get("default_branch") or "main",
            "license_spdx": (item.get("license") or {}).get("spdx_id") or "",
            "size_kb": item.get("size"), "stars": item.get("stargazers_count"),
        }
        reasons = []
        if row["license_spdx"] not in ALLOWED_LICENSES:
            reasons.append("license")
        if normalized_name(repo) in excluded_names or repository_key(repo) in excluded_keys:
            reasons.append("known_repository_name")
        if full_name.lower() in excluded_full:
            reasons.append("known_full_name")
        if owner_key in excluded_owners:
            reasons.append("known_owner")
        if owner_key in selected_owners:
            reasons.append("duplicate_external_owner")
        if reasons:
            row.update({"selected": False, "rejection_reasons": reasons})
            screening.append(row)
            continue
        if not root_pom_exists(full_name, str(row["default_branch"]), args.timeout):
            row.update({"selected": False, "rejection_reasons": ["no_root_pom"]})
            screening.append(row)
            continue

        commit_url = f"https://api.github.com/repos/{full_name}/commits/{urllib.parse.quote(str(row['default_branch']), safe='')}"
        commit = request_json(commit_url, args.timeout)
        commit_sha = str(commit["sha"])
        slug = full_name.replace("/", "_")
        archive = archives / f"rank{rank:04d}_{slug}_{commit_sha[:12]}.zip"
        if not archive.exists():
            download_file(f"https://codeload.github.com/{full_name}/zip/{commit_sha}", archive, args.timeout)
        temporary = screening_root / f"rank{rank:04d}"
        if temporary.exists():
            if not verified_within(temporary, screening_root):
                raise RuntimeError(f"Unsafe cleanup target: {temporary}")
            shutil.rmtree(temporary)
        safe_extract(archive, temporary)
        families = project_families(temporary)
        overlap = sorted(set(families) & (excluded_families | selected_families))
        if overlap:
            row.update({"selected": False, "rejection_reasons": ["api_family_overlap"], "api_families": families, "overlap": overlap})
            screening.append(row)
            if verified_within(temporary, screening_root):
                shutil.rmtree(temporary)
            continue
        index = len(selected) + 1
        destination = projects_root / f"p{index:03d}"
        if destination.exists():
            raise RuntimeError(f"Destination already exists: {destination}; use a fresh output directory")
        temporary.replace(destination)
        selected_row = {
            **row, "selected": True, "rejection_reasons": [], "commit_sha": commit_sha,
            "commit_url": f"https://github.com/{full_name}/commit/{commit_sha}",
            "archive_url": f"https://codeload.github.com/{full_name}/zip/{commit_sha}",
            "archive_file": archive.name, "archive_sha256": sha256(archive),
            "project_dir": destination.name, "project_relative_path": destination.relative_to(output).as_posix(),
            "api_families": families,
        }
        selected.append(selected_row)
        screening.append(selected_row)
        selected_owners.add(owner_key)
        selected_families.update(families)
        print(f"SELECTED {index}/{args.projects} {full_name}@{commit_sha[:12]} families={','.join(families)}", flush=True)

    if len(selected) < args.projects:
        raise SystemExit(f"Only {len(selected)} eligible projects found; requested {args.projects}")
    payload = {
        "artifact": "prospective_external_java_v3_acquisition",
        "acquired_at_utc": datetime.now(timezone.utc).isoformat(),
        "freeze_sha256": sha256(args.freeze_json), "exclusions_sha256": sha256(args.exclusions),
        "search_query": QUERY, "selection_rule": "Frozen rank order; allowed license; root Maven POM; disjoint normalized name, mapped owner, full name, and owned API families; one repository per external owner/API family.",
        "selected": selected, "screened": screening,
    }
    json_path = metadata_root / "external_project_acquisition_v3.json"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = ["# Prospective External Java V3 Acquisition", "", f"- Selected projects: `{len(selected)}`.", "", "| Rank | Repository | Commit | License | API families |", "|---:|---|---|---|---|"]
    lines.extend(f"| {row['rank']} | `{row['full_name']}` | `{row['commit_sha'][:12]}` | `{row['license_spdx']}` | `{', '.join(row['api_families'])}` |" for row in selected)
    (metadata_root / "external_project_acquisition_v3.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"selected_projects": len(selected), "screened": len(screening), "output": str(json_path)}, indent=2))


if __name__ == "__main__":
    main()
