#!/usr/bin/env python3
"""Merge successful unit-level real-test sanitizer probe reruns."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, action="append", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def baseline_pass(row: dict) -> bool:
    return row.get("status") == "pass" and int(row.get("tests", 0)) > 0 and int(row.get("failures", 0)) == 0 and int(row.get("errors", 0)) == 0


def resolve_log(path: str) -> Path:
    value = Path(path)
    return value if value.is_absolute() else WORKSPACE / value


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise SystemExit(f"Output directory exists: {output_dir}")
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True)

    payloads = []
    provenance = []
    for path in args.input:
        resolved = path.resolve()
        payloads.append(json.loads(resolved.read_text(encoding="utf-8")))
        provenance.append({"path": resolved.name, "sha256": sha256(resolved)})

    candidates = {}
    for payload in payloads:
        rows_by_key = {}
        for row in payload["results"]:
            rows_by_key.setdefault(row["build_key"], []).append(row)
        for build_key, rows in rows_by_key.items():
            baseline = next((row for row in rows if row["variant"] == "original_baseline"), None)
            if baseline and baseline_pass(baseline):
                candidates.setdefault(build_key, []).append(rows)

    selected = {}
    for build_key, choices in candidates.items():
        choices.sort(key=lambda rows: sum(1 for row in rows if row["variant"] == "sanitized" and baseline_pass(row)), reverse=True)
        selected[build_key] = choices[0]
    if not selected:
        raise SystemExit("No baseline-passing units found")

    results = []
    for unit_index, (build_key, rows) in enumerate(sorted(selected.items()), start=1):
        for row_index, row in enumerate(rows, start=1):
            copied = dict(row)
            source_log = resolve_log(str(row.get("log_path", "")))
            if source_log.exists():
                target_name = f"u{unit_index:03d}_{row_index:02d}_{source_log.name}"
                target_log = logs_dir / target_name
                shutil.copy2(source_log, target_log)
                copied["log_path"] = f"logs/{target_name}"
            results.append(copied)

    baselines = [row for row in results if row["variant"] == "original_baseline"]
    raw_rows = [row for row in results if row["variant"] == "raw_injected"]
    sanitized_rows = [row for row in results if row["variant"] == "sanitized"]
    baseline_by_key = {row["build_key"]: row for row in baselines}
    baseline_restoration_pairs = [
        row for row in sanitized_rows
        if baseline_pass(row)
        and int(row["tests"]) == int(baseline_by_key[row["build_key"]]["tests"])
        and int(row["skipped"]) == int(baseline_by_key[row["build_key"]]["skipped"])
    ]
    record_ids = sorted({record_id for row in sanitized_rows for record_id in row.get("record_ids", [])})
    summary = {
        "selected_invalid_records": len(record_ids),
        "selected_build_units": len(baselines),
        "selected_projects": len({row["project_path"] for row in baselines}),
        "baseline_unique_tests": sum(int(row["tests"]) for row in baselines),
        "baseline_total_failures": sum(int(row["failures"]) for row in baselines),
        "baseline_total_errors": sum(int(row["errors"]) for row in baselines),
        "raw_injected_failures": sum(row.get("status") != "pass" for row in raw_rows),
        "raw_injected_total_tests": sum(int(row["tests"]) for row in raw_rows),
        "sanitized_passes_with_nonzero_tests": sum(baseline_pass(row) for row in sanitized_rows),
        "sanitized_test_executions": sum(int(row["tests"]) for row in sanitized_rows),
        "sanitized_total_failures": sum(int(row["failures"]) for row in sanitized_rows),
        "sanitized_total_errors": sum(int(row["errors"]) for row in sanitized_rows),
        "baseline_restoration_pairs": len(baseline_restoration_pairs),
        "raw_fail_sanitized_pass_pairs": sum(raw.get("status") != "pass" and baseline_pass(sanitized) for raw, sanitized in zip(raw_rows, sanitized_rows)),
    }
    if summary["selected_invalid_records"] != len(raw_rows) or len(raw_rows) != len(sanitized_rows):
        raise AssertionError("Each selected record must have one raw and one sanitized result")
    if summary["baseline_restoration_pairs"] != len(sanitized_rows):
        raise AssertionError("A sanitized result did not restore baseline test counts")

    output = {
        "artifact": "sanitizer_real_test_probe_final",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "provenance": provenance,
        "selection_rule": "For each build unit, select the rerun whose original baseline passes with nonzero tests and zero failures/errors; prefer the rerun with the most passing sanitized records.",
        "environment_note": "One sandboxed langchain4j run was excluded because a loopback-dependent baseline test failed before mutation; the selected rerun executed outside the network sandbox and passed the unchanged baseline.",
        "interpretation": "The five detector-flagged model-generated imports break compilation before tests; removing exactly the flagged import restores the unchanged source and baseline test counts across five paired records, three projects, and 451 unique baseline tests. This is bounded baseline-restoration test evidence, not general semantic preservation or generated replacement-code functional correctness.",
        "results": results,
    }
    json_path = output_dir / "sanitizer_real_test_probe_final.json"
    json_path.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["build_key", "project_path", "build_root", "record_ids", "variant", "injected_imports", "sanitizer_actions", "command", "status", "failure_detail", "return_code", "timed_out", "duration_seconds", "tests", "failures", "errors", "skipped", "report_file_count", "report_files", "log_path", "tail"]
    with (output_dir / "sanitizer_real_test_probe_final.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in results:
            writer.writerow({**row, "record_ids": ";".join(row.get("record_ids", [])), "injected_imports": ";".join(row.get("injected_imports", [])), "sanitizer_actions": json.dumps(row.get("sanitizer_actions", []), ensure_ascii=False), "report_files": ";".join(row.get("report_files", []))})
    lines = [
        "# Final Real-Test Sanitizer Baseline-Restoration Probe",
        "",
        f"- Records / build units / projects: `{summary['selected_invalid_records']}` / `{summary['selected_build_units']}` / `{summary['selected_projects']}`.",
        f"- Unique baseline tests: `{summary['baseline_unique_tests']}` with `{summary['baseline_total_failures']}` failures and `{summary['baseline_total_errors']}` errors.",
        f"- Raw injected failures: `{summary['raw_injected_failures']}/{len(raw_rows)}`; tests reached: `{summary['raw_injected_total_tests']}`.",
        f"- Sanitized passes with nonzero tests: `{summary['sanitized_passes_with_nonzero_tests']}/{len(sanitized_rows)}`.",
        f"- Cumulative sanitized test executions: `{summary['sanitized_test_executions']}` with `{summary['sanitized_total_failures']}` failures and `{summary['sanitized_total_errors']}` errors; this is not an independent-test denominator.",
        f"- Baseline-restoration pairs with matching test counts: `{summary['baseline_restoration_pairs']}/{len(sanitized_rows)}`.",
        "",
        output["interpretation"],
    ]
    (output_dir / "sanitizer_real_test_probe_final.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
