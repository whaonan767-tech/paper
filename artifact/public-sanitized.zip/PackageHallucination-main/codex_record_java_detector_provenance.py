#!/usr/bin/env python3
"""Record hashes and declared development boundaries for the Java detector."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_DetectorProvenance_Run20260804"
FILES = (
    ROOT / "codex_classify_java_imports.py",
    ROOT / "codex_map_java_imports_to_maven.py",
    ROOT / "codex_summarize_java_window_expansion.py",
    ROOT / "codex_java_recall_extension_audit.py",
    ROOT / "codex_package_experiment_runner.py",
    ROOT / "codex_java_dependency_generation_runner.py",
    ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731" / "full598_candidates_with_audit_status.csv",
    ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731" / "full598_final_human_truth.csv",
)

FILE_GROUPS = {
    "Detector and mapping scripts": {
        "codex_classify_java_imports.py",
        "codex_map_java_imports_to_maven.py",
        "codex_summarize_java_window_expansion.py",
    },
    "Generation, experiment, and recall-extension scripts": {
        "codex_java_recall_extension_audit.py",
        "codex_package_experiment_runner.py",
        "codex_java_dependency_generation_runner.py",
    },
    "Frozen audited exports": {
        "full598_candidates_with_audit_status.csv",
        "full598_final_human_truth.csv",
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--recall-extension-freeze-timestamp", default="2026-07-28T10:52:25+08:00")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for path in FILES:
        resolved = path.resolve()
        if not resolved.exists():
            raise SystemExit(f"Missing provenance input: {resolved}")
        files.append({"path": str(resolved.relative_to(ROOT)), "sha256": sha256(resolved)})
    payload = {
        "artifact": "java_original_detector_provenance",
        "original_detector_freeze_timestamp": None,
        "original_detector_freeze_note": "A separate original-detector freeze timestamp was not preserved. Script and frozen candidate-export hashes are the authoritative snapshot identifiers.",
        "recall_extension_freeze_timestamp": args.recall_extension_freeze_timestamp,
        "version_identifier": "SHA-256 hashes of detector scripts and frozen candidate export",
        "git_commit": None,
        "git_commit_note": "The experiment is an extracted working copy without a reliable detector commit; file hashes are the authoritative identifiers.",
        "development_data": {
            "models": ["Qwen2.5-Coder-3B-Instruct"],
            "prompt_windows": ["FM50", "Off50", "Off100", "Off150", "F-tail"],
            "prompts": 416,
            "candidate_rows": 598,
            "description": "Registry, project-source, platform, and observed candidate-class evidence across all five Java windows informed the mapping rules before the full human truth was completed.",
        },
        "evaluation_boundary": {
            "human_labels_changed_original_detector_flags": False,
            "independent_detector_test_split": False,
            "reported_precision_recall_f1_interpretation": "full-corpus audited characterization (in-corpus performance), not independent generalization performance",
        },
        "files": files,
    }
    (output_dir / "java_detector_provenance.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    lines = [
        "# Java Detector Provenance", "",
        "- Original-detector freeze timestamp: not separately preserved.",
        f"- Recall-extension freeze timestamp: `{args.recall_extension_freeze_timestamp}`; this timestamp must not be attributed to the original detector.",
        "- Version identifier: SHA-256 hashes below; no reliable Git commit is available in the extracted working copy.",
        "- Development source: all five Qwen-3B Java windows (416 prompts, 598 candidate rows) plus registry, project-source, and platform evidence.",
        "- Human labels were completed after the original detector flags and did not rewrite those flags.",
        "- Independent detector test split: `no`.",
        "- Interpretation: precision 0.971, recall 0.653, and F1 0.781 are full-corpus audited characterization, not independent generalization performance.", "",
    ]
    rows_by_name = {Path(row["path"]).name: row for row in files}
    for heading, names in FILE_GROUPS.items():
        lines.extend([f"## {heading}", "", "| File | SHA-256 |", "|---|---|"])
        for row in files:
            if Path(row["path"]).name in names:
                lines.append(f"| `{row['path']}` | `{row['sha256']}` |")
        missing = sorted(names - rows_by_name.keys())
        if missing:
            raise SystemExit(f"Missing grouped provenance rows: {missing}")
        lines.append("")
    (output_dir / "java_detector_provenance.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
