import argparse
import csv
import json
from collections import Counter
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

INVALID_COORDINATE_STATUSES = {"not_found", "missing_coordinate"}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def read_csv(path):
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def count_by(rows, key):
    return dict(Counter(row.get(key, "") for row in rows))


def line_to_record_id(responses):
    return {str(line_no): row.get("record_id", "") for line_no, row in enumerate(responses, start=1)}


def summarize_run(label, run_dir):
    run_dir = Path(run_dir)
    responses = read_jsonl(run_dir / "responses.jsonl")
    candidates = read_csv(run_dir / "candidates.csv")
    maven_rows = read_csv(run_dir / "maven_validation.csv")
    mapping_rows = read_csv(run_dir / "import_maven_mapping_enhanced.csv")
    by_line = line_to_record_id(responses)

    suspicious_imports = [
        row for row in mapping_rows if row.get("mapping_status", "") in SUSPICIOUS_MAPPING_STATUSES
    ]
    invalid_coordinates = [
        row
        for row in maven_rows
        if row.get("kind", "") != "java_import"
        and row.get("validation_status", "") in INVALID_COORDINATE_STATUSES
    ]
    suspicious_records = {row.get("original_record_id", "") for row in suspicious_imports}
    invalid_coordinate_records = {by_line.get(str(row.get("source_line", "")), "") for row in invalid_coordinates}
    target_records = {record for record in suspicious_records | invalid_coordinate_records if record}

    return {
        "label": label,
        "responses": len(responses),
        "candidate_rows": len(candidates),
        "candidate_kind_counts": count_by(candidates, "kind"),
        "candidate_coordinate_rows": len([row for row in candidates if row.get("kind", "") != "java_import"]),
        "candidate_import_rows": len([row for row in candidates if row.get("kind", "") == "java_import"]),
        "maven_validation_status_counts": count_by(maven_rows, "validation_status"),
        "mapping_status_counts": count_by(mapping_rows, "mapping_status"),
        "invalid_coordinate_rows": len(invalid_coordinates),
        "invalid_coordinate_records": len(invalid_coordinate_records),
        "suspicious_import_rows": len(suspicious_imports),
        "suspicious_import_records": len(suspicious_records),
        "target_records": len(target_records),
        "target_record_ids": sorted(target_records),
    }


def rate(num, den):
    return 0.0 if den == 0 else num / den


def write_markdown(path, output):
    rows = output["runs"]
    lines = [
        "# Qwen2.5-Coder-7B Dependency-Seeking B/C Summary",
        "",
        f"- Original-protocol run: `{output['original_run_dir']}`",
        f"- B dependency-seeking run: `{output['b_run_dir']}`",
        f"- C1 LLM feedback run: `{output['c1_run_dir']}`",
        f"- C2 deterministic sanitizer run: `{output['c2_run_dir']}`",
        "",
        "## Run-Level Metrics",
        "",
        "| Run | Responses | Candidates | Coord. rows | Import rows | Invalid coord. rows | Suspicious import rows | Target records |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {label} | {responses} | {candidate_rows} | {candidate_coordinate_rows} | {candidate_import_rows} | {invalid_coordinate_rows} | {suspicious_import_rows} | {target_records} |".format(
                **row
            )
        )
    lines.extend(
        [
            "",
            "## B Rates",
            "",
            f"- Confirmed invalid coordinate rows over coordinate candidates: `{output['b_invalid_coordinate_rows']}/{output['b_candidate_coordinate_rows']}` = `{output['b_invalid_coordinate_rate']:.4f}`.",
            f"- Suspicious import rows over import candidates: `{output['b_suspicious_import_rows']}/{output['b_candidate_import_rows']}` = `{output['b_suspicious_import_rate']:.4f}`.",
            f"- Records with confirmed invalid dependency evidence: `{output['b_target_records']}/416` = `{output['b_target_record_rate']:.4f}`.",
            "",
            "## Repair Comparisons",
            "",
            "| Repair | Target records | Invalid coord. rows | Suspicious import rows | Records with any invalid evidence |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for name, comparison in output["comparisons"].items():
        before = comparison["before"]
        after = comparison["after"]
        lines.append(
            "| {name} before | {target_records} | {invalid_coordinate_rows} | {suspicious_import_rows} | {invalid_or_suspicious_records} |".format(
                name=name, **before
            )
        )
        lines.append(
            "| {name} after | {target_records} | {invalid_coordinate_rows} | {suspicious_import_rows} | {invalid_or_suspicious_records} |".format(
                name=name, **after
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--original-run-dir", required=True)
    parser.add_argument("--b-run-dir", required=True)
    parser.add_argument("--c1-run-dir", required=True)
    parser.add_argument("--c2-run-dir", required=True)
    parser.add_argument("--c1-comparison-json", required=True)
    parser.add_argument("--c2-comparison-json", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    original = summarize_run("7B original protocol", args.original_run_dir)
    b = summarize_run("7B dependency-seeking B", args.b_run_dir)
    c1 = summarize_run("C1 LLM feedback", args.c1_run_dir)
    c2 = summarize_run("C2 deterministic sanitizer", args.c2_run_dir)

    output = {
        "original_run_dir": args.original_run_dir,
        "b_run_dir": args.b_run_dir,
        "c1_run_dir": args.c1_run_dir,
        "c2_run_dir": args.c2_run_dir,
        "runs": [original, b, c1, c2],
        "comparisons": {
            "C1 LLM feedback": json.loads(Path(args.c1_comparison_json).read_text(encoding="utf-8")),
            "C2 deterministic sanitizer": json.loads(Path(args.c2_comparison_json).read_text(encoding="utf-8")),
        },
    }
    output.update(
        {
            "b_invalid_coordinate_rows": b["invalid_coordinate_rows"],
            "b_candidate_coordinate_rows": b["candidate_coordinate_rows"],
            "b_invalid_coordinate_rate": rate(b["invalid_coordinate_rows"], b["candidate_coordinate_rows"]),
            "b_suspicious_import_rows": b["suspicious_import_rows"],
            "b_candidate_import_rows": b["candidate_import_rows"],
            "b_suspicious_import_rate": rate(b["suspicious_import_rows"], b["candidate_import_rows"]),
            "b_target_records": b["target_records"],
            "b_target_record_rate": rate(b["target_records"], 416),
        }
    )

    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), output)
    print(json.dumps({key: output[key] for key in output if key.startswith("b_")}, indent=2))


if __name__ == "__main__":
    main()
