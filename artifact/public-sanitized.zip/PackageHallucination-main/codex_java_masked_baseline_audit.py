#!/usr/bin/env python3
"""Audit baseline buildability for the masked-import semantic experiment."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent
WORKSPACE = PACKAGE_ROOT.parents[1]
APIHUL_ROOT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>"
PROMPTS = (
    PACKAGE_ROOT
    / "Tests"
    / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730"
    / "prompts.jsonl"
)
BUILD_AUDIT = APIHUL_ROOT / "outputs" / "build_validation_audit.json"
DEFAULT_WORK_ROOT = WORKSPACE / "vw" / "masked_semantic_build"
DEFAULT_OUTPUT_ROOT = PACKAGE_ROOT / "Tests"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument(
        "--java-home",
        action="append",
        default=[],
        help="JDK home to try in order; use 'system' for the current PATH. Repeatable.",
    )
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--keep-workdirs", action="store_true")
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def load_validation_module():
    module_path = APIHUL_ROOT / "experiments" / "validate_java_builds.py"
    spec = importlib.util.spec_from_file_location("masked_validate_java_builds", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sample_key(prompt: dict) -> str:
    return f"{prompt['split']}:{prompt['source_line']}"


def safe_remove_tree(path: Path, root: Path) -> None:
    resolved_path = path.resolve()
    resolved_root = root.resolve()
    if resolved_path == resolved_root or resolved_root not in resolved_path.parents:
        raise RuntimeError(f"Refusing to remove path outside work root: {resolved_path}")
    removal_path = (
        Path("\\\\?\\" + str(resolved_path)) if os.name == "nt" else resolved_path
    )
    if removal_path.exists():
        shutil.rmtree(removal_path)
    if removal_path.exists():
        raise RuntimeError(f"Failed to remove temporary work directory: {resolved_path}")


def command_version(command: list[str]) -> str:
    try:
        completed = subprocess.run(
            command,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=20,
            check=False,
        )
        return (completed.stdout or "").strip()
    except Exception as error:
        return f"unavailable: {error}"


def java_matrix(values: list[str]) -> list[tuple[str, Path | None]]:
    requested = values or ["system"]
    matrix = []
    for value in requested:
        if value.lower() == "system":
            matrix.append(("system", None))
            continue
        home = Path(value).resolve()
        executable = home / "bin" / ("java.exe" if os.name == "nt" else "java")
        compiler = home / "bin" / ("javac.exe" if os.name == "nt" else "javac")
        if not executable.exists() or not compiler.exists():
            raise SystemExit(f"Invalid JDK home: {home}")
        label = home.parent.name if home.name.lower() == "library" else home.name
        matrix.append((label, home))
    return matrix


def clean_build_command(command: list[str]) -> list[str]:
    cleaned = list(command)
    if cleaned and "-Dmaven.test.skip=false" not in cleaned:
        cleaned.insert(1, "-Dmaven.test.skip=false")
    if cleaned and cleaned[-1] == "test-compile":
        cleaned.insert(len(cleaned) - 1, "clean")
    return cleaned


def collect_units(prompts: list[dict], audit_by_key: dict[str, dict], validation) -> list[dict]:
    grouped: dict[str, dict] = {}
    for prompt in prompts:
        key = sample_key(prompt)
        audit = audit_by_key.get(key)
        if audit is None:
            raise RuntimeError(f"Build audit is missing sample {key}")
        build_key = validation.project_build_key(audit)
        unit = grouped.setdefault(
            build_key,
            {
                "build_key": build_key,
                "project_path": audit["project_path"],
                "build_root": audit["build_root"],
                "build_system": audit["build_system"],
                "audit": audit,
                "record_ids": [],
                "sample_keys": [],
                "source_sets": [],
                "masked_import_count": 0,
            },
        )
        unit["record_ids"].append(prompt["record_id"])
        unit["sample_keys"].append(key)
        unit["source_sets"].append(prompt["source_set"])
        unit["masked_import_count"] += int(prompt["masked_external_import_count"])
    return sorted(grouped.values(), key=lambda row: row["build_key"])


def summarize(units: list[dict], results: list[dict]) -> dict:
    passed_keys = {row["build_key"] for row in results if row["status"] == "pass"}
    passed_units = [unit for unit in units if unit["build_key"] in passed_keys]
    return {
        "records": sum(len(unit["record_ids"]) for unit in units),
        "projects": len({unit["project_path"] for unit in units}),
        "build_units": len(units),
        "masked_imports": sum(unit["masked_import_count"] for unit in units),
        "completed_build_units": len(results),
        "baseline_pass_units": len(passed_units),
        "baseline_pass_projects": len({unit["project_path"] for unit in passed_units}),
        "records_covered_by_pass_units": sum(len(unit["record_ids"]) for unit in passed_units),
        "masked_imports_covered_by_pass_units": sum(unit["masked_import_count"] for unit in passed_units),
        "source_sets_covered_by_pass_units": dict(
            Counter(source_set for unit in passed_units for source_set in unit["source_sets"])
        ),
        "status_counts": dict(Counter(row["status"] for row in results)),
        "failure_detail_counts": dict(
            Counter(row["failure_detail"] for row in results if row["status"] != "pass")
        ),
        "duration_seconds": round(sum(float(row["duration_seconds"]) for row in results), 3),
    }


def write_outputs(
    output_dir: Path,
    run_name: str,
    args: argparse.Namespace,
    units: list[dict],
    results: list[dict],
    metadata: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(units, results)
    payload = {
        "run_name": run_name,
        "phase": "original_project_baseline",
        "summary": summary,
        "metadata": metadata,
        "results": results,
    }
    (output_dir / "masked_baseline_audit.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    fields = [
        "build_key",
        "project_path",
        "build_root",
        "build_system",
        "record_count",
        "record_ids",
        "sample_keys",
        "source_sets",
        "masked_import_count",
        "status",
        "failure_detail",
        "return_code",
        "timed_out",
        "duration_seconds",
        "reactor_root",
        "module_path",
        "command",
        "selected_java_home",
        "attempts_json",
        "log_path",
    ]
    with (output_dir / "masked_baseline_audit.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    lines = [
        "# Masked-Import Semantic/Build Baseline Audit",
        "",
        f"- Records represented: `{summary['records']}`.",
        f"- Projects represented: `{summary['projects']}`.",
        f"- Unique build units: `{summary['build_units']}`.",
        f"- Hidden import instances: `{summary['masked_imports']}`.",
        f"- Completed baseline builds: `{summary['completed_build_units']}`.",
        f"- Passing build units: `{summary['baseline_pass_units']}`.",
        f"- Projects with a passing unit: `{summary['baseline_pass_projects']}`.",
        f"- Records covered by passing units: `{summary['records_covered_by_pass_units']}`.",
        f"- Hidden imports covered by passing units: `{summary['masked_imports_covered_by_pass_units']}`.",
        "",
        "## Status Counts",
        "",
        "| Status | Units |",
        "|---|---:|",
    ]
    for status, count in sorted(summary["status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(
        [
            "",
            "## Per-Build Results",
            "",
            "| Build unit | Records | Hidden imports | JDK | Status | Detail | Seconds |",
            "|---|---:|---:|---|---|---|---:|",
        ]
    )
    for row in results:
        lines.append(
            f"| `{row['build_key']}` | {row['record_count']} | {row['masked_import_count']} | "
            f"`{row['selected_java_home']}` | `{row['status']}` | `{row['failure_detail']}` | "
            f"{row['duration_seconds']:.3f} |"
        )
    (output_dir / "masked_baseline_audit.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    validation = load_validation_module()
    jdks = java_matrix(args.java_home)
    prompts = read_jsonl(args.prompts.resolve())
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    all_units = collect_units(prompts, audit_by_key, validation)
    units = all_units[: args.limit] if args.limit else all_units

    run_name = args.run_name or datetime.now().strftime(
        "Java_APIHulBench_MaskedSemanticBuild_Baseline_Run%Y%m%d_%H%M%S"
    )
    output_dir = args.output_root.resolve() / run_name
    work_root = args.work_root.resolve() / run_name
    output_json = output_dir / "masked_baseline_audit.json"
    if args.resume:
        if not output_json.exists():
            raise SystemExit(f"Cannot resume; output is missing: {output_json}")
        previous = json.loads(output_json.read_text(encoding="utf-8"))
        results = previous.get("results", [])
    else:
        if output_dir.exists() or work_root.exists():
            raise SystemExit(f"Run path already exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True)
    work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True)
    temp_dir = work_root / "tmp"
    temp_dir.mkdir(parents=True)

    os.environ["TEMP"] = str(temp_dir)
    os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (
        os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}"
    ).strip()

    metadata = {
        "prompts": str(args.prompts.resolve()),
        "prompts_sha256": sha256(args.prompts.resolve()),
        "build_audit": str(args.build_audit.resolve()),
        "build_audit_sha256": sha256(args.build_audit.resolve()),
        "script_sha256": sha256(Path(__file__).resolve()),
        "timeout_seconds": args.timeout,
        "java_matrix": [
            {
                "label": label,
                "home": str(home) if home else "system",
                "version": command_version(
                    [str(home / "bin" / "java.exe"), "-version"]
                    if home
                    else ["java", "-version"]
                ),
            }
            for label, home in jdks
        ],
        "maven_version": command_version(["mvn.cmd", "-version"]),
        "work_root": str(work_root),
        "temporary_files_on_d_drive": True,
        "workdirs_retained": args.keep_workdirs,
        "all_records": len(prompts),
        "all_unique_build_units": len(all_units),
        "selected_build_units": len(units),
    }
    write_outputs(output_dir, run_name, args, units, results, metadata)

    completed_keys = {row["build_key"] for row in results}
    for index, unit in enumerate(units, start=1):
        if unit["build_key"] in completed_keys:
            print(f"[{index}/{len(units)}] SKIP COMPLETED {unit['build_key']}", flush=True)
            continue
        audit = unit["audit"]
        original_project = validation.normalize_workspace_path(unit["project_path"])
        copied_project = work_root / f"b{index:03d}"
        copy_log = logs_dir / f"build_{index:03d}_copy.log"
        print(f"[{index}/{len(units)}] COPY {unit['build_key']}", flush=True)
        copied, copy_error = validation.copy_project_tree(
            original_project, copied_project, copy_log
        )
        plan = {}
        command: list[str] = []
        selected_java_home = ""
        attempts: list[dict] = []
        if not copied:
            outcome = {
                "return_code": "",
                "timed_out": False,
                "duration_seconds": 0.0,
                "status": "project_copy_failed",
                "failure_detail": "project_copy_failed",
                "log_path": validation.display_path(copy_log),
                "tail": copy_error,
            }
        else:
            baseline_log = logs_dir / f"build_{index:03d}_baseline.log"
            try:
                plan = validation.build_plan(audit, copied_project)
                for jdk_index, (jdk_label, java_home) in enumerate(jdks, start=1):
                    attempt_plan = plan
                    command = clean_build_command(attempt_plan["command"])
                    baseline_log = logs_dir / (
                        f"build_{index:03d}_attempt_{jdk_index:02d}_{jdk_label}_baseline.log"
                    )
                    print(
                        f"[{index}/{len(units)}] BUILD JDK={jdk_label}", flush=True
                    )
                    outcome = validation.run_build(
                        command,
                        attempt_plan["cwd"],
                        args.timeout,
                        baseline_log,
                        java_home,
                    )
                    if "maven" in audit["build_system"] and validation.should_retry_local_maven(outcome):
                        retry_plan = validation.build_plan(audit, copied_project, force_local=True)
                        retry_command = clean_build_command(retry_plan["command"])
                        if retry_command != command or retry_plan["cwd"] != attempt_plan["cwd"]:
                            retry_log = logs_dir / (
                                f"build_{index:03d}_attempt_{jdk_index:02d}_{jdk_label}_local_retry.log"
                            )
                            print(
                                f"[{index}/{len(units)}] RETRY LOCAL JDK={jdk_label}",
                                flush=True,
                            )
                            outcome = validation.run_build(
                                retry_command,
                                retry_plan["cwd"],
                                args.timeout,
                                retry_log,
                                java_home,
                            )
                            attempt_plan = retry_plan
                            command = retry_command
                    selected_java_home = jdk_label
                    plan = attempt_plan
                    attempts.append(
                        {
                            "java_home": jdk_label,
                            "status": outcome["status"],
                            "failure_detail": outcome["failure_detail"],
                            "return_code": outcome["return_code"],
                            "timed_out": outcome["timed_out"],
                            "duration_seconds": outcome["duration_seconds"],
                            "log_path": outcome["log_path"],
                        }
                    )
                    if outcome["status"] == "pass" or outcome["status"] != "toolchain_incompatible":
                        break
            except Exception as error:
                outcome = {
                    "return_code": "",
                    "timed_out": False,
                    "duration_seconds": 0.0,
                    "status": "baseline_command_failed",
                    "failure_detail": str(error),
                    "log_path": "",
                    "tail": "",
                }

        results.append(
            {
                "build_key": unit["build_key"],
                "project_path": unit["project_path"],
                "build_root": unit["build_root"],
                "build_system": unit["build_system"],
                "record_count": len(unit["record_ids"]),
                "record_ids": ";".join(unit["record_ids"]),
                "sample_keys": ";".join(unit["sample_keys"]),
                "source_sets": ";".join(unit["source_sets"]),
                "masked_import_count": unit["masked_import_count"],
                "reactor_root": plan.get("reactor_root", ""),
                "module_path": plan.get("module_path", ""),
                "command": " ".join(command),
                "selected_java_home": selected_java_home,
                "attempts_json": json.dumps(attempts, ensure_ascii=False),
                **outcome,
            }
        )
        write_outputs(output_dir, run_name, args, units, results, metadata)
        if not args.keep_workdirs and copied_project.exists():
            safe_remove_tree(copied_project, work_root)

    if not args.keep_workdirs and temp_dir.exists():
        safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
