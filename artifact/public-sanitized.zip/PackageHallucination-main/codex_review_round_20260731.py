"""Prepare review-round audit sheets and masked-import nesting statistics.

This script does not create labels. It freezes the current detector outputs,
marks which rows have already been audited, exports the remaining rows for
independent annotation, and derives dataset/cluster statistics for the
masked-import experiment from existing artifacts.
"""

from __future__ import annotations

import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TESTS = ROOT / "Tests"

WINDOWS = [
    ("FM50", "Java_APIHulBench_Qwen3B_FM50"),
    ("FM50_Offset50", "Java_APIHulBench_Qwen3B_FM50_Offset50"),
    ("FM50_Offset100", "Java_APIHulBench_Qwen3B_FM50_Offset100"),
    ("FM50_Offset150_tail", "Java_APIHulBench_Qwen3B_FM50_Offset150"),
    ("F50_Offset200_tail", "Java_APIHulBench_Qwen3B_F50_Offset200"),
]

SUSPICIOUS_MAPPING = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def truthy(value: str | bool | None) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"true", "1", "yes", "y"}


def key_for(row: dict[str, str], window_label: str | None = None) -> tuple[str, str, str, str]:
    return (
        window_label or row.get("window_label", ""),
        row.get("record_id") or row.get("candidate_record_id", ""),
        row.get("original_record_id", ""),
        row.get("import_path", ""),
    )


def prepare_full598_audit() -> None:
    out_dir = TESTS / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
    all_rows: list[dict[str, object]] = []
    for window_label, dirname in WINDOWS:
        path = TESTS / dirname / "import_maven_mapping_enhanced.csv"
        for row in read_csv(path):
            mapping_status = row.get("mapping_status", "")
            row = dict(row)
            row["window_label"] = window_label
            row["detector_suspicious"] = int(mapping_status in SUSPICIOUS_MAPPING)
            row["audited_in_150_sample"] = 0
            row["audit_id"] = ""
            row["sample_group"] = ""
            all_rows.append(row)

    audit_key = read_csv(TESTS / "Java_APIHulBench_HumanAudit" / "java_human_annotation_key.csv")
    audited = {key_for(row): row for row in audit_key}

    for idx, row in enumerate(all_rows, start=1):
        row["full598_index"] = idx
        hit = audited.get(key_for(row, row["window_label"]))
        if hit:
            row["audited_in_150_sample"] = 1
            row["audit_id"] = hit.get("audit_id", "")
            row["sample_group"] = hit.get("sample_group", "")

    heldout = [row for row in all_rows if int(row["audited_in_150_sample"]) == 0]
    heldout_fields = [
        "full598_index",
        "window_label",
        "record_id",
        "original_record_id",
        "dataset",
        "source_line",
        "project_path",
        "file_path",
        "project_package_prefix",
        "kind",
        "import_path",
        "import_root",
        "import_classification",
        "mapping_status",
        "mapping_reason",
        "mapped_coordinate",
        "suggested_import_prefix",
        "suggested_project_import",
        "detector_suspicious",
        "annotation_validity",
        "annotation_subtype",
        "annotation_deletion_correct",
        "annotation_confidence",
        "annotation_rationale",
    ]
    for row in heldout:
        for field in heldout_fields:
            row.setdefault(field, "")

    full_fields = [
        "full598_index",
        "audited_in_150_sample",
        "audit_id",
        "sample_group",
        "window_label",
        "record_id",
        "original_record_id",
        "dataset",
        "source_line",
        "project_path",
        "file_path",
        "project_package_prefix",
        "kind",
        "import_path",
        "import_root",
        "import_classification",
        "mapping_status",
        "mapping_reason",
        "mapped_coordinate",
        "detector_suspicious",
    ]
    write_csv(out_dir / "full598_candidates_with_audit_status.csv", all_rows, full_fields)
    write_csv(out_dir / "heldout_448_annotation_sheet.csv", heldout, heldout_fields)
    write_csv(out_dir / "heldout_448_annotator_a.csv", heldout, heldout_fields)
    write_csv(out_dir / "heldout_448_annotator_b.csv", heldout, heldout_fields)

    summary = {
        "full_rows": len(all_rows),
        "already_audited_rows": sum(int(r["audited_in_150_sample"]) for r in all_rows),
        "heldout_rows": len(heldout),
        "detector_suspicious_full_rows": sum(int(r["detector_suspicious"]) for r in all_rows),
        "detector_suspicious_heldout_rows": sum(int(r["detector_suspicious"]) for r in heldout),
        "missing_import_full_rows": sum(1 for r in all_rows if r.get("mapping_status") == "missing_import"),
        "window_counts": Counter(str(r["window_label"]) for r in all_rows),
        "heldout_window_counts": Counter(str(r["window_label"]) for r in heldout),
    }
    (out_dir / "full598_heldout_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    lines = [
        "# Full-598 Held-Out Annotation Package",
        "",
        f"- Frozen detector rows: `{summary['full_rows']}`.",
        f"- Already audited in the 150-row stratified sample: `{summary['already_audited_rows']}`.",
        f"- Remaining held-out rows exported for independent annotation: `{summary['heldout_rows']}`.",
        f"- Detector-suspicious rows in the full detector output: `{summary['detector_suspicious_full_rows']}`.",
        f"- Detector-suspicious rows left in the held-out export: `{summary['detector_suspicious_heldout_rows']}`.",
        "",
        "## Files",
        "",
        "- `heldout_448_annotator_a.csv` and `heldout_448_annotator_b.csv`: identical blank sheets for independent double annotation.",
        "- `heldout_448_annotation_sheet.csv`: shared reference copy.",
        "- `full598_candidates_with_audit_status.csv`: all 598 detector rows with flags showing whether each row was already in the completed 150-row audit.",
        "",
        "## Required Labels",
        "",
        "Use the existing Java human-annotation guideline. Do not use AI prelabels as final labels. Each annotator should fill `annotation_validity`, `annotation_subtype`, `annotation_deletion_correct`, `annotation_confidence`, and `annotation_rationale` independently.",
    ]
    (out_dir / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return float("nan")
    values = sorted(values)
    idx = (len(values) - 1) * pct
    lo = int(idx)
    hi = min(lo + 1, len(values) - 1)
    frac = idx - lo
    return values[lo] * (1 - frac) + values[hi] * frac


def cluster_bootstrap(rows: list[dict[str, object]], metric: str, iterations: int = 10000) -> dict[str, float]:
    by_project: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_project[str(row["project_path"])].append(row)
    projects = list(by_project)
    rng = random.Random(20260731)
    values: list[float] = []
    for _ in range(iterations):
        sample_rows: list[dict[str, object]] = []
        for _ in projects:
            sample_rows.extend(by_project[rng.choice(projects)])
        denom = len(sample_rows)
        num = sum(1 for row in sample_rows if bool(row[metric]))
        values.append(num / denom if denom else 0.0)
    observed = sum(1 for row in rows if bool(row[metric])) / len(rows)
    return {
        "observed": observed,
        "ci_low": percentile(values, 0.025),
        "ci_high": percentile(values, 0.975),
        "projects": len(projects),
        "targets": len(rows),
    }


def prepare_masked_stats() -> None:
    out_dir = TESTS / "Java_APIHulBench_MaskedImportDatasetStats_Run20260731"
    out_dir.mkdir(parents=True, exist_ok=True)

    inventory = read_csv(TESTS / "Java_APIHulBench_DependencyCriticalInventory_Run20260729" / "inventory.csv")
    inv_by_record = {row["record_id"]: row for row in inventory}
    prompts_path = TESTS / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730" / "prompts.jsonl"
    prompts = [json.loads(line) for line in prompts_path.read_text(encoding="utf-8").splitlines() if line.strip()]

    selected_ids = {row["record_id"] for row in prompts}
    selected_inventory = [inv_by_record[rid] for rid in selected_ids if rid in inv_by_record]
    hidden_imports: list[str] = []
    prompt_leak_targets = 0
    prompt_leak_records = 0
    for prompt in prompts:
        leaked = False
        for imp in prompt.get("masked_external_imports", []):
            hidden_imports.append(imp)
            if imp in prompt.get("prompt", ""):
                prompt_leak_targets += 1
                leaked = True
        if leaked:
            prompt_leak_records += 1

    hidden_counter = Counter(hidden_imports)
    project_counts = Counter(row["project_path"] for row in selected_inventory)
    build_context_counts = Counter((row["project_path"], row.get("build_files", "")) for row in selected_inventory)

    def count_if(pred) -> int:
        return sum(1 for row in inventory if pred(row))

    flow = [
        ("all_api_hulbench_fm_records", len(inventory)),
        ("source_file_exists", count_if(lambda r: truthy(r.get("source_file_exists")))),
        ("source_and_build_context", count_if(lambda r: truthy(r.get("source_file_exists")) and int(r.get("build_file_count") or 0) > 0)),
        ("external_dependency_import_context", count_if(lambda r: int(r.get("external_import_count") or 0) > 0)),
        ("external_import_used_in_fragment", count_if(lambda r: int(r.get("external_imports_used_in_fragment_count") or 0) > 0)),
        ("dependency_critical_seed", count_if(lambda r: truthy(r.get("dependency_critical_seed")))),
        ("strict_main_test_selected", len(prompts)),
    ]

    target_rows = read_csv(
        TESTS
        / "Java_APIHulBench_DepCriticalMasked_DependencyEvidenceFailure_Run20260730"
        / "dependency_evidence_failure_targets.csv"
    )
    enriched_targets: list[dict[str, object]] = []
    for row in target_rows:
        inv = inv_by_record[row["record_id"]]
        enriched_targets.append(
            {
                **row,
                "project_path": inv["project_path"],
                "strict_import_row_exact": truthy(row.get("strict_import_row_exact")),
                "raw_exact_mention": truthy(row.get("raw_exact_mention")),
                "simple_name_mention": truthy(row.get("simple_name_mention")),
            }
        )

    bootstrap_rows: list[dict[str, object]] = []
    for model in sorted({str(r["model"]) for r in enriched_targets}):
        model_rows = [r for r in enriched_targets if r["model"] == model]
        for metric in ["strict_import_row_exact", "raw_exact_mention", "simple_name_mention"]:
            stat = cluster_bootstrap(model_rows, metric)
            bootstrap_rows.append(
                {
                    "model": model,
                    "metric": metric,
                    "observed": f"{stat['observed']:.4f}",
                    "project_cluster_ci_low": f"{stat['ci_low']:.4f}",
                    "project_cluster_ci_high": f"{stat['ci_high']:.4f}",
                    "projects": int(stat["projects"]),
                    "targets": int(stat["targets"]),
                }
            )
    write_csv(
        out_dir / "project_cluster_bootstrap.csv",
        bootstrap_rows,
        ["model", "metric", "observed", "project_cluster_ci_low", "project_cluster_ci_high", "projects", "targets"],
    )

    stats = {
        "flow": flow,
        "selected_records": len(prompts),
        "selected_projects": len(project_counts),
        "selected_build_context_groups": len(build_context_counts),
        "hidden_imports": len(hidden_imports),
        "unique_hidden_imports": len(hidden_counter),
        "repeated_hidden_import_instances": sum(count - 1 for count in hidden_counter.values() if count > 1),
        "max_reuse_of_one_hidden_import": max(hidden_counter.values()) if hidden_counter else 0,
        "top_hidden_imports": hidden_counter.most_common(10),
        "top_project_contributions": project_counts.most_common(10),
        "split_counts_selected": Counter(p["split"] for p in prompts),
        "source_set_counts_selected": Counter(p["source_set"] for p in prompts),
        "masked_imports_per_prompt": Counter(str(p.get("masked_external_import_count", 0)) for p in prompts),
        "prompt_exact_fqn_leak_targets": prompt_leak_targets,
        "prompt_exact_fqn_leak_records": prompt_leak_records,
        "project_cluster_bootstrap": bootstrap_rows,
    }
    (out_dir / "masked_import_dataset_stats.json").write_text(
        json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    flow_lines = "\n".join(f"| `{name}` | {count} |" for name, count in flow)
    bootstrap_lines = "\n".join(
        "| {model} | `{metric}` | {observed} | {project_cluster_ci_low}--{project_cluster_ci_high} | {projects} | {targets} |".format(
            **row
        )
        for row in bootstrap_rows
    )
    top_import_lines = "\n".join(f"| `{name}` | {count} |" for name, count in hidden_counter.most_common(8))
    top_project_lines = "\n".join(f"| `{name}` | {count} |" for name, count in project_counts.most_common(8))
    md = f"""# Masked-Import Dataset and Cluster Statistics

## Selection Flow

| Step | Records |
|---|---:|
{flow_lines}

## Nesting

- Selected records: `{len(prompts)}`.
- Selected projects: `{len(project_counts)}`.
- Selected build-context groups: `{len(build_context_counts)}`.
- Hidden import targets: `{len(hidden_imports)}`.
- Unique hidden FQNs: `{len(hidden_counter)}`.
- Repeated hidden-import instances: `{sum(count - 1 for count in hidden_counter.values() if count > 1)}`.
- Maximum reuse of one hidden FQN: `{max(hidden_counter.values()) if hidden_counter else 0}`.
- Exact hidden-FQN leakage in rendered prompts: `{prompt_leak_targets}` targets in `{prompt_leak_records}` records.

## Top Hidden Imports

| Import | Count |
|---|---:|
{top_import_lines}

## Top Project Contributions

| Project | Records |
|---|---:|
{top_project_lines}

## Project-Clustered Bootstrap

| Model | Metric | Observed | 95% CI | Projects | Targets |
|---|---|---:|---:|---:|---:|
{bootstrap_lines}
"""
    (out_dir / "masked_import_dataset_stats.md").write_text(md, encoding="utf-8")


def main() -> None:
    prepare_full598_audit()
    prepare_masked_stats()


if __name__ == "__main__":
    main()
