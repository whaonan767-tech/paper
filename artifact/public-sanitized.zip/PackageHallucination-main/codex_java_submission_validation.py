#!/usr/bin/env python3
"""Recompute submission-facing Java validation results from preserved artifacts."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
TESTS = ROOT / "Tests"
AUDIT = TESTS / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
TRUTH_CSV = AUDIT / "full598_final_truth_with_recall_extension.csv"
SEED = 20260801
BOOTSTRAP_REPLICATES = 10_000

WINDOWS = [
    ("FM50", TESTS / "Java_APIHulBench_Qwen3B_FM50" / "responses.jsonl"),
    ("Off50", TESTS / "Java_APIHulBench_Qwen3B_FM50_Offset50" / "responses.jsonl"),
    ("Off100", TESTS / "Java_APIHulBench_Qwen3B_FM50_Offset100" / "responses.jsonl"),
    ("Off150", TESTS / "Java_APIHulBench_Qwen3B_FM50_Offset150" / "responses.jsonl"),
    ("F-tail", TESTS / "Java_APIHulBench_Qwen3B_F50_Offset200" / "responses.jsonl"),
]

BUILD_FILES = [
    WORKSPACE / "vw" / "pkg_import_build_probe" / "fm50_shortroot" / "java_import_build_probe.csv",
    TESTS / "Java_APIHulBench_BuildProbe" / "offset50_import_sanitizer_probe" / "java_import_build_probe.csv",
    WORKSPACE / "vw" / "pkg_import_build_probe" / "offset100_shortroot" / "java_import_build_probe.csv",
    WORKSPACE / "vw" / "pkg_import_build_probe" / "offset150_shortroot" / "java_import_build_probe.csv",
    WORKSPACE / "vw" / "pkg_import_build_probe" / "offset200_f_tail_shortroot" / "java_import_build_probe.csv",
]

MODEL_FORMAT_RUNS = [
    {
        "model": "Qwen2.5-Coder-7B-Instruct",
        "responses": TESTS / "Java_APIHulBench_Qwen7B_DepCriticalMasked_Strict_Full117_Run20260730" / "responses.jsonl",
        "tokenizer": WORKSPACE / "<LOCAL_MODEL_CACHE>" / "Qwen2.5-Coder-7B-Instruct" / "tokenizer.json",
        "token_cap": 512,
    },
    {
        "model": "DeepSeek-Coder-6.7B-Instruct",
        "responses": TESTS / "Java_APIHulBench_DeepSeekCoder67B_DepCriticalMasked_Strict_Full117_FastTok1024_Run20260730" / "responses.jsonl",
        "tokenizer": WORKSPACE / "<LOCAL_MODEL_CACHE>" / "deepseek-coder-6.7b-instruct" / "tokenizer.json",
        "token_cap": 1024,
    },
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def confusion(rows: list[dict[str, str]], prediction: str) -> dict[str, float | int | None]:
    eligible = [row for row in rows if row["final_validity"] in {"valid", "invalid"}]
    tp = sum(row[prediction] == "1" and row["final_validity"] == "invalid" for row in eligible)
    fp = sum(row[prediction] == "1" and row["final_validity"] == "valid" for row in eligible)
    fn = sum(row[prediction] == "0" and row["final_validity"] == "invalid" for row in eligible)
    tn = sum(row[prediction] == "0" and row["final_validity"] == "valid" for row in eligible)
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None
    return {
        "n_valid_invalid": len(eligible),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def project_clustered_rate(records: list[dict], positives: set[str], rng: random.Random) -> dict[str, float | int]:
    by_project: dict[str, list[str]] = defaultdict(list)
    for row in records:
        by_project[row["project_path"]].append(row["record_id"])
    projects = sorted(by_project)
    observed = sum(row["record_id"] in positives for row in records) / len(records)
    samples: list[float] = []
    for _ in range(BOOTSTRAP_REPLICATES):
        chosen = [projects[rng.randrange(len(projects))] for _ in projects]
        sampled_records = [record_id for project in chosen for record_id in by_project[project]]
        samples.append(sum(record_id in positives for record_id in sampled_records) / len(sampled_records))
    return {
        "records": len(records),
        "projects": len(projects),
        "positive_records": sum(row["record_id"] in positives for row in records),
        "rate": observed,
        "ci_low": percentile(samples, 0.025),
        "ci_high": percentile(samples, 0.975),
        "bootstrap_replicates": BOOTSTRAP_REPLICATES,
        "seed": SEED,
        "resampling_unit": "project",
        "interval": "percentile",
    }


def agreement() -> dict[str, float | int]:
    annotator_a = read_csv(AUDIT / "heldout_448_annotator_a.csv")
    annotator_b = {row["full598_index"]: row for row in read_csv(AUDIT / "heldout_448_annotator_b.csv")}
    validity_agreement = 0
    subtype_agreement = 0
    validity_a: Counter[str] = Counter()
    validity_b: Counter[str] = Counter()
    subtype_a: Counter[str] = Counter()
    subtype_b: Counter[str] = Counter()
    for row_a in annotator_a:
        row_b = annotator_b[row_a["full598_index"]]
        a_validity = row_a["annotation_validity"]
        b_validity = row_b["annotation_validity"]
        a_subtype = row_a["annotation_subtype"]
        b_subtype = row_b["annotation_subtype"]
        validity_agreement += a_validity == b_validity
        subtype_agreement += a_subtype == b_subtype
        validity_a[a_validity] += 1
        validity_b[b_validity] += 1
        subtype_a[a_subtype] += 1
        subtype_b[b_subtype] += 1

    def kappa(observed_count: int, counts_a: Counter[str], counts_b: Counter[str]) -> float:
        n = len(annotator_a)
        observed = observed_count / n
        expected = sum(counts_a[label] * counts_b[label] for label in set(counts_a) | set(counts_b)) / (n * n)
        return (observed - expected) / (1 - expected)

    return {
        "rows": len(annotator_a),
        "validity_exact": validity_agreement,
        "validity_rate": validity_agreement / len(annotator_a),
        "validity_kappa": kappa(validity_agreement, validity_a, validity_b),
        "subtype_exact": subtype_agreement,
        "subtype_rate": subtype_agreement / len(annotator_a),
        "subtype_kappa": kappa(subtype_agreement, subtype_a, subtype_b),
    }


def build_probe_summary() -> dict:
    rows = [row for path in BUILD_FILES for row in read_csv(path)]
    baselines = [row for row in rows if row["variant"] == "original_project_baseline"]
    baseline_by_key = {row["build_key"]: row for row in baselines}
    unique_baselines = list(baseline_by_key.values())
    pass_keys = {key for key, row in baseline_by_key.items() if row["status"] == "pass"}
    raw = [row for row in rows if row["variant"] == "raw_suspicious_imports" and row["build_key"] in pass_keys]
    sanitized_by_sample = {
        row["sample_key"]: row
        for row in rows
        if row["variant"] == "sanitized_removed_imports" and row["build_key"] in pass_keys
    }
    pairs = []
    for raw_row in raw:
        sanitized = sanitized_by_sample.get(raw_row["sample_key"])
        pairs.append(
            {
                "sample_key": raw_row["sample_key"],
                "project_path": raw_row["project_path"],
                "build_key": raw_row["build_key"],
                "raw_status": raw_row["status"],
                "sanitized_status": sanitized["status"] if sanitized else "missing",
            }
        )
    uninterpretable = {"target_file_missing", "not_patchable", "no_build_descriptor", "missing"}
    interpretable = [
        pair
        for pair in pairs
        if pair["raw_status"] not in uninterpretable and pair["sanitized_status"] not in uninterpretable
    ]
    return {
        "source_files": [str(path.relative_to(WORKSPACE)) for path in BUILD_FILES],
        "baseline_run_rows": len(baselines),
        "unique_baseline_build_units": len(baseline_by_key),
        "independent_projects": len({row["project_path"] for row in baselines}),
        "baseline_status_counts": dict(Counter(row["status"] for row in baselines)),
        "unique_baseline_status_counts": dict(Counter(row["status"] for row in unique_baselines)),
        "baseline_pass_runs": sum(row["status"] == "pass" for row in baselines),
        "baseline_pass_unique_units": len(pass_keys),
        "baseline_failed_runs": sum(row["status"] != "pass" for row in baselines),
        "baseline_failed_unique_units": sum(row["status"] != "pass" for row in unique_baselines),
        "target_pairs_on_pass_units": len(pairs),
        "interpretable_target_pairs": len(interpretable),
        "interpretable_unique_build_units": len({pair["build_key"] for pair in interpretable}),
        "fail_then_pass": sum(
            pair["raw_status"] == "source_compile_failure" and pair["sanitized_status"] == "pass"
            for pair in interpretable
        ),
        "fail_then_pass_unique_build_units": len(
            {
                pair["build_key"]
                for pair in interpretable
                if pair["raw_status"] == "source_compile_failure" and pair["sanitized_status"] == "pass"
            }
        ),
        "pass_then_pass": sum(
            pair["raw_status"] == "pass" and pair["sanitized_status"] == "pass"
            for pair in interpretable
        ),
        "pass_then_pass_unique_build_units": len(
            {
                pair["build_key"]
                for pair in interpretable
                if pair["raw_status"] == "pass" and pair["sanitized_status"] == "pass"
            }
        ),
        "tests_executed": False,
        "goal": "Maven test-compile with test execution skipped",
        "pairs": pairs,
    }


def model_format_summary() -> dict:
    try:
        from tokenizers import Tokenizer
    except ImportError as exc:
        raise RuntimeError("Run this script in the experiment environment that provides tokenizers.") from exc

    manifest_heading = re.compile(r"Dependencies\s*:", re.IGNORECASE)
    manifest_row = re.compile(
        r"^\s*-\s*(?:Maven|Gradle|Import|Project-local|JDK)\s*:",
        re.IGNORECASE | re.MULTILINE,
    )
    no_external = re.compile(r"Dependencies\s*:\s*No external dependency", re.IGNORECASE)
    import_row = re.compile(r"^\s*-\s*Import\s*:", re.IGNORECASE | re.MULTILINE)
    results = {}
    for spec in MODEL_FORMAT_RUNS:
        tokenizer = Tokenizer.from_file(str(spec["tokenizer"]))
        rows = read_jsonl(spec["responses"])
        responses = [row["response"] for row in rows]
        token_lengths = [len(tokenizer.encode(response).ids) for response in responses]
        compliant = [
            bool(manifest_heading.search(response) and (manifest_row.search(response) or no_external.search(response)))
            for response in responses
        ]
        inferred_cap_stop = [length >= spec["token_cap"] - 2 for length in token_lengths]
        results[spec["model"]] = {
            "records": len(rows),
            "token_cap": spec["token_cap"],
            "manifest_compliant_records": sum(compliant),
            "manifest_compliance_rate": sum(compliant) / len(rows),
            "records_with_parseable_import_row": sum(bool(import_row.search(response)) for response in responses),
            "output_tokens_reencoded_mean": statistics.mean(token_lengths),
            "output_tokens_reencoded_median": statistics.median(token_lengths),
            "output_tokens_reencoded_min": min(token_lengths),
            "output_tokens_reencoded_max": max(token_lengths),
            "inferred_cap_stop_records": sum(inferred_cap_stop),
            "inferred_cap_stop_rate": sum(inferred_cap_stop) / len(rows),
            "inferred_eos_or_other_records": len(rows) - sum(inferred_cap_stop),
            "finish_reason_limitation": (
                "The runner did not preserve the generate() finish reason. Cap stops are inferred when the "
                "decoded response re-encodes to at least token_cap-2 tokens; all other endings are EOS-or-other."
            ),
        }
    return results


def main() -> None:
    rows = read_csv(TRUTH_CSV)
    development = [row for row in rows if row["audited_in_150_sample"] == "1"]
    heldout = [row for row in rows if row["audited_in_150_sample"] == "0"]

    splits = {}
    for name, subset in (("development_150", development), ("heldout_448", heldout), ("overall_598", rows)):
        splits[name] = {
            "rows": len(subset),
            "label_counts": dict(Counter(row["final_validity"] for row in subset)),
            "original": confusion(subset, "detector_suspicious"),
            "enhanced": confusion(subset, "enhanced_detector_suspicious"),
        }

    rule_results = {}
    for split_name, subset in (("development_150", development), ("heldout_448", heldout), ("overall_598", rows)):
        added = [
            row
            for row in subset
            if row["detector_suspicious"] == "0" and row["enhanced_detector_suspicious"] == "1"
        ]
        per_rule = {}
        for rule in sorted({row["recall_extension_rule"] for row in added}):
            rule_rows = [row for row in added if row["recall_extension_rule"] == rule]
            valid_invalid = [row for row in rule_rows if row["final_validity"] in {"valid", "invalid"}]
            tp = sum(row["final_validity"] == "invalid" for row in valid_invalid)
            fp = sum(row["final_validity"] == "valid" for row in valid_invalid)
            per_rule[rule] = {
                "added_flags": len(rule_rows),
                "tp": tp,
                "fp": fp,
                "precision": tp / (tp + fp) if tp + fp else None,
            }
        rule_results[split_name] = per_rule

    mapping_crosstab = {}
    for status in sorted({row["mapping_status"] for row in rows}):
        status_rows = [row for row in rows if row["mapping_status"] == status]
        mapping_crosstab[status] = {
            label: sum(row["final_validity"] == label for row in status_rows)
            for label in ("valid", "invalid", "malformed", "uncertain")
        }
        mapping_crosstab[status]["total"] = len(status_rows)
        mapping_crosstab[status]["detector_flagged"] = sum(row["detector_suspicious"] == "1" for row in status_rows)

    false_negatives = [row for row in rows if row["detector_suspicious"] == "0" and row["final_validity"] == "invalid"]
    false_deletions = [row for row in rows if row["detector_suspicious"] == "1" and row["final_validity"] == "valid"]
    malformed_non_missing = [
        row for row in rows if row["final_validity"] == "malformed" and row["mapping_status"] != "missing_import"
    ]

    suspicious_records = {
        row["original_record_id"] for row in rows if row["detector_suspicious"] == "1"
    }
    rng = random.Random(SEED)
    window_rates = {}
    all_records = []
    for label, path in WINDOWS:
        records = read_jsonl(path)
        all_records.extend(records)
        window_rates[label] = project_clustered_rate(records, suspicious_records, rng)
    overall_record_rate = project_clustered_rate(all_records, suspicious_records, rng)

    summary = {
        "analysis_version": "submission_validation_v1",
        "splits": splits,
        "recall_extension_rules": rule_results,
        "mapping_status_by_human_label": mapping_crosstab,
        "original_false_negatives_by_mapping_status": dict(Counter(row["mapping_status"] for row in false_negatives)),
        "false_deletions": [
            {
                "full598_index": row["full598_index"],
                "import_path": row["import_path"],
                "mapping_status": row["mapping_status"],
            }
            for row in false_deletions
        ],
        "malformed_outside_missing_import": [
            {
                "full598_index": row["full598_index"],
                "import_path": row["import_path"],
                "mapping_status": row["mapping_status"],
            }
            for row in malformed_non_missing
        ],
        "heldout_agreement": agreement(),
        "record_level_clustered_bootstrap": {
            "windows": window_rates,
            "overall": overall_record_rate,
            "paired_3b_minus_7b_risk_difference": overall_record_rate,
            "mcnemar_discordant_3b_only": 48,
            "mcnemar_discordant_7b_only": 0,
            "mcnemar_exact_two_sided_p": 2 * (0.5**48),
        },
        "build_probe": build_probe_summary(),
        "model_format_sensitivity": model_format_summary(),
        "versioning": {
            "recall_rule_script": "codex_java_recall_extension_audit.py",
            "recall_rule_script_sha256": sha256(ROOT / "codex_java_recall_extension_audit.py"),
            "heldout_adjudication_sha256": sha256(AUDIT / "heldout_448_disagreements_for_adjudication.csv"),
            "full_truth_with_extension_sha256": sha256(TRUTH_CSV),
            "rule_freeze_timestamp_from_file_metadata": "2026-07-28T10:52:25+08:00",
            "heldout_annotation_date": "2026-07-31 Asia/Shanghai",
        },
    }

    output_json = AUDIT / "submission_validation_results.json"
    output_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    held = splits["heldout_448"]["enhanced"]
    dev = splits["development_150"]["enhanced"]
    overall = splits["overall_598"]["enhanced"]
    lines = [
        "# Submission Validation Results",
        "",
        f"- Development 150 enhanced: TP={dev['tp']}, FP={dev['fp']}, FN={dev['fn']}, TN={dev['tn']}, precision={dev['precision']:.3f}, recall={dev['recall']:.3f}, F1={dev['f1']:.3f}.",
        f"- Held-out 448 enhanced: TP={held['tp']}, FP={held['fp']}, FN={held['fn']}, TN={held['tn']}, precision={held['precision']:.3f}, recall={held['recall']:.3f}, F1={held['f1']:.3f}.",
        f"- Overall 598 enhanced (descriptive): TP={overall['tp']}, FP={overall['fp']}, FN={overall['fn']}, TN={overall['tn']}, precision={overall['precision']:.3f}, recall={overall['recall']:.3f}, F1={overall['f1']:.3f}.",
        "",
        "## Held-out Rule Precision",
        "",
        "| Rule | Added | TP | FP | Precision |",
        "|---|---:|---:|---:|---:|",
    ]
    for rule, values in rule_results["heldout_448"].items():
        lines.append(f"| `{rule}` | {values['added_flags']} | {values['tp']} | {values['fp']} | {values['precision']:.3f} |")
    lines.extend(
        [
            "",
            "## Mapping Status by Human Label",
            "",
            "| Mapping status | Valid | Invalid | Malformed | Uncertain | Total |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for status, values in mapping_crosstab.items():
        lines.append(
            f"| `{status}` | {values['valid']} | {values['invalid']} | {values['malformed']} | {values['uncertain']} | {values['total']} |"
        )
    build = summary["build_probe"]
    lines.extend(
        [
            "",
            "## Traceable Maven Probe",
            "",
            f"- Five preserved CSVs contain {build['baseline_run_rows']} window-specific baseline runs representing {build['unique_baseline_build_units']} unique build units from {build['independent_projects']} projects.",
            f"- {build['baseline_pass_runs']} baseline runs pass, representing {build['baseline_pass_unique_units']} unique build units.",
            f"- {build['baseline_failed_runs']} baseline runs fail, representing {build['baseline_failed_unique_units']} unique build units; run-level and unique-unit status counts are preserved separately in the JSON output.",
            f"- {build['interpretable_target_pairs']} target pairs across {build['interpretable_unique_build_units']} unique units are interpretable: {build['fail_then_pass']} pairs from {build['fail_then_pass_unique_build_units']} units fail after injection and pass after removal; {build['pass_then_pass']} pass in both variants.",
            "- Maven `test-compile` was invoked with test execution skipped; no test-pass claim is supported.",
            "",
            "## Versioning",
            "",
            f"- Recall-rule script SHA256: `{summary['versioning']['recall_rule_script_sha256']}`.",
            f"- Rule freeze timestamp: `{summary['versioning']['rule_freeze_timestamp_from_file_metadata']}`.",
            f"- Bootstrap: {BOOTSTRAP_REPLICATES} project-clustered replicates, seed {SEED}, percentile 95% intervals.",
        ]
    )
    (AUDIT / "submission_validation_results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output_json)


if __name__ == "__main__":
    main()
