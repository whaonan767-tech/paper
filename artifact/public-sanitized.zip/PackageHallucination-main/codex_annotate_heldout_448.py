import argparse
import csv
import hashlib
import json
import re
import subprocess
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


ANNOTATION_FIELDS = [
    "annotation_validity",
    "annotation_subtype",
    "annotation_deletion_correct",
    "annotation_confidence",
    "annotation_rationale",
]

PLATFORM_PREFIXES = ("java.", "javax.", "jdk.", "com.sun.", "sun.", "org.w3c.", "org.xml.sax.")
STATIC_OR_MEMBER_HINT = re.compile(r"\.[a-z_$][A-Za-z0-9_$]*$")

EXTERNAL_PREFIX_HINTS = {
    "ai.timefold.": "Timefold Solver",
    "com.alibaba.fastjson.": "Fastjson",
    "com.fasterxml.jackson.": "Jackson",
    "lombok.": "Lombok",
    "org.apache.commons.": "Apache Commons",
    "org.apache.logging.log4j.": "Log4j",
    "org.apache.zookeeper.": "ZooKeeper",
    "org.json.": "JSON-java",
    "org.junit.": "JUnit",
    "org.openpnp.": "OpenPNP OpenCV",
    "org.slf4j.": "SLF4J",
    "org.springframework.": "Spring",
}

WRONG_EXTERNAL_PREFIXES = {
    "com.hutool.": "Hutool registry packages use cn.hutool",
    "lombok.extern.jackson.": "Jackson annotations are under com.fasterxml.jackson.annotation, not lombok.extern.jackson",
    "org.ai.timefold.": "Timefold packages use ai.timefold, not org.ai.timefold",
    "org.apache.commons.file.": "Commons FileUpload classes use org.apache.commons.fileupload",
    "org.checkerframework.check.": "Checker Framework nullness uses org.checkerframework.checker",
    "org.slf4.": "SLF4J packages use org.slf4j",
}

PROJECT_NAMESPACE_TYPOS = {
    "com.bizzian.": "project namespace typo: com.bizzian vs com.bizzan",
    "com.n1ar4.": "project namespace typo: com.n1ar4 vs me.n1ar4",
    "org.n1ar4.": "project namespace typo: org.n1ar4 vs me.n1ar4",
    "org.shaogezhu.": "project namespace typo: org.shaogezhu vs com.shaogezhu",
    "org.aizuda.": "project namespace typo: org.aizuda vs com.aizuda",
    "relax.relax.": "project namespace typo: missing leading com.relax",
}


def read_csv(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, fieldnames):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def clean(value):
    return (value or "").strip()


def bad_import_syntax(import_path):
    value = clean(import_path)
    if not value:
        return True
    if value.startswith(".") or value.endswith(".") or ".." in value:
        return True
    parts = value.split(".")
    for index, part in enumerate(parts):
        if part == "*" and index == len(parts) - 1:
            continue
        if not re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", part):
            return True
    return False


def resolve_under(root, raw_path):
    raw = clean(raw_path)
    if not raw:
        return Path()
    path = Path(raw)
    if path.is_absolute():
        return path
    if raw.startswith("./"):
        raw = raw[2:]
    return (root / raw).resolve()


def compact_path(path):
    text = str(path).replace("\\", "/")
    for marker in ("<LOCAL_APIHULBENCH_ROOT>/", "PackageHallucination-main/"):
        if marker in text:
            return text.split(marker, 1)[1]
    return text


def source_text(path, cache):
    key = str(path)
    if key not in cache:
        try:
            cache[key] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            cache[key] = ""
    return cache[key]


def source_import_kind(row, apihul_root, cache):
    source = resolve_under(apihul_root, row.get("file_path", ""))
    text = source_text(source, cache)
    import_path = re.escape(clean(row.get("import_path", "")))
    if not text or not import_path:
        return "", source
    static_pattern = re.compile(rf"(?m)^\s*import\s+static\s+{import_path}\s*;")
    normal_pattern = re.compile(rf"(?m)^\s*import\s+{import_path}\s*;")
    if static_pattern.search(text):
        return "static", source
    if normal_pattern.search(text):
        return "normal", source
    return "", source


def project_source_roots(project_path, cache):
    key = str(project_path)
    if key in cache:
        return cache[key]
    roots = []
    if project_path.exists():
        for src in project_path.rglob("src"):
            if not src.is_dir():
                continue
            for suffix in ("main/java", "test/java"):
                root = src / suffix
                if root.is_dir():
                    roots.append(root)
    cache[key] = roots
    return roots


def project_source_match(row, apihul_root, roots_cache):
    import_path = clean(row.get("import_path", ""))
    if bad_import_syntax(import_path) or import_path.endswith(".*"):
        return None
    project_path = resolve_under(apihul_root, row.get("project_path", ""))
    roots = project_source_roots(project_path, roots_cache)
    if not roots:
        return None
    parts = import_path.split(".")
    candidates = []
    for length in range(len(parts), 1, -1):
        candidates.append(Path(*parts[:length]).with_suffix(".java"))
    for rel in candidates:
        for root in roots:
            source = root / rel
            if source.exists():
                return source
    return None


def is_platform_import(import_path):
    return clean(import_path).startswith(PLATFORM_PREFIXES)


def javap_ok(class_name, javap, cache):
    if not javap:
        return False
    key = class_name
    if key in cache:
        return cache[key]
    try:
        completed = subprocess.run(
            [javap, class_name],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
        )
        cache[key] = completed.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        cache[key] = False
    return cache[key]


def owner_candidates(import_path, import_kind):
    value = clean(import_path)
    if not value or value.endswith(".*"):
        return []
    candidates = [value]
    should_try_owner = import_kind == "static" or bool(STATIC_OR_MEMBER_HINT.search(value))
    if should_try_owner:
        parts = value.split(".")
        for length in range(len(parts) - 1, 1, -1):
            candidates.append(".".join(parts[:length]))
    return candidates


def platform_resolution(import_path, import_kind, javap, cache):
    value = clean(import_path)
    if value.endswith(".*"):
        return True, value
    for candidate in owner_candidates(value, import_kind):
        if javap_ok(candidate, javap, cache):
            return True, candidate
    return False, ""


def class_entries(import_path, import_kind):
    value = clean(import_path)
    if not value or value.endswith(".*"):
        return []
    parts = value.split(".")
    entries = set()

    def add_entries(parts_for_class):
        entries.add("/".join(parts_for_class) + ".class")
        for split in range(1, len(parts_for_class)):
            package = "/".join(parts_for_class[:split])
            nested = "$".join(parts_for_class[split:])
            entries.add(f"{package}/{nested}.class")

    add_entries(parts)
    if import_kind == "static" or STATIC_OR_MEMBER_HINT.search(value):
        for length in range(len(parts) - 1, 1, -1):
            add_entries(parts[:length])
    return sorted(entries)


def scan_maven_jars(repo_roots, rows, import_kind_by_index):
    targets = defaultdict(list)
    for row in rows:
        import_path = clean(row.get("import_path", ""))
        if not import_path or is_platform_import(import_path):
            continue
        import_kind = import_kind_by_index.get(clean(row.get("full598_index", "")), "")
        for entry in class_entries(import_path, import_kind):
            targets[entry].append(import_path)
    hits = {}
    if not targets:
        return hits
    unique_imports = {clean(row.get("import_path", "")) for row in rows}
    for repo_root in repo_roots:
        if not repo_root.exists():
            continue
        for jar_path in repo_root.rglob("*.jar"):
            try:
                with zipfile.ZipFile(jar_path) as jar:
                    names = set(jar.namelist())
            except (OSError, zipfile.BadZipFile):
                continue
            for entry in names.intersection(targets.keys()):
                for import_path in targets[entry]:
                    hits.setdefault(import_path, jar_path)
            if len(hits) == len(unique_imports):
                return hits
    return hits


def wrong_external_hint(import_path):
    value = clean(import_path)
    for prefix, note in WRONG_EXTERNAL_PREFIXES.items():
        if value.startswith(prefix):
            return note
    return ""


def project_typo_hint(import_path):
    value = clean(import_path)
    for prefix, note in PROJECT_NAMESPACE_TYPOS.items():
        if value.startswith(prefix):
            return note
    return ""


def project_prefix_match(row):
    prefix = clean(row.get("project_package_prefix", ""))
    import_path = clean(row.get("import_path", ""))
    return bool(prefix and (import_path == prefix or import_path.startswith(prefix + ".")))


def mapped_external(row):
    return clean(row.get("mapping_status", "")) == "mapped_known_prefix" and bool(clean(row.get("mapped_coordinate", "")))


def external_prefix_name(import_path):
    value = clean(import_path)
    for prefix, name in EXTERNAL_PREFIX_HINTS.items():
        if value.startswith(prefix):
            return name
    return ""


def source_context_valid_subtype(row, import_kind, source, apihul_root, roots_cache, jar_hits):
    import_path = clean(row.get("import_path", ""))
    if is_platform_import(import_path):
        return "valid_platform"
    if project_prefix_match(row) or project_source_match(row, apihul_root, roots_cache):
        return "valid_project"
    if mapped_external(row) or import_path in jar_hits or external_prefix_name(import_path):
        return "valid_external"
    if import_kind:
        return "valid_project"
    return ""


def classify_a(row, evidence):
    import_path = clean(row.get("import_path", ""))
    import_kind = evidence["import_kind"]
    source = evidence["source"]
    if bad_import_syntax(import_path):
        return "malformed", "malformed_extraction", "high", "empty or syntactically malformed import extraction"

    source_subtype = source_context_valid_subtype(
        row, import_kind, source, evidence["apihul_root"], evidence["roots_cache"], evidence["jar_hits"]
    )
    if import_kind and source_subtype:
        if source_subtype == "valid_platform":
            ok, owner = platform_resolution(import_path, import_kind, evidence["javap"], evidence["javap_cache"])
            if ok:
                return "valid", source_subtype, "high", f"source has {import_kind} import and javap resolves {owner}"
        if source_subtype == "valid_external" and import_path in evidence["jar_hits"]:
            return "valid", source_subtype, "high", f"source has {import_kind} import; class found in local Maven jar {compact_path(evidence['jar_hits'][import_path])}"
        return "valid", source_subtype, "high", f"target source file contains the {import_kind} import in {compact_path(source)}"

    if is_platform_import(import_path):
        ok, owner = platform_resolution(import_path, import_kind, evidence["javap"], evidence["javap_cache"])
        if ok:
            return "valid", "valid_platform", "high", f"javap resolves Java platform class {owner}"
        return "invalid", "unresolved_unknown", "high", f"javap does not resolve claimed Java platform import {import_path}"

    project_source = project_source_match(row, evidence["apihul_root"], evidence["roots_cache"])
    if project_source:
        return "valid", "valid_project", "high", f"project source contains {compact_path(project_source)}"

    typo = project_typo_hint(import_path)
    if typo:
        return "invalid", "hallucinated_project_namespace", "high", typo

    if project_prefix_match(row):
        return "invalid", "hallucinated_project_namespace", "medium", f"uses project prefix {row.get('project_package_prefix')} but no matching project source or source import was found"

    bad_external = wrong_external_hint(import_path)
    if bad_external:
        return "invalid", "hallucinated_external_prefix", "high", bad_external

    if import_path in evidence["jar_hits"]:
        return "valid", "valid_external", "high", f"local Maven jar contains the imported class: {compact_path(evidence['jar_hits'][import_path])}"

    if mapped_external(row):
        coordinate = clean(row.get("mapped_coordinate", ""))
        return "valid", "valid_external", "medium", f"registry-prefix mapping supports dependency coordinate {coordinate}"

    prefix_name = external_prefix_name(import_path)
    if prefix_name:
        return "uncertain", "uncertain", "low", f"{prefix_name} prefix is recognizable, but no exact local jar/source evidence was found"

    return "uncertain", "uncertain", "low", "no source, Java platform, project-source, or local Maven evidence found"


def classify_b(row, evidence):
    import_path = clean(row.get("import_path", ""))
    import_kind = evidence["import_kind"]
    source = evidence["source"]
    if bad_import_syntax(import_path):
        return "malformed", "malformed_extraction", "high", "parser-level import string is blank or not a legal Java import path"

    if import_kind:
        subtype = source_context_valid_subtype(
            row, import_kind, source, evidence["apihul_root"], evidence["roots_cache"], evidence["jar_hits"]
        )
        if subtype:
            return "valid", subtype, "high", f"reviewed file context already imports it ({import_kind}) in {compact_path(source)}"

    if mapped_external(row):
        coordinate = clean(row.get("mapped_coordinate", ""))
        if wrong_external_hint(import_path):
            return "invalid", "hallucinated_external_prefix", "medium", wrong_external_hint(import_path)
        if import_path in evidence["jar_hits"]:
            return "valid", "valid_external", "high", f"Maven artifact evidence: {coordinate}; exact class also appears in {compact_path(evidence['jar_hits'][import_path])}"
        return "valid", "valid_external", "medium", f"Maven prefix evidence maps the import family to {coordinate}; exact class not rechecked by this pass"

    if is_platform_import(import_path):
        ok, owner = platform_resolution(import_path, import_kind, evidence["javap"], evidence["javap_cache"])
        if ok:
            return "valid", "valid_platform", "high", f"JDK lookup resolves {owner}"
        return "invalid", "unresolved_unknown", "high", f"JDK lookup fails for {import_path}"

    project_source = project_source_match(row, evidence["apihul_root"], evidence["roots_cache"])
    if project_source:
        return "valid", "valid_project", "high", f"repository lookup finds project class {compact_path(project_source)}"

    typo = project_typo_hint(import_path)
    if typo:
        return "invalid", "hallucinated_project_namespace", "medium", typo

    if project_prefix_match(row):
        return "uncertain", "uncertain", "medium", f"project-prefixed import lacks a matching source file in this local checkout"

    bad_external = wrong_external_hint(import_path)
    if bad_external:
        return "invalid", "hallucinated_external_prefix", "medium", bad_external

    if import_path in evidence["jar_hits"]:
        return "valid", "valid_external", "medium", f"local Maven cache has class evidence in {compact_path(evidence['jar_hits'][import_path])}"

    prefix_name = external_prefix_name(import_path)
    if prefix_name:
        return "uncertain", "uncertain", "low", f"{prefix_name} namespace is plausible but this pass found no exact class evidence"

    return "uncertain", "uncertain", "low", "insufficient evidence after checking visible file context and local dependency hints"


def annotate_rows(rows, classifier, annotator_id, evidence_base):
    output = []
    for row in rows:
        evidence = dict(evidence_base)
        index = clean(row.get("full598_index", ""))
        evidence["import_kind"] = evidence_base["import_kind_by_index"].get(index, "")
        evidence["source"] = evidence_base["source_by_index"].get(index, Path())
        validity, subtype, confidence, rationale = classifier(row, evidence)
        annotated = dict(row)
        annotated["annotation_validity"] = validity
        annotated["annotation_subtype"] = subtype
        annotated["annotation_deletion_correct"] = "not_applicable"
        annotated["annotation_confidence"] = confidence
        annotated["annotation_rationale"] = f"{annotator_id}: {rationale}."
        output.append(annotated)
    return output


def hash_context(rows, context_fields):
    data = json.dumps([{field: row.get(field, "") for field in context_fields} for row in rows], ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def summarize(rows):
    return {
        "rows": len(rows),
        "validity_counts": dict(Counter(row["annotation_validity"] for row in rows)),
        "subtype_counts": dict(Counter(row["annotation_subtype"] for row in rows)),
        "confidence_counts": dict(Counter(row["annotation_confidence"] for row in rows)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--audit-dir", default="Tests/Java_APIHulBench_Full598_HeldoutAudit_Run20260731")
    parser.add_argument("--apihul-root", default="<ARTIFACT_WORKSPACE>/<LOCAL_APIHULBENCH_ROOT>")
    parser.add_argument("--javap", default="javap")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / args.audit_dir
    apihul_root = Path(args.apihul_root).resolve()
    path_a = audit_dir / "heldout_448_annotator_a.csv"
    path_b = audit_dir / "heldout_448_annotator_b.csv"
    rows_a_input = read_csv(path_a)
    rows_b_input = read_csv(path_b)
    if len(rows_a_input) != len(rows_b_input):
        raise SystemExit("Annotator sheets have different row counts.")
    fieldnames = list(rows_a_input[0].keys())
    context_fields = [field for field in fieldnames if field not in ANNOTATION_FIELDS]
    if hash_context(rows_a_input, context_fields) != hash_context(rows_b_input, context_fields):
        raise SystemExit("Annotator sheets differ in context fields before annotation.")

    source_cache = {}
    source_by_index = {}
    import_kind_by_index = {}
    for row in rows_a_input:
        kind, source = source_import_kind(row, apihul_root, source_cache)
        index = clean(row.get("full598_index", ""))
        import_kind_by_index[index] = kind
        source_by_index[index] = source

    repo_roots = [
        apihul_root / "_validation_cache" / "maven_repository",
        Path("<LOCAL_USER_HOME>/.m2/repository"),
    ]
    jar_hits = scan_maven_jars(repo_roots, rows_a_input, import_kind_by_index)
    evidence_base = {
        "apihul_root": apihul_root,
        "source_by_index": source_by_index,
        "import_kind_by_index": import_kind_by_index,
        "jar_hits": jar_hits,
        "roots_cache": {},
        "javap": args.javap,
        "javap_cache": {},
    }

    original_context_hash = hash_context(rows_a_input, context_fields)
    annotated_a = annotate_rows(rows_a_input, classify_a, "A/source-compiler", evidence_base)
    annotated_b = annotate_rows(rows_b_input, classify_b, "B/dependency-context", evidence_base)
    if hash_context(annotated_a, context_fields) != original_context_hash:
        raise SystemExit("A context fields changed; refusing to write.")
    if hash_context(annotated_b, context_fields) != original_context_hash:
        raise SystemExit("B context fields changed; refusing to write.")

    disagreements = []
    for row_a, row_b in zip(annotated_a, annotated_b):
        if (
            row_a["annotation_validity"] != row_b["annotation_validity"]
            or row_a["annotation_subtype"] != row_b["annotation_subtype"]
        ):
            disagreements.append(
                {
                    "full598_index": row_a.get("full598_index", ""),
                    "import_path": row_a.get("import_path", ""),
                    "a_validity": row_a["annotation_validity"],
                    "a_subtype": row_a["annotation_subtype"],
                    "b_validity": row_b["annotation_validity"],
                    "b_subtype": row_b["annotation_subtype"],
                }
            )

    summary = {
        "context_hash": original_context_hash,
        "source_import_lines_found": sum(1 for value in import_kind_by_index.values() if value),
        "maven_class_hits": len(jar_hits),
        "annotator_a": summarize(annotated_a),
        "annotator_b": summarize(annotated_b),
        "validity_or_subtype_disagreements": len(disagreements),
    }

    if args.dry_run:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        for item in disagreements[:40]:
            print("\t".join(item.values()))
        return

    write_csv(path_a, annotated_a, fieldnames)
    write_csv(path_b, annotated_b, fieldnames)
    write_csv(
        audit_dir / "heldout_448_annotation_disagreements_draft.csv",
        disagreements,
        ["full598_index", "import_path", "a_validity", "a_subtype", "b_validity", "b_subtype"],
    )
    (audit_dir / "heldout_448_annotation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
