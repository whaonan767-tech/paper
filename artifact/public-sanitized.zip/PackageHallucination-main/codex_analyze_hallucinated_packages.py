import argparse
import ast
import csv
import json
import re
from collections import Counter
from pathlib import Path

import pandas as pd


LIST_COLUMNS = [
    "valid_1",
    "hallucinated_1",
    "valid_2",
    "hallucinated_2",
    "pip_valid",
    "pip_hallucinated",
    "npm_valid",
    "npm_hallucinated",
]


def parse_list(value):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return []
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    except Exception:
        pass
    return [text]


def artifact_flags(name):
    flags = []
    raw_name = name
    name = (name or "").strip()
    if re.fullmatch(r"\d+", name):
        flags.append("numeric")
    if "`" in name or "\n" in name:
        flags.append("formatting")
    if len(name) <= 2:
        flags.append("too_short")
    if name in {"python", "pip", "bash", "package", "module", "run", "with", "the"}:
        flags.append("language_word")
    if any(part in name for part in ["venven", "</", "<p", "quot", "&"]):
        flags.append("html_or_generation_noise")
    if any(ch in raw_name for ch in ["'", '"', " "]):
        flags.append("quote_or_space")
    if name.startswith(("example-", "my", "your-")) or name in {"xyz", "abc"}:
        flags.append("placeholder")
    if name.count("-") >= 3:
        flags.append("many_hyphens")
    return flags


def is_artifact_like(name):
    disqualifying = {
        "numeric",
        "formatting",
        "too_short",
        "language_word",
        "html_or_generation_noise",
        "quote_or_space",
        "placeholder",
    }
    return bool(disqualifying.intersection(artifact_flags(name)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output-prefix", default="hallucination_audit")
    parser.add_argument("--top-n", type=int, default=30)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    df = pd.read_csv(run_dir / "PACKAGE_NAMES.csv")

    for column in LIST_COLUMNS:
        if column not in df.columns:
            df[column] = "[]"
        df[column + "_list"] = df[column].apply(parse_list)

    counters = {
        "hallucinated_1": Counter(),
        "hallucinated_2": Counter(),
        "pip_hallucinated": Counter(),
        "npm_hallucinated": Counter(),
    }
    filtered_counters = {column: Counter() for column in counters}
    row_records = []
    filtered_row_records = []
    for idx, row in df.iterrows():
        row_hallucinations = []
        filtered_hallucinations = []
        for column in counters:
            values = row[column + "_list"]
            counters[column].update(values)
            retained = [value for value in values if not is_artifact_like(value)]
            filtered_counters[column].update(retained)
            row_hallucinations.extend((column, value) for value in values)
            filtered_hallucinations.extend((column, value) for value in retained)

        if row_hallucinations:
            names = [value for _, value in row_hallucinations]
            flags = sorted(set(flag for name in names for flag in artifact_flags(name)))
            row_records.append(
                {
                    "row_index": int(idx),
                    "count": len(names),
                    "names": names,
                    "flags": flags,
                    "valid_1": row["valid_1_list"],
                    "valid_2": row["valid_2_list"],
                }
            )
        if filtered_hallucinations:
            names = [value for _, value in filtered_hallucinations]
            flags = sorted(set(flag for name in names for flag in artifact_flags(name)))
            filtered_row_records.append(
                {
                    "row_index": int(idx),
                    "count": len(names),
                    "names": names,
                    "flags": flags,
                    "valid_1": row["valid_1_list"],
                    "valid_2": row["valid_2_list"],
                }
            )

    top_by_column = {
        column: [{"package": pkg, "count": count, "flags": artifact_flags(pkg)} for pkg, count in counter.most_common(args.top_n)]
        for column, counter in counters.items()
    }
    all_hallucinated = Counter()
    for counter in counters.values():
        all_hallucinated.update(counter)
    filtered_all_hallucinated = Counter()
    for counter in filtered_counters.values():
        filtered_all_hallucinated.update(counter)

    summary = {
        "run_dir": str(run_dir),
        "rows": int(len(df)),
        "rows_with_hallucinations": int(len(row_records)),
        "total_hallucinated_mentions": int(sum(all_hallucinated.values())),
        "unique_hallucinated_packages": int(len(all_hallucinated)),
        "artifact_filtered": {
            "rows_with_hallucinations": int(len(filtered_row_records)),
            "total_hallucinated_mentions": int(sum(filtered_all_hallucinated.values())),
            "unique_hallucinated_packages": int(len(filtered_all_hallucinated)),
            "removed_mentions": int(sum(all_hallucinated.values()) - sum(filtered_all_hallucinated.values())),
            "top_all": [
                {"package": pkg, "count": count, "flags": artifact_flags(pkg)}
                for pkg, count in filtered_all_hallucinated.most_common(args.top_n)
            ],
            "top_by_column": {
                column: [
                    {"package": pkg, "count": count, "flags": artifact_flags(pkg)}
                    for pkg, count in counter.most_common(args.top_n)
                ]
                for column, counter in filtered_counters.items()
            },
            "rows_with_most_hallucinations": sorted(
                filtered_row_records, key=lambda item: item["count"], reverse=True
            )[: args.top_n],
        },
        "top_all": [
            {"package": pkg, "count": count, "flags": artifact_flags(pkg)}
            for pkg, count in all_hallucinated.most_common(args.top_n)
        ],
        "top_by_column": top_by_column,
        "rows_with_most_hallucinations": sorted(row_records, key=lambda item: item["count"], reverse=True)[: args.top_n],
    }

    out_json = run_dir / f"{args.output_prefix}.json"
    out_md = run_dir / f"{args.output_prefix}.md"
    out_csv = run_dir / f"{args.output_prefix}_top.csv"
    out_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    with open(out_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["scope", "package", "count", "flags"])
        writer.writeheader()
        for item in summary["top_all"]:
            writer.writerow(
                {
                    "scope": "all",
                    "package": item["package"],
                    "count": item["count"],
                    "flags": ";".join(item["flags"]),
                }
            )
        for column, items in top_by_column.items():
            for item in items:
                writer.writerow(
                    {
                        "scope": column,
                        "package": item["package"],
                        "count": item["count"],
                        "flags": ";".join(item["flags"]),
                    }
                )

    lines = [
        "# Hallucinated Package Audit",
        "",
        f"- Run directory: `{run_dir}`",
        f"- Rows: `{summary['rows']}`",
        f"- Rows with hallucinations: `{summary['rows_with_hallucinations']}`",
        f"- Total hallucinated mentions: `{summary['total_hallucinated_mentions']}`",
        f"- Unique hallucinated packages: `{summary['unique_hallucinated_packages']}`",
        f"- Artifact-filtered rows with hallucinations: `{summary['artifact_filtered']['rows_with_hallucinations']}`",
        f"- Artifact-filtered hallucinated mentions: `{summary['artifact_filtered']['total_hallucinated_mentions']}`",
        f"- Artifact-filtered unique hallucinated packages: `{summary['artifact_filtered']['unique_hallucinated_packages']}`",
        f"- Removed as likely artifacts/placeholders: `{summary['artifact_filtered']['removed_mentions']}`",
        "",
        "## Top Hallucinated Mentions",
        "",
        "| Package | Count | Flags |",
        "|---|---:|---|",
    ]
    for item in summary["top_all"]:
        lines.append(f"| `{item['package']}` | {item['count']} | {', '.join(item['flags'])} |")
    lines.extend(
        [
            "",
            "## Top Artifact-Filtered Mentions",
            "",
            "| Package | Count | Flags |",
            "|---|---:|---|",
        ]
    )
    for item in summary["artifact_filtered"]["top_all"]:
        lines.append(f"| `{item['package']}` | {item['count']} | {', '.join(item['flags'])} |")
    lines.extend(["", "## Rows With Most Hallucinations", "", "| Row | Count | Names | Flags |", "|---:|---:|---|---|"])
    for item in summary["rows_with_most_hallucinations"][:10]:
        names = ", ".join(f"`{name}`" for name in item["names"][:12])
        if len(item["names"]) > 12:
            names += ", ..."
        lines.append(f"| {item['row_index']} | {item['count']} | {names} | {', '.join(item['flags'])} |")
    out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {out_json}, {out_md}, and {out_csv}")


if __name__ == "__main__":
    main()
