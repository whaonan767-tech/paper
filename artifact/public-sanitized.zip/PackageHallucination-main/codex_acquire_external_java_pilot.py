#!/usr/bin/env python3
"""Acquire a prospective, project-disjoint Java/Maven pilot corpus."""

from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath


ALLOWED_LICENSES = {"Apache-2.0", "MIT", "BSD-2-Clause", "BSD-3-Clause", "EPL-1.0", "EPL-2.0"}
QUERY = "language:Java fork:false archived:false stars:100..2000 size:<15000"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--projects", type=int, default=8)
    parser.add_argument("--search-size", type=int, default=40)
    parser.add_argument("--search-snapshot", type=Path)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def request_bytes(url: str, timeout: float, accept: str = "application/vnd.github+json") -> bytes:
    last_error = None
    for attempt in range(4):
        request = urllib.request.Request(
            url,
            headers={
                "Accept": accept,
                "User-Agent": "dependency-audit-prospective-pilot/1.0",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.read()
        except urllib.error.HTTPError as error:
            if error.code == 404:
                raise
            last_error = error
            if attempt == 3:
                break
            time.sleep(2**attempt)
        except (urllib.error.URLError, TimeoutError, http.client.IncompleteRead, ConnectionResetError) as error:
            last_error = error
            if attempt == 3:
                break
            time.sleep(2**attempt)
    raise RuntimeError(f"Request failed after 4 attempts: {url}: {last_error}")


def request_json(url: str, timeout: float) -> dict:
    return json.loads(request_bytes(url, timeout).decode("utf-8"))


def download_file(url: str, path: Path, timeout: float, total_timeout: float = 600.0) -> None:
    partial = path.with_suffix(path.suffix + ".part")
    deadline = time.monotonic() + total_timeout
    last_error = None
    for attempt in range(4):
        if partial.exists():
            partial.unlink()
        request = urllib.request.Request(
            url,
            headers={"Accept": "application/zip", "User-Agent": "dependency-audit-prospective-pilot/1.0"},
        )
        try:
            downloaded = 0
            with urllib.request.urlopen(request, timeout=timeout) as response, partial.open("wb") as handle:
                while True:
                    if time.monotonic() > deadline:
                        raise TimeoutError(f"Archive download exceeded {total_timeout:.0f}s total")
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    handle.write(chunk)
                    downloaded += len(chunk)
                    print(f"DOWNLOAD {path.name} {downloaded} bytes", flush=True)
            partial.replace(path)
            return
        except (urllib.error.URLError, TimeoutError, http.client.IncompleteRead) as error:
            last_error = error
            if time.monotonic() > deadline or attempt == 3:
                break
            time.sleep(2**attempt)
    if partial.exists():
        partial.unlink()
    raise RuntimeError(f"Archive download failed: {url}: {last_error}")


def root_pom_exists(full_name: str, branch: str, timeout: float) -> bool:
    url = f"https://github.com/{full_name}/blob/{urllib.parse.quote(branch, safe='')}/pom.xml"
    try:
        data = request_bytes(url, timeout, accept="text/html")
        return b"pom.xml" in data and (b"<project" in data or b"&lt;project" in data)
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError):
        return False


def archive_commit_sha(archive: Path, repo_name: str) -> str:
    with zipfile.ZipFile(archive) as handle:
        first = next((name for name in handle.namelist() if name), "")
    root = PurePosixPath(first).parts[0] if first else ""
    prefix = repo_name + "-"
    if not root.startswith(prefix):
        raise RuntimeError(f"Cannot recover commit SHA from archive root {root!r}")
    value = root[len(prefix) :]
    if not re.fullmatch(r"[0-9a-fA-F]{12,40}", value):
        raise RuntimeError(f"Invalid archive commit SHA: {value!r}")
    return value.lower()


def filename_sha_prefix(path: Path) -> str:
    name = path.name.removesuffix(".part").removesuffix(".zip")
    value = name.rsplit("_", 1)[-1]
    if not re.fullmatch(r"[0-9a-fA-F]{7,40}", value):
        raise RuntimeError(f"Cannot recover SHA prefix from {path.name}")
    return value.lower()


def safe_extract(archive: Path, target: Path) -> str:
    with zipfile.ZipFile(archive) as handle:
        names = [name for name in handle.namelist() if name and not name.endswith("/")]
        roots = {PurePosixPath(name).parts[0] for name in names}
        if len(roots) != 1:
            raise RuntimeError(f"Unexpected archive roots: {roots}")
        root = next(iter(roots))
        for info in handle.infolist():
            parts = PurePosixPath(info.filename).parts
            if not parts or any(part in {"", ".", ".."} for part in parts):
                continue
            relative_parts = parts[1:]
            if not relative_parts:
                continue
            destination = target.joinpath(*relative_parts)
            if info.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            with handle.open(info) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
        return root


def normalized_name(value: str) -> str:
    return "".join(character.lower() for character in value if character.isalnum())


def local_selected_slugs(archives_dir: Path) -> dict[int, str]:
    selected = {}
    pattern = re.compile(r"^p(\d{3})_(.+)_([0-9a-fA-F]{7,40})\.zip(?:\.part)?$")
    for path in archives_dir.glob("p*.zip*"):
        match = pattern.match(path.name)
        if match:
            selected[int(match.group(1))] = match.group(2)
    return selected


def main() -> None:
    args = parse_args()
    freeze_dir = args.freeze_dir.resolve()
    output_dir = args.output_dir.resolve()
    if output_dir.exists() and not args.resume:
        raise SystemExit(f"Output directory exists: {output_dir}")
    projects_dir = output_dir / "p"
    archives_dir = output_dir / "archives"
    metadata_dir = output_dir / "metadata"
    projects_dir.mkdir(parents=True, exist_ok=args.resume)
    archives_dir.mkdir(exist_ok=args.resume)
    metadata_dir.mkdir(exist_ok=args.resume)

    freeze_json = freeze_dir / "prospective_external_evaluation_freeze.json"
    freeze_payload = json.loads(freeze_json.read_text(encoding="utf-8"))
    known_names = {normalized_name(Path(row["project_path"]).name) for row in freeze_payload["known_project_paths"]}
    search_url = "https://api.github.com/search/repositories?" + urllib.parse.urlencode(
        {"q": QUERY, "sort": "updated", "order": "desc", "per_page": args.search_size, "page": 1}
    )
    search_bytes = (
        args.search_snapshot.resolve().read_bytes()
        if args.search_snapshot
        else request_bytes(search_url, args.timeout)
    )
    search_path = metadata_dir / "github_search_snapshot.json"
    search_path.write_bytes(search_bytes)
    search = json.loads(search_bytes.decode("utf-8"))
    resume_slugs = local_selected_slugs(archives_dir) if args.resume else {}

    selected = []
    screening = []
    for item in search.get("items", []):
        license_id = (item.get("license") or {}).get("spdx_id", "")
        repo_name = item.get("name", "")
        full_name = item.get("full_name", "")
        branch = item.get("default_branch", "")
        project_index = len(selected) + 1
        slug = full_name.replace("/", "_")
        project_path = projects_dir / f"p{project_index:03d}"
        existing_archives = sorted(archives_dir.glob(f"p{project_index:03d}_{slug}_*.zip"))
        partial_archives = sorted(archives_dir.glob(f"p{project_index:03d}_{slug}_*.zip.part"))
        locally_selected = bool(
            (existing_archives and (project_path / "pom.xml").exists())
            or partial_archives
        )
        resume_prior_rejection = bool(
            args.resume
            and resume_slugs.get(project_index)
            and resume_slugs[project_index] != slug
        )
        row = {
            "rank": len(screening) + 1,
            "full_name": full_name,
            "repo_name": repo_name,
            "default_branch": branch,
            "size_kb": item.get("size"),
            "stars": item.get("stargazers_count"),
            "pushed_at": item.get("pushed_at"),
            "license_spdx": license_id,
            "known_name_collision": normalized_name(repo_name) in known_names,
        }
        row["license_allowed"] = license_id in ALLOWED_LICENSES
        row["root_pom"] = False
        if locally_selected:
            row["root_pom"] = True
            row["root_pom_source"] = "local_completed_or_partial_acquisition"
        elif resume_prior_rejection:
            row["root_pom_source"] = "resume_prior_screening"
        elif row["license_allowed"] and not row["known_name_collision"]:
            row["root_pom"] = root_pom_exists(full_name, branch, args.timeout)
            row["root_pom_source"] = "github_html_probe"
        else:
            row["root_pom_source"] = "not_queried"
        row["selected"] = bool(row["license_allowed"] and not row["known_name_collision"] and row["root_pom"] and len(selected) < args.projects)
        screening.append(row)
        if not row["selected"]:
            continue

        if existing_archives and (project_path / "pom.xml").exists():
            archive_path = existing_archives[0]
            sha = archive_commit_sha(archive_path, repo_name)
        elif partial_archives:
            archive_path = partial_archives[0].with_suffix("")
            sha = filename_sha_prefix(partial_archives[0])
        else:
            commit_api = f"https://api.github.com/repos/{full_name}/commits/{urllib.parse.quote(branch, safe='')}"
            commit = request_json(commit_api, args.timeout)
            sha = commit["sha"]
            archive_path = archives_dir / f"p{project_index:03d}_{slug}_{sha[:12]}.zip"
        archive_url = f"https://codeload.github.com/{full_name}/zip/{sha}"
        reused = archive_path.exists() and (project_path / "pom.xml").exists()
        if not reused:
            if archive_path.exists():
                archive_path.unlink()
            if project_path.exists():
                shutil.rmtree(project_path)
            download_file(archive_url, archive_path, args.timeout)
            safe_extract(archive_path, project_path)
        sha = archive_commit_sha(archive_path, repo_name)
        if not (project_path / "pom.xml").exists():
            raise RuntimeError(f"Archive has no root pom.xml: {full_name}@{sha}")
        selected_row = {
            **row,
            "commit_sha": sha,
            "commit_url": f"https://github.com/{full_name}/commit/{sha}",
            "archive_url": archive_url,
            "archive_file": archive_path.name,
            "archive_sha256": sha256(archive_path),
            "project_dir": project_path.name,
            "project_relative_path": project_path.relative_to(output_dir).as_posix(),
        }
        selected.append(selected_row)
        action = "REUSED" if reused else "ACQUIRED"
        print(f"{action} {project_index}/{args.projects} {full_name}@{sha[:12]}", flush=True)
        if len(selected) >= args.projects:
            break

    if len(selected) < args.projects:
        raise SystemExit(f"Only {len(selected)} eligible projects found; requested {args.projects}")

    payload = {
        "artifact": "prospective_external_java_pilot_acquisition",
        "acquired_at_utc": datetime.now(timezone.utc).isoformat(),
        "freeze_json_sha256": sha256(freeze_json),
        "search_query": QUERY,
        "search_sort": "updated desc",
        "search_snapshot_sha256": sha256(search_path),
        "allowed_licenses": sorted(ALLOWED_LICENSES),
        "selection_rule": "Take the first query-ranked repositories with an allowed SPDX license, no normalized name collision with the 97 frozen projects, and a root pom.xml.",
        "screened": screening,
        "selected": selected,
    }
    (metadata_dir / "external_project_acquisition.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = [
        "# Prospective External Java Pilot Acquisition",
        "",
        f"- Acquired after freeze: `{payload['acquired_at_utc']}`.",
        f"- Query: `{QUERY}` sorted by most recently updated.",
        f"- Selected projects: `{len(selected)}`.",
        "- Selection: first ranked repositories with an allowed license, no frozen-name collision, and a root Maven POM.",
        "",
        "| Rank | Repository | Commit | License | Size KB |",
        "|---:|---|---|---|---:|",
    ]
    lines.extend(f"| {row['rank']} | `{row['full_name']}` | `{row['commit_sha'][:12]}` | `{row['license_spdx']}` | {row['size_kb']} |" for row in selected)
    (metadata_dir / "external_project_acquisition.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "selected_projects": len(selected)}, indent=2))


if __name__ == "__main__":
    main()
