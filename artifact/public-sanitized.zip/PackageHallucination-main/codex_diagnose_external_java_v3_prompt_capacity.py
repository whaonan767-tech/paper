#!/usr/bin/env python3
"""Report per-project prompt capacity using the frozen V3 prompt criteria."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from codex_build_external_java_v3_prompts import (
    COMMON_TARGET_FAMILIES,
    IMPORT_RE,
    PACKAGE_RE,
    nearest_pom,
)
from codex_build_external_v3_exclusions import family


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--acquisition-dir", type=Path, required=True)
    parser.add_argument("--exclusions", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    acquisition = json.loads((args.acquisition_dir / "metadata" / "external_project_acquisition_v3.json").read_text(encoding="utf-8"))
    exclusions = json.loads(args.exclusions.read_text(encoding="utf-8"))
    excluded_families = set(exclusions["api_families"])
    rows = []
    for project in acquisition["selected"]:
        root = args.acquisition_dir / project["project_relative_path"]
        owned = set(project.get("api_families", []))
        candidate_keys = set()
        eligible_files = set()
        for path in root.rglob("*.java"):
            relative = path.relative_to(root)
            parts_lower = {part.lower() for part in relative.parts}
            if {"target", "build", ".git"} & parts_lower:
                continue
            if not any(relative.parts[index:index + 3] == ("src", "main", "java") for index in range(max(0, len(relative.parts) - 2))):
                continue
            try:
                source = path.read_text(encoding="utf-8", errors="strict")
            except (OSError, UnicodeError):
                continue
            if not 800 <= len(source) <= 12_000:
                continue
            package_match = PACKAGE_RE.search(source)
            package_family = family(package_match.group(1)) if package_match else ""
            owned_here = owned | ({package_family} if package_family else set())
            for match in IMPORT_RE.finditer(source):
                target = match.group("value")
                target_family = family(target)
                if not target_family or target_family in COMMON_TARGET_FAMILIES or target_family in owned_here or target_family in excluded_families:
                    continue
                if source.count(target) != 1:
                    continue
                simple = target.rsplit(".", 1)[-1]
                if not re.search(rf"\b{re.escape(simple)}\b", source[match.end():]):
                    continue
                if nearest_pom(path, root) is None:
                    continue
                candidate_keys.add((relative.as_posix(), target))
                eligible_files.add(relative.as_posix())
        rows.append({
            "rank": project["rank"], "full_name": project["full_name"],
            "candidate_count": len(candidate_keys), "eligible_file_count": len(eligible_files),
            "capacity_at_least_7": len(candidate_keys) >= 7,
        })
    payload = {
        "artifact": "external_java_v3_prompt_capacity_diagnostic",
        "criterion": "Unchanged frozen prompt eligibility criteria; computed before any response generation or annotation.",
        "projects": rows,
        "insufficient": [row for row in rows if not row["capacity_at_least_7"]],
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"projects": len(rows), "insufficient": len(payload["insufficient"]), "details": payload["insufficient"]}, indent=2))


if __name__ == "__main__":
    main()
