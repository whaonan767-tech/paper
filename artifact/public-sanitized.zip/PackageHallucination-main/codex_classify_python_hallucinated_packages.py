import argparse
import ast
import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path


DATASET_ORDER = ["LLM_LY", "LLM_AT", "SO_LY", "SO_AT"]
HALLUCINATED_COLUMNS = ["hallucinated_1", "hallucinated_2", "pip_hallucinated"]
VALID_COLUMNS = {"hallucinated_1": "valid_1", "hallucinated_2": "valid_2", "pip_hallucinated": "pip_valid"}

LANGUAGE_WORDS = {"python", "pip", "bash", "package", "module", "run", "with", "the"}
PLACEHOLDER_WORDS = {"xyz", "abc", "foo", "bar", "baz", "mycustomconstraint"}
WEB_OR_CROSS_ECOSYSTEM_TOKENS = {"prototype", "foreach", "router"}
WEB_OR_CROSS_ECOSYSTEM_NAMES = {
    "imageclassification",
    "image-classification",
    "next-image",
    "next-router",
}
COMMON_MODULE_ROOTS = {
    "boto3",
    "botocore",
    "django",
    "flask",
    "google",
    "google-auth",
    "keras",
    "matplotlib",
    "numpy",
    "pandas",
    "requests",
    "scipy",
    "sklearn",
    "sqlalchemy",
    "sphinx",
    "torch",
    "torchvision",
}
ALIAS_OR_ECOSYSTEM_HINTS = {
    "opencv": "opencv-python",
    "dns-python": "dnspython",
    "python-jupyter-core": "jupyter-core",
    "real-esrgan": "realesrgan",
    "botoc": "boto3/botocore",
}
NON_PYPI_ECOSYSTEM_ROOTS = {
    "clang",
    "cudnn",
    "cufft",
    "cuda",
    "cusparse",
    "cusparsesparse",
    "nccl",
    "nginx",
    "rust",
}


def pep503(name):
    return re.sub(r"[-_.]+", "-", (name or "").strip().lower())


def parse_list(value):
    if value is None:
        return []
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return []
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    except Exception:
        pass
    return [text]


def artifact_flags(name):
    flags = []
    raw_name = name or ""
    clean = raw_name.strip()
    normalized = pep503(clean)
    if re.fullmatch(r"\d+", clean):
        flags.append("numeric")
    if "`" in clean or "\n" in clean:
        flags.append("formatting")
    if len(clean) <= 2:
        flags.append("too_short")
    if normalized in LANGUAGE_WORDS:
        flags.append("language_word")
    if any(part in clean for part in ["venven", "</", "<p", "quot", "&"]):
        flags.append("html_or_generation_noise")
    normalized_parts = [part for part in re.split(r"[-_.\/]+", clean.lower()) if part]
    if (
        normalized in WEB_OR_CROSS_ECOSYSTEM_NAMES
        or any(part in WEB_OR_CROSS_ECOSYSTEM_TOKENS for part in normalized_parts)
    ):
        flags.append("cross_language_or_web_token")
    if any(ch in raw_name for ch in ["'", '"', " "]):
        flags.append("quote_or_space")
    if normalized.startswith(("example-", "my", "your-")) or normalized in PLACEHOLDER_WORDS:
        flags.append("placeholder")
    if normalized.count("-") >= 5:
        flags.append("many_hyphens")
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", normalized):
        flags.append("non_package_token")
    return flags


def is_artifact_like(name):
    disqualifying = {
        "numeric",
        "formatting",
        "too_short",
        "language_word",
        "html_or_generation_noise",
        "cross_language_or_web_token",
        "quote_or_space",
        "placeholder",
        "non_package_token",
    }
    return bool(disqualifying.intersection(artifact_flags(name)))


def load_pypi_names(data_dir):
    names = set()
    path = Path(data_dir) / "pypi_package_names.csv"
    if not path.exists():
        return names
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            value = line.strip().split(",", 1)[0]
            if value:
                names.add(pep503(value))
    return names


def stdlib_names():
    names = set(getattr(sys, "stdlib_module_names", set()))
    names.update(sys.builtin_module_names)
    names.update(
        {
            "collections",
            "datetime",
            "email",
            "functools",
            "html",
            "http",
            "importlib",
            "itertools",
            "json",
            "logging",
            "math",
            "os",
            "pathlib",
            "random",
            "re",
            "sqlite3",
            "statistics",
            "sys",
            "time",
            "typing",
            "urllib",
            "xml",
        }
    )
    return {name.lower() for name in names}


def is_stdlib_token(normalized, stdlib):
    underscore = normalized.replace("-", "_")
    if underscore in stdlib or normalized in stdlib:
        return True
    parts = normalized.split("-")
    if parts and parts[0] in stdlib and len(parts) > 1:
        return True
    if len(parts) >= 2 and "-".join(parts[:2]).replace("-", "_") in stdlib:
        return True
    return False


def row_valid_roots(row, column):
    valid_column = VALID_COLUMNS.get(column, "")
    roots = set(COMMON_MODULE_ROOTS)
    for value in parse_list(row.get(valid_column, "")):
        normalized = pep503(value)
        if normalized:
            roots.add(normalized)
            parts = normalized.split("-")
            if parts:
                roots.add(parts[0])
    return roots


def is_module_path_token(normalized, roots):
    if "-" not in normalized:
        return False, ""
    parts = normalized.split("-")
    candidates = []
    for end in range(1, min(len(parts), 4) + 1):
        candidates.append("-".join(parts[:end]))
    candidates.sort(key=len, reverse=True)
    for candidate in candidates:
        if candidate in roots and normalized != candidate:
            return True, candidate
    return False, ""


def classify_name(name, row, column, pypi_names, stdlib):
    normalized = pep503(name)
    flags = artifact_flags(name)
    if is_artifact_like(name):
        return {
            "label": "artifact_or_placeholder_noise",
            "normalized": normalized,
            "reason": ";".join(flags),
            "suggested_real_package": "",
        }
    if normalized in pypi_names:
        return {
            "label": "pypi_present_after_normalization",
            "normalized": normalized,
            "reason": "found in local PyPI package index after PEP503 normalization",
            "suggested_real_package": normalized,
        }
    if is_stdlib_token(normalized, stdlib):
        return {
            "label": "stdlib_or_builtin_module_token",
            "normalized": normalized,
            "reason": "matches or prefixes a Python standard-library/builtin module",
            "suggested_real_package": "",
        }
    root = normalized.split("-", 1)[0]
    if root in NON_PYPI_ECOSYSTEM_ROOTS:
        return {
            "label": "alias_or_ecosystem_package_token",
            "normalized": normalized,
            "reason": f"`{root}` is commonly a non-PyPI/toolchain/native-library ecosystem token",
            "suggested_real_package": "",
        }
    roots = row_valid_roots(row, column)
    is_module_path, root = is_module_path_token(normalized, roots)
    if is_module_path:
        return {
            "label": "package_module_path_token",
            "normalized": normalized,
            "reason": f"looks like submodule/path under `{root}` rather than a distribution name",
            "suggested_real_package": root,
        }
    if normalized in ALIAS_OR_ECOSYSTEM_HINTS:
        return {
            "label": "alias_or_ecosystem_package_token",
            "normalized": normalized,
            "reason": "common alias or ecosystem package name",
            "suggested_real_package": ALIAS_OR_ECOSYSTEM_HINTS[normalized],
        }
    return {
        "label": "registry_missing_candidate",
        "normalized": normalized,
        "reason": "not artifact-like, not stdlib-like, not module-path-like, and absent from local PyPI index",
        "suggested_real_package": "",
    }


def rate(valid, hallucinated):
    denom = valid + hallucinated
    return hallucinated / denom if denom else 0.0


def dataset_for_row(row_index, limit):
    if not limit:
        return ""
    dataset_index = row_index // limit
    if 0 <= dataset_index < len(DATASET_ORDER):
        return DATASET_ORDER[dataset_index]
    return ""


def read_rows(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    if not rows:
        return
    fieldnames = sorted({key for row in rows for key in row})
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def summarize_mentions(mentions, source_rows, limit):
    label_counts = Counter(row["label"] for row in mentions)
    unique_by_label = defaultdict(set)
    for row in mentions:
        unique_by_label[row["label"]].add(row["normalized"])

    query_summary = {}
    for column in ["hallucinated_1", "hallucinated_2"]:
        valid_column = VALID_COLUMNS[column]
        valid_total = sum(len(parse_list(row.get(valid_column, ""))) for row in source_rows)
        raw_items = [row for row in mentions if row["column"] == column]
        registry_items = [row for row in raw_items if row["label"] == "registry_missing_candidate"]
        query_summary[column] = {
            "valid": valid_total,
            "raw_hallucinated": len(raw_items),
            "raw_rate": rate(valid_total, len(raw_items)),
            "registry_missing_candidates": len(registry_items),
            "label_audited_registry_missing_rate": rate(valid_total, len(registry_items)),
            "label_counts": dict(Counter(row["label"] for row in raw_items).most_common()),
        }

    dataset_query_summary = {}
    for dataset_index, dataset in enumerate(DATASET_ORDER):
        start = dataset_index * limit
        end = start + limit
        subset = source_rows[start:end]
        dataset_mentions = [row for row in mentions if row["dataset"] == dataset]
        dataset_query_summary[dataset] = {}
        for column in ["hallucinated_1", "hallucinated_2"]:
            valid_column = VALID_COLUMNS[column]
            valid_total = sum(len(parse_list(row.get(valid_column, ""))) for row in subset)
            raw_items = [row for row in dataset_mentions if row["column"] == column]
            registry_items = [row for row in raw_items if row["label"] == "registry_missing_candidate"]
            dataset_query_summary[dataset][column] = {
                "valid": valid_total,
                "raw_hallucinated": len(raw_items),
                "registry_missing_candidates": len(registry_items),
                "raw_rate": rate(valid_total, len(raw_items)),
                "label_audited_registry_missing_rate": rate(valid_total, len(registry_items)),
            }

    return {
        "total_mentions": len(mentions),
        "unique_names": len({row["normalized"] for row in mentions}),
        "label_counts": dict(label_counts.most_common()),
        "unique_label_counts": {label: len(names) for label, names in sorted(unique_by_label.items())},
        "query_summary": query_summary,
        "dataset_query_summary": dataset_query_summary,
    }


def write_markdown(path, output):
    summary = output["summary"]
    lines = [
        "# Python Hallucinated Package Label Audit",
        "",
        f"- Run directory: `{output['run_dir']}`",
        f"- Rows: `{output['rows']}`",
        f"- Total hallucinated mentions: `{summary['total_mentions']}`",
        f"- Unique hallucinated names: `{summary['unique_names']}`",
        "",
        "## Mention Labels",
        "",
        "| Label | Mentions | Unique names |",
        "|---|---:|---:|",
    ]
    unique_counts = summary["unique_label_counts"]
    for label, count in summary["label_counts"].items():
        lines.append(f"| `{label}` | {count} | {unique_counts.get(label, 0)} |")

    lines.extend(
        [
            "",
            "## Label-Audited Registry-Missing Rates",
            "",
            "| Query | Raw hallucinated | Raw rate | Registry-missing candidates | Registry-missing rate | Label counts |",
            "|---|---:|---:|---:|---:|---|",
        ]
    )
    for column, row in summary["query_summary"].items():
        query = "Q1 generated-code packages" if column == "hallucinated_1" else "Q2 prompt packages"
        lines.append(
            f"| {query} | {row['raw_hallucinated']}/{row['valid'] + row['raw_hallucinated']} | "
            f"{row['raw_rate']:.3f} | {row['registry_missing_candidates']}/{row['valid'] + row['registry_missing_candidates']} | "
            f"{row['label_audited_registry_missing_rate']:.3f} | `{row['label_counts']}` |"
        )

    lines.extend(
        [
            "",
            "## Top Names by Label",
            "",
        ]
    )
    for label, items in output["top_by_label"].items():
        lines.extend([f"### {label}", "", "| Name | Mentions | Suggested real package | Reason |", "|---|---:|---|---|"])
        for item in items[:20]:
            lines.append(
                f"| `{item['name']}` | {item['count']} | `{item.get('suggested_real_package', '')}` | {item.get('reason', '')} |"
            )
        lines.append("")

    Path(path).write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def classify_run(run_dir, data_dir, output_prefix):
    run_dir = Path(run_dir)
    metadata = json.loads((run_dir / "metadata.json").read_text(encoding="utf-8"))
    limit = int(metadata.get("limit_per_dataset", 0) or 0)
    source_rows = read_rows(run_dir / "PACKAGE_NAMES.csv")
    pypi_names = load_pypi_names(data_dir)
    stdlib = stdlib_names()

    mentions = []
    for row_index, row in enumerate(source_rows):
        dataset = dataset_for_row(row_index, limit)
        for column in HALLUCINATED_COLUMNS:
            for name in parse_list(row.get(column, "")):
                info = classify_name(name, row, column, pypi_names, stdlib)
                mentions.append(
                    {
                        "row_index": row_index,
                        "dataset": dataset,
                        "column": column,
                        "name": name,
                        **info,
                    }
                )

    summary = summarize_mentions(mentions, source_rows, limit)

    top_by_label = {}
    by_label_name = defaultdict(Counter)
    metadata_by_label_name = {}
    for row in mentions:
        key = (row["label"], row["normalized"])
        by_label_name[row["label"]][row["normalized"]] += 1
        metadata_by_label_name[key] = {
            "name": row["name"],
            "reason": row["reason"],
            "suggested_real_package": row["suggested_real_package"],
        }
    for label, counter in by_label_name.items():
        top_by_label[label] = []
        for normalized, count in counter.most_common(30):
            item = dict(metadata_by_label_name[(label, normalized)])
            item["normalized"] = normalized
            item["count"] = count
            top_by_label[label].append(item)

    output = {
        "run_dir": str(run_dir),
        "rows": len(source_rows),
        "model_label": metadata.get("model_label", ""),
        "limit_per_dataset": limit,
        "summary": summary,
        "top_by_label": top_by_label,
        "mentions": mentions,
    }

    out_json = run_dir / f"{output_prefix}.json"
    out_md = run_dir / f"{output_prefix}.md"
    out_csv = run_dir / f"{output_prefix}.csv"
    out_json.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(out_csv, mentions)
    write_markdown(out_md, output)
    return output, out_json, out_md, out_csv


def combined_summary(outputs, output_dir):
    rows = []
    for output in outputs:
        summary = output["summary"]
        q1 = summary["query_summary"]["hallucinated_1"]
        q2 = summary["query_summary"]["hallucinated_2"]
        rows.append(
            {
                "run_dir": output["run_dir"],
                "model_label": output["model_label"],
                "mentions": summary["total_mentions"],
                "unique_names": summary["unique_names"],
                "registry_missing_mentions": summary["label_counts"].get("registry_missing_candidate", 0),
                "artifact_noise": summary["label_counts"].get("artifact_or_placeholder_noise", 0),
                "stdlib_tokens": summary["label_counts"].get("stdlib_or_builtin_module_token", 0),
                "module_path_tokens": summary["label_counts"].get("package_module_path_token", 0),
                "alias_or_ecosystem_tokens": summary["label_counts"].get("alias_or_ecosystem_package_token", 0),
                "q1_raw_rate": q1["raw_rate"],
                "q1_label_audited_registry_missing_rate": q1["label_audited_registry_missing_rate"],
                "q2_raw_rate": q2["raw_rate"],
                "q2_label_audited_registry_missing_rate": q2["label_audited_registry_missing_rate"],
            }
        )

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "python_false_positive_label_summary.json"
    csv_path = output_dir / "python_false_positive_label_summary.csv"
    md_path = output_dir / "python_false_positive_label_summary.md"
    json_path.write_text(json.dumps({"runs": rows}, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(csv_path, rows)

    lines = [
        "# Python Hallucination Label Summary",
        "",
        "| Run | Mentions | Registry-missing | Artifact/noise | Stdlib tokens | Module-path tokens | Alias/ecosystem | Q1 raw -> label-audited | Q2 raw -> label-audited |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        run = Path(row["run_dir"]).name
        lines.append(
            f"| `{run}` | {row['mentions']} | {row['registry_missing_mentions']} | {row['artifact_noise']} | "
            f"{row['stdlib_tokens']} | {row['module_path_tokens']} | {row['alias_or_ecosystem_tokens']} | "
            f"{row['q1_raw_rate']:.3f} -> {row['q1_label_audited_registry_missing_rate']:.3f} | "
            f"{row['q2_raw_rate']:.3f} -> {row['q2_label_audited_registry_missing_rate']:.3f} |"
        )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return json_path, md_path, csv_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", action="append", required=True)
    parser.add_argument("--data-dir", default="Data/Python")
    parser.add_argument("--output-prefix", default="python_hallucination_labels")
    parser.add_argument("--combined-output-dir", default="Tests/PythonFalsePositiveLabels")
    args = parser.parse_args()

    outputs = []
    for run_dir in args.run_dir:
        output, out_json, out_md, out_csv = classify_run(run_dir, args.data_dir, args.output_prefix)
        outputs.append(output)
        print(f"Wrote {out_json}, {out_md}, and {out_csv}")
    if len(outputs) > 1:
        json_path, md_path, csv_path = combined_summary(outputs, args.combined_output_dir)
        print(f"Wrote {json_path}, {md_path}, and {csv_path}")


if __name__ == "__main__":
    main()
