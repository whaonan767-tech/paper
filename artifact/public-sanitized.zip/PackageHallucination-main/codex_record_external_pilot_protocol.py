#!/usr/bin/env python3
"""Record the external-pilot protocol snapshot before model generation."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--acquisition-dir", type=Path, required=True)
    parser.add_argument("--original-freeze", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def display(path: Path) -> str:
    try:
        return path.resolve().relative_to(WORKSPACE).as_posix()
    except ValueError:
        return path.name


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise SystemExit(f"Output directory exists: {output_dir}")
    output_dir.mkdir(parents=True)
    acquisition_metadata = args.acquisition_dir.resolve() / "metadata" / "external_project_acquisition.json"
    files = [
        args.original_freeze.resolve(),
        acquisition_metadata,
        ROOT / "codex_acquire_external_java_pilot.py",
        ROOT / "codex_build_external_java_pilot_prompts.py",
        ROOT / "codex_java_dependency_generation_runner.py",
        ROOT / "codex_java_dependency_extractor.py",
        ROOT / "codex_map_java_imports_to_maven.py",
        ROOT / "codex_classify_java_imports.py",
    ]
    rows = []
    for path in files:
        if not path.exists():
            raise SystemExit(f"Missing protocol input: {path}")
        rows.append({"path": display(path), "sha256": sha256(path), "size_bytes": path.stat().st_size})
    acquisition = json.loads(acquisition_metadata.read_text(encoding="utf-8"))
    payload = {
        "artifact": "prospective_external_java_pilot_protocol_v2_freeze",
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "frozen_before_model_generation": True,
        "projects": len(acquisition["selected"]),
        "protocol_revision": {
            "v1_result": "Only 1/8 acquired projects had eligible files because V1 scanned only the root src/main/java tree.",
            "v2_change": "Recursively discover module src/main/java trees; all length, import-count, hashing, seed, and per-project limits are unchanged.",
            "performance_results_seen_before_revision": False,
            "model_outputs_generated_before_revision": False,
        },
        "files": rows,
        "claim_boundary": "Build-grounded prospective pilot on new projects and new outputs; not a substitute for a large independently human-annotated external test corpus.",
    }
    (output_dir / "external_pilot_protocol_v2_freeze.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = [
        "# External Pilot Protocol V2 Freeze",
        "",
        f"- Frozen before model generation: `{payload['frozen_at_utc']}`.",
        f"- Acquired projects: `{payload['projects']}`.",
        "- V1 issue: root-module-only discovery yielded eligible files in 1/8 projects.",
        "- V2 revision: recursively discover module `src/main/java` trees; selection hash, seed, file limits, and two-files-per-project target are unchanged.",
        "- No external model outputs or performance results existed when V2 was frozen.",
        "",
        "| File | SHA-256 |",
        "|---|---|",
    ]
    lines.extend(f"| `{row['path']}` | `{row['sha256']}` |" for row in rows)
    (output_dir / "external_pilot_protocol_v2_freeze.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "files": len(rows), "projects": len(acquisition["selected"])}, indent=2))


if __name__ == "__main__":
    main()
