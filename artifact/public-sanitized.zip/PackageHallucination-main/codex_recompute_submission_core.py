#!/usr/bin/env python3
"""One-command recomputation and assertion of submission-critical paper results."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    return parser.parse_args()


def run(script: str, *arguments: str) -> None:
    command = [sys.executable, str(ROOT / script), *arguments]
    subprocess.run(command, cwd=ROOT, check=True)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    args = parse_args()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    output_dir = (args.output_dir or ROOT / "Tests" / f"SubmissionCoreRecompute_{stamp}").resolve()
    if output_dir.exists():
        raise SystemExit(f"Output path already exists: {output_dir}")
    output_dir.mkdir(parents=True)
    reps = str(args.bootstrap_repetitions)

    python_out = output_dir / "python_prompt_level"
    human_out = output_dir / "java_human_truth_clustered"
    build_out = output_dir / "java_masked_build"
    v2_test_out = output_dir / "java_v2_test_eligibility"
    v3_out = output_dir / "java_structured_v3"
    grounding_out = output_dir / "java_grounding_ablation"
    raw_mention_out = output_dir / "java_raw_response_mention_audit"

    run(
        "codex_analyze_python_prompt_level.py",
        "--output-dir", str(python_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260804",
    )
    run(
        "codex_analyze_java_human_truth_clustered.py",
        "--output-dir", str(human_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260804",
    )
    run(
        "codex_java_masked_build_analysis.py",
        "--output-dir", str(build_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260803",
    )
    run("codex_analyze_java_v2_test_eligibility.py", "--output-dir", str(v2_test_out))
    run(
        "codex_analyze_java_masked_v3_results.py",
        "--output-dir", str(v3_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260804",
    )
    run(
        "codex_analyze_java_grounding_ablation.py",
        "--output-dir", str(grounding_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260812",
    )
    run(
        "codex_prepare_raw_response_mention_audit.py",
        "--score", str(
            ROOT
            / "Tests"
            / "Java_APIHulBench_RawMentionHumanAudit_Final_Run20260816"
            / "raw_response_mention_audit_merged_final.csv"
        ),
        "--output-dir", str(raw_mention_out),
        "--bootstrap-repetitions", reps,
        "--seed", "20260814",
    )

    artifact_json_tool = ROOT / "artifact_json_tools.py"
    if artifact_json_tool.exists():
        subprocess.run(
            [
                sys.executable,
                str(artifact_json_tool),
                "sanitize",
                "--root", str(output_dir),
                "--workspace", str(ROOT.parent),
                "--repo", str(ROOT),
            ],
            cwd=ROOT,
            check=True,
        )

    python_result = load_json(python_out / "python_prompt_level_comparison.json")
    human_result = load_json(human_out / "java_human_truth_clustered_metrics.json")
    build_result = load_json(build_out / "masked_build_analysis.json")
    v2_test_result = load_json(v2_test_out / "v2_real_test_eligibility.json")
    v3_result = load_json(v3_out / "masked_v3_combined_analysis.json")
    grounding_result = load_json(grounding_out / "java_grounding_ablation.json")
    raw_mention_result = load_json(raw_mention_out / "raw_response_mention_audit_scored.json")

    checks = []

    def check(name: str, condition: bool, observed: object) -> None:
        require(condition, f"{name} mismatch: {observed}")
        checks.append({"check": name, "status": "pass", "observed": observed})

    p3, p7 = python_result["models"]["qwen_3b"], python_result["models"]["qwen_7b"]
    discordance = python_result["paired_discordance"]
    check("python_3b_positive_prompts", p3["prompts_with_registry_missing"] == 43, p3["prompts_with_registry_missing"])
    check("python_7b_positive_prompts", p7["prompts_with_registry_missing"] == 18, p7["prompts_with_registry_missing"])
    check("python_pair_3b_only", discordance["3b_only"] == 38, discordance["3b_only"])
    check("python_pair_7b_only", discordance["7b_only"] == 13, discordance["7b_only"])
    check("python_pair_both", discordance["both"] == 5, discordance["both"])
    check("python_pair_neither", discordance["neither"] == 344, discordance["neither"])
    check("python_3b_candidate_mentions", p3["candidate_mentions"] == 1110, p3["candidate_mentions"])
    check("python_7b_candidate_mentions", p7["candidate_mentions"] == 864, p7["candidate_mentions"])

    check("java_extracted_rows", human_result["all_extracted_rows"] == 598, human_result["all_extracted_rows"])
    check("java_valid_invalid_rows", human_result["valid_invalid_rows"] == 580, human_result["valid_invalid_rows"])
    check("java_projects", human_result["projects"] == 73, human_result["projects"])
    check("java_confusion", human_result["confusion"] == {"tp": 66, "fp": 2, "fn": 35, "tn": 477}, human_result["confusion"])
    for metric, expected in {"precision": 0.971, "recall": 0.653, "f1": 0.781}.items():
        observed = human_result["metrics"][metric]["estimate"]
        check(f"java_{metric}", round(observed, 3) == expected, observed)
    check("java_candidate_analysis_is_post_extraction", human_result["extraction_recall_evaluated"] is False, human_result["extraction_recall_evaluated"])

    build = build_result["summary"]
    check("masked_v1_passes", build["v1_masked_gold_passes"] == 0, build["v1_masked_gold_passes"])
    check("masked_v2_passes", build["v2_generated_evidence_passes"] == 14, build["v2_generated_evidence_passes"])
    sign_flip = build["v1_to_v2_project_sign_flip"]
    check("masked_sign_flip_p", sign_flip["exact_two_sided_p"] == 0.015625, sign_flip["exact_two_sided_p"])
    check("masked_sign_flip_assignments", sign_flip["assignments"] == 128, sign_flip["assignments"])

    eligibility = v2_test_result["summary"]
    check("v2_nonzero_test_overlap", eligibility["overlap_records"] == 0, eligibility["overlap_records"])
    check("v2_test_rate_not_estimable", eligibility["v2_real_test_rate_estimable"] is False, eligibility["v2_real_test_rate_estimable"])

    v3 = v3_result["summary"]
    check("v3_records", v3["records"] == 83, v3["records"])
    check("v3_repeated_context", v3["repeated_context_records"] == 8, v3["repeated_context_records"])
    check("v3_overall_matrix", [v3["records"], v3["b_pass"], v3["c_pass"], v3["d_pass"]] == [83, 13, 12, 3], [v3["records"], v3["b_pass"], v3["c_pass"], v3["d_pass"]])
    clean = v3["nonrepeated_context"]
    check("v3_clean_matrix", [clean["records"], clean["b_pass"], clean["c_pass"], clean["d_pass"]] == [75, 12, 9, 3], [clean["records"], clean["b_pass"], clean["c_pass"], clean["d_pass"]])
    check("v3_clean_end_to_end_not_repeated", clean["d_repeated_context_pass"] == 0, clean["d_repeated_context_pass"])

    partition = human_result["annotation_partition"]
    expected_partition = {
        "development_rows": 150,
        "development_projects": 49,
        "evaluation_rows": 448,
        "evaluation_projects": 71,
        "overlap_projects": 47,
        "project_disjoint": False,
        "interpretation": "annotation-held-out row-level evaluation",
    }
    check("truth_partition_and_project_overlap", partition == expected_partition, partition)

    grounding_scope = grounding_result["scope"]
    observed_scope = {
        "valid_invalid_rows": grounding_scope["valid_invalid_rows"],
        "projects": grounding_scope["projects"],
    }
    check("grounding_ablation_scope", observed_scope == {"valid_invalid_rows": 580, "projects": 73}, observed_scope)
    variants = grounding_result["variants"]
    observed_confusions = {name: item["confusion"] for name, item in variants.items()}
    expected_confusions = {
        "registry_only": {"tp": 89, "fp": 370, "fn": 12, "tn": 109},
        "registry_platform": {"tp": 74, "fp": 262, "fn": 27, "tn": 217},
        "registry_project_source": {"tp": 81, "fp": 113, "fn": 20, "tn": 366},
        "registry_maven_class_search": {"tp": 88, "fp": 367, "fn": 13, "tn": 112},
        "full_detector": {"tp": 66, "fp": 2, "fn": 35, "tn": 477},
    }
    check("grounding_ablation_confusions", observed_confusions == expected_confusions, observed_confusions)
    observed_metrics = {
        name: {
            metric: round(item["metrics"][metric]["estimate"], 3)
            for metric in ("precision", "recall", "f1")
        }
        for name, item in variants.items()
    }
    expected_metrics = {
        "registry_only": {"precision": 0.194, "recall": 0.881, "f1": 0.318},
        "registry_platform": {"precision": 0.220, "recall": 0.733, "f1": 0.339},
        "registry_project_source": {"precision": 0.418, "recall": 0.802, "f1": 0.549},
        "registry_maven_class_search": {"precision": 0.193, "recall": 0.871, "f1": 0.317},
        "full_detector": {"precision": 0.971, "recall": 0.653, "f1": 0.781},
    }
    check("grounding_ablation_metrics", observed_metrics == expected_metrics, observed_metrics)
    effects = grounding_result["source_effects_relative_to_registry_only"]
    expected_effects = {
        "registry_platform": {"alerts_avoided": 123, "false_positives_avoided": 108, "true_positives_lost": 15},
        "registry_project_source": {"alerts_avoided": 265, "false_positives_avoided": 257, "true_positives_lost": 8},
        "registry_maven_class_search": {"alerts_avoided": 4, "false_positives_avoided": 3, "true_positives_lost": 1},
    }
    check("grounding_ablation_source_effects", effects == expected_effects, effects)

    raw_protocol = raw_mention_result["annotation_protocol"]
    observed_raw_scope = {
        "rows": raw_mention_result["rows"],
        "human_annotation_completed": raw_mention_result["human_annotation_completed"],
        "annotators": raw_protocol["annotators"],
        "automated_preannotation_used": raw_protocol["automated_preannotation_used"],
        "from_scratch_blank_enumeration": raw_protocol["from_scratch_blank_enumeration"],
        "exact_mention_sequence_agreement_rows": raw_protocol["exact_mention_sequence_agreement_rows"],
        "disagreement_rows_adjudicated": raw_protocol["disagreement_rows_adjudicated"],
    }
    expected_raw_scope = {
        "rows": 416,
        "human_annotation_completed": True,
        "annotators": 2,
        "automated_preannotation_used": False,
        "from_scratch_blank_enumeration": True,
        "exact_mention_sequence_agreement_rows": 370,
        "disagreement_rows_adjudicated": 146,
    }
    check("raw_mention_audit_scope", observed_raw_scope == expected_raw_scope, observed_raw_scope)
    raw = raw_mention_result["adjudicated"]
    raw_extractor_confusion = {"tp": raw["tp"], "fp": raw["fp"], "fn": raw["fn"]}
    check("raw_mention_extractor_confusion", raw_extractor_confusion == {"tp": 589, "fp": 9, "fn": 437}, raw_extractor_confusion)
    raw_extractor_metrics = {
        "precision": round(raw["extractor_precision"], 3),
        "recall": round(raw["extractor_recall"], 3),
        "f1": round(raw["f1"], 3),
    }
    check("raw_mention_extractor_metrics", raw_extractor_metrics == {"precision": 0.985, "recall": 0.574, "f1": 0.725}, raw_extractor_metrics)
    raw_end_to_end_confusion = {"tp": raw["end_to_end_tp"], "fp": raw["end_to_end_fp"], "fn": raw["end_to_end_fn"]}
    check("raw_mention_end_to_end_confusion", raw_end_to_end_confusion == {"tp": 66, "fp": 2, "fn": 249}, raw_end_to_end_confusion)
    raw_end_to_end_metrics = {
        "precision": round(raw["end_to_end_invalid_or_malformed_precision"], 3),
        "recall": round(raw["end_to_end_invalid_or_malformed_recall"], 3),
    }
    check("raw_mention_end_to_end_metrics", raw_end_to_end_metrics == {"precision": 0.971, "recall": 0.210}, raw_end_to_end_metrics)
    raw_missed_surfaces = {
        key.removeprefix("surface:"): value
        for key, value in raw["unextracted_category_counts"].items()
        if key.startswith("surface:")
    }
    expected_missed_surfaces = {"broken_fence": 156, "code": 99, "malformed": 173, "other": 1, "prose": 8}
    check("raw_mention_missed_surfaces", raw_missed_surfaces == expected_missed_surfaces, raw_missed_surfaces)
    raw_bootstrap = raw["project_clustered_bootstrap"]
    raw_clustered_scope = {
        "projects": raw_bootstrap["projects"],
        "repetitions": raw_bootstrap["repetitions"],
        "seed": raw_bootstrap["seed"],
    }
    check("raw_mention_clustered_scope", raw_clustered_scope == {"projects": 97, "repetitions": args.bootstrap_repetitions, "seed": 20260814}, raw_clustered_scope)
    raw_intervals = {
        "extractor": {
            metric: [round(item["ci_low"], 3), round(item["ci_high"], 3)]
            for metric, item in raw_bootstrap["extractor"].items()
        },
        "end_to_end": {
            metric: [round(item["ci_low"], 3), round(item["ci_high"], 3)]
            for metric, item in raw_bootstrap["end_to_end_invalid_or_malformed"].items()
        },
    }
    expected_raw_intervals = {
        "extractor": {"precision": [0.962, 0.998], "recall": [0.530, 0.626], "f1": [0.688, 0.766]},
        "end_to_end": {"precision": [0.920, 1.000], "recall": [0.151, 0.291], "f1": [0.260, 0.449]},
    }
    check("raw_mention_clustered_intervals", raw_intervals == expected_raw_intervals, raw_intervals)

    report = {
        "status": "pass",
        "bootstrap_repetitions": args.bootstrap_repetitions,
        "checks_passed": len(checks),
        "output_dir": str(output_dir.relative_to(ROOT)),
        "checks": checks,
    }
    (output_dir / "submission_core_recompute.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    lines = [
        "# Submission Core Recomputation",
        "",
        "- Status: `pass`",
        f"- Assertions passed: `{len(checks)}`",
        f"- Bootstrap repetitions: `{args.bootstrap_repetitions}`",
        "- Scope: deterministic recomputation from preserved outputs; model generation and Maven build execution are not repeated.",
        "",
        "| Check | Observed |",
        "|---|---:|",
    ]
    lines.extend(f"| {item['check']} | `{item['observed']}` |" for item in checks)
    (output_dir / "submission_core_recompute.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"PASS {len(checks)} checks -> {output_dir}")


if __name__ == "__main__":
    main()
