#!/usr/bin/env python3
"""Build the frozen repository, owner, and API-family exclusion boundary for V3."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path


PACKAGE_RE = re.compile(r"(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s*;")
GITHUB_RE = re.compile(r"https?://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)", re.I)
BRANCH_SUFFIX_RE = re.compile(r"(?i)(?:[-_](?:master|main|dev|release))$")
VERSION_SUFFIX_RE = re.compile(r"(?i)(?:[-_](?:v{0,2}[-_]?)?\d[\w.+-]*)$")
GENERIC_FAMILIES = {
    "java", "javax", "jakarta", "org.junit", "org.slf4j", "lombok",
    "org.springframework", "org.springframework.boot", "com.fasterxml.jackson",
    "com.google", "com.example", "org.example", "org.acme", "org.apache.maven",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def normalized_name(value: str) -> str:
    return "".join(character.lower() for character in value if character.isalnum())


def repository_key(value: str) -> str:
    stem = value.strip().rstrip("/")
    previous = None
    while stem != previous:
        previous = stem
        stem = BRANCH_SUFFIX_RE.sub("", stem)
        stem = VERSION_SUFFIX_RE.sub("", stem)
    return normalized_name(stem)


def family(value: str) -> str:
    parts = [part for part in value.strip().split(".") if part]
    if not parts:
        return ""
    width = 3 if parts[0] in {"com", "org", "net", "io", "dev", "ai"} else 2
    result = ".".join(parts[:width])
    return "" if result in GENERIC_FAMILIES or len(parts) < 2 else result.lower()


def xml_group_ids(project: Path) -> collections.Counter[str]:
    counts: collections.Counter[str] = collections.Counter()
    for pom in list(project.rglob("pom.xml"))[:200]:
        try:
            root = ET.parse(pom).getroot()
        except (ET.ParseError, OSError):
            continue
        namespace = root.tag.partition("}")[0] + "}" if "}" in root.tag else ""
        candidates = [root.findtext(f"{namespace}groupId"), root.findtext(f"{namespace}parent/{namespace}groupId")]
        for value in candidates:
            key = family(value or "")
            if key:
                counts[key] += 1
    return counts


def package_families(project: Path) -> collections.Counter[str]:
    counts: collections.Counter[str] = collections.Counter()
    seen = 0
    for path in project.rglob("*.java"):
        if seen >= 600:
            break
        if not any(part.lower() == "main" for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")[:8000]
        except OSError:
            continue
        seen += 1
        match = PACKAGE_RE.search(text)
        if match:
            key = family(match.group(1))
            if key:
                counts[key] += 1
    return counts


def inferred_github(project: Path) -> list[str]:
    candidates: collections.Counter[str] = collections.Counter()
    readmes = sorted((path for path in project.rglob("README*") if path.is_file()), key=lambda path: len(path.parts))[:8]
    target = repository_key(project.name)
    for path in readmes:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")[:250_000]
        except OSError:
            continue
        for owner, repo in GITHUB_RE.findall(text):
            repo = repo.removesuffix(".git")
            if repository_key(repo) == target:
                candidates[f"{owner}/{repo}"] += 1
    if not candidates:
        return []
    best_score = max(candidates.values())
    return sorted(name for name, score in candidates.items() if score == best_score)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repositories-root", type=Path, required=True)
    parser.add_argument("--pilot-acquisition", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    parser.add_argument("--owner-resolution", type=Path)
    args = parser.parse_args()

    rows = []
    repo_names: set[str] = set()
    repo_keys: set[str] = set()
    full_names: set[str] = set()
    owners: set[str] = set()
    api_families: set[str] = set()
    projects = sorted((path for path in args.repositories_root.iterdir() if path.is_dir()), key=lambda path: path.name.lower())
    for project in projects:
        names = inferred_github(project)
        groups = xml_group_ids(project)
        packages = package_families(project)
        selected_families = [name for name, _ in (groups + packages).most_common(4)]
        repo_names.add(normalized_name(project.name))
        repo_keys.add(repository_key(project.name))
        api_families.update(selected_families)
        for name in names:
            full_names.add(name.lower())
            owner, repo = name.split("/", 1)
            owners.add(owner.lower())
            repo_names.add(normalized_name(repo))
            repo_keys.add(repository_key(repo))
        rows.append({"project_folder": project.name, "inferred_full_names": names, "api_families": selected_families})

    pilot = json.loads(args.pilot_acquisition.read_text(encoding="utf-8"))
    pilot_rows = []
    for item in pilot.get("selected", []):
        full = str(item["full_name"])
        owner, repo = full.split("/", 1)
        full_names.add(full.lower())
        owners.add(owner.lower())
        repo_names.add(normalized_name(repo))
        repo_keys.add(repository_key(repo))
        pilot_rows.append(full)

    resolved_by_folder = {}
    if args.owner_resolution:
        resolution = json.loads(args.owner_resolution.read_text(encoding="utf-8"))
        resolved_by_folder = {row["project_folder"]: row.get("candidate_full_names", []) for row in resolution.get("rows", [])}
        for row in rows:
            resolved = resolved_by_folder.get(row["project_folder"], [])
            row["resolved_full_names"] = resolved
            for name in resolved:
                full_names.add(name.lower())
                owner, repo = name.split("/", 1)
                owners.add(owner.lower())
                repo_names.add(normalized_name(repo))
                repo_keys.add(repository_key(repo))
    mapped_count = sum(bool(row["inferred_full_names"] or row.get("resolved_full_names")) for row in rows)
    payload = {
        "artifact": "external_java_v3_exclusion_boundary",
        "local_project_count": len(projects),
        "pilot_project_count": len(pilot_rows),
        "mapped_local_full_name_count": mapped_count,
        "repository_names_normalized": sorted(repo_names),
        "repository_keys": sorted(repo_keys),
        "full_names": sorted(full_names),
        "owners": sorted(owners),
        "api_families": sorted(api_families),
        "local_projects": rows,
        "pilot_full_names": sorted(pilot_rows),
        "sources": {
            "repositories_root": args.repositories_root.name,
            "pilot_acquisition": args.pilot_acquisition.as_posix(),
            "pilot_acquisition_sha256": sha256(args.pilot_acquisition),
            "owner_resolution": args.owner_resolution.as_posix() if args.owner_resolution else "",
            "owner_resolution_sha256": sha256(args.owner_resolution) if args.owner_resolution else "",
        },
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = [
        "# External Java V3 Exclusion Boundary", "",
        f"- Local projects: `{len(projects)}`.",
        f"- Existing pilot projects: `{len(pilot_rows)}`.",
        f"- Local projects with an inferred exact GitHub full name: `{payload['mapped_local_full_name_count']}`.",
        f"- Excluded mapped owners: `{len(owners)}`.",
        f"- Excluded API families: `{len(api_families)}`.", "",
        "Exact owner disjointness is enforced for every mapped local repository and all pilot repositories; name-key and API-family disjointness cover all 97 local folders.",
    ]
    args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({key: payload[key] for key in ("local_project_count", "pilot_project_count", "mapped_local_full_name_count")}, indent=2))


if __name__ == "__main__":
    main()
