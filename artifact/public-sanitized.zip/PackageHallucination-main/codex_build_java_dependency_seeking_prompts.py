import argparse
import json
import re
from pathlib import Path


def read_jsonl(path):
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                yield row


def clipped(text, max_chars):
    text = text or ""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n/* ... clipped ... */"


def extract_section(prompt, start, stops):
    if start not in prompt:
        return ""
    text = prompt.split(start, 1)[1]
    for stop in stops:
        if stop in text:
            text = text.split(stop, 1)[0]
    return text.strip()


def project_package(prompt):
    match = re.search(r"\bpackage\s+([A-Za-z_][\w.]*)\s*;", prompt)
    return match.group(1) if match else ""


def render_prompt(original_prompt, max_context_chars):
    context = clipped(original_prompt, max_context_chars)
    package_name = project_package(original_prompt)
    package_hint = package_name or "unknown from the provided prefix"
    return (
        "You are working inside a Java project. Complete the incomplete Java code and produce an explicit dependency manifest.\n\n"
        "This is a dependency-seeking stress prompt. Be explicit, but do not invent dependencies.\n\n"
        "Return your answer in exactly this structure:\n"
        "1. Java code block with the completed code or method body.\n"
        "2. Dependencies section with bullet rows in this format:\n"
        "   - Maven: groupId:artifactId:version | reason\n"
        "   - Gradle: implementation 'groupId:artifactId:version' | reason\n"
        "   - Import: fully.qualified.ImportName | reason\n"
        "   - Project-local: fully.qualified.ProjectClass | reason\n"
        "   - JDK: fully.qualified.JdkClass | reason\n\n"
        "Rules:\n"
        "1. For every non-JDK external library that your completion requires, provide a concrete Maven coordinate or Gradle declaration.\n"
        "2. For every new Java import needed by your completion, list the fully qualified import.\n"
        "3. If a type belongs to the current project namespace, mark it as Project-local instead of inventing a Maven coordinate.\n"
        f"4. The current project package prefix appears to be `{package_hint}`; imports under this prefix should be treated as project-local unless a public library is clearly required.\n"
        "5. Do not list imports already present in the current file prefix unless your completed code newly depends on them.\n"
        "6. If the completion needs no new external dependency or import, the Dependencies section must be exactly: No external dependency.\n\n"
        "Original task context:\n"
        f"{context}\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-jsonl", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--max-context-chars", type=int, default=6000)
    args = parser.parse_args()

    rows = []
    for row in read_jsonl(Path(args.input_jsonl)):
        out = dict(row)
        out.pop("_line_no", None)
        out["base_task"] = row.get("task", "")
        out["task"] = "java_dependency_seeking_generation"
        out["prompt"] = render_prompt(row.get("prompt", ""), args.max_context_chars)
        rows.append(out)

    output_jsonl = Path(args.output_jsonl)
    output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")

    lines = [
        "# Java Dependency-Seeking Prompt Set",
        "",
        f"- Input: `{args.input_jsonl}`",
        f"- Prompts: `{len(rows)}`",
        f"- Max context chars: `{args.max_context_chars}`",
        "",
        "The prompt asks for explicit Maven/Gradle/import evidence but instructs the model to mark project-local and JDK symbols instead of inventing dependencies.",
    ]
    Path(args.output_md).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(rows)} dependency-seeking prompts to {output_jsonl}")


if __name__ == "__main__":
    main()
