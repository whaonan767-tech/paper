import argparse
import csv
import http.client
import json
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


MAVEN_SEARCH_URL = "https://search.maven.org/solrsearch/select"


def cache_key(group_id, artifact_id, version):
    return "::".join([group_id or "", artifact_id or "", version or ""])


def load_cache(path):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def save_cache(path, cache):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")


def query_maven(group_id, artifact_id, version, timeout):
    clauses = [f'g:"{group_id}"', f'a:"{artifact_id}"']
    if version:
        clauses.append(f'v:"{version}"')
    query = " AND ".join(clauses)
    params = urllib.parse.urlencode({"q": query, "rows": "5", "wt": "json"})
    url = f"{MAVEN_SEARCH_URL}?{params}"
    request = urllib.request.Request(url, headers={"User-Agent": "codex-package-hallucination-study"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    docs = payload.get("response", {}).get("docs", [])
    return {
        "url": url,
        "num_found": int(payload.get("response", {}).get("numFound", 0)),
        "docs": docs,
    }


def validate_row(row, cache, timeout, sleep_s, retry_errors=False):
    group_id = row.get("group_id", "").strip()
    artifact_id = row.get("artifact_id", "").strip()
    version = row.get("version", "").strip()

    if not group_id or not artifact_id:
        status = "import_only" if row.get("kind") == "java_import" else "missing_coordinate"
        return {**row, "validation_status": status, "maven_num_found": "", "maven_url": "", "latest_version": ""}

    key = cache_key(group_id, artifact_id, version)
    if key not in cache or (retry_errors and not cache.get(key, {}).get("ok")):
        try:
            cache[key] = {"ok": True, "result": query_maven(group_id, artifact_id, version, timeout)}
            if sleep_s:
                time.sleep(sleep_s)
        except (
            urllib.error.URLError,
            TimeoutError,
            socket.timeout,
            http.client.HTTPException,
            OSError,
            json.JSONDecodeError,
        ) as exc:
            cache[key] = {"ok": False, "error": repr(exc)}

    cached = cache[key]
    if not cached.get("ok"):
        return {
            **row,
            "validation_status": "query_error",
            "maven_num_found": "",
            "maven_url": "",
            "latest_version": "",
            "error": cached.get("error", ""),
        }

    result = cached["result"]
    docs = result.get("docs", [])
    num_found = int(result.get("num_found", 0))
    status = "valid_coordinate" if num_found > 0 else "not_found"
    latest_version = ""
    if docs:
        latest_version = docs[0].get("latestVersion") or docs[0].get("v") or ""
    return {
        **row,
        "validation_status": status,
        "maven_num_found": num_found,
        "maven_url": result.get("url", ""),
        "latest_version": latest_version,
        "error": "",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--cache-json", default="Tests/maven_validation_cache.json")
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--sleep", type=float, default=0.05)
    parser.add_argument("--retry-errors", action="store_true")
    args = parser.parse_args()

    input_csv = Path(args.input_csv)
    output_csv = Path(args.output_csv)
    output_json = Path(args.output_json)
    cache_path = Path(args.cache_json)
    cache = load_cache(cache_path)

    rows = list(csv.DictReader(input_csv.open("r", encoding="utf-8")))
    validated = [validate_row(row, cache, args.timeout, args.sleep, args.retry_errors) for row in rows]
    save_cache(cache_path, cache)

    fieldnames = sorted({key for row in validated for key in row})
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(validated)

    counts = {}
    for row in validated:
        counts[row["validation_status"]] = counts.get(row["validation_status"], 0) + 1
    summary = {
        "input_csv": str(input_csv),
        "rows": len(rows),
        "status_counts": counts,
        "cache_json": str(cache_path),
        "validated": validated,
    }
    output_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"rows": len(rows), "status_counts": counts}, indent=2))


if __name__ == "__main__":
    main()
