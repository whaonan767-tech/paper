#!/usr/bin/env python3
"""Build projects after inserting structured Qwen code spans and import evidence."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from collections import Counter
from datetime import datetime
from pathlib import Path

import codex_java_masked_baseline_audit as baseline
import codex_java_masked_evidence_build as evidence
import codex_java_masked_necessity_probe as necessity


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
OLD_PROMPTS = ROOT / "Tests" / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730" / "prompts.jsonl"
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803" / "masked_baseline_audit.json"
NECESSITY = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_NecessityFull83_TestCompile_Run20260803" / "masked_necessity_probe.json"
PARSED = ROOT / "Tests" / "Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804" / "parsed_v3.json"
DEFAULT_WORK = WORKSPACE / "vw" / "masked_v3_build"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=OLD_PROMPTS)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--necessity", type=Path, default=NECESSITY)
    parser.add_argument("--parsed", type=Path, default=PARSED)
    parser.add_argument("--output-root", type=Path, default=ROOT / "Tests")
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-status", action="append", default=[])
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def summarize(records: list[dict], results: list[dict]) -> dict:
    passes = [row for row in results if row["status"] == "pass"]
    valid = [row for row in results if row["strict_json_valid"]]
    exact_code = [row for row in valid if row["replacement_compact_exact"]]
    nonexact_code = [row for row in valid if not row["replacement_compact_exact"]]
    return {
        "eligible_records": len(records),
        "eligible_projects": len({row["project_path"] for row in records}),
        "eligible_build_units": len({row["build_key"] for row in records}),
        "completed_records": len(results),
        "strict_json_valid_records": len(valid),
        "format_failure_records": sum(row["status"] == "format_failure" for row in results),
        "build_pass_records": len(passes),
        "build_pass_projects": len({row["project_path"] for row in passes}),
        "build_pass_units": len({row["build_key"] for row in passes}),
        "exact_code_records": len(exact_code),
        "exact_code_build_pass": sum(row["status"] == "pass" for row in exact_code),
        "exact_code_build_fail": sum(row["status"] != "pass" for row in exact_code),
        "nonexact_code_build_pass": sum(row["status"] == "pass" for row in nonexact_code),
        "nonexact_code_build_fail": sum(row["status"] != "pass" for row in nonexact_code),
        "all_imports_exact_build_pass": sum(
            row["status"] == "pass" and row["all_hidden_imports_exact"] for row in valid
        ),
        "all_imports_exact_build_fail": sum(
            row["status"] != "pass" and row["all_hidden_imports_exact"] for row in valid
        ),
        "target_failure_records": sum(row["target_failure_evidence"] for row in results),
        "status_counts": dict(Counter(row["status"] for row in results)),
        "failure_detail_counts": dict(Counter(row["failure_detail"] for row in results if row["status"] != "pass")),
        "duration_seconds": round(sum(float(row["duration_seconds"]) for row in results), 3),
    }


def write_outputs(output_dir: Path, run_name: str, records: list[dict], results: list[dict], metadata: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(records, results)
    payload = {
        "run_name": run_name,
        "phase": "structured_model_code_and_import_test_compile",
        "summary": summary,
        "metadata": metadata,
        "results": results,
    }
    (output_dir / "masked_v3_build.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    fields = [
        "record_id", "source_set", "project_path", "file_path", "build_key", "selected_java_home",
        "strict_json_valid", "replacement", "ground_truth", "replacement_compact_exact",
        "ground_truth_other_occurrences", "generated_imports", "masked_imports",
        "all_hidden_imports_exact", "inserted_imports", "status", "failure_detail",
        "target_failure_evidence", "target_evidence_imports", "target_resolution", "return_code",
        "timed_out", "duration_seconds", "command", "log_path",
    ]
    csv_rows = []
    for row in results:
        csv_rows.append({
            **row,
            "generated_imports": ";".join(row["generated_imports"]),
            "masked_imports": ";".join(row["masked_imports"]),
            "inserted_imports": ";".join(row["inserted_imports"]),
            "target_evidence_imports": ";".join(row["target_evidence_imports"]),
        })
    with (output_dir / "masked_v3_build.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(csv_rows)
    lines = [
        "# Structured Model-Code and Import Build Validation",
        "",
        f"- Eligible records: `{summary['eligible_records']}` from `{summary['eligible_projects']}` projects and `{summary['eligible_build_units']}` build units.",
        f"- Completed records: `{summary['completed_records']}`.",
        f"- Strict JSON valid: `{summary['strict_json_valid_records']}/{summary['eligible_records']}`.",
        f"- Build passes: `{summary['build_pass_records']}/{summary['eligible_records']}` across `{summary['build_pass_projects']}` projects and `{summary['build_pass_units']}` build units.",
        f"- Exact code: pass `{summary['exact_code_build_pass']}`, fail `{summary['exact_code_build_fail']}`.",
        f"- Non-exact code: pass `{summary['nonexact_code_build_pass']}`, fail `{summary['nonexact_code_build_fail']}`.",
        "",
        "| Status | Records |",
        "|---|---:|",
    ]
    for status, count in sorted(summary["status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    (output_dir / "masked_v3_build.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve())
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    necessity_payload = json.loads(args.necessity.resolve().read_text(encoding="utf-8"))
    necessary_ids = {
        row["record_id"] for row in necessity_payload["results"] if row["target_failure_evidence"]
    }
    base_records, jdk_homes = necessity.load_records(prompts, audit_by_key, baseline_payload)
    parsed_payload = json.loads(args.parsed.resolve().read_text(encoding="utf-8"))
    parsed_by_id = {row["record_id"]: row for row in parsed_payload["results"]}
    records = [
        {**row, **parsed_by_id[row["record_id"]]}
        for row in base_records
        if row["record_id"] in necessary_ids
    ]
    records.sort(key=lambda row: row["record_id"])
    if args.limit:
        records = records[: args.limit]

    samples = validation.load_samples()
    run_name = args.run_name or datetime.now().strftime("Java_APIHulBench_MaskedV3Build_Run%Y%m%d_%H%M%S")
    output_dir = args.output_root.resolve() / run_name
    work_root = args.work_root.resolve() / ("run_" + hashlib.sha256(run_name.encode()).hexdigest()[:10])
    output_json = output_dir / "masked_v3_build.json"
    if args.resume:
        previous = json.loads(output_json.read_text(encoding="utf-8"))
        results = previous.get("results", [])
        if args.retry_status:
            retry = set(args.retry_status)
            results = [row for row in results if row["status"] not in retry]
    else:
        if output_dir.exists() or work_root.exists():
            raise SystemExit(f"Run path exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True)
    work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = work_root / "tmp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(temp_dir)
    os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}").strip()
    metadata = {
        "prompts_sha256": baseline.sha256(args.prompts.resolve()),
        "parsed_sha256": baseline.sha256(args.parsed.resolve()),
        "baseline_sha256": baseline.sha256(args.baseline.resolve()),
        "necessity_sha256": baseline.sha256(args.necessity.resolve()),
        "script_sha256": baseline.sha256(Path(__file__).resolve()),
        "timeout_seconds": args.timeout,
        "test_execution": False,
        "goal": "clean test-compile",
        "maven_test_skip_forced_false": True,
        "jdk_homes": jdk_homes,
    }
    write_outputs(output_dir, run_name, records, results, metadata)
    completed = {row["record_id"] for row in results}

    for index, record in enumerate(records, start=1):
        if record["record_id"] in completed:
            continue
        common = {
            "record_id": record["record_id"],
            "source_set": record["source_set"],
            "project_path": record["project_path"],
            "file_path": record["file_path"],
            "build_key": record["build_key"],
            "selected_java_home": record["selected_java_home"],
            "strict_json_valid": record["strict_json_valid"],
            "replacement": record["replacement"],
            "ground_truth": record["ground_truth"],
            "replacement_compact_exact": record["replacement_compact_exact"],
            "ground_truth_other_occurrences": record["ground_truth_other_occurrences"],
            "generated_imports": record["generated_imports"],
            "masked_imports": record["masked_imports"],
            "all_hidden_imports_exact": record["all_hidden_imports_exact"],
        }
        inserted = []
        target_evidence = []
        target_resolution = ""
        command = []
        if not record["strict_json_valid"]:
            outcome = {"status": "format_failure", "failure_detail": record["parse_error"], "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
        else:
            original_project = validation.normalize_workspace_path(record["project_path"])
            original_target = validation.normalize_workspace_path(record["file_path"])
            copied_project = work_root / f"r{index:03d}"
            copy_log = logs_dir / f"record_{index:03d}_copy.log"
            print(f"[{index}/{len(records)}] COPY {record['record_id']}", flush=True)
            copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
            if not copied:
                outcome = {"status": "project_copy_failed", "failure_detail": "project_copy_failed", "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": validation.display_path(copy_log), "tail": copy_error}
            else:
                try:
                    copied_target, target_resolution = necessity.locate_target_file(copied_project, original_project, original_target)
                    source = copied_target.read_text(encoding="utf-8", errors="strict")
                    sample = samples[record["sample_key"]]
                    patched, _ = validation.patch_ground_truth(source, sample["incomplete_function"], sample["ground_truth"], record["replacement"])
                    masked, removed = necessity.remove_imports(patched, record["masked_imports"])
                    if len(removed) != len(record["masked_imports"]):
                        raise ValueError("hidden imports were not removed exactly")
                    mutated, inserted = evidence.insert_imports(masked, record["generated_imports"])
                    copied_target.write_text(mutated, encoding="utf-8", newline="")
                    plan = validation.build_plan(record["audit"], copied_project)
                    command = baseline.clean_build_command(plan["command"])
                    java_value = jdk_homes[record["selected_java_home"]]
                    java_home = Path(java_value) if java_value else None
                    log_path = logs_dir / f"record_{index:03d}_v3_test_compile.log"
                    print(f"[{index}/{len(records)}] BUILD {record['selected_java_home']}", flush=True)
                    outcome = validation.run_build(command, plan["cwd"], args.timeout, log_path, java_home)
                    if "maven" in record["build_system"] and validation.should_retry_local_maven(outcome):
                        retry_plan = validation.build_plan(record["audit"], copied_project, force_local=True)
                        retry_command = baseline.clean_build_command(retry_plan["command"])
                        retry_log = logs_dir / f"record_{index:03d}_v3_test_compile_local_retry.log"
                        outcome = validation.run_build(retry_command, retry_plan["cwd"], args.timeout, retry_log, java_home)
                        command, log_path = retry_command, retry_log
                    full_output = Path(log_path).read_text(encoding="utf-8", errors="replace")
                    target_evidence = necessity.target_evidence(full_output, record["masked_imports"])
                except Exception as error:
                    outcome = {"status": "mutation_error", "failure_detail": str(error), "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
                if not args.keep_workdirs and copied_project.exists():
                    baseline.safe_remove_tree(copied_project, work_root)
        results.append({
            **common,
            "inserted_imports": inserted,
            "target_failure_evidence": outcome["status"] == "source_compile_failure" and bool(target_evidence),
            "target_evidence_imports": target_evidence,
            "target_resolution": target_resolution,
            "command": " ".join(command),
            **outcome,
        })
        write_outputs(output_dir, run_name, records, results, metadata)
    if not args.keep_workdirs and temp_dir.exists():
        baseline.safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
