#!/usr/bin/env python3
"""Combine structured V3 parsing, factorial builds, and real-test baselines."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import codex_java_masked_build_analysis as stats
import codex_java_masked_baseline_audit as baseline


ROOT = Path(__file__).resolve().parent
PARSED = ROOT / "Tests" / "Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804" / "parsed_v3.json"
FACTORIAL = ROOT / "Tests" / "Java_APIHulBench_MaskedV3FactorialBuild_Run20260804" / "masked_v3_factorial_build.json"
END_TO_END = ROOT / "Tests" / "Java_APIHulBench_MaskedV3Build_Corrected_Full83_Run20260804" / "masked_v3_build.json"
TEST_BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedRealTestBaseline_Full58_Run20260804" / "masked_test_baseline.json"
END_TO_END_TEST = ROOT / "Tests" / "Java_APIHulBench_MaskedV3RealTest_Run20260804" / "masked_v3_test.json"
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_MaskedV3CombinedAnalysis_Run20260804"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parsed", type=Path, default=PARSED)
    parser.add_argument("--factorial", type=Path, default=FACTORIAL)
    parser.add_argument("--end-to-end", type=Path, default=END_TO_END)
    parser.add_argument("--test-baseline", type=Path, default=TEST_BASELINE)
    parser.add_argument("--end-to-end-test", type=Path, default=END_TO_END_TEST)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20_260_804)
    return parser.parse_args()


def paired(rows: list[dict], left: str, right: str) -> dict:
    left_only = sum(row[left] and not row[right] for row in rows)
    right_only = sum(row[right] and not row[left] for row in rows)
    return {
        "left_only": left_only,
        "right_only": right_only,
        "note": "descriptive paired counts; no record-level independence test",
    }


def clustered_metrics(rows: list[dict], repetitions: int, seed: int) -> dict:
    fields = (
        "format_valid",
        "code_exact",
        "imports_exact_all",
        "both_exact",
        "b_gold_code_model_imports_pass",
        "c_model_code_gold_imports_pass",
        "d_model_code_model_imports_pass",
    )
    return {
        field: stats.clustered_bootstrap(
            rows,
            lambda row, current=field: int(row[current]),
            lambda row: 1,
            repetitions,
            seed + offset,
        )
        for offset, field in enumerate(fields)
    }


def main() -> None:
    args = parse_args(); output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {"parsed": args.parsed.resolve(), "factorial": args.factorial.resolve(), "end_to_end": args.end_to_end.resolve(), "test_baseline": args.test_baseline.resolve(), "end_to_end_test": args.end_to_end_test.resolve()}
    parsed_payload = json.loads(paths["parsed"].read_text(encoding="utf-8")); parsed = {row["record_id"]: row for row in parsed_payload["results"]}
    factorial_payload = json.loads(paths["factorial"].read_text(encoding="utf-8")); factorial = {(row["record_id"], row["variant"]): row for row in factorial_payload["results"]}
    end_payload = json.loads(paths["end_to_end"].read_text(encoding="utf-8")); end = {row["record_id"]: row for row in end_payload["results"]}
    test_payload = json.loads(paths["test_baseline"].read_text(encoding="utf-8"))
    end_test_payload = json.loads(paths["end_to_end_test"].read_text(encoding="utf-8"))
    rows = []
    for record_id in sorted(parsed):
        p = parsed[record_id]; b = factorial[(record_id, "gold_code_model_imports")]; c = factorial[(record_id, "model_code_gold_imports")]; d = end[record_id]
        rows.append({
            "record_id": record_id, "project_path": p["project_path"], "build_key": p["build_key"], "source_set": p["source_set"],
            "format_valid": bool(p["strict_json_valid"]), "code_exact": bool(p["replacement_compact_exact"]),
            "imports_exact_all": bool(p["all_hidden_imports_exact"]), "both_exact": bool(p["replacement_compact_exact"] and p["all_hidden_imports_exact"]),
            "b_gold_code_model_imports_pass": b["status"] == "pass", "c_model_code_gold_imports_pass": c["status"] == "pass",
            "d_model_code_model_imports_pass": d["status"] == "pass", "replacement": p["replacement"], "ground_truth": p["ground_truth"],
            "generated_imports": p["generated_imports"], "hidden_imports": p["hidden_imports"], "ground_truth_other_occurrences": p["ground_truth_other_occurrences"],
            "repeated_context": int(p["ground_truth_other_occurrences"]) > 0,
        })
    repetitions = args.bootstrap_repetitions; seed = args.seed
    metrics = clustered_metrics(rows, repetitions, seed)
    clean_rows = [row for row in rows if not row["repeated_context"]]
    clean_metrics = clustered_metrics(clean_rows, repetitions, seed + 100)
    for offset, (name, left, right) in enumerate((
        ("b_minus_d", "b_gold_code_model_imports_pass", "d_model_code_model_imports_pass"),
        ("c_minus_d", "c_model_code_gold_imports_pass", "d_model_code_model_imports_pass"),
        ("b_minus_c", "b_gold_code_model_imports_pass", "c_model_code_gold_imports_pass"),
    ), start=20):
        metrics[name] = stats.clustered_bootstrap(rows, lambda row, l=left, r=right: int(row[l]) - int(row[r]), lambda row: 1, repetitions, seed + offset)
    test_summary = test_payload["summary"]
    clean_summary = {
        "records": len(clean_rows),
        "projects": len({row["project_path"] for row in clean_rows}),
        "build_units": len({row["build_key"] for row in clean_rows}),
        "format_valid": sum(row["format_valid"] for row in clean_rows),
        "code_exact": sum(row["code_exact"] for row in clean_rows),
        "imports_exact_all": sum(row["imports_exact_all"] for row in clean_rows),
        "both_exact": sum(row["both_exact"] for row in clean_rows),
        "b_pass": sum(row["b_gold_code_model_imports_pass"] for row in clean_rows),
        "c_pass": sum(row["c_model_code_gold_imports_pass"] for row in clean_rows),
        "d_pass": sum(row["d_model_code_model_imports_pass"] for row in clean_rows),
        "d_repeated_context_pass": sum(
            row["d_model_code_model_imports_pass"] and row["repeated_context"]
            for row in rows
        ),
        "clustered_metrics": clean_metrics,
    }
    summary = {
        "records": len(rows), "projects": len({row["project_path"] for row in rows}), "build_units": len({row["build_key"] for row in rows}),
        "repeated_context_records": sum(row["repeated_context"] for row in rows),
        "format_valid": sum(row["format_valid"] for row in rows), "code_exact": sum(row["code_exact"] for row in rows),
        "imports_exact_all": sum(row["imports_exact_all"] for row in rows), "both_exact": sum(row["both_exact"] for row in rows),
        "b_pass": sum(row["b_gold_code_model_imports_pass"] for row in rows), "c_pass": sum(row["c_model_code_gold_imports_pass"] for row in rows),
        "d_pass": sum(row["d_model_code_model_imports_pass"] for row in rows),
        "b_nonexact_import_pass": sum(row["b_gold_code_model_imports_pass"] and not row["imports_exact_all"] for row in rows),
        "c_nonexact_code_pass": sum(row["c_model_code_gold_imports_pass"] and not row["code_exact"] for row in rows),
        "d_nonexact_pass": sum(row["d_model_code_model_imports_pass"] and not row["both_exact"] for row in rows),
        "paired": {"b_vs_d": paired(rows, "b_gold_code_model_imports_pass", "d_model_code_model_imports_pass"), "c_vs_d": paired(rows, "c_model_code_gold_imports_pass", "d_model_code_model_imports_pass"), "b_vs_c": paired(rows, "b_gold_code_model_imports_pass", "c_model_code_gold_imports_pass")},
        "nonrepeated_context": clean_summary,
        "test_baseline": test_summary, "end_to_end_real_test": end_test_payload["summary"], "clustered_metrics": metrics,
    }
    payload = {"analysis": "masked_v3_combined_factorial_build_and_test", "inputs": {name: {"path": str(path), "sha256": baseline.sha256(path)} for name, path in paths.items()}, "bootstrap": {"repetitions": repetitions, "seed": seed, "resampling_unit": "project_path", "interval": "two-sided 95% percentile"}, "summary": summary, "results": rows}
    (output_dir / "masked_v3_combined_analysis.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = list(rows[0]); csv_rows = [{**row, "generated_imports": ";".join(row["generated_imports"]), "hidden_imports": ";".join(row["hidden_imports"])} for row in rows]
    with (output_dir / "masked_v3_combined_records.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(csv_rows)
    semantic_rows = []
    for row in rows:
        if not row["c_model_code_gold_imports_pass"]: continue
        semantic_rows.append({"record_id": row["record_id"], "source_set": row["source_set"], "project_path": row["project_path"], "replacement": row["replacement"], "ground_truth": row["ground_truth"], "automatic_reference_label": "reference_exact" if row["code_exact"] else "nonexact_requires_human_review", "project_build_with_gold_imports": "pass", "ground_truth_other_occurrences": row["ground_truth_other_occurrences"]})
    with (output_dir / "masked_v3_semantic_evidence.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields2 = list(semantic_rows[0]); writer = csv.DictWriter(handle, fieldnames=fields2); writer.writeheader(); writer.writerows(semantic_rows)
    def ci(metric_set: dict, field: str) -> str:
        value = metric_set[field]; return f"{100*value['estimate']:.1f}% [{100*value['ci_low']:.1f}%, {100*value['ci_high']:.1f}%]"
    lines = [
        "# Masked V3 Combined Analysis", "",
        f"- Cohort: `{summary['records']}` records, `{summary['projects']}` projects, `{summary['build_units']}` build units.",
        f"- Strict JSON: `{summary['format_valid']}/83`; code exact: `{summary['code_exact']}/83`; all imports exact: `{summary['imports_exact_all']}/83`; both exact: `{summary['both_exact']}/83`.", "",
        "## Same-Output 2x2 Build Matrix", "", "| Code | Imports | Pass | Project-clustered 95% CI |", "|---|---|---:|---:|",
        "| Gold | Gold | 83/83 | eligibility baseline |",
        f"| Gold | Model | {summary['b_pass']}/83 | {ci(metrics, 'b_gold_code_model_imports_pass')} |",
        f"| Model | Gold | {summary['c_pass']}/83 | {ci(metrics, 'c_model_code_gold_imports_pass')} |",
        f"| Model | Model | {summary['d_pass']}/83 | {ci(metrics, 'd_model_code_model_imports_pass')} |", "",
        f"- Gold-code/model-import passes include `{summary['b_nonexact_import_pass']}` non-exact compilation-valid substitutions.",
        f"- Model-code/gold-import passes include `{summary['c_nonexact_code_pass']}` non-exact code substitutions; all `{summary['c_pass']}` passes are reference-exact.",
        f"- End-to-end passes include `{summary['d_nonexact_pass']}` non-exact cases; all `{summary['d_pass']}` passes are both code- and import-exact.", "",
        "## Non-Repeated-Context 2x2 Matrix", "",
        f"- Repeated-context records: `{summary['repeated_context_records']}`; non-repeated cohort: `{clean_summary['records']}` records.",
        "- The two strict-JSON failures remain in the denominator; strict JSON is "
        f"`{clean_summary['format_valid']}/{clean_summary['records']}` and exact code recovery is "
        f"`{clean_summary['code_exact']}/{clean_summary['records']}`.", "",
        "| Code | Imports | Pass | Project-clustered 95% CI |", "|---|---|---:|---:|",
        f"| Gold | Gold | {clean_summary['records']}/{clean_summary['records']} | eligibility baseline |",
        f"| Gold | Model | {clean_summary['b_pass']}/{clean_summary['records']} | {ci(clean_metrics, 'b_gold_code_model_imports_pass')} |",
        f"| Model | Gold | {clean_summary['c_pass']}/{clean_summary['records']} | {ci(clean_metrics, 'c_model_code_gold_imports_pass')} |",
        f"| Model | Model | {clean_summary['d_pass']}/{clean_summary['records']} | {ci(clean_metrics, 'd_model_code_model_imports_pass')} |", "",
        f"- End-to-end passes in repeated-context records: `{clean_summary['d_repeated_context_pass']}`; all `{clean_summary['d_pass']}` end-to-end passes are in the non-repeated cohort.", "",
        "## Real Tests", "",
        f"- Of 58 test-compile-eligible units, `{test_summary['build_pass_units']}` pass `clean test`, `{test_summary['pass_with_tests_units']}` pass while executing at least one test, and `{test_summary['pass_zero_tests_units']}` pass with zero detected tests.",
        f"- Passing nonzero-test baselines execute `{test_summary['tests']}` tests with `{test_summary['failures']}` failures, `{test_summary['errors']}` errors, and `{test_summary['skipped']}` skipped.",
        f"- End-to-end V3 build passes with a main-source, passing nonzero-test baseline: `{end_test_payload['summary']['semantic_test_eligible_records']}`. The real-test success denominator is therefore zero.", "",
        "No human semantic-alternative audit is required for compilation-valid model-code cells because all 12 model-code/gold-import passes are reference-exact; there are zero non-exact compilation-valid model-code candidates.",
    ]
    (output_dir / "masked_v3_combined_analysis.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
