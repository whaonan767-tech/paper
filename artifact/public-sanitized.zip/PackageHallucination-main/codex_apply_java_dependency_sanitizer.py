import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

INVALID_COORDINATE_STATUSES = {"not_found", "missing_coordinate"}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")


def response_line_to_record_id(responses):
    return {str(line_no): row.get("record_id", "") for line_no, row in enumerate(responses, start=1)}


def group_suspicious_imports(mapping_rows, statuses):
    grouped = defaultdict(list)
    for row in mapping_rows:
        if row.get("mapping_status", "") not in statuses:
            continue
        record_id = row.get("original_record_id", "")
        import_path = row.get("import_path", "")
        if record_id and import_path:
            grouped[record_id].append(row)
    return grouped


def group_invalid_coordinates(maven_rows, line_to_record_id, statuses):
    grouped = defaultdict(list)
    for row in maven_rows:
        if row.get("validation_status", "") not in statuses:
            continue
        if row.get("kind", "") == "java_import":
            continue
        record_id = line_to_record_id.get(str(row.get("source_line", "")), "")
        coordinate = row.get("coordinate", "")
        if record_id and coordinate:
            grouped[record_id].append(row)
    return grouped


def remove_line_containing(text, needle):
    if not needle:
        return text, 0
    lines = text.splitlines(keepends=True)
    kept = []
    removed = 0
    for line in lines:
        if needle in line:
            removed += 1
            continue
        kept.append(line)
    return "".join(kept), removed


def remove_java_import(text, import_path):
    pattern = re.compile(rf"(?m)^[ \t]*import\s+(static\s+)?{re.escape(import_path)}\s*;?[ \t]*(?:\r?\n|$)")
    return pattern.subn("", text)


def sanitize_response(row, suspicious_imports, invalid_coordinates):
    text = row.get("response", "")
    actions = []

    for item in suspicious_imports:
        import_path = item.get("import_path", "")
        before = text
        text, import_line_count = remove_java_import(text, import_path)
        text, containing_line_count = remove_line_containing(text, import_path)
        actions.append(
            {
                "kind": "import",
                "value": import_path,
                "status": item.get("mapping_status", ""),
                "removed_import_lines": import_line_count,
                "removed_containing_lines": containing_line_count,
                "residual_exact_string": import_path in text,
                "changed": before != text,
            }
        )

    for item in invalid_coordinates:
        coordinate = item.get("coordinate", "")
        before = text
        text, containing_line_count = remove_line_containing(text, coordinate)
        actions.append(
            {
                "kind": "coordinate",
                "value": coordinate,
                "status": item.get("validation_status", ""),
                "removed_import_lines": 0,
                "removed_containing_lines": containing_line_count,
                "residual_exact_string": coordinate in text,
                "changed": before != text,
            }
        )

    out = dict(row)
    if actions:
        out["original_response"] = row.get("response", "")
        out["response"] = text
        out["dependency_sanitizer_actions"] = actions
    return out, actions


def write_audit_md(path, output):
    lines = [
        "# Java Dependency Sanitizer Audit",
        "",
        f"- Input responses: `{output['input_responses']}`",
        f"- Input Maven validation: `{output['input_maven_validation']}`",
        f"- Input import mapping: `{output['input_mapping']}`",
        f"- Targeted records: `{output['targeted_records']}`",
        f"- Actions: `{len(output['audit_rows'])}`",
        "",
        "## Action Counts",
        "",
        "| Kind | Status | Count |",
        "|---|---|---:|",
    ]
    for key, count in sorted(output["action_status_counts"].items()):
        kind, status = key.split("::", 1)
        lines.append(f"| `{kind}` | `{status}` | {count} |")
    lines.extend(
        [
            "",
            "## Audit Rows",
            "",
            "| Record | Kind | Value | Status | Removed containing lines | Residual exact string |",
            "|---|---|---|---|---:|---|",
        ]
    )
    for row in output["audit_rows"][:160]:
        lines.append(
            "| `{record_id}` | `{kind}` | `{value}` | `{status}` | {removed} | `{residual}` |".format(
                record_id=row["record_id"],
                kind=row["kind"],
                value=row["value"],
                status=row["status"],
                removed=row["removed_containing_lines"] + row["removed_import_lines"],
                residual=row["residual_exact_string"],
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--maven-validation-csv", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--audit-json", required=True)
    parser.add_argument("--audit-md", required=True)
    parser.add_argument("--suspicious-mapping-statuses", nargs="*", default=sorted(SUSPICIOUS_MAPPING_STATUSES))
    parser.add_argument("--invalid-coordinate-statuses", nargs="*", default=sorted(INVALID_COORDINATE_STATUSES))
    args = parser.parse_args()

    responses = read_jsonl(Path(args.responses_jsonl))
    maven_rows = list(csv.DictReader(Path(args.maven_validation_csv).open("r", encoding="utf-8")))
    mapping_rows = list(csv.DictReader(Path(args.mapping_csv).open("r", encoding="utf-8")))

    line_to_record_id = response_line_to_record_id(responses)
    suspicious_by_record = group_suspicious_imports(mapping_rows, set(args.suspicious_mapping_statuses))
    invalid_by_record = group_invalid_coordinates(maven_rows, line_to_record_id, set(args.invalid_coordinate_statuses))
    targeted_records = sorted(set(suspicious_by_record) | set(invalid_by_record))

    sanitized = []
    audit_rows = []
    for row in responses:
        record_id = row.get("record_id", "")
        out, actions = sanitize_response(row, suspicious_by_record.get(record_id, []), invalid_by_record.get(record_id, []))
        for action in actions:
            audit_rows.append({"record_id": record_id, **action})
        sanitized.append(out)

    output = {
        "input_responses": args.responses_jsonl,
        "input_maven_validation": args.maven_validation_csv,
        "input_mapping": args.mapping_csv,
        "output_jsonl": args.output_jsonl,
        "targeted_records": len(targeted_records),
        "targeted_record_ids": targeted_records,
        "action_status_counts": dict(Counter(f"{row['kind']}::{row['status']}" for row in audit_rows)),
        "changed_action_count": sum(1 for row in audit_rows if row["changed"]),
        "residual_exact_string_count": sum(1 for row in audit_rows if row["residual_exact_string"]),
        "audit_rows": audit_rows,
    }

    write_jsonl(Path(args.output_jsonl), sanitized)
    Path(args.audit_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_audit_md(Path(args.audit_md), output)
    print(
        json.dumps(
            {
                "targeted_records": output["targeted_records"],
                "actions": len(audit_rows),
                "changed_action_count": output["changed_action_count"],
                "residual_exact_string_count": output["residual_exact_string_count"],
                "action_status_counts": output["action_status_counts"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
