#!/usr/bin/env python3
"""Run same-output factorial builds isolating model code and model imports."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from collections import Counter
from pathlib import Path

import codex_java_masked_baseline_audit as baseline
import codex_java_masked_evidence_build as evidence
import codex_java_masked_necessity_probe as necessity


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
PROMPTS = ROOT / "Tests" / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730" / "prompts.jsonl"
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
BASELINE = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803" / "masked_baseline_audit.json"
PARSED = ROOT / "Tests" / "Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804" / "parsed_v3.json"
DEFAULT_WORK = WORKSPACE / "vw" / "masked_v3_factorial"
VARIANTS = ("gold_code_model_imports", "model_code_gold_imports")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--parsed", type=Path, default=PARSED)
    parser.add_argument("--output-root", type=Path, default=ROOT / "Tests")
    parser.add_argument("--work-root", type=Path, default=DEFAULT_WORK)
    parser.add_argument("--run-name", default="Java_APIHulBench_MaskedV3FactorialBuild_Run20260804")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--keep-workdirs", action="store_true")
    return parser.parse_args()


def write_outputs(output_dir: Path, run_name: str, records: list[dict], results: list[dict], metadata: dict) -> None:
    by_variant = {}
    for variant in VARIANTS:
        rows = [row for row in results if row["variant"] == variant]
        passes = [row for row in rows if row["status"] == "pass"]
        by_variant[variant] = {
            "completed": len(rows), "passes": len(passes),
            "pass_projects": len({row["project_path"] for row in passes}),
            "pass_units": len({row["build_key"] for row in passes}),
            "exact_code_passes": sum(row["status"] == "pass" and row["replacement_compact_exact"] for row in rows),
            "nonexact_code_passes": sum(row["status"] == "pass" and not row["replacement_compact_exact"] for row in rows),
            "status_counts": dict(Counter(row["status"] for row in rows)),
        }
    summary = {"eligible_records": len(records), "eligible_projects": len({row["project_path"] for row in records}), "eligible_build_units": len({row["build_key"] for row in records}), "variants": by_variant}
    payload = {"run_name": run_name, "phase": "same_output_code_import_factorial_build", "summary": summary, "metadata": metadata, "results": results}
    (output_dir / "masked_v3_factorial_build.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["record_id", "variant", "source_set", "project_path", "file_path", "build_key", "selected_java_home", "strict_json_valid", "replacement", "ground_truth", "replacement_compact_exact", "generated_imports", "hidden_imports", "all_hidden_imports_exact", "inserted_imports", "status", "failure_detail", "return_code", "timed_out", "duration_seconds", "command", "log_path"]
    csv_rows = [{**row, "generated_imports": ";".join(row["generated_imports"]), "hidden_imports": ";".join(row["hidden_imports"]), "inserted_imports": ";".join(row["inserted_imports"])} for row in results]
    with (output_dir / "masked_v3_factorial_build.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore"); writer.writeheader(); writer.writerows(csv_rows)
    lines = ["# Same-Output Code/Import Factorial Build", "", f"- Eligible records: `{summary['eligible_records']}`.", "", "| Variant | Completed | Pass | Projects | Units | Exact-code pass | Non-exact-code pass |", "|---|---:|---:|---:|---:|---:|---:|"]
    for variant in VARIANTS:
        row = by_variant[variant]
        lines.append(f"| `{variant}` | {row['completed']} | {row['passes']} | {row['pass_projects']} | {row['pass_units']} | {row['exact_code_passes']} | {row['nonexact_code_passes']} |")
    (output_dir / "masked_v3_factorial_build.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args(); validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve()); samples = validation.load_samples()
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8")); audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    base_records, jdk_homes = necessity.load_records(prompts, audit_by_key, baseline_payload)
    parsed = {row["record_id"]: row for row in json.loads(args.parsed.resolve().read_text(encoding="utf-8"))["results"]}
    records = [{**row, **parsed[row["record_id"]]} for row in base_records]
    records.sort(key=lambda row: row["record_id"])
    run_name = args.run_name; output_dir = args.output_root.resolve() / run_name
    work_root = args.work_root.resolve() / ("run_" + hashlib.sha256(run_name.encode()).hexdigest()[:10]); output_json = output_dir / "masked_v3_factorial_build.json"
    if args.resume:
        results = json.loads(output_json.read_text(encoding="utf-8")).get("results", [])
    else:
        if output_dir.exists() or work_root.exists(): raise SystemExit(f"Run path exists: {run_name}")
        results = []
    output_dir.mkdir(parents=True, exist_ok=True); work_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_dir / "logs"; logs_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = work_root / "tmp"; temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(temp_dir); os.environ["TMP"] = str(temp_dir)
    os.environ["MAVEN_OPTS"] = (os.environ.get("MAVEN_OPTS", "") + f" -Djava.io.tmpdir={temp_dir}").strip()
    metadata = {"parsed_sha256": baseline.sha256(args.parsed.resolve()), "baseline_sha256": baseline.sha256(args.baseline.resolve()), "script_sha256": baseline.sha256(Path(__file__).resolve()), "timeout_seconds": args.timeout, "goal": "clean test-compile", "test_execution": False, "factorial_cells": {"gold_code_gold_imports": "V0 eligibility baseline: 83/83 pass", "gold_code_model_imports": "isolates generated import set", "model_code_gold_imports": "isolates generated code span", "model_code_model_imports": "separate V3 end-to-end result"}}
    write_outputs(output_dir, run_name, records, results, metadata)
    completed = {(row["record_id"], row["variant"]) for row in results}
    for index, record in enumerate(records, 1):
        for variant_index, variant in enumerate(VARIANTS, 1):
            if (record["record_id"], variant) in completed: continue
            common = {"record_id": record["record_id"], "variant": variant, "source_set": record["source_set"], "project_path": record["project_path"], "file_path": record["file_path"], "build_key": record["build_key"], "selected_java_home": record["selected_java_home"], "strict_json_valid": record["strict_json_valid"], "replacement": record["replacement"], "ground_truth": record["ground_truth"], "replacement_compact_exact": record["replacement_compact_exact"], "generated_imports": record["generated_imports"], "hidden_imports": record["hidden_imports"], "all_hidden_imports_exact": record["all_hidden_imports_exact"]}
            inserted = []; command = []
            if not record["strict_json_valid"]:
                outcome = {"status": "format_failure", "failure_detail": record["parse_error"], "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
            else:
                original_project = validation.normalize_workspace_path(record["project_path"]); original_target = validation.normalize_workspace_path(record["file_path"])
                copied_project = work_root / f"r{index:03d}v{variant_index}"
                copy_log = logs_dir / f"record_{index:03d}_{variant}_copy.log"
                print(f"[{index}/{len(records)}] COPY {variant} {record['record_id']}", flush=True)
                copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
                if not copied:
                    outcome = {"status": "project_copy_failed", "failure_detail": "project_copy_failed", "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": validation.display_path(copy_log), "tail": copy_error}
                else:
                    try:
                        target, _ = necessity.locate_target_file(copied_project, original_project, original_target); source = target.read_text(encoding="utf-8", errors="strict")
                        if variant == "gold_code_model_imports":
                            mutated, removed = necessity.remove_imports(source, record["hidden_imports"])
                            if len(removed) != len(record["hidden_imports"]): raise ValueError("hidden imports were not removed exactly")
                            mutated, inserted = evidence.insert_imports(mutated, record["generated_imports"])
                        else:
                            sample = samples[record["sample_key"]]
                            mutated, _ = validation.patch_ground_truth(source, sample["incomplete_function"], sample["ground_truth"], record["replacement"])
                        target.write_text(mutated, encoding="utf-8", newline="")
                        plan = validation.build_plan(record["audit"], copied_project); command = baseline.clean_build_command(plan["command"])
                        java_value = jdk_homes[record["selected_java_home"]]; java_home = Path(java_value) if java_value else None
                        log_path = logs_dir / f"record_{index:03d}_{variant}.log"
                        print(f"[{index}/{len(records)}] BUILD {variant}", flush=True)
                        outcome = validation.run_build(command, plan["cwd"], args.timeout, log_path, java_home)
                        if "maven" in record["build_system"] and validation.should_retry_local_maven(outcome):
                            retry_plan = validation.build_plan(record["audit"], copied_project, force_local=True); retry_command = baseline.clean_build_command(retry_plan["command"])
                            retry_log = logs_dir / f"record_{index:03d}_{variant}_local_retry.log"
                            outcome = validation.run_build(retry_command, retry_plan["cwd"], args.timeout, retry_log, java_home); command, log_path = retry_command, retry_log
                    except Exception as error:
                        outcome = {"status": "mutation_error", "failure_detail": str(error), "return_code": "", "timed_out": False, "duration_seconds": 0.0, "log_path": "", "tail": ""}
                    if not args.keep_workdirs and copied_project.exists(): baseline.safe_remove_tree(copied_project, work_root)
            results.append({**common, "inserted_imports": inserted, "command": " ".join(command), **outcome}); write_outputs(output_dir, run_name, records, results, metadata)
    if temp_dir.exists() and not args.keep_workdirs: baseline.safe_remove_tree(temp_dir, work_root)
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
