import argparse
import csv
import json
import re
import shutil
import subprocess
from collections import Counter
from pathlib import Path


SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

OUTPUT_NOTICE = "AI_PREANNOTATION_NOT_HUMAN_GROUND_TRUTH"


def read_csv(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, fieldnames=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def clean(value):
    return (value or "").strip()


def safe_lower(value):
    return clean(value).lower()


def resolve_dataset_path(apihul_root, value):
    raw = clean(value)
    if not raw:
        return Path()
    path = Path(raw)
    if path.is_absolute():
        return path
    if raw.startswith("./"):
        raw = raw[2:]
    return (apihul_root / raw).resolve()


def import_has_bad_syntax(import_path):
    value = clean(import_path)
    if not value:
        return True
    if value.endswith(".") or value.startswith(".") or ".." in value:
        return True
    parts = value.split(".")
    if any(not part for part in parts):
        return True
    for index, part in enumerate(parts):
        if part == "*" and index == len(parts) - 1:
            continue
        if not re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", part):
            return True
    return False


def is_platform_import(import_path):
    value = clean(import_path)
    return value.startswith(("java.", "javax."))


def javap_class_exists(import_path, javap):
    value = clean(import_path)
    if not value or value.endswith(".*"):
        return None
    if not is_platform_import(value):
        return None
    if not javap:
        return None
    completed = subprocess.run(
        [javap, value],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=10,
    )
    return completed.returncode == 0


def source_roots(project_path):
    roots = []
    if not project_path.exists():
        return roots
    for pattern in ("src/main/java", "src/test/java"):
        roots.extend(path for path in project_path.rglob(pattern) if path.is_dir())
    return roots


def project_import_exists(project_path, import_path):
    value = clean(import_path)
    if not value or value.endswith(".*") or import_has_bad_syntax(value):
        return None
    parts = value.split(".")
    roots = source_roots(project_path)
    if not roots:
        return None
    for class_len in range(len(parts), 1, -1):
        rel = Path(*parts[:class_len]).with_suffix(".java")
        for root in roots:
            if (root / rel).exists():
                return True
    return False


def control_record_map(path):
    if not path.exists():
        return {}
    return {row.get("record_id", ""): row for row in read_csv(path)}


def label_from_validity(label):
    if label in {"valid_platform", "valid_project", "valid_external"}:
        return "valid"
    if label in {"hallucinated_project_namespace", "hallucinated_external_prefix", "unresolved_unknown"}:
        return "invalid"
    if label == "malformed_extraction":
        return "malformed"
    return "uncertain"


def hallucination_type(label):
    return {
        "valid_platform": "none",
        "valid_project": "none",
        "valid_external": "none",
        "hallucinated_project_namespace": "project_namespace",
        "hallucinated_external_prefix": "external_prefix",
        "unresolved_unknown": "unresolved",
        "malformed_extraction": "parser_artifact",
        "uncertain": "uncertain",
    }.get(label, "uncertain")


def deletion_correct(row, validity):
    if row.get("sanitizer_action") != "remove_import":
        return "not_applicable"
    if validity == "invalid":
        return "yes"
    if validity == "valid":
        return "no"
    return "uncertain"


def base_label(row):
    status = safe_lower(row.get("mapping_status"))
    classification = safe_lower(row.get("import_classification"))
    if status == "missing_import" or classification == "missing_import":
        return "malformed_extraction", "high", "empty or malformed extraction row"
    if status in {"project_namespace_hallucination", "project_namespace_typo_hallucination"}:
        return "hallucinated_project_namespace", "high", f"detector/project mapping status is {status}"
    if status == "hallucinated_prefix_with_suggestion":
        return "hallucinated_external_prefix", "high", "wrong external-library prefix with suggested registry-backed replacement"
    if status == "unresolved_after_mapping":
        return "unresolved_unknown", "medium", "unresolved after registry/project mapping"
    if status == "mapped_maven_class_search":
        return "valid_external", "high", "mapped by Maven class-level registry search"
    if status == "mapped_known_prefix":
        return "valid_external", "medium", "matched a known external dependency prefix"
    if "platform_import" in classification or is_platform_import(row.get("import_path", "")):
        return "valid_platform", "medium", "classified as platform import"
    if "project_local_import" in classification or "provided_context_import" in classification:
        return "valid_project", "medium", "classified as project-local or prompt-context import"
    return "uncertain", "low", "insufficient non-detector evidence"


def annotate_pass_a(row):
    label, confidence, rationale = base_label(row)
    validity = label_from_validity(label)
    row = dict(row)
    row["annotation_label"] = label
    row["annotation_validity"] = validity
    row["annotation_hallucination_type"] = hallucination_type(label)
    row["annotation_deletion_correct"] = deletion_correct(row, validity)
    row["annotation_confidence"] = confidence
    row["annotation_rationale"] = f"{OUTPUT_NOTICE}; pass=A; {rationale}."
    return row


def annotate_pass_b(row, apihul_root, javap, control_by_record):
    label, confidence, rationale = base_label(row)
    import_path = clean(row.get("import_path", ""))
    classification = safe_lower(row.get("import_classification"))
    project_path = resolve_dataset_path(apihul_root, row.get("project_path", ""))
    control = control_by_record.get(row.get("original_record_id", ""))
    control_imports = [value.strip() for value in (control or {}).get("imports", "").split(";") if value.strip()]
    control_mentions_this_import = import_path in control_imports

    if import_has_bad_syntax(import_path):
        label = "malformed_extraction"
        confidence = "high"
        rationale = "import path is empty or syntactically malformed"
    elif is_platform_import(import_path):
        exists = javap_class_exists(import_path, javap)
        if exists is True:
            label = "valid_platform"
            confidence = "high"
            rationale = "JDK javap resolves the platform class"
        elif exists is False:
            label = "unresolved_unknown"
            confidence = "high"
            rationale = "JDK javap does not resolve the claimed java/javax class"
    elif "project_local_import" in classification:
        exists = project_import_exists(project_path, import_path)
        if exists is True:
            label = "valid_project"
            confidence = "high"
            rationale = "project source tree contains a matching Java class"
        elif exists is False:
            label = "unresolved_unknown"
            confidence = "medium"
            rationale = "project-local classification but no matching source file was found"
    elif control_mentions_this_import and control.get("failure_category") == "malformed_import_syntax":
        label = "malformed_extraction"
        confidence = "high"
        rationale = "same-protocol control probe reports malformed import syntax"
    elif control_mentions_this_import and control.get("failure_category") == "cannot_find_symbol" and label == "valid_project":
        label = "unresolved_unknown"
        confidence = "medium"
        rationale = "project/context import also triggered cannot-find-symbol in the control probe"

    validity = label_from_validity(label)
    row = dict(row)
    row["annotation_label"] = label
    row["annotation_validity"] = validity
    row["annotation_hallucination_type"] = hallucination_type(label)
    row["annotation_deletion_correct"] = deletion_correct(row, validity)
    row["annotation_confidence"] = confidence
    row["annotation_rationale"] = f"{OUTPUT_NOTICE}; pass=B; {rationale}."
    return row


def adjudicate(row_a, row_b):
    row = dict(row_b)
    label_a = row_a.get("annotation_label", "")
    label_b = row_b.get("annotation_label", "")
    if label_a == label_b:
        chosen = row_b
        note = "AI passes agree."
    else:
        chosen = row_b
        note = f"AI passes disagree: A={label_a}, B={label_b}; B selected because it applies syntax/JDK/project checks."
    row["adjudicated_label"] = chosen.get("annotation_label", "")
    row["adjudicated_validity"] = chosen.get("annotation_validity", "")
    row["adjudicated_hallucination_type"] = chosen.get("annotation_hallucination_type", "")
    row["adjudicated_deletion_correct"] = chosen.get("annotation_deletion_correct", "")
    row["adjudicated_notes"] = f"{OUTPUT_NOTICE}; {note}"
    return row


def blind_fields(rows):
    keep = [
        "audit_id",
        "window_label",
        "prompt_window",
        "candidate_record_id",
        "original_record_id",
        "source_line",
        "dataset",
        "split",
        "project_path",
        "file_path",
        "project_package_prefix",
        "import_path",
        "import_root",
        "raw_response_excerpt",
        "annotation_label",
        "annotation_validity",
        "annotation_hallucination_type",
        "annotation_confidence",
        "annotation_rationale",
    ]
    return [{key: row.get(key, "") for key in keep} for row in rows], keep


def write_summary(path, rows_a, rows_b, adjudicated):
    counts = {
        "pass_a_validity": Counter(row.get("annotation_validity", "") for row in rows_a),
        "pass_b_validity": Counter(row.get("annotation_validity", "") for row in rows_b),
        "adjudicated_validity": Counter(row.get("adjudicated_validity", "") for row in adjudicated),
        "adjudicated_by_group": Counter(
            f"{row.get('sample_group', '')}:{row.get('adjudicated_validity', '')}" for row in adjudicated
        ),
        "disagreements": sum(
            a.get("annotation_label", "") != b.get("annotation_label", "") for a, b in zip(rows_a, rows_b)
        ),
    }
    lines = [
        "# Java AI Preannotation Summary",
        "",
        f"Notice: `{OUTPUT_NOTICE}`. These files are not independent human labels and must not be reported as human ground truth.",
        "",
        f"- Rows: {len(adjudicated)}",
        f"- AI pass disagreements: {counts['disagreements']}",
        "",
        "## Adjudicated Validity Counts",
        "",
        "| Validity | Rows |",
        "|---|---:|",
    ]
    for key, value in sorted(counts["adjudicated_validity"].items()):
        lines.append(f"| `{key}` | {value} |")
    lines.extend(["", "## Adjudicated Counts by Sample Group", "", "| Group:validity | Rows |", "|---|---:|"])
    for key, value in sorted(counts["adjudicated_by_group"].items()):
        lines.append(f"| `{key}` | {value} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(path.with_suffix(".json"), {key: dict(value) if isinstance(value, Counter) else value for key, value in counts.items()})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--audit-dir", default="Tests/Java_APIHulBench_HumanAudit")
    parser.add_argument("--apihul-root", default="<ARTIFACT_WORKSPACE>/<LOCAL_APIHULBENCH_ROOT>")
    parser.add_argument("--javap", default=shutil.which("javap") or "")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / args.audit_dir
    apihul_root = Path(args.apihul_root).resolve()
    sheet = read_csv(audit_dir / "java_human_annotation_sheet.csv")
    control_by_record = control_record_map(root / "Tests/Java_APIHulBench_ControlProbe/java_unflagged_control_probe_records.csv")

    rows_a = [annotate_pass_a(row) for row in sheet]
    rows_b = [annotate_pass_b(row, apihul_root, args.javap, control_by_record) for row in sheet]
    adjudicated = [adjudicate(a, b) for a, b in zip(rows_a, rows_b)]

    blind_a, blind_fieldnames = blind_fields(rows_a)
    blind_b, _ = blind_fields(rows_b)
    write_csv(audit_dir / "java_human_annotation_ai_pass_a.csv", blind_a, blind_fieldnames)
    write_csv(audit_dir / "java_human_annotation_ai_pass_b.csv", blind_b, blind_fieldnames)
    write_csv(audit_dir / "java_human_annotation_ai_adjudicated_draft.csv", adjudicated, list(adjudicated[0].keys()))
    write_summary(audit_dir / "java_human_annotation_ai_preannotation_summary.md", rows_a, rows_b, adjudicated)

    print(f"notice={OUTPUT_NOTICE}")
    print(f"rows={len(adjudicated)}")
    print(f"pass_disagreements={sum(a.get('annotation_label', '') != b.get('annotation_label', '') for a, b in zip(rows_a, rows_b))}")
    print(f"output_dir={audit_dir}")


if __name__ == "__main__":
    main()
