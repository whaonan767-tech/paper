import argparse
import subprocess
import sys
from pathlib import Path


PYTHON_RUNS = [
    "Tests/Qwen3B_Pilot100_Python",
    "Tests/Qwen7B_Pilot100_Python",
]


def run(command, cwd):
    print("$ " + " ".join(str(part) for part in command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def require(path):
    if not path.exists():
        raise FileNotFoundError(f"Required artifact is missing: {path}")


def recompute_python(root, python_exe):
    for run_dir in PYTHON_RUNS:
        run_path = root / run_dir
        require(run_path)
        run(
            [
                python_exe,
                "-c",
                (
                    "import os, package_detection; "
                    "package_detection.detect_packages("
                    "os.path.join(os.getcwd(),'Data','Python'), "
                    f"os.path.join(os.getcwd(),{run_dir!r}), "
                    f"{Path(run_dir).name.split('_')[0]!r}, 'off', 'Python')"
                ),
            ],
            root,
        )
        run([python_exe, "codex_summarize_package_results.py", "--run-dir", run_dir, "--output-prefix", "summary"], root)
        run([python_exe, "codex_compute_filtered_rates.py", "--run-dir", run_dir, "--output-prefix", "filtered_rates"], root)
        run([python_exe, "codex_analyze_hallucinated_packages.py", "--run-dir", run_dir, "--output-prefix", "hallucination_audit"], root)

    run(
        [
            python_exe,
            "codex_classify_python_hallucinated_packages.py",
            "--run-dir",
            PYTHON_RUNS[0],
            "--run-dir",
            PYTHON_RUNS[1],
            "--data-dir",
            "Data/Python",
            "--combined-output-dir",
            "Tests/PythonFalsePositiveLabels_Qwen3B7B100",
        ],
        root,
    )
    run(
        [
            python_exe,
            "codex_compare_model_sensitivity.py",
            "--run-dir",
            PYTHON_RUNS[0],
            "--run-dir",
            PYTHON_RUNS[1],
            "--output-dir",
            "Tests/ModelSensitivity_Qwen3B_7B_Pilot100",
        ],
        root,
    )


def recompute_java_summary(root, python_exe):
    build_probe = (root / ".." / ".." / "vw" / "pkg_import_build_probe" / "fm50_shortroot" / "java_import_build_probe.json").resolve()
    inputs = {
        "original_mapping": root / "Tests/Java_APIHulBench_Qwen3B_FM50/import_maven_mapping_enhanced.json",
        "repair1": root / "Tests/Java_APIHulBench_Qwen3B_FM50_RegistryRepair/repair_comparison_enhanced.json",
        "repair2": root / "Tests/Java_APIHulBench_Qwen3B_FM50_RegistryRepair_Round2/repair_comparison_enhanced.json",
        "sanitizer": root / "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/sanitizer_comparison_enhanced.json",
        "sanitized_mapping": root / "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/import_maven_mapping_enhanced.json",
        "build_probe": build_probe,
    }
    missing = [name for name, path in inputs.items() if not path.exists()]
    if missing:
        print("Skipping Java summary; missing inputs: " + ", ".join(missing), flush=True)
        return

    run(
        [
            python_exe,
            "codex_summarize_java_dependency_extension.py",
            "--original-mapping-json",
            str(inputs["original_mapping"]),
            "--repair1-json",
            str(inputs["repair1"]),
            "--repair2-json",
            str(inputs["repair2"]),
            "--sanitizer-json",
            str(inputs["sanitizer"]),
            "--sanitized-mapping-json",
            str(inputs["sanitized_mapping"]),
            "--build-probe-json",
            str(inputs["build_probe"]),
            "--output-json",
            "Tests/Java_APIHulBench_MitigationSummary/java_dependency_extension_summary.json",
            "--output-md",
            "Tests/Java_APIHulBench_MitigationSummary/java_dependency_extension_summary.md",
            "--output-csv",
            "Tests/Java_APIHulBench_MitigationSummary/java_dependency_mitigation_table.csv",
        ],
        root,
    )


def recompute_java_window_summary(root, python_exe):
    fm50_build_probe = (root / ".." / ".." / "vw" / "pkg_import_build_probe" / "fm50_shortroot" / "java_import_build_probe.json").resolve()
    inputs = [
        root / "codex_summarize_java_window_expansion.py",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/sanitizer_audit.json",
        root / "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_suspicious_imports_v3/java_import_only_probe.json",
        fm50_build_probe,
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50_Sanitized/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50_Sanitized/sanitizer_audit.json",
        root / "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset50_suspicious_imports/java_import_only_probe.json",
        root / "Tests/Java_APIHulBench_BuildProbe/offset50_import_sanitizer_probe/java_import_build_probe.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100_Sanitized/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100_Sanitized/sanitizer_audit.json",
        root / "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset100_suspicious_imports/java_import_only_probe.json",
        (root / ".." / ".." / "vw" / "pkg_import_build_probe" / "offset100_shortroot" / "java_import_build_probe.json").resolve(),
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150_Sanitized/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150_Sanitized/sanitizer_audit.json",
        root / "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset150_suspicious_imports/java_import_only_probe.json",
        (root / ".." / ".." / "vw" / "pkg_import_build_probe" / "offset150_shortroot" / "java_import_build_probe.json").resolve(),
        root / "Tests/Java_APIHulBench_Qwen3B_F50_Offset200/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_F50_Offset200_Sanitized/import_maven_mapping_enhanced.json",
        root / "Tests/Java_APIHulBench_Qwen3B_F50_Offset200_Sanitized/sanitizer_audit.json",
        root / "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_f50_offset200_suspicious_imports/java_import_only_probe.json",
        (root / ".." / ".." / "vw" / "pkg_import_build_probe" / "offset200_f_tail_shortroot" / "java_import_build_probe.json").resolve(),
    ]
    missing = [str(path) for path in inputs if not path.exists()]
    if missing:
        print("Skipping Java window summary; missing inputs: " + ", ".join(missing), flush=True)
        return

    run(
        [
            python_exe,
            "codex_summarize_java_window_expansion.py",
            "--output-dir",
            "Tests/Java_APIHulBench_WindowExpansionSummary",
        ],
        root,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="PackageHallucination repository root")
    parser.add_argument("--python", default=sys.executable, help="Python executable with pandas installed")
    parser.add_argument("--skip-python", action="store_true")
    parser.add_argument("--skip-java", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    require(root / "package_detection.py")

    if not args.skip_python:
        recompute_python(root, args.python)
    if not args.skip_java:
        recompute_java_summary(root, args.python)
        recompute_java_window_summary(root, args.python)

    print("Recomputed paper table artifacts.", flush=True)


if __name__ == "__main__":
    main()
