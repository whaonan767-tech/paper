#!/usr/bin/env python3
"""Build content-addressed provenance for Java compilation units used in the paper."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
DEFAULT_BENCHMARK_ROOT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>"
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_BuildProvenance_Run20260804"
IGNORED_DIRS = {".git", ".gradle", ".idea", "node_modules", "target", "build", "dist", "out"}
BUILD_FILE_NAMES = {
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "settings.gradle",
    "settings.gradle.kts",
    "gradle.properties",
    "maven-wrapper.properties",
    "gradle-wrapper.properties",
}
LICENSE_PREFIXES = ("license", "copying", "notice")
LICENSE_SUFFIXES = ("", ".txt", ".md", ".rst", ".html")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark-root", type=Path, default=DEFAULT_BENCHMARK_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def normalized(path: str) -> str:
    return path.replace("\\", "/").removeprefix("./")


def is_license_evidence(path: Path) -> bool:
    name = path.name.lower()
    return any(name == prefix or name == f"{prefix}{suffix}" for prefix in LICENSE_PREFIXES for suffix in LICENSE_SUFFIXES)


def source_records() -> dict[str, dict]:
    prompt_path = ROOT / "Tests" / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730" / "prompts.jsonl"
    return {row["record_id"]: row for row in read_jsonl(prompt_path)}


def collect_units() -> list[dict]:
    prompts = source_records()
    baseline_path = ROOT / "Tests" / "Java_APIHulBench_MaskedSemanticBuild_BaselineFull85_TestCompile_Run20260803" / "masked_baseline_audit.json"
    baseline = read_json(baseline_path)
    units: list[dict] = []
    for row in baseline["results"]:
        record_ids = [item.strip() for item in re.split(r"[,;]", row["record_ids"]) if item.strip()]
        units.append(
            {
                "protocol": "masked_project_test_compile",
                "project_path": normalized(row["project_path"]),
                "build_key": row["build_key"],
                "build_root": normalized(row["build_root"]),
                "reactor_root": normalized(row["reactor_root"]),
                "module_path": row["module_path"],
                "build_system": row["build_system"],
                "selected_jdk": row["selected_java_home"],
                "record_ids": record_ids,
                "source_files": [normalized(prompts[item]["file_path"]) for item in record_ids],
                "baseline_status": row["status"],
            }
        )

    injection_paths = [
        WORKSPACE / "vw" / "pkg_import_build_probe" / "fm50_shortroot" / "java_import_build_probe.json",
        ROOT / "Tests" / "Java_APIHulBench_BuildProbe" / "offset50_import_sanitizer_probe" / "java_import_build_probe.json",
        WORKSPACE / "vw" / "pkg_import_build_probe" / "offset100_shortroot" / "java_import_build_probe.json",
        WORKSPACE / "vw" / "pkg_import_build_probe" / "offset150_shortroot" / "java_import_build_probe.json",
        WORKSPACE / "vw" / "pkg_import_build_probe" / "offset200_f_tail_shortroot" / "java_import_build_probe.json",
    ]
    for path in injection_paths:
        payload = read_json(path)
        sources: dict[str, set[str]] = defaultdict(set)
        records: dict[str, set[str]] = defaultdict(set)
        for result in payload["results"]:
            sources[result["build_key"]].add(normalized(result["file_path"]))
            records[result["build_key"]].add(result["record_id"])
        for row in payload["baselines"]:
            units.append(
                {
                    "protocol": "injected_import_compilation_impact",
                    "project_path": normalized(row["project_path"]),
                    "build_key": row["build_key"],
                    "build_root": normalized(row["build_root"]),
                    "reactor_root": normalized(row["reactor_root"]),
                    "module_path": row["module_path"],
                    "build_system": row["build_system"],
                    "selected_jdk": "system-openjdk21",
                    "record_ids": sorted(records[row["build_key"]]),
                    "source_files": sorted(sources[row["build_key"]]),
                    "baseline_status": row["status"],
                }
            )
    return units


def project_snapshot(project_root: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    files = 0
    bytes_total = 0
    errors: list[str] = []
    license_files: list[str] = []
    try:
        candidates = sorted(
            (
                path
                for path in project_root.rglob("*")
                if path.is_file() and not any(part.lower() in IGNORED_DIRS for part in path.relative_to(project_root).parts)
            ),
            key=lambda path: path.relative_to(project_root).as_posix(),
        )
    except OSError as error:
        candidates = []
        errors.append(str(error))
    for path in candidates:
        relative = path.relative_to(project_root).as_posix()
        try:
            file_hash = sha256(path)
            size = path.stat().st_size
        except OSError as error:
            errors.append(f"{relative}: {error}")
            continue
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(size).encode("ascii"))
        digest.update(b"\0")
        digest.update(file_hash.encode("ascii"))
        digest.update(b"\n")
        files += 1
        bytes_total += size
        if is_license_evidence(path):
            license_files.append(f"{relative}={file_hash}")
    return {
        "tree_sha256": digest.hexdigest().upper() if files and not errors else "",
        "files_hashed": files,
        "bytes_hashed": bytes_total,
        "hash_errors": errors,
        "license_files": license_files,
    }


def file_manifest(paths: list[str], benchmark_root: Path) -> list[str]:
    output = []
    for value in sorted(set(paths)):
        path = benchmark_root / value
        output.append(f"{value}={sha256(path)}" if path.is_file() else f"{value}=MISSING")
    return output


def main() -> None:
    args = parse_args()
    benchmark_root = args.benchmark_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    units = collect_units()
    project_paths = sorted({row["project_path"] for row in units})
    snapshots = {
        project_path: project_snapshot(benchmark_root / project_path)
        for project_path in project_paths
    }

    output_rows = []
    for unit in units:
        reactor = benchmark_root / unit["reactor_root"]
        build_files = []
        if reactor.is_dir():
            build_files = [
                path.relative_to(benchmark_root).as_posix()
                for path in reactor.rglob("*")
                if path.is_file()
                and path.name.lower() in BUILD_FILE_NAMES
                and not any(part.lower() in IGNORED_DIRS for part in path.relative_to(reactor).parts)
            ]
        snapshot = snapshots[unit["project_path"]]
        output_rows.append(
            {
                "protocol": unit["protocol"],
                "project_id": unit["project_path"].split("/", 1)[-1],
                "project_path": unit["project_path"],
                "upstream_identifier": f"APIHulBench project_path={unit['project_path']}",
                "git_commit": "UNAVAILABLE_IN_BENCHMARK_SNAPSHOT",
                "content_addressed_revision": snapshot["tree_sha256"],
                "snapshot_files_hashed": snapshot["files_hashed"],
                "snapshot_hash_errors": len(snapshot["hash_errors"]),
                "build_key": unit["build_key"],
                "build_root": unit["build_root"],
                "reactor_root": unit["reactor_root"],
                "module_path": unit["module_path"],
                "build_system": unit["build_system"],
                "selected_jdk": unit["selected_jdk"],
                "maven_version": "3.6.3",
                "baseline_status": unit["baseline_status"],
                "record_ids": ";".join(unit["record_ids"]),
                "source_file_hashes": ";".join(file_manifest(unit["source_files"], benchmark_root)),
                "build_file_hashes": ";".join(file_manifest(build_files, benchmark_root)),
                "license_file_hashes": ";".join(snapshot["license_files"]) or "NOT_FOUND_IN_SNAPSHOT",
            }
        )

    dataset_files = [benchmark_root / "APIHulBench_F.jsonl", benchmark_root / "APIHulBench_M.jsonl"]
    payload = {
        "analysis": "java_build_source_provenance",
        "benchmark_upstream": "https://github.com/yujiachen99/APIMitigation",
        "benchmark_commit": "unavailable because the downloaded benchmark snapshot contains no .git metadata",
        "benchmark_file_hashes": {path.name: sha256(path) for path in dataset_files},
        "source_snapshot": {
            "projects": len(project_paths),
            "content_addressed_revisions_complete": all(snapshots[path]["tree_sha256"] for path in project_paths),
            "git_commits_available": 0,
            "interpretation": "tree_sha256 is the immutable revision identifier for the exact local project snapshot",
            "official_archive_url": "https://drive.google.com/file/d/12c46In9w9fqJyU-qAAKccMSVycFIszOz/view?usp=sharing",
            "official_archive_id": "12c46In9w9fqJyU-qAAKccMSVycFIszOz",
            "distribution_requirement": "project trees are not redistributed by this paper; full compilation reruns require lawful acquisition from the benchmark authors and verification against the listed revisions",
        },
        "toolchains": {
            "conda-jdk8": "Zulu OpenJDK 1.8.0_472-b08",
            "conda-jdk11": "Zulu OpenJDK 11.0.30+7-LTS",
            "conda-jdk17": "Zulu OpenJDK 17.0.18+8-LTS",
            "system-openjdk21": "Microsoft OpenJDK 21.0.11+10-LTS",
            "maven": "Apache Maven 3.6.3",
        },
        "units": output_rows,
        "project_snapshots": snapshots,
    }
    (output_dir / "java_build_provenance.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with (output_dir / "java_build_provenance.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)

    protocol_counts = defaultdict(int)
    for row in output_rows:
        protocol_counts[row["protocol"]] += 1
    missing_licenses = sum(1 for path in project_paths if not snapshots[path]["license_files"])
    lines = [
        "# Java Build Source Provenance",
        "",
        "- Benchmark source: `https://github.com/yujiachen99/APIMitigation`.",
        f"- APIHulBench-F SHA256: `{payload['benchmark_file_hashes']['APIHulBench_F.jsonl']}`.",
        f"- APIHulBench-M SHA256: `{payload['benchmark_file_hashes']['APIHulBench_M.jsonl']}`.",
        f"- Build-unit rows: `{len(output_rows)}` across `{len(project_paths)}` project snapshots.",
        f"- Masked-project units: `{protocol_counts['masked_project_test_compile']}`; injected-import units: `{protocol_counts['injected_import_compilation_impact']}`.",
        "- The downloaded project directories contain no `.git` metadata. Therefore no project commit can be truthfully reported; each exact local project tree is identified by a deterministic SHA256 content-addressed revision after excluding generated/cache directories.",
        f"- Project snapshots without a discoverable LICENSE/COPYING/NOTICE file: `{missing_licenses}`; the CSV reports this as `NOT_FOUND_IN_SNAPSHOT` rather than inferring a license.",
        "- Project trees are not redistributed by this paper. `codex_acquire_apihulbench_projects.py` retrieves the benchmark authors' official Google Drive archive (id `12c46In9w9fqJyU-qAAKccMSVycFIszOz`) and verifies the 70 relevant trees against these revisions.",
        "",
        "The CSV provides one row per build unit with project identifier, content-addressed revision, module/build root, source and build-file hashes, selected JDK, Maven version, record IDs, and license-file evidence.",
    ]
    (output_dir / "java_build_provenance.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"units": len(output_rows), "projects": len(project_paths), "missing_licenses": missing_licenses}))


if __name__ == "__main__":
    main()
