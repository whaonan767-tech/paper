#!/usr/bin/env python3
"""Generate detector-blind automated preannotations for workflow development.

These outputs are not human annotations and must not be used as human gold
labels or placed in the final human-audit directory.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


ANNOTATION_FIELDS = {
    "annotation_status",
    "annotator_mentions",
    "mention_surface",
    "mention_validity",
    "annotator_notes",
}

IMPORT_LINE_RE = re.compile(r"^\s*import\s+(static\s+)?(.+?)\s*$")
COORD_RE = re.compile(
    r"\b(?:[a-z][A-Za-z0-9_-]*\.)+[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.+-]+)?\b"
)
GROUP_RE = re.compile(r"(?:<\s*groupId\s*>|(?<![A-Za-z0-9_])groupId>?)\s*([A-Za-z0-9_.-]+)")
ARTIFACT_RE = re.compile(r"(?:<\s*artifactId\s*>|(?<![A-Za-z0-9_])artifactId>?)\s*([A-Za-z0-9_.-]+)")
DEP_DECL_RE = re.compile(
    r"\b(?:implementation|api|compileOnly|runtimeOnly|testImplementation|annotationProcessor|compile|testCompile)\b",
    re.IGNORECASE,
)
FQN_TOKEN_RE = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$*][A-Za-z0-9_$*]*)*$")
PLATFORM_PREFIXES = ("java.", "javax.", "jdk.", "com.sun.", "sun.", "org.w3c.", "org.xml.sax.")
ROOT_FRAGMENTS = {"com", "org", "io", "net", "java", "javax", "ai", "cn", "me", "dev"}
PLACEHOLDERS = {"groupid", "artifactid", "version", "dependency", "dependencies", "con", "ac"}
KNOWN_EXTERNAL_PREFIXES = {
    "ai.timefold.": "timefold",
    "cn.hutool.": "hutool",
    "com.alibaba.fastjson.": "fastjson",
    "com.fasterxml.jackson.": "jackson",
    "com.google.common.": "guava",
    "com.mongodb.": "mongodb",
    "lombok.": "lombok",
    "org.apache.commons.": "apache-commons",
    "org.apache.logging.log4j.": "log4j",
    "org.apache.zookeeper.": "zookeeper",
    "org.junit.": "junit",
    "org.openpnp.": "opencv",
    "org.slf4j.": "slf4j",
    "org.springframework.": "spring",
    "reactor.core.publisher.": "reactor",
}
KNOWN_PROSE_NAMES = {
    "apache commons": "apache-commons",
    "fastjson": "fastjson",
    "guava": "guava",
    "jackson": "jackson",
    "junit": "junit",
    "log4j": "log4j",
    "lombok": "lombok",
    "mongodb": "mongodb",
    "opencv": "opencv",
    "slf4j": "slf4j",
    "spring": "spring",
    "timefold": "timefold",
    "zookeeper": "zookeeper",
}
WRONG_EXTERNAL_PREFIXES = {
    "com.hutool.": "Hutool normally uses cn.hutool",
    "lombok.extern.slf4": "Lombok logger annotation package should use lombok.extern.slf4j.Slf4j",
    "lombok.extern.jackson.": "Jackson annotations are not under lombok.extern.jackson",
    "org.ai.timefold.": "Timefold packages use ai.timefold",
    "org.apache.commons.file.": "Commons FileUpload uses org.apache.commons.fileupload",
    "org.slf4.": "SLF4J uses org.slf4j",
}


@dataclass(frozen=True)
class Mention:
    value: str
    kind: str
    line_index: int
    import_static: bool = False
    malformed_hint: bool = False


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def clean(value: str | None) -> str:
    return (value or "").strip()


def normalize(value: str) -> str:
    return re.sub(r"\s+", " ", clean(value)).rstrip(";")


def context_hash(rows: list[dict[str, str]], fields: list[str]) -> str:
    payload = json.dumps([{field: row.get(field, "") for field in fields} for row in rows], ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def fence_state(lines: list[str]) -> tuple[bool, list[bool]]:
    in_fence = False
    broken = False
    line_in_fence: list[bool] = []
    fence_count = 0
    for line in lines:
        stripped = line.strip()
        is_fence = stripped.startswith("```")
        line_in_fence.append(in_fence)
        if is_fence:
            fence_count += 1
            if in_fence and stripped.lower().startswith("```java"):
                broken = True
            in_fence = not in_fence
    if in_fence or fence_count % 2:
        broken = True
    return broken, line_in_fence


def trim_import_token(raw: str) -> str:
    token = raw.split("//", 1)[0].strip()
    token = token.split()[0] if token.split() else ""
    token = token.rstrip(";,.")
    return token


def add_unique(mentions: list[Mention], seen: set[str], mention: Mention) -> None:
    key = mention.value.lower()
    if key not in seen:
        seen.add(key)
        mentions.append(mention)


def extract_mentions(text: str) -> tuple[list[Mention], bool, list[bool]]:
    lines = text.splitlines()
    broken_fence, line_in_fence = fence_state(lines)
    mentions: list[Mention] = []
    seen: set[str] = set()

    for index, line in enumerate(lines):
        match = IMPORT_LINE_RE.match(line)
        if match:
            token = trim_import_token(match.group(2))
            if token:
                malformed = not FQN_TOKEN_RE.match(token) or token.lower() in ROOT_FRAGMENTS or token.endswith(".")
                add_unique(mentions, seen, Mention(token, "import", index, bool(match.group(1)), malformed))
        for coord in COORD_RE.findall(line):
            add_unique(mentions, seen, Mention(coord, "coordinate", index))
        if DEP_DECL_RE.search(line) and not COORD_RE.search(line):
            rest = normalize(line)
            if rest and "no dependency" not in rest.lower():
                add_unique(mentions, seen, Mention(rest, "declaration", index, malformed_hint=True))

    groups = [value for value in GROUP_RE.findall(text) if value.lower() not in {"groupid"}]
    artifacts = [value for value in ARTIFACT_RE.findall(text) if value.lower() not in {"artifactid"}]
    for offset, (group, artifact) in enumerate(zip(groups, artifacts)):
        value = f"{group}:{artifact}"
        malformed = (
            group.lower() in ROOT_FRAGMENTS
            or artifact.lower() in PLACEHOLDERS
            or "." not in group
            or not re.match(r"^[A-Za-z0-9_.-]+$", artifact)
        )
        add_unique(mentions, seen, Mention(value, "coordinate", -1 - offset, malformed))
    if groups and not artifacts:
        for offset, group in enumerate(groups):
            add_unique(mentions, seen, Mention(f"groupId={group}", "declaration", -100 - offset, malformed_hint=True))
    if artifacts and not groups:
        for offset, artifact in enumerate(artifacts):
            add_unique(mentions, seen, Mention(f"artifactId={artifact}", "declaration", -200 - offset, malformed_hint=True))

    for index, line in enumerate(lines):
        lowered = line.lower()
        if "no dependency" in lowered or IMPORT_LINE_RE.match(line) or COORD_RE.search(line):
            continue
        if line_in_fence[index] or line.strip().startswith("```"):
            continue
        for phrase, normalized in KNOWN_PROSE_NAMES.items():
            if re.search(rf"\b{re.escape(phrase)}\b", lowered):
                add_unique(mentions, seen, Mention(normalized, "prose", index))
    return mentions, broken_fence, line_in_fence


def source_roots(project_path: Path, cache: dict[str, list[Path]]) -> list[Path]:
    key = str(project_path)
    if key in cache:
        return cache[key]
    roots: list[Path] = []
    if project_path.exists():
        for src in project_path.rglob("src"):
            if src.is_dir():
                for suffix in ("main/java", "test/java"):
                    root = src / suffix
                    if root.is_dir():
                        roots.append(root)
    cache[key] = roots
    return roots


def resolve_under(root: Path, value: str) -> Path:
    raw = clean(value)
    if raw.startswith("./"):
        raw = raw[2:]
    path = Path(raw)
    return path if path.is_absolute() else (root / raw).resolve()


def possible_class_names(value: str, is_static: bool) -> list[str]:
    if not value or value.endswith(".*"):
        return []
    parts = value.split(".")
    names = [value]
    if is_static or (parts and re.match(r"^[a-z_$]", parts[-1])):
        for length in range(len(parts) - 1, 1, -1):
            names.append(".".join(parts[:length]))
    return list(dict.fromkeys(names))


def project_source_hit(value: str, row: dict[str, str], apihul_root: Path, roots_cache: dict[str, list[Path]]) -> Path | None:
    if not FQN_TOKEN_RE.match(value) or value.endswith(".*"):
        return None
    project_path = resolve_under(apihul_root, row.get("project_path", ""))
    roots = source_roots(project_path, roots_cache)
    parts = value.split(".")
    candidates: list[Path] = []
    for name in possible_class_names(value, False):
        candidates.append(Path(*name.split(".")).with_suffix(".java"))
    for length in range(len(parts), 1, -1):
        candidates.append(Path(*parts[:length]).with_suffix(".java"))
    for rel in candidates:
        for root in roots:
            candidate = root / rel
            if candidate.exists():
                return candidate
    return None


def class_entries(value: str, is_static: bool) -> list[str]:
    entries: set[str] = set()
    for name in possible_class_names(value, is_static):
        parts = name.split(".")
        entries.add("/".join(parts) + ".class")
        for split in range(1, len(parts)):
            package = "/".join(parts[:split])
            nested = "$".join(parts[split:])
            entries.add(f"{package}/{nested}.class")
    return sorted(entries)


def build_jar_hits(values: list[Mention], repo_roots: list[Path]) -> dict[str, Path]:
    targets: dict[str, str] = {}
    for mention in values:
        if mention.kind != "import" or mention.malformed_hint or mention.value.startswith(PLATFORM_PREFIXES):
            continue
        for entry in class_entries(mention.value, mention.import_static):
            targets.setdefault(entry, mention.value)
    hits: dict[str, Path] = {}
    if not targets:
        return hits
    for repo_root in repo_roots:
        if not repo_root.exists():
            continue
        for jar_path in repo_root.rglob("*.jar"):
            try:
                with zipfile.ZipFile(jar_path) as jar:
                    names = set(jar.namelist())
            except (OSError, zipfile.BadZipFile):
                continue
            for entry in names.intersection(targets):
                hits.setdefault(targets[entry], jar_path)
    return hits


def javap_ok(name: str, javap: str, cache: dict[str, bool]) -> bool:
    if name in cache:
        return cache[name]
    try:
        completed = subprocess.run(
            [javap, name],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=6,
        )
        cache[name] = completed.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        cache[name] = False
    return cache[name]


def coordinate_validity(value: str, malformed_hint: bool, jar_roots: list[Path], mode: str) -> tuple[str, str]:
    if malformed_hint:
        return "malformed", "partial or placeholder dependency declaration"
    parts = value.split(":")
    if len(parts) < 2 or "." not in parts[0] or parts[0].lower() in ROOT_FRAGMENTS:
        return "malformed", "coordinate is incomplete"
    rel = Path(*parts[0].split(".")) / parts[1]
    if any((root / rel).exists() for root in jar_roots if root.exists()):
        return "valid", "local Maven repository contains the coordinate family"
    return ("uncertain" if mode == "B" else "valid"), "coordinate-like Maven/Gradle dependency declaration"


def import_validity(mention: Mention, row: dict[str, str], apihul_root: Path, roots_cache: dict[str, list[Path]], jar_hits: dict[str, Path], javap: str, javap_cache: dict[str, bool], mode: str) -> tuple[str, str]:
    value = mention.value
    if mention.malformed_hint:
        return "malformed", "incomplete or non-Java import-like fragment"
    for prefix, reason in WRONG_EXTERNAL_PREFIXES.items():
        if value.startswith(prefix):
            return "invalid", reason
    if value.startswith(PLATFORM_PREFIXES):
        if value.endswith(".*"):
            return "valid", "Java platform wildcard/package mention"
        for candidate in possible_class_names(value, mention.import_static):
            if javap_ok(candidate, javap, javap_cache):
                return "valid", f"JDK lookup resolves {candidate}"
        return "invalid", "JDK lookup does not resolve the platform class/member owner"
    source = project_source_hit(value, row, apihul_root, roots_cache)
    if source:
        return "valid", "local project source contains the referenced class"
    if value in jar_hits:
        return "valid", "local Maven jar contains the referenced class or owner"
    if any(value.startswith(prefix) for prefix in KNOWN_EXTERNAL_PREFIXES):
        return ("uncertain" if mode == "B" else "invalid"), "known dependency namespace but no exact class evidence in local caches"
    project_prefix = clean(row.get("project_path", "")).lower()
    if "repositories" in project_prefix:
        first_two = ".".join(value.split(".")[:2]).lower()
        if first_two and first_two in clean(row.get("file_path", "")).lower():
            return ("uncertain" if mode == "B" else "invalid"), "project-looking mention lacks an exact source hit"
    return "uncertain", "no local source/JDK/Maven evidence"


def surface_for(mention: Mention, broken_fence: bool, line_in_fence: list[bool], mode: str) -> str:
    if mention.malformed_hint:
        return "malformed"
    if mention.kind == "prose":
        return "prose"
    if mention.kind in {"coordinate", "declaration"}:
        return "malformed" if mention.malformed_hint else "code"
    in_fence = 0 <= mention.line_index < len(line_in_fence) and line_in_fence[mention.line_index]
    if mode == "A" and broken_fence and in_fence:
        return "broken_fence"
    if mode == "B" and broken_fence and not in_fence:
        return "broken_fence"
    return "code"


def annotate_row(row: dict[str, str], mentions: list[Mention], broken_fence: bool, line_in_fence: list[bool], apihul_root: Path, roots_cache: dict[str, list[Path]], jar_hits: dict[str, Path], jar_roots: list[Path], javap: str, javap_cache: dict[str, bool], mode: str) -> dict[str, str]:
    output = dict(row)
    output["annotation_status"] = "complete"
    if not mentions:
        output["annotator_mentions"] = ""
        output["mention_surface"] = ""
        output["mention_validity"] = ""
        output["annotator_notes"] = "no_mentions"
        return output

    surfaces: list[str] = []
    validities: list[str] = []
    reasons: Counter[str] = Counter()
    for mention in mentions:
        surfaces.append(surface_for(mention, broken_fence, line_in_fence, mode))
        if mention.kind in {"coordinate", "declaration"}:
            validity, reason = coordinate_validity(mention.value, mention.malformed_hint, jar_roots, mode)
        elif mention.kind == "prose":
            validity, reason = "valid", "dependency name appears in prose"
        else:
            validity, reason = import_validity(mention, row, apihul_root, roots_cache, jar_hits, javap, javap_cache, mode)
        validities.append(validity)
        reasons[reason] += 1

    output["annotator_mentions"] = "; ".join(mention.value for mention in mentions)
    output["mention_surface"] = "; ".join(surfaces)
    output["mention_validity"] = "; ".join(validities)
    invalid_count = sum(value in {"invalid", "malformed"} for value in validities)
    if mode == "A":
        output["annotator_notes"] = f"A/compiler pass: {len(mentions)} mention(s), {invalid_count} invalid/malformed; main evidence: {', '.join(reason for reason, _ in reasons.most_common(3))}."
    else:
        output["annotator_notes"] = f"B/dependency pass: {len(mentions)} mention(s) recorded; {invalid_count} looked invalid or malformed; evidence used: {', '.join(reason for reason, _ in reasons.most_common(3))}."
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--audit-dir", default="Tests/Java_APIHulBench_RawMentionAutoPreannotation_Run20260813")
    parser.add_argument("--apihul-root", default="<ARTIFACT_WORKSPACE>/<LOCAL_APIHULBENCH_ROOT>")
    parser.add_argument("--javap", default="javap")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / args.audit_dir
    path_a = audit_dir / "raw_response_mention_audit_blind_a.csv"
    path_b = audit_dir / "raw_response_mention_audit_blind_b.csv"
    rows_a = read_csv(path_a)
    rows_b = read_csv(path_b)
    fieldnames = list(rows_a[0].keys())
    context_fields = [field for field in fieldnames if field not in ANNOTATION_FIELDS]
    if context_hash(rows_a, context_fields) != context_hash(rows_b, context_fields):
        raise SystemExit("Blind sheets differ before annotation.")

    extracted: dict[str, tuple[list[Mention], bool, list[bool]]] = {}
    all_mentions: list[Mention] = []
    for row in rows_a:
        mentions, broken_fence, line_in_fence = extract_mentions(row.get("raw_response", ""))
        extracted[row["audit_row_id"]] = (mentions, broken_fence, line_in_fence)
        all_mentions.extend(mentions)

    apihul_root = Path(args.apihul_root).resolve()
    jar_roots = [
        apihul_root / "_validation_cache" / "maven_repository",
        Path("<LOCAL_USER_HOME>/.m2/repository"),
    ]
    jar_hits = build_jar_hits(all_mentions, jar_roots)
    roots_cache: dict[str, list[Path]] = {}
    javap_cache: dict[str, bool] = {}
    annotated_a: list[dict[str, str]] = []
    annotated_b: list[dict[str, str]] = []
    for row_a, row_b in zip(rows_a, rows_b):
        mentions, broken_fence, line_in_fence = extracted[row_a["audit_row_id"]]
        annotated_a.append(annotate_row(row_a, mentions, broken_fence, line_in_fence, apihul_root, roots_cache, jar_hits, jar_roots, args.javap, javap_cache, "A"))
        annotated_b.append(annotate_row(row_b, mentions, broken_fence, line_in_fence, apihul_root, roots_cache, jar_hits, jar_roots, args.javap, javap_cache, "B"))

    original_context_hash = context_hash(rows_a, context_fields)
    if context_hash(annotated_a, context_fields) != original_context_hash:
        raise SystemExit("A context fields changed.")
    if context_hash(annotated_b, context_fields) != original_context_hash:
        raise SystemExit("B context fields changed.")

    def summarize(rows: list[dict[str, str]]) -> dict[str, object]:
        mention_rows = sum(bool(clean(row["annotator_mentions"])) for row in rows)
        total_mentions = sum(len([part for part in row["annotator_mentions"].split(";") if part.strip()]) for row in rows)
        validity = Counter()
        surface = Counter()
        for row in rows:
            validity.update(part.strip() for part in row["mention_validity"].split(";") if part.strip())
            surface.update(part.strip() for part in row["mention_surface"].split(";") if part.strip())
        return {
            "rows": len(rows),
            "rows_with_mentions": mention_rows,
            "total_mentions": total_mentions,
            "validity_counts": dict(validity),
            "surface_counts": dict(surface),
        }

    row_disagreements = 0
    for row_a, row_b in zip(annotated_a, annotated_b):
        if (
            row_a["annotator_mentions"] != row_b["annotator_mentions"]
            or row_a["mention_surface"] != row_b["mention_surface"]
            or row_a["mention_validity"] != row_b["mention_validity"]
        ):
            row_disagreements += 1

    summary = {
        "context_hash": original_context_hash,
        "rows": len(rows_a),
        "unique_import_or_dependency_mentions_seen": len({mention.value.lower() for mention in all_mentions}),
        "maven_class_hits": len(jar_hits),
        "annotator_a": summarize(annotated_a),
        "annotator_b": summarize(annotated_b),
        "rows_with_a_b_annotation_differences": row_disagreements,
        "note": "Generated without reading raw_response_mention_audit_extractor_key.csv.",
    }
    if args.dry_run:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    write_csv(path_a, annotated_a, fieldnames)
    write_csv(path_b, annotated_b, fieldnames)
    (audit_dir / "raw_response_mention_audit_blind_annotation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
