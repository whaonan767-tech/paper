#!/usr/bin/env python3
"""Run frozen V3 selection against browser-recovered fixed-commit archives."""

from __future__ import annotations

import json
import re
import sys
import urllib.error
import zipfile
from pathlib import Path

import codex_acquire_external_java_v3 as frozen


def archive_index(output_dir: Path, snapshot_path: Path) -> dict[str, dict[str, object]]:
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    archives = output_dir / "archives"
    result: dict[str, dict[str, object]] = {}
    for rank, item in enumerate(snapshot["items"], 1):
        full_name = str(item["full_name"])
        prefix = f"rank{rank:04d}_{full_name.replace('/', '_')}_"
        matches = sorted(path for path in archives.glob(prefix + "*.zip") if path.is_file())
        if not matches:
            continue
        archive = matches[0]
        with zipfile.ZipFile(archive) as handle:
            names = handle.namelist()
        sha_matches = [re.search(r"-([0-9a-f]{40})/", name, re.IGNORECASE) for name in names[:200]]
        sha = next((match.group(1).lower() for match in sha_matches if match), None)
        if not sha:
            raise RuntimeError(f"Cannot recover full commit SHA from {archive}")
        roots = {name.split("/", 1)[0] for name in names if "/" in name}
        has_root_pom = any(f"{root}/pom.xml" in names for root in roots)
        result[full_name.lower()] = {"archive": archive, "sha": sha, "has_root_pom": has_root_pom}
    return result


def main() -> None:
    args = frozen.parse_args()
    if not args.search_snapshot:
        raise SystemExit("--search-snapshot is required for offline archive recovery")
    index = archive_index(args.output_dir, args.search_snapshot)

    def root_pom_exists(full_name: str, branch: str, timeout: float) -> bool:
        row = index.get(full_name.lower())
        return bool(row and row["has_root_pom"])

    def request_json(url: str, timeout: float) -> dict:
        match = re.fullmatch(r"https://api\.github\.com/repos/([^/]+/[^/]+)/commits/.+", url)
        if not match or match.group(1).lower() not in index:
            raise urllib.error.URLError(f"No offline response for {url}")
        return {"sha": index[match.group(1).lower()]["sha"]}

    def download_file(url: str, path: Path, timeout: float, attempts: int = 4) -> None:
        if not path.is_file():
            raise urllib.error.URLError(f"Frozen acquisition requested uncached archive: {path.name}")

    frozen.root_pom_exists = root_pom_exists
    frozen.request_json = request_json
    frozen.download_file = download_file
    sys.argv = [sys.argv[0], *sys.argv[1:]]
    frozen.main()


if __name__ == "__main__":
    main()
