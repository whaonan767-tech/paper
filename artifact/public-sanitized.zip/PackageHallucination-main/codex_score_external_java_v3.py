#!/usr/bin/env python3
"""Merge, adjudicate, and project-cluster score the external Java V3 audit."""

from __future__ import annotations

import argparse
import collections
import csv
import json
import math
import random
import re
from pathlib import Path


LABELS = {"valid", "invalid", "malformed", "uncertain"}
SURFACES = {"code", "prose", "broken_fence", "malformed", "other"}


def clean(value: object) -> str:
    return "" if value is None else str(value).strip()


def split_list(value: object) -> list[str]:
    return [part.strip() for part in clean(value).split(";") if part.strip()]


def normalize(value: object) -> str:
    text = clean(value).strip("`'\" ")
    text = re.sub(r"(?i)^import\s+(?:static\s+)?", "", text)
    text = re.sub(r"[;,.)\]}]+$", "", text)
    return re.sub(r"\s+", "", text).lower()


def read_json_rows(path: Path) -> list[dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["rows"] if isinstance(payload, dict) and "rows" in payload else payload


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def validate_completed(rows: list[dict], label: str) -> dict[str, dict]:
    if len(rows) != 200:
        raise SystemExit(f"Annotator {label}: expected 200 rows, found {len(rows)}")
    result = {}
    for row in rows:
        record_id = clean(row.get("record_id"))
        if not record_id or record_id in result:
            raise SystemExit(f"Annotator {label}: missing or duplicate record_id {record_id!r}")
        if clean(row.get("annotation_status")).lower() != "complete":
            raise SystemExit(f"Annotator {label}: incomplete record {record_id}")
        mentions = split_list(row.get("annotator_mentions"))
        surfaces = [value.lower() for value in split_list(row.get("mention_surface"))]
        validities = [value.lower() for value in split_list(row.get("mention_validity"))]
        if not (len(mentions) == len(surfaces) == len(validities)):
            raise SystemExit(f"Annotator {label}: unaligned lists for {record_id}")
        if set(surfaces) - SURFACES or set(validities) - LABELS:
            raise SystemExit(f"Annotator {label}: invalid surface/validity label for {record_id}")
        if not mentions and "no_mentions" not in clean(row.get("annotator_notes")).lower():
            raise SystemExit(f"Annotator {label}: completed negative {record_id} must include no_mentions note")
        result[record_id] = row
    return result


def aligned_triplets(row: dict, prefix: str = "annotator") -> list[tuple[str, str, str]]:
    mentions = split_list(row.get(f"{prefix}_mentions"))
    surfaces = [value.lower() for value in split_list(row.get("mention_surface" if prefix == "annotator" else f"{prefix}_surface"))]
    validities = [value.lower() for value in split_list(row.get("mention_validity" if prefix == "annotator" else f"{prefix}_validity"))]
    return [(normalize(mention), surface, validity) for mention, surface, validity in zip(mentions, surfaces, validities)]


def cohen_kappa(pairs: list[tuple[str, str]]) -> float | None:
    if not pairs:
        return None
    observed = sum(left == right for left, right in pairs) / len(pairs)
    left_counts = collections.Counter(left for left, _ in pairs)
    right_counts = collections.Counter(right for _, right in pairs)
    expected = sum(left_counts[label] * right_counts[label] for label in LABELS) / (len(pairs) ** 2)
    return 1.0 if expected == 1.0 else (observed - expected) / (1.0 - expected)


def agreement(rows_a: dict[str, dict], rows_b: dict[str, dict]) -> dict:
    intersection = total_a = total_b = union = 0
    label_pairs: list[tuple[str, str]] = []
    exact_rows = 0
    for record_id in sorted(rows_a):
        triplets_a = aligned_triplets(rows_a[record_id])
        triplets_b = aligned_triplets(rows_b[record_id])
        counter_a = collections.Counter(value for value, _, _ in triplets_a)
        counter_b = collections.Counter(value for value, _, _ in triplets_b)
        matched = counter_a & counter_b
        intersection += sum(matched.values())
        total_a += sum(counter_a.values())
        total_b += sum(counter_b.values())
        union += sum((counter_a | counter_b).values())
        labels_a: dict[str, list[str]] = collections.defaultdict(list)
        labels_b: dict[str, list[str]] = collections.defaultdict(list)
        for mention, _, label in triplets_a:
            labels_a[mention].append(label)
        for mention, _, label in triplets_b:
            labels_b[mention].append(label)
        for mention, count in matched.items():
            label_pairs.extend(zip(labels_a[mention][:count], labels_b[mention][:count]))
        if triplets_a == triplets_b:
            exact_rows += 1
    precision = intersection / total_a if total_a else None
    recall = intersection / total_b if total_b else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    return {
        "annotator_a_mentions": total_a, "annotator_b_mentions": total_b, "matched_mentions": intersection,
        "mention_set_jaccard": intersection / union if union else 1.0, "mention_set_f1": f1,
        "matched_label_pairs": len(label_pairs), "matched_label_agreement": sum(a == b for a, b in label_pairs) / len(label_pairs) if label_pairs else None,
        "cohen_kappa": cohen_kappa(label_pairs), "exact_agreement_rows": exact_rows,
    }


def merge_mode(args: argparse.Namespace) -> None:
    rows_a = validate_completed(read_json_rows(args.annotator_a_json), "A")
    rows_b = validate_completed(read_json_rows(args.annotator_b_json), "B")
    if set(rows_a) != set(rows_b):
        raise SystemExit("Annotator workbooks do not contain the same record IDs")
    merged = []
    disagreements = []
    for record_id in sorted(rows_a):
        a, b = rows_a[record_id], rows_b[record_id]
        same = aligned_triplets(a) == aligned_triplets(b)
        row = {
            "record_id": record_id, "task": a.get("task", ""), "project_id": a.get("project_id", ""),
            "project_path": a.get("project_path", ""), "file_path": a.get("file_path", ""),
            "prompt": a.get("prompt", ""), "raw_response": a.get("raw_response", ""),
            "annotator_a_mentions": a.get("annotator_mentions", ""), "annotator_a_surface": a.get("mention_surface", ""),
            "annotator_a_validity": a.get("mention_validity", ""), "annotator_a_notes": a.get("annotator_notes", ""),
            "annotator_b_mentions": b.get("annotator_mentions", ""), "annotator_b_surface": b.get("mention_surface", ""),
            "annotator_b_validity": b.get("mention_validity", ""), "annotator_b_notes": b.get("annotator_notes", ""),
            "agreement_status": "exact" if same else "adjudication_required",
            "adjudicated_mentions": a.get("annotator_mentions", "") if same else "",
            "adjudicated_surface": a.get("mention_surface", "") if same else "",
            "adjudicated_validity": a.get("mention_validity", "") if same else "",
            "adjudication_notes": "double_agreement" if same else "",
        }
        merged.append(row)
        if not same:
            disagreements.append(row)
    fields = list(merged[0])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "annotation_merged_pre_adjudication.csv", merged, fields)
    write_csv(args.output_dir / "annotation_adjudication_template.csv", disagreements, fields)
    summary = agreement(rows_a, rows_b)
    summary.update({"records": 200, "disagreement_rows": len(disagreements)})
    (args.output_dir / "annotation_agreement.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


def candidate_value(row: dict) -> str:
    return normalize(row.get("normalized_mention") or row.get("import_path") or row.get("coordinate"))


def detector_flag(row: dict) -> bool:
    if clean(row.get("detector_decision")).lower():
        return clean(row.get("detector_decision")).lower() == "flag"
    status = clean(row.get("import_classification")).lower()
    return "hallucinated" in status or status == "unresolved_external_or_hallucinated"


def load_detector(path: Path) -> dict[str, list[tuple[str, bool]]]:
    result: dict[str, list[tuple[str, bool]]] = collections.defaultdict(list)
    for row in read_csv(path):
        record_id = clean(row.get("record_id") or row.get("original_record_id"))
        value = candidate_value(row)
        if record_id and value:
            result[record_id].append((value, detector_flag(row)))
    return result


def counts_for_record(truth: list[tuple[str, str]], predictions: list[tuple[str, bool]], uncertain_mode: str = "exclude") -> dict[str, int]:
    truth_counter = collections.Counter(value for value, _ in truth)
    pred_counter = collections.Counter(value for value, _ in predictions)
    extraction_tp = sum((truth_counter & pred_counter).values())
    result = {"ext_tp": extraction_tp, "ext_fp": sum(pred_counter.values()) - extraction_tp, "ext_fn": sum(truth_counter.values()) - extraction_tp}
    truth_labels: dict[str, list[str]] = collections.defaultdict(list)
    for value, label in truth:
        truth_labels[value].append(label)
    matched_seen: collections.Counter[str] = collections.Counter()
    cls_tp = cls_fp = cls_fn = e2e_tp = e2e_fp = e2e_fn = uncertain_pred = 0
    invalid_total = 0
    for value, label in truth:
        positive = label in {"invalid", "malformed"} or (label == "uncertain" and uncertain_mode == "positive")
        known = label != "uncertain" or uncertain_mode != "exclude"
        if positive:
            invalid_total += 1
        flags_for_value = [flag for candidate, flag in predictions if candidate == value]
        occurrence = matched_seen[value]
        predicted_flag = flags_for_value[occurrence] if occurrence < len(flags_for_value) else False
        matched_seen[value] += 1
        extracted = occurrence < len(flags_for_value)
        if known and extracted:
            if predicted_flag and positive: cls_tp += 1
            elif predicted_flag and not positive: cls_fp += 1
            elif not predicted_flag and positive: cls_fn += 1
        if label == "uncertain" and uncertain_mode == "exclude":
            uncertain_pred += int(predicted_flag)
        elif predicted_flag and positive:
            e2e_tp += 1
        elif predicted_flag and not positive:
            e2e_fp += 1
        elif not predicted_flag and positive:
            e2e_fn += 1
    unmatched = collections.Counter(value for value, _ in predictions) - truth_counter
    for value, flag in predictions:
        if flag and unmatched[value] > 0:
            e2e_fp += 1
            unmatched[value] -= 1
    result.update({"cls_tp": cls_tp, "cls_fp": cls_fp, "cls_fn": cls_fn, "e2e_tp": e2e_tp, "e2e_fp": e2e_fp, "e2e_fn": e2e_fn, "uncertain_predictions": uncertain_pred, "invalid_total": invalid_total})
    return result


def metric(tp: int, fp: int, fn: int) -> dict[str, float | None]:
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    return {"precision": precision, "recall": recall, "f1": f1}


def summarize(counts: list[dict[str, int]]) -> dict:
    total = collections.Counter()
    for row in counts:
        total.update(row)
    return {
        "counts": dict(total), "extraction": metric(total["ext_tp"], total["ext_fp"], total["ext_fn"]),
        "conditional_classification": metric(total["cls_tp"], total["cls_fp"], total["cls_fn"]),
        "end_to_end": metric(total["e2e_tp"], total["e2e_fp"], total["e2e_fn"]),
    }


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * p
    low, high = math.floor(index), math.ceil(index)
    return ordered[low] if low == high else ordered[low] + (ordered[high] - ordered[low]) * (index - low)


def bootstrap(per_project_v1: dict[str, list[dict]], per_project_v2: dict[str, list[dict]], repetitions: int, seed: int) -> tuple[dict, list[dict]]:
    projects = sorted(per_project_v2)
    rng = random.Random(seed)
    draws = []
    for index in range(repetitions):
        sampled = [rng.choice(projects) for _ in projects]
        v1 = summarize([row for project in sampled for row in per_project_v1.get(project, [])])
        v2 = summarize([row for project in sampled for row in per_project_v2.get(project, [])])
        recall1 = v1["end_to_end"]["recall"]
        recall2 = v2["end_to_end"]["recall"]
        draws.append({"draw": index + 1, "v1_precision": v1["end_to_end"]["precision"], "v1_recall": recall1, "v2_precision": v2["end_to_end"]["precision"], "v2_recall": recall2, "recall_delta": None if recall1 is None or recall2 is None else recall2 - recall1})
    intervals = {}
    for key in ("v1_precision", "v1_recall", "v2_precision", "v2_recall", "recall_delta"):
        values = [row[key] for row in draws if row[key] is not None]
        intervals[key] = {"ci_low": percentile(values, 0.025), "ci_high": percentile(values, 0.975)}
    return intervals, draws


def score_mode(args: argparse.Namespace) -> None:
    merged = {row["record_id"]: row for row in read_csv(args.merged_csv)}
    adjudication = {row["record_id"]: row for row in read_csv(args.adjudication_csv)} if args.adjudication_csv else {}
    truth_by_record = {}
    project_by_record = {}
    for record_id, row in merged.items():
        update = adjudication.get(record_id, {})
        mentions = split_list(update.get("adjudicated_mentions") or row.get("adjudicated_mentions"))
        validities = [value.lower() for value in split_list(update.get("adjudicated_validity") or row.get("adjudicated_validity"))]
        surfaces = split_list(update.get("adjudicated_surface") or row.get("adjudicated_surface"))
        notes = clean(update.get("adjudication_notes") or row.get("adjudication_notes"))
        if not (len(mentions) == len(validities) == len(surfaces)):
            raise SystemExit(f"Unaligned adjudication for {record_id}")
        if not mentions and not notes:
            raise SystemExit(f"Missing adjudication for {record_id}")
        if set(validities) - LABELS:
            raise SystemExit(f"Invalid adjudicated label for {record_id}")
        truth_by_record[record_id] = list(zip(map(normalize, mentions), validities))
        project_by_record[record_id] = clean(row.get("project_id") or row.get("project_path"))

    detectors = {"v1": load_detector(args.v1_csv), "v2": load_detector(args.v2_csv)}
    modes = {}
    per_project = {}
    for uncertain_mode in ("exclude", "positive", "negative"):
        modes[uncertain_mode] = {}
        for version, predictions in detectors.items():
            counts = []
            clusters: dict[str, list[dict]] = collections.defaultdict(list)
            for record_id, truth in truth_by_record.items():
                row_counts = counts_for_record(truth, predictions.get(record_id, []), uncertain_mode)
                counts.append(row_counts)
                clusters[project_by_record[record_id]].append(row_counts)
            modes[uncertain_mode][version] = summarize(counts)
            if uncertain_mode == "exclude":
                per_project[version] = clusters
    intervals, draws = bootstrap(per_project["v1"], per_project["v2"], args.bootstrap_repetitions, args.seed)
    v1_recall = modes["exclude"]["v1"]["end_to_end"]["recall"] or 0.0
    v2_main = modes["exclude"]["v2"]
    v2_precision = v2_main["end_to_end"]["precision"] or 0.0
    v2_recall = v2_main["end_to_end"]["recall"] or 0.0
    invalid_projects = {project_by_record[record_id] for record_id, truth in truth_by_record.items() if any(label in {"invalid", "malformed"} for _, label in truth)}
    invalid_total = sum(label in {"invalid", "malformed"} for truth in truth_by_record.values() for _, label in truth)
    gate = {
        "invalid_mentions_at_least_30": invalid_total >= 30,
        "invalid_projects_at_least_10": len(invalid_projects) >= 10,
        "v2_end_to_end_precision_at_least_0_90": v2_precision >= 0.90,
        "v2_end_to_end_recall_at_least_0_40": v2_recall >= 0.40,
        "recall_delta_at_least_0_15": v2_recall - v1_recall >= 0.15,
        "recall_delta_ci_low_above_zero": (intervals["recall_delta"]["ci_low"] or -1.0) > 0,
    }
    gate["detector_prototype_claim_allowed"] = all(gate.values())
    output = {
        "artifact": "external_java_v3_scored", "records": len(truth_by_record), "projects": len(set(project_by_record.values())),
        "invalid_or_malformed_mentions": invalid_total, "projects_with_invalid_or_malformed": len(invalid_projects),
        "uncertain_sensitivity": modes, "project_clustered_bootstrap": {"repetitions": args.bootstrap_repetitions, "seed": args.seed, "intervals": intervals},
        "claim_gate": gate,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "external_v3_scored.json").write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_csv(args.output_dir / "external_v3_project_bootstrap_draws.csv", draws, list(draws[0]))
    lines = ["# External Java V3 Scored Results", "", f"- Records/projects: `{output['records']}` / `{output['projects']}`.", f"- Invalid/malformed mentions/projects: `{invalid_total}` / `{len(invalid_projects)}`.", "", "| Version | Layer | Precision | Recall | F1 |", "|---|---|---:|---:|---:|"]
    for version in ("v1", "v2"):
        for layer in ("extraction", "conditional_classification", "end_to_end"):
            values = modes["exclude"][version][layer]
            render = lambda value: "NA" if value is None else f"{value:.3f}"
            lines.append(f"| {version.upper()} | {layer} | {render(values['precision'])} | {render(values['recall'])} | {render(values['f1'])} |")
    lines.extend(["", "## Claim Gate", ""] + [f"- {key}: `{value}`" for key, value in gate.items()])
    (args.output_dir / "external_v3_scored.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"invalid_mentions": invalid_total, "claim_gate": gate}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    merge = subparsers.add_parser("merge")
    merge.add_argument("--annotator-a-json", type=Path, required=True)
    merge.add_argument("--annotator-b-json", type=Path, required=True)
    merge.add_argument("--output-dir", type=Path, required=True)
    score = subparsers.add_parser("score")
    score.add_argument("--merged-csv", type=Path, required=True)
    score.add_argument("--adjudication-csv", type=Path)
    score.add_argument("--v1-csv", type=Path, required=True)
    score.add_argument("--v2-csv", type=Path, required=True)
    score.add_argument("--output-dir", type=Path, required=True)
    score.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    score.add_argument("--seed", type=int, default=20260818)
    args = parser.parse_args()
    merge_mode(args) if args.command == "merge" else score_mode(args)


if __name__ == "__main__":
    main()
