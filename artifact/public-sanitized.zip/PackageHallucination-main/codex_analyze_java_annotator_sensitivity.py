#!/usr/bin/env python3
"""Compare Java detector metrics under Annotator A, B, and adjudicated truth."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
AUDIT_DIR = ROOT / "Tests" / "Java_APIHulBench_HumanAudit"
HELDOUT_DIR = ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731"
DEFAULT_OUTPUT = ROOT / "Tests" / "Java_APIHulBench_AnnotatorSensitivity_Run20260804"
EVALUABLE = {"valid", "invalid"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def clean(value: str | None) -> str:
    return (value or "").strip().lower()


def metric_block(rows: list[dict[str, object]]) -> dict[str, object]:
    tp = fp = fn = tn = 0
    counts = Counter()
    for row in rows:
        validity = str(row["validity"])
        counts[validity] += 1
        if validity not in EVALUABLE:
            continue
        predicted = bool(row["detector_suspicious"])
        actual = validity == "invalid"
        if predicted and actual:
            tp += 1
        elif predicted:
            fp += 1
        elif actual:
            fn += 1
        else:
            tn += 1
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision and recall else None
    return {
        "validity_counts": dict(sorted(counts.items())),
        "evaluable_rows": tp + fp + fn + tn,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    truth = read_csv(HELDOUT_DIR / "full598_final_human_truth.csv")
    initial_a = {row["audit_id"]: row for row in read_csv(AUDIT_DIR / "java_human_annotation_blind_sheet_annotator_a.csv")}
    initial_b = {row["audit_id"]: row for row in read_csv(AUDIT_DIR / "java_human_annotation_blind_sheet_annotator_b.csv")}
    heldout_a = {row["full598_index"]: row for row in read_csv(HELDOUT_DIR / "heldout_448_annotator_a.csv")}
    heldout_b = {row["full598_index"]: row for row in read_csv(HELDOUT_DIR / "heldout_448_annotator_b.csv")}

    views: dict[str, list[dict[str, object]]] = {"annotator_a": [], "annotator_b": [], "adjudicated": []}
    row_output: list[dict[str, object]] = []
    for row in truth:
        index = row["full598_index"]
        audit_id = row.get("audit_id", "")
        in_initial = clean(row.get("audited_in_150_sample")) in {"1", "true", "yes"}
        if in_initial:
            validity_a = clean(initial_a[audit_id].get("annotation_validity"))
            validity_b = clean(initial_b[audit_id].get("annotation_validity"))
        else:
            validity_a = clean(heldout_a[index].get("annotation_validity"))
            validity_b = clean(heldout_b[index].get("annotation_validity"))
        validity_final = clean(row.get("final_validity"))
        detector = clean(row.get("detector_suspicious")) in {"1", "true", "yes"}
        for name, validity in (
            ("annotator_a", validity_a),
            ("annotator_b", validity_b),
            ("adjudicated", validity_final),
        ):
            views[name].append({"validity": validity, "detector_suspicious": detector})
        row_output.append(
            {
                "full598_index": index,
                "audit_id": audit_id,
                "detector_suspicious": int(detector),
                "annotator_a_validity": validity_a,
                "annotator_b_validity": validity_b,
                "adjudicated_validity": validity_final,
            }
        )

    metrics = {name: metric_block(rows) for name, rows in views.items()}
    payload = {
        "analysis": "annotator_specific_full598_detector_sensitivity",
        "rows": len(truth),
        "adjudication": {
            "disagreements": 7,
            "adjudicator": "lead author after both independent sheets were locked",
            "third_independent_annotator": False,
            "detector_blind_during_adjudication": False,
            "reason": "the adjudication sheet retained mapping and detector fields; all seven disagreement rows were detector-unflagged",
        },
        "metrics": metrics,
    }
    (output_dir / "annotator_sensitivity.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with (output_dir / "annotator_sensitivity_rows.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row_output[0]))
        writer.writeheader()
        writer.writerows(row_output)

    lines = [
        "# Java Annotator-Sensitivity Analysis",
        "",
        "The seven held-out disagreements were adjudicated by the lead author after both independent sheets were locked. This was not a third independent annotation pass. The adjudication sheet retained mapping and detector fields, so adjudication was not detector-blind; all seven disagreement rows were detector-unflagged.",
        "",
        "| Truth view | Evaluable | TP | FP | FN | TN | Precision | Recall | F1 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for name in ("annotator_a", "annotator_b", "adjudicated"):
        item = metrics[name]
        label = name.replace("_", " ").title()
        lines.append(
            f"| {label} | {item['evaluable_rows']} | {item['tp']} | {item['fp']} | {item['fn']} | {item['tn']} | "
            f"{item['precision']:.3f} | {item['recall']:.3f} | {item['f1']:.3f} |"
        )
    lines.extend(
        [
            "",
            "The detector precision is unchanged because all seven disagreements occur on detector-unflagged rows. Recall/F1 sensitivity reflects whether those rows are treated as invalid, valid, or uncertain before adjudication.",
        ]
    )
    (output_dir / "annotator_sensitivity.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(metrics, ensure_ascii=False))


if __name__ == "__main__":
    main()
