import argparse
import csv
import importlib.util
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path


SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}
SKIP_STATUSES = {
    "not_patchable",
    "no_build_descriptor",
    "unsupported_build_system",
    "project_copy_failed",
    "baseline_failed",
    "target_file_missing",
    "mutation_error",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def load_validation_module(apihul_root):
    module_path = apihul_root / "experiments" / "validate_java_builds.py"
    spec = importlib.util.spec_from_file_location("validate_java_builds", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["validate_java_builds"] = module
    spec.loader.exec_module(module)
    return module


def unique_preserve_order(values):
    seen = set()
    out = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def import_package(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    if len(parts) <= 1:
        return import_path
    return ".".join(parts[:-1])


def load_target_records(prompts_jsonl, mapping_csv, statuses, selected_record_ids):
    prompts = {row["record_id"]: row for row in read_jsonl(Path(prompts_jsonl))}
    grouped = defaultdict(list)
    for row in csv.DictReader(Path(mapping_csv).open("r", encoding="utf-8")):
        if row.get("mapping_status") not in statuses:
            continue
        record_id = row.get("original_record_id", "")
        if selected_record_ids and record_id not in selected_record_ids:
            continue
        grouped[record_id].append(row)

    records = []
    for record_id in sorted(grouped):
        prompt = prompts.get(record_id)
        if not prompt:
            continue
        split = prompt.get("split", "")
        source_line = int(prompt.get("source_line") or 0)
        records.append(
            {
                "record_id": record_id,
                "sample_key": f"{split}:{source_line}",
                "split": split,
                "source_line": source_line,
                "project_path": prompt.get("project_path", ""),
                "file_path": prompt.get("file_path", ""),
                "ground_truth": prompt.get("ground_truth", ""),
                "suspicious_imports": unique_preserve_order(row.get("import_path", "") for row in grouped[record_id]),
                "mapping_statuses": unique_preserve_order(row.get("mapping_status", "") for row in grouped[record_id]),
            }
        )
    return records


def load_build_audit(apihul_root):
    data = json.loads((apihul_root / "outputs" / "build_validation_audit.json").read_text(encoding="utf-8"))
    return {row["sample_key"]: row for row in data["samples"]}


def apply_build_overrides(plan, audit_row, maven_args):
    if not maven_args or "maven" not in audit_row.get("build_system", ""):
        return plan
    command = list(plan["command"])
    if command:
        command = command[:-1] + list(maven_args) + command[-1:]
    plan = {**plan, "command": command}
    return plan


def insert_imports(source, imports):
    if not imports:
        return source, []
    existing = set(re.findall(r"(?m)^\s*import\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;", source))
    imports_to_add = [value for value in imports if value not in existing]
    if not imports_to_add:
        return source, []
    insertion = "\n".join(f"import {value};" for value in imports_to_add) + "\n"
    package_match = re.search(r"(?m)^\s*package\s+[A-Za-z_][\w.]*\s*;\s*(?:\r?\n)?", source)
    if package_match:
        insert_at = package_match.end()
        return source[:insert_at] + insertion + source[insert_at:], imports_to_add
    return insertion + source, imports_to_add


def suffix_score(path, expected_relative):
    path_parts = path.parts
    expected_parts = expected_relative.parts
    score = 0
    for left, right in zip(reversed(path_parts), reversed(expected_parts)):
        if left.lower() != right.lower():
            break
        score += 1
    return score


def locate_target_file(copied_project, original_project, original_file):
    expected_relative = original_file.relative_to(original_project)
    exact = copied_project / expected_relative
    if exact.exists() and exact.is_file():
        return exact, "exact"

    matches = []
    try:
        matches = [path for path in copied_project.rglob(original_file.name) if path.exists() and path.is_file()]
    except OSError:
        matches = []
    if matches:
        matches.sort(key=lambda path: suffix_score(path, expected_relative), reverse=True)
        return matches[0], "filename_fallback"

    return exact, "not_found"


def log_mentions_imports(tail, imports):
    lowered = (tail or "").lower()
    evidence = []
    for import_path in imports:
        package_path = import_package(import_path)
        if import_path.lower() in lowered or package_path.lower() in lowered:
            evidence.append(import_path)
    return evidence


def skipped_record(record, audit_row, variant, status, detail, validation, log_path="", tail=""):
    return {
        "record_id": record["record_id"],
        "sample_key": record["sample_key"],
        "split": record["split"],
        "source_line": record["source_line"],
        "project_path": audit_row.get("project_path", record.get("project_path", "")),
        "file_path": audit_row.get("file_path", record.get("file_path", "")),
        "build_root": audit_row.get("build_root", ""),
        "build_system": audit_row.get("build_system", ""),
        "build_key": validation.project_build_key(audit_row) if audit_row.get("build_root") else "",
        "variant": variant,
        "injected_imports": ";".join(record["suspicious_imports"]) if variant == "raw_suspicious_imports" else "",
        "mapping_statuses": ";".join(record["mapping_statuses"]),
        "target_resolution": "",
        "status": status,
        "failure_detail": detail,
        "return_code": "",
        "timed_out": False,
        "duration_seconds": 0.0,
        "log_path": log_path,
        "tail": tail,
        "log_mentions_injected_import": "",
    }


def build_result_record(record, audit_row, variant, injected_imports, build_result, validation):
    tail = build_result.get("tail", "")
    mentions = log_mentions_imports(tail, injected_imports)
    return {
        "record_id": record["record_id"],
        "sample_key": record["sample_key"],
        "split": record["split"],
        "source_line": record["source_line"],
        "project_path": audit_row.get("project_path", record.get("project_path", "")),
        "file_path": audit_row.get("file_path", record.get("file_path", "")),
        "build_root": audit_row.get("build_root", ""),
        "build_system": audit_row.get("build_system", ""),
        "build_key": validation.project_build_key(audit_row),
        "variant": variant,
        "injected_imports": ";".join(injected_imports),
        "mapping_statuses": ";".join(record["mapping_statuses"]),
        "target_resolution": record.get("target_resolution", ""),
        "status": build_result.get("status", ""),
        "failure_detail": build_result.get("failure_detail", ""),
        "return_code": build_result.get("return_code", ""),
        "timed_out": build_result.get("timed_out", False),
        "duration_seconds": build_result.get("duration_seconds", 0.0),
        "log_path": build_result.get("log_path", ""),
        "tail": tail,
        "log_mentions_injected_import": ";".join(mentions),
    }


def summarize(results, baselines):
    by_variant = defaultdict(list)
    for row in results:
        by_variant[row["variant"]].append(row)

    variants = {}
    for variant, rows in sorted(by_variant.items()):
        runnable = [row for row in rows if row["status"] not in SKIP_STATUSES]
        variants[variant] = {
            "total_records": len(rows),
            "runnable_records": len(runnable),
            "pass": sum(row["status"] == "pass" for row in runnable),
            "status_counts": dict(Counter(row["status"] for row in rows).most_common()),
            "failure_details": dict(
                Counter(row.get("failure_detail", row["status"]) for row in rows if row["status"] != "pass").most_common()
            ),
        }

    paired = {"baseline_pass_records": 0, "raw_fail_sanitized_pass": 0, "raw_pass_sanitized_pass": 0, "other": 0}
    grouped = defaultdict(dict)
    for row in results:
        grouped[row["record_id"]][row["variant"]] = row
    for variants_for_record in grouped.values():
        raw = variants_for_record.get("raw_suspicious_imports", {})
        sanitized = variants_for_record.get("sanitized_removed_imports", {})
        if raw.get("status") in SKIP_STATUSES:
            continue
        paired["baseline_pass_records"] += 1
        if raw.get("status") != "pass" and sanitized.get("status") == "pass":
            paired["raw_fail_sanitized_pass"] += 1
        elif raw.get("status") == "pass" and sanitized.get("status") == "pass":
            paired["raw_pass_sanitized_pass"] += 1
        else:
            paired["other"] += 1

    return {
        "baseline_build_units_total": len(baselines),
        "baseline_build_units_pass": sum(row["status"] == "pass" for row in baselines),
        "baseline_status_counts": dict(Counter(row["status"] for row in baselines).most_common()),
        "variants": variants,
        "paired_outcomes": paired,
    }


def write_csv(path, rows):
    if not rows:
        return
    fieldnames = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, payload):
    summary = payload["summary"]
    lines = [
        "# Java Import Build Probe",
        "",
        f"- Run name: `{payload['run_name']}`",
        f"- Target records: `{payload['target_records']}`",
        f"- Timeout: `{payload['timeout_seconds']}` seconds per build",
        f"- Work root: `{payload['work_root']}`",
        "",
        "## Baselines",
        "",
        f"- Build units passing baseline: `{summary['baseline_build_units_pass']} / {summary['baseline_build_units_total']}`",
        "",
        "| Baseline status | Count |",
        "|---|---:|",
    ]
    for status, count in summary["baseline_status_counts"].items():
        lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Variant Outcomes",
            "",
            "| Variant | Total records | Runnable records | Pass | Status counts |",
            "|---|---:|---:|---:|---|",
        ]
    )
    for variant, row in summary["variants"].items():
        lines.append(
            f"| `{variant}` | {row['total_records']} | {row['runnable_records']} | {row['pass']} | `{row['status_counts']}` |"
        )

    paired = summary["paired_outcomes"]
    lines.extend(
        [
            "",
            "## Paired Build-Level Signal",
            "",
            f"- Baseline-pass target records: `{paired['baseline_pass_records']}`",
            f"- Raw suspicious imports fail while sanitized imports pass: `{paired['raw_fail_sanitized_pass']}`",
            f"- Raw suspicious imports still pass and sanitized imports pass: `{paired['raw_pass_sanitized_pass']}`",
            f"- Other paired outcomes: `{paired['other']}`",
            "",
            "## Per-Record Results",
            "",
            "| Record | Sample | Variant | Status | Detail | Injected imports | Evidence in log | Log |",
            "|---|---|---|---|---|---|---|---|",
        ]
    )
    for row in payload["results"]:
        injected = row.get("injected_imports", "").replace("|", "\\|")
        evidence = row.get("log_mentions_injected_import", "").replace("|", "\\|")
        lines.append(
            f"| `{row['record_id']}` | `{row['sample_key']}` | `{row['variant']}` | `{row['status']}` | "
            f"`{row.get('failure_detail', '')}` | `{injected}` | `{evidence}` | `{row.get('log_path', '')}` |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--timeout", type=int, default=90)
    parser.add_argument("--record-id", action="append", default=[])
    parser.add_argument("--statuses", nargs="*", default=sorted(SUSPICIOUS_STATUSES))
    parser.add_argument("--maven-arg", action="append", default=[], help="Extra Maven argument inserted before the build goal.")
    parser.add_argument("--maven-opt", action="append", default=[], help="Extra MAVEN_OPTS token for build subprocesses.")
    parser.add_argument("--force-local-maven", action="store_true", help="Build the audited Maven build root directly instead of the highest reactor root.")
    args = parser.parse_args()

    if args.maven_opt:
        os.environ["MAVEN_OPTS"] = (os.environ.get("MAVEN_OPTS", "") + " " + " ".join(args.maven_opt)).strip()

    apihul_root = Path(args.apihul_root).resolve()
    validation = load_validation_module(apihul_root)
    run_name = args.run_name or datetime.now().strftime("java_import_build_probe_%Y%m%d_%H%M%S")
    output_root = Path(args.output_dir).resolve()
    run_root = output_root / run_name
    if run_root.exists():
        raise SystemExit(f"Run directory already exists: {run_root}")
    (run_root / "logs").mkdir(parents=True, exist_ok=True)

    statuses = set(args.statuses)
    selected_record_ids = set(args.record_id)
    records = load_target_records(args.prompts_jsonl, args.mapping_csv, statuses, selected_record_ids)
    audit = load_build_audit(apihul_root)

    target_rows = []
    for record in records:
        audit_row = audit.get(record["sample_key"], {})
        target_rows.append({**record, "audit_available": bool(audit_row), "build_system": audit_row.get("build_system", "")})

    results = []
    baselines = []
    project_to_records = defaultdict(list)
    for record in records:
        audit_row = audit.get(record["sample_key"])
        if not audit_row:
            empty = {}
            for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                results.append(skipped_record(record, empty, variant, "no_build_descriptor", "missing_build_audit", validation))
            continue
        if audit_row.get("patch_status") not in validation.PATCHABLE_STATUSES:
            for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                results.append(
                    skipped_record(record, audit_row, variant, "not_patchable", audit_row.get("patch_status", ""), validation)
                )
            continue
        if audit_row.get("build_system") == "none" or not audit_row.get("build_root"):
            for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                results.append(skipped_record(record, audit_row, variant, "no_build_descriptor", "no_build_descriptor", validation))
            continue
        if audit_row.get("build_system") not in validation.SUPPORTED_BUILD_SYSTEMS:
            for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                results.append(
                    skipped_record(
                        record,
                        audit_row,
                        variant,
                        "unsupported_build_system",
                        audit_row.get("build_system", ""),
                        validation,
                    )
                )
            continue
        project_to_records[audit_row["project_path"]].append((record, audit_row))

    for project_index, (project_path, project_records) in enumerate(project_to_records.items(), start=1):
        original_project = validation.normalize_workspace_path(project_path)
        copied_project = run_root / f"p{project_index:03d}"
        copy_log = run_root / "logs" / f"project_{project_index:03d}_copy.log"
        print(f"COPY {original_project} -> {copied_project}", flush=True)
        copied, copy_error = validation.copy_project_tree(original_project, copied_project, copy_log)
        if not copied:
            for record, audit_row in project_records:
                for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                    results.append(
                        skipped_record(
                            record,
                            audit_row,
                            variant,
                            "project_copy_failed",
                            "project_copy_failed",
                            validation,
                            validation.display_path(copy_log),
                            copy_error,
                        )
                    )
            continue

        build_groups = defaultdict(list)
        for record, audit_row in project_records:
            build_groups[validation.project_build_key(audit_row)].append((record, audit_row))

        for build_index, (build_key, build_records) in enumerate(build_groups.items(), start=1):
            first_record, first_audit = build_records[0]
            baseline_log = run_root / "logs" / f"project_{project_index:03d}_build_{build_index:03d}_baseline.log"
            plan = {}
            command = []
            try:
                plan = validation.build_plan(first_audit, copied_project, force_local=args.force_local_maven)
                plan = apply_build_overrides(plan, first_audit, args.maven_arg)
                command = plan["command"]
                print(f"BASELINE {build_key}: {' '.join(command)}", flush=True)
                baseline = validation.run_build(command, plan["cwd"], args.timeout, baseline_log)
                if (
                    not args.force_local_maven
                    and "maven" in first_audit["build_system"]
                    and validation.should_retry_local_maven(baseline)
                ):
                    retry_plan = validation.build_plan(first_audit, copied_project, force_local=True)
                    retry_plan = apply_build_overrides(retry_plan, first_audit, args.maven_arg)
                    if retry_plan["cwd"] != plan["cwd"] or retry_plan["command"] != command:
                        retry_log = run_root / "logs" / f"project_{project_index:03d}_build_{build_index:03d}_baseline_local_retry.log"
                        print(f"RETRY BASELINE {build_key}: {' '.join(retry_plan['command'])}", flush=True)
                        baseline = validation.run_build(retry_plan["command"], retry_plan["cwd"], args.timeout, retry_log)
                        plan = retry_plan
                        command = retry_plan["command"]
            except Exception as error:
                baseline = {
                    "return_code": "",
                    "timed_out": False,
                    "duration_seconds": 0.0,
                    "status": "baseline_command_failed",
                    "failure_detail": str(error),
                    "log_path": "",
                    "tail": "",
                }
            baseline_record = {
                "project_path": first_audit["project_path"],
                "build_root": first_audit["build_root"],
                "build_system": first_audit["build_system"],
                "build_key": build_key,
                "variant": "original_project_baseline",
                "command": " ".join(command),
                "reactor_root": plan.get("reactor_root", ""),
                "module_path": plan.get("module_path", ""),
                **baseline,
            }
            baselines.append(baseline_record)

            if baseline.get("status") != "pass":
                for record, audit_row in build_records:
                    for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                        results.append(
                            skipped_record(
                                record,
                                audit_row,
                                variant,
                                "baseline_failed",
                                baseline.get("failure_detail", baseline.get("status", "")),
                                validation,
                                baseline.get("log_path", ""),
                                baseline.get("tail", ""),
                            )
                        )
                continue

            for record, audit_row in build_records:
                original_file = validation.normalize_workspace_path(audit_row["file_path"])
                target_file, target_resolution = locate_target_file(copied_project, original_project, original_file)
                record["target_resolution"] = target_resolution
                if not target_file.exists():
                    for variant in ["raw_suspicious_imports", "sanitized_removed_imports"]:
                        results.append(
                            skipped_record(
                                record,
                                audit_row,
                                variant,
                                "target_file_missing",
                                f"{target_resolution}:{target_file}",
                                validation,
                            )
                        )
                    continue

                original_source = target_file.read_text(encoding="utf-8", errors="replace")
                variants = [
                    ("raw_suspicious_imports", record["suspicious_imports"]),
                    ("sanitized_removed_imports", []),
                ]
                for variant_index, (variant, imports) in enumerate(variants, start=1):
                    log_path = run_root / "logs" / f"{record['record_id']}_{variant}.log"
                    try:
                        mutated_source, injected_imports = insert_imports(original_source, imports)
                        target_file.write_text(mutated_source, encoding="utf-8")
                        print(f"BUILD {record['record_id']} {variant}: {len(injected_imports)} imports", flush=True)
                        build_result = validation.run_build(command, plan["cwd"], args.timeout, log_path)
                        results.append(build_result_record(record, audit_row, variant, injected_imports, build_result, validation))
                    except Exception as error:
                        results.append(
                            skipped_record(record, audit_row, variant, "mutation_error", str(error), validation)
                        )
                    finally:
                        target_file.write_text(original_source, encoding="utf-8")

    summary = summarize(results, baselines)
    payload = {
        "run_name": run_name,
        "work_root": validation.display_path(run_root),
        "timeout_seconds": args.timeout,
        "maven_args": args.maven_arg,
        "maven_opts": args.maven_opt,
        "force_local_maven": args.force_local_maven,
        "target_records": len(records),
        "statuses": sorted(statuses),
        "target_rows": target_rows,
        "summary": summary,
        "baselines": baselines,
        "results": results,
    }
    json_path = run_root / "java_import_build_probe.json"
    csv_path = run_root / "java_import_build_probe.csv"
    md_path = run_root / "java_import_build_probe.md"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(csv_path, baselines + results)
    write_markdown(md_path, payload)
    print(json.dumps({"output_md": str(md_path), "summary": summary}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
