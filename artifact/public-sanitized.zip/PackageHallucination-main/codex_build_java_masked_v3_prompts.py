#!/usr/bin/env python3
"""Build leakage-audited JSON infill prompts for masked-import V3 validation."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

import codex_java_masked_baseline_audit as baseline
import codex_java_masked_necessity_probe as necessity


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
PROMPTS = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730"
    / "prompts.jsonl"
)
NECESSITY = (
    ROOT
    / "Tests"
    / "Java_APIHulBench_MaskedSemanticBuild_NecessityFull83_TestCompile_Run20260803"
    / "masked_necessity_probe.json"
)
BUILD_AUDIT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>" / "outputs" / "build_validation_audit.json"
DEFAULT_OUTPUT = ROOT / "Tests"
MARKER = "/*__DEPENDENCY_CODE_FILL__*/"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, default=PROMPTS)
    parser.add_argument("--necessity", type=Path, default=NECESSITY)
    parser.add_argument("--build-audit", type=Path, default=BUILD_AUDIT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--prefix-chars", type=int, default=6000)
    parser.add_argument("--suffix-chars", type=int, default=3000)
    return parser.parse_args()


def window_source(source: str, prefix_chars: int, suffix_chars: int) -> str:
    marker_index = source.index(MARKER)
    marker_end = marker_index + len(MARKER)
    start = max(0, marker_index - prefix_chars)
    end = min(len(source), marker_end + suffix_chars)
    local = source[start:end]
    if start == 0:
        return local

    header_end = 0
    for token in ("\npublic class ", "\nclass ", "\npublic interface ", "\ninterface ", "\npublic enum ", "\nenum "):
        found = source.find(token)
        if found >= 0:
            header_end = max(header_end, found + 1)
    header = source[: min(header_end or 2500, 3500)]
    return header + "\n// ... unchanged earlier code omitted ...\n" + local


def build_prompt(record: dict, source_window: str) -> str:
    return (
        "You are completing one hidden Java source span inside a real project.\n\n"
        "Return exactly one JSON object and no Markdown or prose:\n"
        '{"replacement":"<Java text replacing only the marker>",'
        '"imports":["fully.qualified.ClassName"]}\n\n'
        "Rules:\n"
        f"1. Replace only {MARKER}. Do not repeat code before or after the marker.\n"
        "2. The replacement must fit the shown suffix exactly; do not add enclosing class or method braces unless the marker itself requires them.\n"
        "3. List every missing non-JDK import required anywhere in the shown source window, including annotations and simple names around the marker even when the replacement itself does not mention them. Use an empty list only when the whole shown window needs no missing non-JDK import.\n"
        "4. Do not invent dependencies, helper methods, classes, comments, or unrelated behavior.\n"
        "5. JSON strings must escape newlines and quotation marks correctly.\n\n"
        f"Project path: {record['project_path']}\n"
        f"Source path: {record['file_path']}\n\n"
        "Java source window:\n"
        f"{source_window}\n"
    )


def main() -> None:
    args = parse_args()
    validation = baseline.load_validation_module()
    prompts = baseline.read_jsonl(args.prompts.resolve())
    prompts_by_id = {row["record_id"]: row for row in prompts}
    necessity_payload = json.loads(args.necessity.resolve().read_text(encoding="utf-8"))
    eligible_ids = sorted(
        row["record_id"]
        for row in necessity_payload["results"]
        if row["target_failure_evidence"]
    )
    samples = validation.load_samples()
    audit_payload = json.loads(args.build_audit.resolve().read_text(encoding="utf-8"))
    audit_by_key = {row["sample_key"]: row for row in audit_payload["samples"]}

    run_name = args.run_name or datetime.now().strftime(
        "Java_APIHulBench_MaskedV3StructuredPrompts_Run%Y%m%d_%H%M%S"
    )
    output_dir = args.output_root.resolve() / run_name
    if output_dir.exists():
        raise SystemExit(f"Output exists: {output_dir}")
    output_dir.mkdir(parents=True)

    output_rows = []
    audit_rows = []
    for record_id in eligible_ids:
        old = prompts_by_id[record_id]
        key = baseline.sample_key(old)
        sample = samples[key]
        audit = audit_by_key[key]
        source_path = validation.normalize_workspace_path(old["file_path"])
        source = source_path.read_text(encoding="utf-8", errors="strict")
        marked, patch_meta = validation.patch_ground_truth(
            source,
            sample["incomplete_function"],
            sample["ground_truth"],
            MARKER,
        )
        masked, removed = necessity.remove_imports(marked, old["masked_external_imports"])
        if len(removed) != len(old["masked_external_imports"]):
            raise RuntimeError(f"Could not remove every hidden import for {record_id}")
        if masked.count(MARKER) != 1:
            raise RuntimeError(f"Marker count is not one for {record_id}")
        source_window = window_source(masked, args.prefix_chars, args.suffix_chars)
        prompt_text = build_prompt(old, source_window)
        leaked_fqns = [value for value in old["masked_external_imports"] if value in prompt_text]
        if leaked_fqns:
            raise RuntimeError(f"Hidden FQN leaked for {record_id}: {leaked_fqns}")
        output_rows.append(
            {
                "record_id": record_id,
                "source_line": old["source_line"],
                "dataset": old["dataset"],
                "split": old["split"],
                "task": "java_masked_v3_structured_infill",
                "project_path": old["project_path"],
                "file_path": old["file_path"],
                "source_set": old["source_set"],
                "build_key": validation.project_build_key(audit),
                "incomplete_function": sample["incomplete_function"],
                "ground_truth": sample["ground_truth"],
                "masked_external_imports": old["masked_external_imports"],
                "prompt": prompt_text,
            }
        )
        audit_rows.append(
            {
                "record_id": record_id,
                "marker_count": prompt_text.count(MARKER),
                "hidden_fqn_leaks": leaked_fqns,
                "prompt_characters": len(prompt_text),
                "source_window_characters": len(source_window),
                "ground_truth_characters": len(sample["ground_truth"]),
                "ground_truth_other_occurrences": max(
                    0, source.count(sample["ground_truth"]) - 1
                ),
                "source_start": patch_meta["source_start"],
                "source_end": patch_meta["source_end"],
            }
        )

    prompts_path = output_dir / "prompts.jsonl"
    with prompts_path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in output_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    audit_payload = {
        "run_name": run_name,
        "records": len(output_rows),
        "projects": len({row["project_path"] for row in output_rows}),
        "build_units": len({row["build_key"] for row in output_rows}),
        "hidden_imports": sum(len(row["masked_external_imports"]) for row in output_rows),
        "marker": MARKER,
        "input_sha256": baseline.sha256(args.prompts.resolve()),
        "necessity_sha256": baseline.sha256(args.necessity.resolve()),
        "prompts_sha256": baseline.sha256(prompts_path),
        "prompt_characters": {
            "min": min(row["prompt_characters"] for row in audit_rows),
            "max": max(row["prompt_characters"] for row in audit_rows),
            "mean": sum(row["prompt_characters"] for row in audit_rows) / len(audit_rows),
        },
        "ground_truth_other_occurrence_counts": dict(
            Counter(row["ground_truth_other_occurrences"] for row in audit_rows)
        ),
        "rows": audit_rows,
    }
    (output_dir / "prompt_audit.json").write_text(
        json.dumps(audit_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    lines = [
        "# Masked V3 Structured Prompt Audit",
        "",
        f"- Records: `{audit_payload['records']}`.",
        f"- Projects: `{audit_payload['projects']}`.",
        f"- Build units: `{audit_payload['build_units']}`.",
        f"- Hidden imports: `{audit_payload['hidden_imports']}`.",
        "- Marker count: exactly one in every prompt.",
        "- Hidden fully qualified import leaks: zero.",
        f"- Prompt characters: min `{audit_payload['prompt_characters']['min']}`, mean `{audit_payload['prompt_characters']['mean']:.1f}`, max `{audit_payload['prompt_characters']['max']}`.",
        f"- Prompt SHA-256: `{audit_payload['prompts_sha256']}`.",
    ]
    (output_dir / "prompt_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
