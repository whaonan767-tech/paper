#!/usr/bin/env python3
"""Build exactly 200 deterministic two-arm prompts from 30 V3 repositories."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from codex_build_external_v3_exclusions import family


IMPORT_RE = re.compile(r"(?m)^[ \t]*import[ \t]+(?P<value>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s*;[ \t]*(?:\r?\n|$)")
PACKAGE_RE = re.compile(r"(?m)^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\s*;")
COMMON_TARGET_FAMILIES = {
    "org.junit.jupiter", "org.junit", "org.slf4j", "org.springframework.boot",
    "com.fasterxml.jackson", "com.google.common", "lombok",
}


def stable_key(seed: str, value: str) -> str:
    return hashlib.sha256(f"{seed}:{value}".encode()).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def nearest_pom(path: Path, root: Path) -> Path | None:
    current = path.parent
    while current == root or root in current.parents:
        pom = current / "pom.xml"
        if pom.is_file():
            return pom
        if current == root:
            break
        current = current.parent
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--acquisition-dir", type=Path, required=True)
    parser.add_argument("--exclusions", type=Path, required=True)
    parser.add_argument("--output-jsonl", type=Path, required=True)
    parser.add_argument("--seed", default="20260818")
    args = parser.parse_args()
    acquisition = json.loads((args.acquisition_dir / "metadata" / "external_project_acquisition_v3.json").read_text(encoding="utf-8"))
    exclusions = json.loads(args.exclusions.read_text(encoding="utf-8"))
    excluded_families = set(exclusions["api_families"])
    projects = acquisition["selected"]
    if len(projects) != 30:
        raise SystemExit(f"Expected 30 projects, found {len(projects)}")
    project_order = sorted(projects, key=lambda row: stable_key(args.seed, row["full_name"]))
    quotas = {row["full_name"]: (7 if index < 20 else 6) for index, row in enumerate(project_order)}

    candidates_by_project: dict[str, list[dict]] = {}
    for project in projects:
        root = args.acquisition_dir / project["project_relative_path"]
        owned = set(project.get("api_families", []))
        candidates = []
        for path in root.rglob("*.java"):
            relative = path.relative_to(root)
            parts_lower = {part.lower() for part in relative.parts}
            if {"target", "build", ".git"} & parts_lower:
                continue
            if not any(relative.parts[index:index + 3] == ("src", "main", "java") for index in range(max(0, len(relative.parts) - 2))):
                continue
            try:
                source = path.read_text(encoding="utf-8", errors="strict")
            except (OSError, UnicodeError):
                continue
            if not 800 <= len(source) <= 12_000:
                continue
            package_match = PACKAGE_RE.search(source)
            package_family = family(package_match.group(1)) if package_match else ""
            owned_here = owned | ({package_family} if package_family else set())
            for match in IMPORT_RE.finditer(source):
                target = match.group("value")
                target_family = family(target)
                if not target_family or target_family in COMMON_TARGET_FAMILIES or target_family in owned_here or target_family in excluded_families:
                    continue
                if source.count(target) != 1:
                    continue
                simple = target.rsplit(".", 1)[-1]
                body = source[match.end():]
                if not re.search(rf"\b{re.escape(simple)}\b", body):
                    continue
                pom = nearest_pom(path, root)
                if pom is None:
                    continue
                key = stable_key(args.seed, f"{project['full_name']}:{relative.as_posix()}:{target}")
                candidates.append({
                    "key": key, "path": path, "relative": relative.as_posix(), "source": source,
                    "target": target, "target_family": target_family, "match_start": match.start(), "match_end": match.end(),
                    "module_pom": pom.relative_to(root).as_posix(),
                })
        candidates.sort(key=lambda row: row["key"])
        quota = quotas[project["full_name"]]
        if len(candidates) < quota:
            raise SystemExit(f"{project['full_name']} has only {len(candidates)} eligible disjoint required-import records; needs {quota}")
        candidates_by_project[project["full_name"]] = candidates[:quota]

    flat = []
    for project in projects:
        for candidate in candidates_by_project[project["full_name"]]:
            flat.append((stable_key(args.seed + ":arm", candidate["key"]), project, candidate))
    flat.sort(key=lambda item: item[0])
    arm_a_keys = {candidate["key"] for _, _, candidate in flat[:100]}
    rows = []
    counters: dict[str, int] = {}
    for _, project, candidate in sorted(flat, key=lambda item: (item[1]["full_name"], item[2]["key"])):
        project_name = project["full_name"]
        counters[project_name] = counters.get(project_name, 0) + 1
        source = candidate["source"]
        masked = source[:candidate["match_start"]] + "// [MISSING_IMPORT]\n" + source[candidate["match_end"]:]
        arm = "natural_code_repair" if candidate["key"] in arm_a_keys else "dependency_advice"
        if arm == "natural_code_repair":
            instruction = "A required Java import was replaced by // [MISSING_IMPORT]. Repair the file for the developer. Respond naturally; you may return code, an import, or a brief explanation."
        else:
            instruction = "A required Java import was replaced by // [MISSING_IMPORT]. Identify the missing import and any dependency declaration the developer may need. You may use prose, Java, Maven, or Gradle notation."
        record_id = f"V3_P{projects.index(project) + 1:03d}_{counters[project_name]:02d}"
        rows.append({
            "record_id": record_id, "dataset": "prospective_external_java_v3", "split": "external_frozen",
            "task": arm, "project_id": project_name, "project_owner": project["owner"],
            "project_commit": project["commit_sha"], "project_path": f"{args.acquisition_dir.name}/{project['project_relative_path']}",
            "file_path": f"{args.acquisition_dir.name}/{project['project_relative_path']}/{candidate['relative']}",
            "project_relative_path": project["project_relative_path"], "relative_file_path": candidate["relative"],
            "module_pom": candidate["module_pom"], "target_api_family": candidate["target_family"],
            "ground_truth": f"import {candidate['target']};", "ground_truth_import": candidate["target"],
            "source_sha256": sha256_text(source), "prompt": instruction + "\n\n" + masked,
        })
    if len(rows) != 200 or sum(row["task"] == "natural_code_repair" for row in rows) != 100:
        raise AssertionError("Prompt allocation must be exactly 200 records with 100 records per arm")
    args.output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = {
        "artifact": "external_java_v3_prompts", "records": len(rows), "projects": len(projects),
        "arms": {name: sum(row["task"] == name for row in rows) for name in ("natural_code_repair", "dependency_advice")},
        "project_record_counts": {name: sum(row["project_id"] == name for row in rows) for name in sorted(counters)},
        "seed": args.seed,
    }
    args.output_jsonl.with_suffix(".summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
