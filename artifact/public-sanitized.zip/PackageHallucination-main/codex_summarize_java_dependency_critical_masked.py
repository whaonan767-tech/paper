import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def count_by(rows, key):
    return dict(Counter(row.get(key, "") for row in rows))


def generated_imports_by_source_line(candidate_rows):
    grouped = defaultdict(set)
    for row in candidate_rows:
        if row.get("kind") == "java_import" and row.get("import_path"):
            grouped[str(row.get("source_line", ""))].add(row["import_path"])
    return grouped


def summarize(args):
    prompt_rows_all = read_jsonl(Path(args.prompts_jsonl))
    prompt_by_id = {row.get("record_id", ""): row for row in prompt_rows_all}
    responses = read_jsonl(Path(args.responses_jsonl))
    candidates = read_csv(Path(args.candidates_csv))
    maven_rows = read_csv(Path(args.maven_validation_csv))
    mapping_rows = read_csv(Path(args.import_mapping_csv))
    response_record_by_line = {
        str(line_no): row.get("record_id", "")
        for line_no, row in enumerate(responses, start=1)
    }

    imports_by_line = generated_imports_by_source_line(candidates)
    target_rows = []
    masked_import_total = 0
    exact_recovered_total = 0
    records_any_recovered = 0
    records_all_recovered = 0
    for response_line, response in enumerate(responses, start=1):
        record_id = response.get("record_id", "")
        prompt = prompt_by_id.get(record_id, {})
        targets = prompt.get("masked_external_imports", [])
        generated = sorted(imports_by_line.get(str(response_line), set()))
        recovered = [import_path for import_path in targets if import_path in generated]
        masked_import_total += len(targets)
        exact_recovered_total += len(recovered)
        if recovered:
            records_any_recovered += 1
        if targets and len(recovered) == len(targets):
            records_all_recovered += 1
        target_rows.append(
            {
                "record_id": record_id,
                "split": response.get("split", ""),
                "source_set": prompt.get("source_set", ""),
                "masked_imports": targets,
                "generated_imports": generated,
                "exact_recovered_imports": recovered,
                "exact_recovered_count": len(recovered),
                "masked_import_count": len(targets),
            }
        )

    suspicious_rows = [
        row for row in mapping_rows if row.get("mapping_status") in SUSPICIOUS_MAPPING_STATUSES
    ]
    suspicious_records = sorted({row.get("original_record_id", "") for row in suspicious_rows if row.get("original_record_id")})
    invalid_coordinate_rows = [
        {
            **row,
            "original_record_id": response_record_by_line.get(str(row.get("source_line", "")), ""),
        }
        for row in maven_rows
        if row.get("validation_status") in {"not_found", "missing_coordinate"}
    ]
    invalid_coordinate_records = sorted(
        {row.get("original_record_id", "") for row in invalid_coordinate_rows if row.get("original_record_id")}
    )
    detector_records_union = sorted(set(suspicious_records) | set(invalid_coordinate_records))

    maven_counts = count_by(maven_rows, "validation_status")
    mapping_counts = count_by(mapping_rows, "mapping_status")
    candidate_kind_counts = count_by(candidates, "kind")

    summary = {
        "prompts_jsonl": args.prompts_jsonl,
        "responses_jsonl": args.responses_jsonl,
        "records": len(responses),
        "candidate_rows": len(candidates),
        "candidate_kind_counts": candidate_kind_counts,
        "maven_validation_status_counts": maven_counts,
        "import_mapping_status_counts": mapping_counts,
        "masked_imports": masked_import_total,
        "exact_target_import_recovered": exact_recovered_total,
        "exact_target_import_recall": exact_recovered_total / masked_import_total if masked_import_total else None,
        "records_any_target_recovered": records_any_recovered,
        "records_all_targets_recovered": records_all_recovered,
        "suspicious_import_rows": len(suspicious_rows),
        "records_with_suspicious_import": len(suspicious_records),
        "suspicious_records": suspicious_records,
        "invalid_coordinate_rows": len(invalid_coordinate_rows),
        "records_with_invalid_coordinate": len(invalid_coordinate_records),
        "invalid_coordinate_records": invalid_coordinate_records,
        "detector_evidence_records_union": detector_records_union,
        "records_with_detector_evidence": len(detector_records_union),
        "query_error_rows": maven_counts.get("query_error", 0),
        "target_recovery_rows": target_rows,
        "suspicious_import_examples": suspicious_rows[:50],
        "invalid_coordinate_examples": invalid_coordinate_rows[:50],
    }
    return summary


def write_markdown(path, summary):
    lines = [
        "# Java Dependency-Critical Masked-Import Summary",
        "",
        f"- Prompts: `{summary['prompts_jsonl']}`",
        f"- Responses: `{summary['responses_jsonl']}`",
        f"- Records evaluated: `{summary['records']}`",
        f"- Extracted candidate rows: `{summary['candidate_rows']}`",
        f"- Masked gold imports: `{summary['masked_imports']}`",
        f"- Exact target imports recovered: `{summary['exact_target_import_recovered']}`",
        f"- Exact target import recall: `{summary['exact_target_import_recall']:.4f}`",
        f"- Records with any target import recovered: `{summary['records_any_target_recovered']}`",
        f"- Records with all target imports recovered: `{summary['records_all_targets_recovered']}`",
        f"- Invalid coordinate rows: `{summary['invalid_coordinate_rows']}`",
        f"- Records with invalid coordinates: `{summary['records_with_invalid_coordinate']}`",
        f"- Query-error rows: `{summary['query_error_rows']}`",
        f"- Suspicious import rows: `{summary['suspicious_import_rows']}`",
        f"- Records with suspicious imports: `{summary['records_with_suspicious_import']}`",
        f"- Records with any detector evidence: `{summary['records_with_detector_evidence']}`",
        "",
        "## Candidate Kinds",
        "",
        "| Kind | Count |",
        "|---|---:|",
    ]
    for key, count in sorted(summary["candidate_kind_counts"].items()):
        lines.append(f"| `{key}` | {count} |")

    lines.extend(["", "## Maven Validation", "", "| Status | Count |", "|---|---:|"])
    for key, count in sorted(summary["maven_validation_status_counts"].items()):
        lines.append(f"| `{key}` | {count} |")

    lines.extend(["", "## Import Mapping", "", "| Status | Count |", "|---|---:|"])
    for key, count in sorted(summary["import_mapping_status_counts"].items()):
        lines.append(f"| `{key}` | {count} |")

    if summary["suspicious_import_examples"]:
        lines.extend(["", "## Suspicious Imports", "", "| Import | Status | Record | Reason |", "|---|---|---|---|"])
        for row in summary["suspicious_import_examples"][:30]:
            lines.append(
                f"| `{row.get('import_path', '')}` | `{row.get('mapping_status', '')}` | "
                f"`{row.get('original_record_id', '')}` | {row.get('mapping_reason', '')} |"
            )

    if summary["invalid_coordinate_examples"]:
        lines.extend(["", "## Invalid Coordinates", "", "| Coordinate | Status | Record |", "|---|---|---|"])
        for row in summary["invalid_coordinate_examples"][:30]:
            lines.append(
                f"| `{row.get('coordinate', '')}` | `{row.get('validation_status', '')}` | "
                f"`{row.get('original_record_id', '')}` |"
            )

    lines.extend(["", "## Target Recovery Samples", "", "| Record | Masked | Recovered |", "|---|---|---|"])
    for row in summary["target_recovery_rows"][:30]:
        lines.append(
            f"| `{row['record_id']}` | `{'; '.join(row['masked_imports'])}` | "
            f"`{'; '.join(row['exact_recovered_imports'])}` |"
        )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--candidates-csv", required=True)
    parser.add_argument("--maven-validation-csv", required=True)
    parser.add_argument("--import-mapping-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    summary = summarize(args)
    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), summary)
    printable = {
        key: summary[key]
        for key in [
            "records",
            "candidate_rows",
            "masked_imports",
            "exact_target_import_recovered",
            "exact_target_import_recall",
            "invalid_coordinate_rows",
            "query_error_rows",
            "suspicious_import_rows",
            "records_with_suspicious_import",
            "records_with_detector_evidence",
        ]
    }
    print(json.dumps(printable, indent=2))


if __name__ == "__main__":
    main()
