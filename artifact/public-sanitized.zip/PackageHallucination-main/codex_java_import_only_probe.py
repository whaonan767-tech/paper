import argparse
import csv
import json
import re
import shutil
import subprocess
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path


SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def unique_preserve_order(values):
    seen = set()
    out = []
    for value in values:
        value = (value or "").strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def import_package(import_path):
    parts = [part for part in import_path.split(".") if part and part != "*"]
    if len(parts) <= 1:
        return import_path
    return ".".join(parts[:-1])


def safe_class_suffix(record_id):
    cleaned = re.sub(r"[^A-Za-z0-9_]", "_", record_id)
    if not cleaned or cleaned[0].isdigit():
        cleaned = f"R_{cleaned}"
    return cleaned


def resolve_dataset_path(apihul_root, value):
    raw = (value or "").strip()
    if not raw:
        return Path()
    path = Path(raw)
    if path.is_absolute():
        return path
    normalized = raw[2:] if raw.startswith("./") else raw
    return (apihul_root / normalized).resolve()


def read_package_statement(source_file):
    if not source_file.exists():
        return ""
    try:
        text = source_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    match = re.search(r"(?m)^\s*package\s+([A-Za-z_][\w.]*)\s*;", text)
    return match.group(1) if match else ""


def source_roots(project_path):
    roots = []
    for pattern in ("src/main/java", "src/test/java"):
        roots.extend(path for path in project_path.rglob(pattern) if path.is_dir())
    return unique_preserve_order(str(path) for path in roots)


def load_records(mapping_csv, apihul_root, statuses):
    grouped = defaultdict(list)
    with Path(mapping_csv).open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("mapping_status") not in statuses:
                continue
            record_id = row.get("original_record_id") or row.get("record_id")
            if not record_id:
                continue
            grouped[record_id].append(row)

    records = []
    for record_id in sorted(grouped):
        rows = grouped[record_id]
        first = rows[0]
        project_path = resolve_dataset_path(apihul_root, first.get("project_path", ""))
        source_file = resolve_dataset_path(apihul_root, first.get("file_path", ""))
        records.append(
            {
                "record_id": record_id,
                "dataset": first.get("dataset", ""),
                "source_line": first.get("source_line", ""),
                "project_path": str(project_path),
                "file_path": str(source_file),
                "package_name": read_package_statement(source_file),
                "source_roots": source_roots(project_path) if project_path.exists() else [],
                "suspicious_imports": unique_preserve_order(row.get("import_path", "") for row in rows),
                "mapping_status_rows": [row.get("mapping_status", "") for row in rows],
                "mapping_statuses": unique_preserve_order(row.get("mapping_status", "") for row in rows),
                "suggested_import_prefixes": unique_preserve_order(row.get("suggested_import_prefix", "") for row in rows),
                "suggested_project_imports": unique_preserve_order(row.get("suggested_project_import", "") for row in rows),
            }
        )
    return records


def write_sentinel(path, package_name, class_name, imports):
    lines = []
    if package_name:
        lines.append(f"package {package_name};")
        lines.append("")
    for import_path in imports:
        lines.append(f"import {import_path};")
    if imports:
        lines.append("")
    lines.append(f"public class {class_name} {{")
    lines.append("    public void codexImportProbe() {")
    lines.append("    }")
    lines.append("}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_javac(javac, source_file, class_dir, log_path, source_roots_for_record, timeout):
    command = [
        javac,
        "-J-Duser.language=en",
        "-J-Duser.country=US",
        "-J-Dfile.encoding=UTF-8",
        "-encoding",
        "UTF-8",
        "-proc:none",
        "-d",
        str(class_dir),
    ]
    if source_roots_for_record:
        command.extend(["-sourcepath", ";".join(source_roots_for_record)])
    command.append(str(source_file))
    try:
        completed = subprocess.run(
            command,
            cwd=str(source_file.parent),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        output = (completed.stdout or "") + (completed.stderr or "")
        log_path.write_text(output, encoding="utf-8")
        return_code = completed.returncode
        timed_out = False
    except subprocess.TimeoutExpired as error:
        output = ((error.stdout or "") + (error.stderr or "")).strip()
        log_path.write_text(output, encoding="utf-8")
        return_code = ""
        timed_out = True

    status = "pass" if return_code == 0 else "source_compile_failure"
    if timed_out:
        status = "timeout"
    return {
        "command": " ".join(command),
        "return_code": return_code,
        "timed_out": timed_out,
        "status": status,
        "tail": output[-3000:],
        "log_path": str(log_path),
    }


def log_mentions_imports(output, imports):
    lowered = (output or "").lower()
    evidence = []
    for import_path in imports:
        package_path = import_package(import_path)
        if import_path.lower() in lowered or package_path.lower() in lowered:
            evidence.append(import_path)
    return evidence


def summarize(results, records):
    by_variant = defaultdict(list)
    for row in results:
        by_variant[row["variant"]].append(row)
    variants = {}
    for variant, rows in sorted(by_variant.items()):
        variants[variant] = {
            "records": len(rows),
            "pass": sum(row["status"] == "pass" for row in rows),
            "fail": sum(row["status"] != "pass" for row in rows),
            "status_counts": dict(Counter(row["status"] for row in rows).most_common()),
        }
    paired = {"records": 0, "raw_fail_sanitized_pass": 0, "raw_pass_sanitized_pass": 0, "other": 0}
    grouped = defaultdict(dict)
    for row in results:
        grouped[row["record_id"]][row["variant"]] = row
    for record_id, variants_for_record in grouped.items():
        raw = variants_for_record.get("raw_suspicious_imports", {})
        sanitized = variants_for_record.get("sanitized_removed_imports", {})
        if not raw or not sanitized:
            continue
        paired["records"] += 1
        if raw.get("status") != "pass" and sanitized.get("status") == "pass":
            paired["raw_fail_sanitized_pass"] += 1
        elif raw.get("status") == "pass" and sanitized.get("status") == "pass":
            paired["raw_pass_sanitized_pass"] += 1
        else:
            paired["other"] += 1

    status_counts_by_row = Counter(status for record in records for status in record["mapping_status_rows"])
    status_counts_by_record_presence = Counter(status for record in records for status in record["mapping_statuses"])
    return {
        "target_records": len(records),
        "suspicious_import_rows": sum(len(record["suspicious_imports"]) for record in records),
        "mapping_status_counts_by_row": dict(status_counts_by_row.most_common()),
        "mapping_status_counts_by_record_presence": dict(status_counts_by_record_presence.most_common()),
        "variants": variants,
        "paired": paired,
    }


def write_csv(path, rows):
    if not rows:
        return
    fieldnames = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, payload):
    summary = payload["summary"]
    lines = [
        "# Java Import-Only Compiler Probe",
        "",
        "This probe compiles generated sentinel classes with the suspicious imports only. It complements the Maven build-level import probe; it does not claim full project build success.",
        "",
        f"- Target records: `{summary['target_records']}`",
        f"- Suspicious import rows: `{summary['suspicious_import_rows']}`",
        f"- Java compiler: `{payload['javac']}`",
        "",
        "## Mapping Status Counts",
        "",
        "| Mapping status | Import rows | Record presence |",
        "|---|---:|---:|",
    ]
    row_counts = summary["mapping_status_counts_by_row"]
    record_counts = summary["mapping_status_counts_by_record_presence"]
    for status in sorted(set(row_counts) | set(record_counts)):
        lines.append(f"| `{status}` | {row_counts.get(status, 0)} | {record_counts.get(status, 0)} |")
    lines.extend(
        [
            "",
        ]
    )
    lines.extend(
        [
        "## Variant Outcomes",
        "",
        "| Variant | Records | Pass | Fail | Status counts |",
        "|---|---:|---:|---:|---|",
        ]
    )
    for variant, row in summary["variants"].items():
        lines.append(
            f"| `{variant}` | {row['records']} | {row['pass']} | {row['fail']} | `{row['status_counts']}` |"
        )
    paired = summary["paired"]
    lines.extend(
        [
            "",
            "## Paired Signal",
            "",
            f"- Records compared: `{paired['records']}`",
            f"- Raw suspicious imports fail while sanitized sentinel passes: `{paired['raw_fail_sanitized_pass']}`",
            f"- Raw suspicious imports pass while sanitized sentinel passes: `{paired['raw_pass_sanitized_pass']}`",
            f"- Other paired outcomes: `{paired['other']}`",
            "",
            "## Per-Record Results",
            "",
            "| Record | Variant | Status | Imports | Evidence in compiler output | Log |",
            "|---|---|---|---|---|---|",
        ]
    )
    for row in payload["results"]:
        imports = row.get("injected_imports", "").replace("|", "\\|")
        evidence = row.get("log_mentions_injected_import", "").replace("|", "\\|")
        lines.append(
            f"| `{row['record_id']}` | `{row['variant']}` | `{row['status']}` | `{imports}` | "
            f"`{evidence}` | `{row['log_path']}` |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--run-name", default="")
    parser.add_argument("--javac", default=shutil.which("javac") or "javac")
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--statuses", nargs="*", default=sorted(SUSPICIOUS_STATUSES))
    args = parser.parse_args()

    apihul_root = Path(args.apihul_root).resolve()
    output_root = Path(args.output_dir).resolve()
    run_name = args.run_name or datetime.now().strftime("java_import_only_probe_%Y%m%d_%H%M%S")
    run_root = output_root / run_name
    if run_root.exists():
        raise SystemExit(f"Run directory already exists: {run_root}")
    (run_root / "logs").mkdir(parents=True, exist_ok=True)
    (run_root / "src").mkdir(parents=True, exist_ok=True)
    (run_root / "classes").mkdir(parents=True, exist_ok=True)

    records = load_records(args.mapping_csv, apihul_root, set(args.statuses))
    results = []
    for record in records:
        class_name = f"CodexImportProbe_{safe_class_suffix(record['record_id'])}"
        record_src_dir = run_root / "src" / safe_class_suffix(record["record_id"])
        record_class_dir = run_root / "classes" / safe_class_suffix(record["record_id"])
        record_src_dir.mkdir(parents=True, exist_ok=True)
        record_class_dir.mkdir(parents=True, exist_ok=True)
        for variant, imports in [
            ("raw_suspicious_imports", record["suspicious_imports"]),
            ("sanitized_removed_imports", []),
        ]:
            source_path = record_src_dir / f"{class_name}_{variant}.java"
            class_variant_dir = record_class_dir / variant
            class_variant_dir.mkdir(parents=True, exist_ok=True)
            write_sentinel(source_path, record["package_name"], f"{class_name}_{variant}", imports)
            log_path = run_root / "logs" / f"{record['record_id']}_{variant}.log"
            build = run_javac(args.javac, source_path, class_variant_dir, log_path, record["source_roots"], args.timeout)
            evidence = log_mentions_imports(build.get("tail", ""), imports)
            results.append(
                {
                    "record_id": record["record_id"],
                    "dataset": record["dataset"],
                    "source_line": record["source_line"],
                    "variant": variant,
                    "status": build["status"],
                    "return_code": build["return_code"],
                    "timed_out": build["timed_out"],
                    "injected_imports": ";".join(imports),
                    "mapping_statuses": ";".join(record["mapping_statuses"]),
                    "log_mentions_injected_import": ";".join(evidence),
                    "source_file": str(source_path),
                    "log_path": str(log_path),
                    "command": build["command"],
                    "tail": build["tail"],
                }
            )

    summary = summarize(results, records)
    payload = {
        "run_name": run_name,
        "work_root": str(run_root),
        "javac": args.javac,
        "timeout_seconds": args.timeout,
        "statuses": sorted(set(args.statuses)),
        "summary": summary,
        "records": records,
        "results": results,
    }
    json_path = run_root / "java_import_only_probe.json"
    csv_path = run_root / "java_import_only_probe.csv"
    md_path = run_root / "java_import_only_probe.md"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(csv_path, results)
    write_markdown(md_path, payload)
    print(json.dumps({"output_md": str(md_path), "summary": summary}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
