import argparse
import csv
import json
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

INVALID_COORDINATE_STATUSES = {
    "not_found",
    "missing_coordinate",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def count_by(rows, key):
    counts = {}
    for row in rows:
        value = row.get(key, "")
        counts[value] = counts.get(value, 0) + 1
    return counts


def source_lines_for_records(responses, record_ids):
    return {
        str(line_no)
        for line_no, row in enumerate(responses, start=1)
        if row.get("record_id", "") in record_ids
    }


def import_summary(mapping_rows, record_ids):
    rows = [row for row in mapping_rows if row.get("original_record_id", "") in record_ids]
    suspicious = [row for row in rows if row.get("mapping_status", "") in SUSPICIOUS_MAPPING_STATUSES]
    return {
        "candidate_import_rows": len(rows),
        "suspicious_import_rows": len(suspicious),
        "suspicious_import_records": len({row.get("original_record_id", "") for row in suspicious if row.get("original_record_id", "")}),
        "mapping_status_counts": count_by(rows, "mapping_status"),
        "suspicious_mapping_status_counts": count_by(suspicious, "mapping_status"),
    }


def maven_summary(maven_rows, source_lines):
    rows = [row for row in maven_rows if str(row.get("source_line", "")) in source_lines]
    invalid = [row for row in rows if row.get("validation_status", "") in INVALID_COORDINATE_STATUSES and row.get("kind") != "java_import"]
    return {
        "candidate_coordinate_rows": len([row for row in rows if row.get("kind") != "java_import"]),
        "invalid_coordinate_rows": len(invalid),
        "invalid_coordinate_records": len({str(row.get("source_line", "")) for row in invalid}),
        "validation_status_counts": count_by(rows, "validation_status"),
        "invalid_coordinate_status_counts": count_by(invalid, "validation_status"),
    }


def merged_summary(label, responses, maven_rows, mapping_rows, record_ids):
    source_lines = source_lines_for_records(responses, record_ids)
    line_to_record_id = {
        str(line_no): row.get("record_id", "")
        for line_no, row in enumerate(responses, start=1)
        if row.get("record_id", "") in record_ids
    }
    imp = import_summary(mapping_rows, record_ids)
    mvn = maven_summary(maven_rows, source_lines)
    affected_records = set()
    for row in mapping_rows:
        if row.get("original_record_id", "") in record_ids and row.get("mapping_status", "") in SUSPICIOUS_MAPPING_STATUSES:
            affected_records.add(row.get("original_record_id", ""))
    for row in maven_rows:
        if str(row.get("source_line", "")) in source_lines and row.get("validation_status", "") in INVALID_COORDINATE_STATUSES and row.get("kind") != "java_import":
            affected_records.add(line_to_record_id.get(str(row.get("source_line", "")), str(row.get("source_line", ""))))
    return {
        "label": label,
        "target_records": len(record_ids),
        **imp,
        **mvn,
        "invalid_or_suspicious_records": len(affected_records),
    }


def reduction(before, after, key):
    b = before.get(key, 0)
    a = after.get(key, 0)
    return 0.0 if b == 0 else (b - a) / b


def write_markdown(path, output):
    before = output["before"]
    after = output["after"]
    lines = [
        "# Java Dependency Feedback Repair Comparison",
        "",
        f"- Targeted records: `{output['targeted_records']}`",
        "",
        "| Metric | Before | After | Reduction |",
        "|---|---:|---:|---:|",
    ]
    for key, label in [
        ("suspicious_import_rows", "Suspicious import rows"),
        ("invalid_coordinate_rows", "Invalid Maven/Gradle coordinate rows"),
        ("invalid_or_suspicious_records", "Records with any invalid dependency evidence"),
    ]:
        lines.append(f"| {label} | {before[key]} | {after[key]} | {reduction(before, after, key):.3f} |")
    lines.extend(["", "## Before Status Counts", "", "### Import Mapping", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(before["mapping_status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(["", "### Maven Validation", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(before["validation_status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(["", "## After Status Counts", "", "### Import Mapping", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(after["mapping_status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    lines.extend(["", "### Maven Validation", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(after["validation_status_counts"].items()):
        lines.append(f"| `{status}` | {count} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repair-prompts-jsonl", required=True)
    parser.add_argument("--before-responses-jsonl", required=True)
    parser.add_argument("--after-responses-jsonl", required=True)
    parser.add_argument("--before-maven-csv", required=True)
    parser.add_argument("--after-maven-csv", required=True)
    parser.add_argument("--before-mapping-csv", required=True)
    parser.add_argument("--after-mapping-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    repair_records = {row["record_id"] for row in read_jsonl(Path(args.repair_prompts_jsonl))}
    before = merged_summary(
        "before",
        read_jsonl(Path(args.before_responses_jsonl)),
        read_csv(Path(args.before_maven_csv)),
        read_csv(Path(args.before_mapping_csv)),
        repair_records,
    )
    after = merged_summary(
        "after",
        read_jsonl(Path(args.after_responses_jsonl)),
        read_csv(Path(args.after_maven_csv)),
        read_csv(Path(args.after_mapping_csv)),
        repair_records,
    )
    output = {
        "targeted_records": len(repair_records),
        "before": before,
        "after": after,
        "reductions": {
            key: reduction(before, after, key)
            for key in ["suspicious_import_rows", "invalid_coordinate_rows", "invalid_or_suspicious_records"]
        },
    }
    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), output)
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
