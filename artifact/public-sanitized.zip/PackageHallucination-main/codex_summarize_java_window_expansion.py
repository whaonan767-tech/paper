import argparse
import csv
import json
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


DEFAULT_WINDOWS = [
    {
        "label": "FM50",
        "prompt_window": "offset=0,F=50,M=50",
        "prompt_count": 100,
        "raw_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50/import_maven_mapping_enhanced.json",
        "sanitized_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/import_maven_mapping_enhanced.json",
        "audit_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/sanitizer_audit.json",
        "import_probe_json": "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_suspicious_imports_v3/java_import_only_probe.json",
        "build_probe_json": "../../vw/pkg_import_build_probe/fm50_shortroot/java_import_build_probe.json",
    },
    {
        "label": "FM50_Offset50",
        "prompt_window": "offset=50,F=50,M=50",
        "prompt_count": 100,
        "raw_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50/import_maven_mapping_enhanced.json",
        "sanitized_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50_Sanitized/import_maven_mapping_enhanced.json",
        "audit_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50_Sanitized/sanitizer_audit.json",
        "import_probe_json": "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset50_suspicious_imports/java_import_only_probe.json",
        "build_probe_json": "Tests/Java_APIHulBench_BuildProbe/offset50_import_sanitizer_probe/java_import_build_probe.json",
    },
    {
        "label": "FM50_Offset100",
        "prompt_window": "offset=100,F=50,M=50",
        "prompt_count": 100,
        "raw_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100/import_maven_mapping_enhanced.json",
        "sanitized_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100_Sanitized/import_maven_mapping_enhanced.json",
        "audit_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100_Sanitized/sanitizer_audit.json",
        "import_probe_json": "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset100_suspicious_imports/java_import_only_probe.json",
        "build_probe_json": "../../vw/pkg_import_build_probe/offset100_shortroot/java_import_build_probe.json",
    },
    {
        "label": "FM50_Offset150_tail",
        "prompt_window": "offset=150,F=50,M=45",
        "prompt_count": 95,
        "raw_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150/import_maven_mapping_enhanced.json",
        "sanitized_mapping_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150_Sanitized/import_maven_mapping_enhanced.json",
        "audit_json": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150_Sanitized/sanitizer_audit.json",
        "import_probe_json": "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_fm50_offset150_suspicious_imports/java_import_only_probe.json",
        "build_probe_json": "../../vw/pkg_import_build_probe/offset150_shortroot/java_import_build_probe.json",
    },
    {
        "label": "F50_Offset200_tail",
        "prompt_window": "offset=200,F=21,M=0",
        "prompt_count": 21,
        "raw_mapping_json": "Tests/Java_APIHulBench_Qwen3B_F50_Offset200/import_maven_mapping_enhanced.json",
        "sanitized_mapping_json": "Tests/Java_APIHulBench_Qwen3B_F50_Offset200_Sanitized/import_maven_mapping_enhanced.json",
        "audit_json": "Tests/Java_APIHulBench_Qwen3B_F50_Offset200_Sanitized/sanitizer_audit.json",
        "import_probe_json": "Tests/Java_APIHulBench_ImportOnlyProbe/qwen3b_f50_offset200_suspicious_imports/java_import_only_probe.json",
        "build_probe_json": "../../vw/pkg_import_build_probe/offset200_f_tail_shortroot/java_import_build_probe.json",
    },
]


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pct(numerator, denominator):
    if denominator == 0:
        return 0.0
    return numerator / denominator


def percent_reduction(before, after):
    if before == 0:
        return 0.0
    return (before - after) / before


def count_suspicious_rows(counts):
    return sum(int(counts.get(status, 0)) for status in SUSPICIOUS_MAPPING_STATUSES)


def count_suspicious_records(mapped_rows):
    records = {
        row.get("original_record_id", "")
        for row in mapped_rows
        if row.get("mapping_status") in SUSPICIOUS_MAPPING_STATUSES and row.get("original_record_id", "")
    }
    return len(records)


def merge_counts(accumulator, counts):
    for key, value in counts.items():
        accumulator[key] = accumulator.get(key, 0) + int(value)


def summarize_build_probe(path):
    payload = read_json(path)
    summary = payload["summary"]
    raw = summary["variants"]["raw_suspicious_imports"]
    sanitized = summary["variants"]["sanitized_removed_imports"]
    paired = summary["paired_outcomes"]
    baseline_total = int(summary["baseline_build_units_total"])
    baseline_pass = int(summary["baseline_build_units_pass"])
    baseline_pass_records = int(paired["baseline_pass_records"])
    raw_fail_sanitized_pass = int(paired["raw_fail_sanitized_pass"])
    return {
        "build_target_records": int(payload["target_records"]),
        "build_baseline_units_total": baseline_total,
        "build_baseline_units_pass": baseline_pass,
        "build_raw_runnable_records": int(raw["runnable_records"]),
        "build_raw_pass": int(raw["pass"]),
        "build_sanitized_runnable_records": int(sanitized["runnable_records"]),
        "build_sanitized_pass": int(sanitized["pass"]),
        "build_baseline_pass_target_records": baseline_pass_records,
        "build_raw_fail_sanitized_pass": raw_fail_sanitized_pass,
        "build_raw_pass_sanitized_pass": int(paired["raw_pass_sanitized_pass"]),
        "build_other_paired": int(paired["other"]),
        "build_signal_rate": pct(raw_fail_sanitized_pass, baseline_pass_records),
        "build_probe_json": path,
    }


def summarize_window(window):
    raw_mapping = read_json(window["raw_mapping_json"])
    sanitized_mapping = read_json(window["sanitized_mapping_json"])
    audit = read_json(window["audit_json"])
    import_probe = read_json(window["import_probe_json"])
    build_probe = summarize_build_probe(window["build_probe_json"])
    probe_summary = import_probe["summary"]

    raw_suspicious_rows = count_suspicious_rows(raw_mapping["mapping_status_counts"])
    sanitized_suspicious_rows = count_suspicious_rows(sanitized_mapping["mapping_status_counts"])
    raw_suspicious_records = count_suspicious_records(raw_mapping.get("mapped", []))
    sanitized_suspicious_records = count_suspicious_records(sanitized_mapping.get("mapped", []))

    raw_variant = probe_summary["variants"]["raw_suspicious_imports"]
    sanitized_variant = probe_summary["variants"]["sanitized_removed_imports"]
    paired = probe_summary["paired"]

    row = {
        "label": window["label"],
        "prompt_window": window["prompt_window"],
        "prompt_count": int(window["prompt_count"]),
        "candidate_rows_before": int(raw_mapping["rows"]),
        "candidate_rows_after": int(sanitized_mapping["rows"]),
        "suspicious_rows_before": raw_suspicious_rows,
        "suspicious_rows_after": sanitized_suspicious_rows,
        "suspicious_records_before": raw_suspicious_records,
        "suspicious_records_after": sanitized_suspicious_records,
        "targeted_records": int(audit["targeted_records"]),
        "removed_imports": int(audit.get("action_counts", {}).get("remove_import", 0)),
        "raw_compile_records": int(raw_variant["records"]),
        "raw_compile_pass": int(raw_variant["pass"]),
        "raw_compile_fail": int(raw_variant["fail"]),
        "sanitized_compile_records": int(sanitized_variant["records"]),
        "sanitized_compile_pass": int(sanitized_variant["pass"]),
        "sanitized_compile_fail": int(sanitized_variant["fail"]),
        "paired_records": int(paired["records"]),
        "raw_fail_sanitized_pass": int(paired["raw_fail_sanitized_pass"]),
        "raw_pass_sanitized_pass": int(paired["raw_pass_sanitized_pass"]),
        "other_paired": int(paired["other"]),
        "suspicious_row_rate_per_candidate": pct(raw_suspicious_rows, int(raw_mapping["rows"])),
        "suspicious_record_rate_per_prompt": pct(raw_suspicious_records, int(window["prompt_count"])),
        "suspicious_row_reduction": percent_reduction(raw_suspicious_rows, sanitized_suspicious_rows),
        "suspicious_record_reduction": percent_reduction(raw_suspicious_records, sanitized_suspicious_records),
        "compile_signal_rate": pct(int(paired["raw_fail_sanitized_pass"]), int(paired["records"])),
        "raw_mapping_status_counts": raw_mapping["mapping_status_counts"],
        "sanitized_mapping_status_counts": sanitized_mapping["mapping_status_counts"],
        "inputs": {
            "raw_mapping_json": window["raw_mapping_json"],
            "sanitized_mapping_json": window["sanitized_mapping_json"],
            "audit_json": window["audit_json"],
            "import_probe_json": window["import_probe_json"],
            "build_probe_json": window["build_probe_json"],
        },
    }
    row.update(build_probe)
    return row


def summarize_combined(rows):
    raw_counts = {}
    sanitized_counts = {}
    combined = {
        "label": "combined",
        "prompt_window": " plus ".join(row["prompt_window"].split(",")[0] for row in rows),
        "prompt_count": 0,
        "candidate_rows_before": 0,
        "candidate_rows_after": 0,
        "suspicious_rows_before": 0,
        "suspicious_rows_after": 0,
        "suspicious_records_before": 0,
        "suspicious_records_after": 0,
        "targeted_records": 0,
        "removed_imports": 0,
        "raw_compile_records": 0,
        "raw_compile_pass": 0,
        "raw_compile_fail": 0,
        "sanitized_compile_records": 0,
        "sanitized_compile_pass": 0,
        "sanitized_compile_fail": 0,
        "paired_records": 0,
        "raw_fail_sanitized_pass": 0,
        "raw_pass_sanitized_pass": 0,
        "other_paired": 0,
        "build_target_records": 0,
        "build_baseline_units_total": 0,
        "build_baseline_units_pass": 0,
        "build_raw_runnable_records": 0,
        "build_raw_pass": 0,
        "build_sanitized_runnable_records": 0,
        "build_sanitized_pass": 0,
        "build_baseline_pass_target_records": 0,
        "build_raw_fail_sanitized_pass": 0,
        "build_raw_pass_sanitized_pass": 0,
        "build_other_paired": 0,
    }
    for row in rows:
        for key in combined:
            if key in {"label", "prompt_window"}:
                continue
            combined[key] += int(row[key])
        merge_counts(raw_counts, row["raw_mapping_status_counts"])
        merge_counts(sanitized_counts, row["sanitized_mapping_status_counts"])

    combined["label"] = f"Java{combined['prompt_count']}_combined"
    combined["suspicious_row_rate_per_candidate"] = pct(
        combined["suspicious_rows_before"], combined["candidate_rows_before"]
    )
    combined["suspicious_record_rate_per_prompt"] = pct(
        combined["suspicious_records_before"], combined["prompt_count"]
    )
    combined["suspicious_row_reduction"] = percent_reduction(
        combined["suspicious_rows_before"], combined["suspicious_rows_after"]
    )
    combined["suspicious_record_reduction"] = percent_reduction(
        combined["suspicious_records_before"], combined["suspicious_records_after"]
    )
    combined["compile_signal_rate"] = pct(
        combined["raw_fail_sanitized_pass"], combined["paired_records"]
    )
    combined["build_signal_rate"] = pct(
        combined["build_raw_fail_sanitized_pass"], combined["build_baseline_pass_target_records"]
    )
    combined["raw_mapping_status_counts"] = raw_counts
    combined["sanitized_mapping_status_counts"] = sanitized_counts
    return combined


def compact_row(row):
    keys = [
        "label",
        "prompt_window",
        "prompt_count",
        "candidate_rows_before",
        "candidate_rows_after",
        "suspicious_rows_before",
        "suspicious_rows_after",
        "suspicious_records_before",
        "suspicious_records_after",
        "targeted_records",
        "removed_imports",
        "raw_compile_fail",
        "sanitized_compile_pass",
        "paired_records",
        "raw_fail_sanitized_pass",
        "suspicious_row_rate_per_candidate",
        "suspicious_record_rate_per_prompt",
        "suspicious_row_reduction",
        "compile_signal_rate",
        "build_target_records",
        "build_baseline_units_pass",
        "build_baseline_units_total",
        "build_baseline_pass_target_records",
        "build_raw_fail_sanitized_pass",
        "build_raw_pass_sanitized_pass",
        "build_sanitized_pass",
        "build_signal_rate",
    ]
    out = {}
    for key in keys:
        value = row[key]
        if isinstance(value, float):
            value = f"{value:.3f}"
        out[key] = value
    return out


def write_csv(path, rows):
    compact = [compact_row(row) for row in rows]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(compact[0].keys()))
        writer.writeheader()
        writer.writerows(compact)


def counts_table(counts):
    lines = ["| Mapping status | Count |", "|---|---:|"]
    for status, count in sorted(counts.items()):
        lines.append(f"| `{status}` | {count} |")
    return lines


def write_markdown(path, rows, combined):
    lines = [
        "# Java Window Expansion Summary",
        "",
        "## Main Table",
        "",
        "| Window | Prompts | Candidates before->after | Suspicious rows before->after | Suspicious records before->after | Import-only compiler signal |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows + [combined]:
        lines.append(
            "| {label} | {prompts} | {cb}->{ca} | {sb}->{sa} | {rb}->{ra} | {signal}/{paired} |".format(
                label=row["label"],
                prompts=row["prompt_count"],
                cb=row["candidate_rows_before"],
                ca=row["candidate_rows_after"],
                sb=row["suspicious_rows_before"],
                sa=row["suspicious_rows_after"],
                rb=row["suspicious_records_before"],
                ra=row["suspicious_records_after"],
                signal=row["raw_fail_sanitized_pass"],
                paired=row["paired_records"],
            )
        )

    lines.extend(
        [
            "",
            "## Build-Level Probe Table",
            "",
            "| Window | Target records | Baseline build units passing | Interpretable target records | Raw fail + sanitized pass | Raw pass + sanitized pass |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in rows + [combined]:
        lines.append(
            "| {label} | {targets} | {bp}/{bt} | {records} | {fail_pass} | {pass_pass} |".format(
                label=row["label"],
                targets=row["build_target_records"],
                bp=row["build_baseline_units_pass"],
                bt=row["build_baseline_units_total"],
                records=row["build_baseline_pass_target_records"],
                fail_pass=row["build_raw_fail_sanitized_pass"],
                pass_pass=row["build_raw_pass_sanitized_pass"],
            )
        )

    lines.extend(
        [
            "",
            "## Rate Table",
            "",
            "| Window | Suspicious rows / candidates | Suspicious records / prompts | Suspicious row reduction | Import-only signal rate | Build-level signal rate |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in rows + [combined]:
        lines.append(
            "| {label} | {row_rate:.3f} | {record_rate:.3f} | {reduction:.3f} | {compile_rate:.3f} | {build_rate:.3f} |".format(
                label=row["label"],
                row_rate=row["suspicious_row_rate_per_candidate"],
                record_rate=row["suspicious_record_rate_per_prompt"],
                reduction=row["suspicious_row_reduction"],
                compile_rate=row["compile_signal_rate"],
                build_rate=row["build_signal_rate"],
            )
        )

    lines.extend(
        [
            "",
            "## Combined Raw Mapping Status",
            "",
            *counts_table(combined["raw_mapping_status_counts"]),
            "",
            "## Combined Sanitized Mapping Status",
            "",
            *counts_table(combined["sanitized_mapping_status_counts"]),
            "",
            "## Paper-Ready Reading",
            "",
            "- Across five disjoint Java APIHulBench windows, covering all 416 local F/M prompts, Qwen2.5-Coder-3B generated {rows_before} suspicious import rows in {records_before} records out of {prompts} prompts.".format(
                rows_before=combined["suspicious_rows_before"],
                records_before=combined["suspicious_records_before"],
                prompts=combined["prompt_count"],
            ),
            "- The deterministic sanitizer removed all detected suspicious import rows in these windows: {rows_before}->{rows_after} rows and {records_before}->{records_after} affected records.".format(
                rows_before=combined["suspicious_rows_before"],
                rows_after=combined["suspicious_rows_after"],
                records_before=combined["suspicious_records_before"],
                records_after=combined["suspicious_records_after"],
            ),
            "- The import-only compiler probe gives executable evidence for every detected record: raw suspicious-import sentinels failed and sanitized sentinels passed in {signal}/{paired} paired cases.".format(
                signal=combined["raw_fail_sanitized_pass"],
                paired=combined["paired_records"],
            ),
            "- The Maven build-level import-injection probe targets all {targets} detected records. {interpretable} target records are interpretable after baseline and target-file checks; {fail_pass}/{interpretable} fail after suspicious-import injection and pass after sanitizer removal, while {pass_pass}/{interpretable} pass both variants.".format(
                targets=combined["build_target_records"],
                interpretable=combined["build_baseline_pass_target_records"],
                fail_pass=combined["build_raw_fail_sanitized_pass"],
                pass_pass=combined["build_raw_pass_sanitized_pass"],
            ),
            "- The final F-only tail window completes local APIHulBench F/M coverage and repeats the same detection-mitigation-compile pattern, adding one more Maven raw-fail/sanitized-pass build-level case.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-dir",
        default="Tests/Java_APIHulBench_WindowExpansionSummary",
    )
    args = parser.parse_args()

    rows = [summarize_window(window) for window in DEFAULT_WINDOWS]
    combined = summarize_combined(rows)
    output = {
        "windows": rows,
        "combined": combined,
    }

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "java_window_expansion_summary.json"
    md_path = output_dir / "java_window_expansion_summary.md"
    csv_path = output_dir / "java_window_expansion_summary.csv"
    json_path.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(csv_path, rows + [combined])
    write_markdown(md_path, rows, combined)
    print(
        json.dumps(
            {
                "output_md": str(md_path),
                "combined_prompts": combined["prompt_count"],
                "combined_suspicious_rows_before": combined["suspicious_rows_before"],
                "combined_suspicious_rows_after": combined["suspicious_rows_after"],
                "combined_raw_fail_sanitized_pass": combined["raw_fail_sanitized_pass"],
                "combined_paired_records": combined["paired_records"],
                "combined_build_raw_fail_sanitized_pass": combined["build_raw_fail_sanitized_pass"],
                "combined_build_baseline_pass_target_records": combined["build_baseline_pass_target_records"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
