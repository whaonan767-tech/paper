import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

INVALID_COORDINATE_STATUSES = {
    "not_found",
    "missing_coordinate",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                row = json.loads(line)
                row["_line_no"] = line_no
                rows.append(row)
    return rows


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def original_record_id(row):
    value = row.get("original_record_id", "")
    if value:
        return value
    source_line = row.get("source_line", "")
    return source_line


def response_by_record_id(responses):
    return {row.get("record_id", ""): row for row in responses}


def clipped(text, max_chars):
    text = text or ""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n/* ... clipped ... */"


def extract_original_task_context(prompt_text):
    marker = "Original task context:\n"
    if marker in prompt_text:
        return prompt_text.split(marker, 1)[1].strip()
    return prompt_text.strip()


def group_invalid_coordinates(rows, statuses):
    grouped = defaultdict(list)
    for row in rows:
        if row.get("validation_status", "") not in statuses:
            continue
        if row.get("kind") == "java_import":
            continue
        source_line = row.get("source_line", "")
        if source_line:
            grouped[source_line].append(row)
    return grouped


def group_suspicious_imports(rows, statuses):
    grouped = defaultdict(list)
    for row in rows:
        if row.get("mapping_status", "") not in statuses:
            continue
        record_id = row.get("original_record_id", "")
        if record_id:
            grouped[record_id].append(row)
    return grouped


def record_id_to_source_line(responses):
    return {
        row.get("record_id", ""): str(line_no)
        for line_no, row in enumerate(responses, start=1)
        if row.get("record_id", "")
    }


def valid_coordinates(maven_rows):
    coords = []
    for row in maven_rows:
        if row.get("validation_status") != "valid_coordinate":
            continue
        coord = row.get("coordinate", "")
        if coord and coord not in coords:
            coords.append(coord)
    return coords


def render_invalid_coordinates(rows):
    if not rows:
        return "- None"
    lines = []
    for row in rows:
        coord = row.get("coordinate", "")
        status = row.get("validation_status", "")
        found = row.get("maven_num_found", "")
        lines.append(f"- {coord}: {status}; Maven search matches={found}")
    return "\n".join(lines)


def render_suspicious_imports(rows):
    if not rows:
        return "- None"
    lines = []
    for row in rows:
        import_path = row.get("import_path", "")
        status = row.get("mapping_status", "")
        reason = row.get("mapping_reason", "")
        suggestion = row.get("suggested_import_prefix", "")
        project = row.get("suggested_project_import", "") or row.get("suggested_project_prefix", "")
        detail = f"- {import_path}: {status}"
        if suggestion:
            detail += f"; suggested external prefix={suggestion}"
        if project:
            detail += f"; closest project evidence={project}"
        if reason:
            detail += f"; reason={reason}"
        lines.append(detail)
    return "\n".join(lines)


def render_valid_coordinates(coords):
    if not coords:
        return "- None"
    return "\n".join(f"- {coord}" for coord in coords)


def build_prompt(response_row, invalid_coords, suspicious_imports, valid_coords, max_prompt_chars, max_response_chars):
    original_prompt = clipped(extract_original_task_context(response_row.get("prompt", "")), max_prompt_chars)
    original_response = clipped(response_row.get("response", ""), max_response_chars)
    forbidden_coords = [row.get("coordinate", "") for row in invalid_coords if row.get("coordinate", "")]
    forbidden_imports = [row.get("import_path", "") for row in suspicious_imports if row.get("import_path", "")]
    forbidden = "\n".join(f"- {item}" for item in forbidden_coords + forbidden_imports) or "- None"
    return (
        "You previously produced a Java completion and dependency manifest. A deterministic validation pass found invalid dependency evidence.\n\n"
        "Revise the answer using these rules:\n"
        "1. Do not repeat any forbidden Maven coordinate, Gradle declaration, or import string.\n"
        "2. Remove Maven coordinates that Maven search reports as not found unless you can replace them with a registry-backed coordinate from the valid list.\n"
        "3. Remove project-namespace imports unless they match project source evidence. If a closest project import is provided, use it only when it exactly fits the code need.\n"
        "4. Mark JDK classes as JDK and project classes as Project-local. Do not turn project-local classes into public Maven dependencies.\n"
        "5. Return only the two-part structure: Java code block, then Dependencies section. No extra explanation.\n"
        "6. If no external dependency is needed, the Dependencies section must be exactly: No external dependency.\n\n"
        "Original task context:\n"
        f"{original_prompt}\n\n"
        "Original answer:\n"
        f"```text\n{original_response}\n```\n\n"
        "Forbidden strings:\n"
        f"{forbidden}\n\n"
        "Invalid Maven/Gradle coordinates:\n"
        f"{render_invalid_coordinates(invalid_coords)}\n\n"
        "Suspicious imports:\n"
        f"{render_suspicious_imports(suspicious_imports)}\n\n"
        "Registry-valid coordinates already found in this answer:\n"
        f"{render_valid_coordinates(valid_coords)}\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--maven-validation-csv", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--max-prompt-chars", type=int, default=3500)
    parser.add_argument("--max-response-chars", type=int, default=2200)
    parser.add_argument("--invalid-coordinate-statuses", nargs="*", default=sorted(INVALID_COORDINATE_STATUSES))
    parser.add_argument("--suspicious-mapping-statuses", nargs="*", default=sorted(SUSPICIOUS_MAPPING_STATUSES))
    args = parser.parse_args()

    responses = read_jsonl(Path(args.responses_jsonl))
    responses_by_id = response_by_record_id(responses)
    id_to_line = record_id_to_source_line(responses)
    maven_rows = read_csv(Path(args.maven_validation_csv))
    mapping_rows = read_csv(Path(args.mapping_csv))

    invalid_by_line = group_invalid_coordinates(maven_rows, set(args.invalid_coordinate_statuses))
    suspicious_by_record = group_suspicious_imports(mapping_rows, set(args.suspicious_mapping_statuses))
    records = sorted(set(suspicious_by_record) | {rid for rid, line in id_to_line.items() if line in invalid_by_line})

    output_rows = []
    for record_id in records:
        response_row = responses_by_id.get(record_id)
        if not response_row:
            continue
        source_line = id_to_line.get(record_id, "")
        invalid_coords = invalid_by_line.get(source_line, [])
        suspicious_imports = suspicious_by_record.get(record_id, [])
        valid_coords = valid_coordinates([row for row in maven_rows if row.get("source_line") == source_line])
        output_rows.append(
            {
                "record_id": record_id,
                "dataset": response_row.get("dataset", ""),
                "split": response_row.get("split", ""),
                "source_line": response_row.get("source_line", ""),
                "project_path": response_row.get("project_path", ""),
                "file_path": response_row.get("file_path", ""),
                "ground_truth": response_row.get("ground_truth", ""),
                "task": "java_dependency_feedback_repair",
                "invalid_coordinates": [row.get("coordinate", "") for row in invalid_coords],
                "suspicious_imports": [row.get("import_path", "") for row in suspicious_imports],
                "valid_maven_coordinates": valid_coords,
                "prompt": build_prompt(
                    response_row,
                    invalid_coords,
                    suspicious_imports,
                    valid_coords,
                    args.max_prompt_chars,
                    args.max_response_chars,
                ),
            }
        )

    output_jsonl = Path(args.output_jsonl)
    output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in output_rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")

    lines = [
        "# Java Dependency Feedback Repair Prompt Set",
        "",
        f"- Input responses: `{args.responses_jsonl}`",
        f"- Input Maven validation: `{args.maven_validation_csv}`",
        f"- Input import mapping: `{args.mapping_csv}`",
        f"- Repair prompts: `{len(output_rows)}`",
        "",
        "| Record | Invalid coordinates | Suspicious imports | Valid coordinates |",
        "|---|---:|---:|---:|",
    ]
    for row in output_rows:
        lines.append(
            f"| `{row['record_id']}` | {len(row['invalid_coordinates'])} | {len(row['suspicious_imports'])} | {len(row['valid_maven_coordinates'])} |"
        )
    Path(args.output_md).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(output_rows)} dependency feedback prompts to {output_jsonl}")


if __name__ == "__main__":
    main()
