import argparse
import json
from pathlib import Path


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def summarize(prompts_jsonl, responses_jsonl):
    prompts = {row.get("record_id", ""): row for row in read_jsonl(prompts_jsonl)}
    responses = read_jsonl(responses_jsonl)
    total = 0
    exact = 0
    records_any = 0
    rows = []
    for response in responses:
        record_id = response.get("record_id", "")
        targets = prompts.get(record_id, {}).get("masked_external_imports", [])
        text = response.get("response", "")
        hits = [target for target in targets if target in text]
        total += len(targets)
        exact += len(hits)
        if hits:
            records_any += 1
        rows.append(
            {
                "record_id": record_id,
                "masked_import_count": len(targets),
                "raw_exact_mentions": hits,
                "raw_exact_mention_count": len(hits),
            }
        )
    return {
        "prompts_jsonl": str(prompts_jsonl),
        "responses_jsonl": str(responses_jsonl),
        "records": len(responses),
        "masked_imports": total,
        "raw_exact_mentions": exact,
        "raw_exact_mention_recall": exact / total if total else None,
        "records_any_raw_exact_mention": records_any,
        "record_rows": rows,
    }


def write_md(path, summary):
    lines = [
        "# Masked Import Raw Exact Mention Summary",
        "",
        f"- Prompts: `{summary['prompts_jsonl']}`",
        f"- Responses: `{summary['responses_jsonl']}`",
        f"- Records: `{summary['records']}`",
        f"- Masked imports: `{summary['masked_imports']}`",
        f"- Raw exact mentions: `{summary['raw_exact_mentions']}`",
        f"- Raw exact mention recall: `{summary['raw_exact_mention_recall']:.4f}`",
        f"- Records with any raw exact mention: `{summary['records_any_raw_exact_mention']}`",
        "",
        "## Records With Hits",
        "",
        "| Record | Raw exact mentions |",
        "|---|---|",
    ]
    for row in summary["record_rows"]:
        if row["raw_exact_mentions"]:
            lines.append(f"| `{row['record_id']}` | `{'; '.join(row['raw_exact_mentions'])}` |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompts-jsonl", required=True)
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    summary = summarize(Path(args.prompts_jsonl), Path(args.responses_jsonl))
    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    write_md(Path(args.output_md), summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "record_rows"}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
