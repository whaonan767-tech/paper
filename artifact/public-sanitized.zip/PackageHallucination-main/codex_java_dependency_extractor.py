import argparse
import csv
import json
import re
from pathlib import Path


DEPENDENCY_BLOCK_RE = re.compile(r"<dependency\b[^>]*>(.*?)</dependency>", re.IGNORECASE | re.DOTALL)
TAG_RE_TEMPLATE = r"<{tag}\b[^>]*>(.*?)</{tag}>"
GRADLE_STRING_RE = re.compile(
    r"\b(?:implementation|api|compileOnly|runtimeOnly|testImplementation|annotationProcessor|compile|testCompile)\s*"
    r"\(?\s*['\"]([A-Za-z0-9_.-]+):([A-Za-z0-9_.-]+):([^'\")\s]+)['\"]",
    re.IGNORECASE,
)
GRADLE_MAP_RE = re.compile(
    r"\b(?:implementation|api|compileOnly|runtimeOnly|testImplementation|annotationProcessor|compile|testCompile)\s*"
    r"\(?\s*group\s*:\s*['\"]([^'\"]+)['\"]\s*,\s*name\s*:\s*['\"]([^'\"]+)['\"]"
    r"(?:\s*,\s*version\s*:\s*['\"]([^'\"]+)['\"])?",
    re.IGNORECASE,
)
RAW_COORD_RE = re.compile(
    r"\b([A-Za-z][A-Za-z0-9_.-]*):([A-Za-z0-9_.-]+):([A-Za-z0-9_.+/-]+)\b"
)
IMPORT_RE = re.compile(
    r"^\s*import\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;",
    re.MULTILINE,
)
DEPENDENCY_SECTION_RE = re.compile(
    r"(?ims)^\s*(?:\d+\.\s*)?Dependencies(?:\s+section)?\s*:?\s*(.*)$"
)


def clean(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", value).strip()


def tag_value(block, tag):
    pattern = re.compile(TAG_RE_TEMPLATE.format(tag=re.escape(tag)), re.IGNORECASE | re.DOTALL)
    match = pattern.search(block)
    return clean(match.group(1)) if match else ""


def import_root(import_path):
    parts = import_path.split(".")
    if len(parts) >= 3 and parts[0] in {"com", "org", "net", "io"}:
        return ".".join(parts[:3])
    if len(parts) >= 2:
        return ".".join(parts[:2])
    return import_path


def add_candidate(candidates, seen, candidate):
    key = (
        candidate.get("kind"),
        candidate.get("group_id"),
        candidate.get("artifact_id"),
        candidate.get("version"),
        candidate.get("import_path"),
    )
    if key in seen:
        return
    seen.add(key)
    candidates.append(candidate)


def dependency_sections(text):
    """Return explicit dependency-answer spans for broad raw-coordinate scanning."""
    return [match.group(1) for match in DEPENDENCY_SECTION_RE.finditer(text or "")]


def extract_candidates(text):
    candidates = []
    seen = set()
    text = text or ""
    dependency_text = "\n".join(dependency_sections(text))

    for match in DEPENDENCY_BLOCK_RE.finditer(text):
        block = match.group(1)
        group_id = tag_value(block, "groupId")
        artifact_id = tag_value(block, "artifactId")
        version = tag_value(block, "version")
        if group_id and artifact_id:
            add_candidate(
                candidates,
                seen,
                {
                    "kind": "maven_xml",
                    "group_id": group_id,
                    "artifact_id": artifact_id,
                    "version": version,
                    "coordinate": ":".join(part for part in [group_id, artifact_id, version] if part),
                },
            )

    for group_id, artifact_id, version in GRADLE_STRING_RE.findall(text):
        add_candidate(
            candidates,
            seen,
            {
                "kind": "gradle_string",
                "group_id": clean(group_id),
                "artifact_id": clean(artifact_id),
                "version": clean(version),
                "coordinate": f"{clean(group_id)}:{clean(artifact_id)}:{clean(version)}",
            },
        )

    for group_id, artifact_id, version in GRADLE_MAP_RE.findall(text):
        add_candidate(
            candidates,
            seen,
            {
                "kind": "gradle_map",
                "group_id": clean(group_id),
                "artifact_id": clean(artifact_id),
                "version": clean(version),
                "coordinate": ":".join(part for part in [clean(group_id), clean(artifact_id), clean(version)] if part),
            },
        )

    for group_id, artifact_id, version in RAW_COORD_RE.findall(dependency_text):
        add_candidate(
            candidates,
            seen,
            {
                "kind": "raw_maven_coordinate",
                "group_id": clean(group_id),
                "artifact_id": clean(artifact_id),
                "version": clean(version),
                "coordinate": f"{clean(group_id)}:{clean(artifact_id)}:{clean(version)}",
            },
        )

    for import_path in IMPORT_RE.findall(text):
        add_candidate(
            candidates,
            seen,
            {
                "kind": "java_import",
                "import_path": import_path,
                "import_root": import_root(import_path),
            },
        )

    return candidates


def rows_from_jsonl(path, field):
    with open(path, "r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            yield line_no, row, row.get(field, "")


def write_outputs(rows, output_json, output_csv):
    output_json.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
    fieldnames = [
        "record_id",
        "source_line",
        "dataset",
        "task",
        "kind",
        "coordinate",
        "group_id",
        "artifact_id",
        "version",
        "import_path",
        "import_root",
    ]
    with open(output_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name, "") for name in fieldnames})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-jsonl")
    parser.add_argument("--field", default="response")
    parser.add_argument("--text-file")
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-csv", required=True)
    args = parser.parse_args()

    extracted = []
    if args.input_jsonl:
        for line_no, row, text in rows_from_jsonl(Path(args.input_jsonl), args.field):
            for idx, candidate in enumerate(extract_candidates(text), 1):
                out = {
                    "record_id": f"{line_no}:{idx}",
                    "source_line": line_no,
                    "dataset": row.get("dataset", ""),
                    "task": row.get("task", ""),
                }
                out.update(candidate)
                extracted.append(out)
    elif args.text_file:
        text = Path(args.text_file).read_text(encoding="utf-8")
        for idx, candidate in enumerate(extract_candidates(text), 1):
            out = {"record_id": f"text:{idx}", "source_line": 1}
            out.update(candidate)
            extracted.append(out)
    else:
        raise SystemExit("Provide --input-jsonl or --text-file")

    write_outputs(extracted, Path(args.output_json), Path(args.output_csv))
    print(f"Extracted {len(extracted)} Java dependency candidates")


if __name__ == "__main__":
    main()
