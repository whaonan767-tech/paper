import argparse
import json
from pathlib import Path

import pandas as pd


def safe_rate(num, den):
    return float(num) / float(den) if den else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output-prefix", default="codex_summary")
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    final_results = pd.read_csv(run_dir / "FINAL_RESULTS.csv", index_col=0)
    package_names = pd.read_csv(run_dir / "PACKAGE_NAMES.csv")
    metadata_path = run_dir / "metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}

    rows = []
    for name, row in final_results.iterrows():
        if name == "Totals":
            continue
        valid_1 = int(row.get("valid_1", 0))
        hallucinated_1 = int(row.get("hallucinated_1", 0))
        valid_2 = int(row.get("valid_2", 0))
        hallucinated_2 = int(row.get("hallucinated_2", 0))
        rows.append(
            {
                "dataset": name,
                "valid_1": valid_1,
                "hallucinated_1": hallucinated_1,
                "hallucination_rate_1": safe_rate(hallucinated_1, valid_1 + hallucinated_1),
                "valid_2": valid_2,
                "hallucinated_2": hallucinated_2,
                "hallucination_rate_2": safe_rate(hallucinated_2, valid_2 + hallucinated_2),
            }
        )

    totals = final_results.loc["Totals"]
    total_valid_1 = int(totals.get("valid_1", 0))
    total_hallucinated_1 = int(totals.get("hallucinated_1", 0))
    total_valid_2 = int(totals.get("valid_2", 0))
    total_hallucinated_2 = int(totals.get("hallucinated_2", 0))

    summary = {
        "run_dir": str(run_dir),
        "metadata": metadata,
        "rows": rows,
        "totals": {
            "valid_1": total_valid_1,
            "hallucinated_1": total_hallucinated_1,
            "hallucination_rate_1": safe_rate(total_hallucinated_1, total_valid_1 + total_hallucinated_1),
            "valid_2": total_valid_2,
            "hallucinated_2": total_hallucinated_2,
            "hallucination_rate_2": safe_rate(total_hallucinated_2, total_valid_2 + total_hallucinated_2),
            "rows_in_package_names": int(len(package_names)),
        },
    }

    out_json = run_dir / f"{args.output_prefix}.json"
    out_md = run_dir / f"{args.output_prefix}.md"
    out_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = [
        "# Package Hallucination Run Summary",
        "",
        f"- Run directory: `{run_dir}`",
        f"- Model: `{metadata.get('model_label', 'unknown')}`",
        f"- Language: `{metadata.get('language', 'unknown')}`",
        f"- Offset / limit per dataset: `{metadata.get('offset', '?')}` / `{metadata.get('limit_per_dataset', '?')}`",
        "",
        "| Dataset | Valid Q1 | Hallucinated Q1 | Hallucination Rate Q1 | Valid Q2 | Hallucinated Q2 | Hallucination Rate Q2 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {dataset} | {valid_1} | {hallucinated_1} | {hallucination_rate_1:.3f} | "
            "{valid_2} | {hallucinated_2} | {hallucination_rate_2:.3f} |".format(**row)
        )
    lines.extend(
        [
            "| **Totals** | {valid_1} | {hallucinated_1} | {hallucination_rate_1:.3f} | "
            "{valid_2} | {hallucinated_2} | {hallucination_rate_2:.3f} |".format(**summary["totals"]),
            "",
            f"- Parsed prompt rows: `{summary['totals']['rows_in_package_names']}`",
        ]
    )
    out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {out_json} and {out_md}")


if __name__ == "__main__":
    main()
