#!/usr/bin/env python3
"""Create a pre-response V3.1 exclusion amendment for prompt-capacity failures."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from codex_build_external_v3_exclusions import normalized_name, repository_key


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-exclusions", type=Path, required=True)
    parser.add_argument("--acquisition-json", type=Path, required=True)
    parser.add_argument("--capacity-json", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    exclusions = json.loads(args.base_exclusions.read_text(encoding="utf-8"))
    acquisition = json.loads(args.acquisition_json.read_text(encoding="utf-8"))
    capacity = json.loads(args.capacity_json.read_text(encoding="utf-8"))
    selected = {row["full_name"]: row for row in acquisition["selected"]}
    amendments = []
    for failure in capacity["insufficient"]:
        row = selected[failure["full_name"]]
        amendments.append({
            "full_name": row["full_name"], "owner": row["owner"],
            "repo_name": row["repo_name"], "api_families": row.get("api_families", []),
            "candidate_count": failure["candidate_count"],
            "reason": "Fewer than seven records satisfy the unchanged frozen prompt criteria.",
        })
        exclusions["full_names"].append(row["full_name"].lower())
        exclusions["owners"].append(row["owner"].lower())
        exclusions["repository_names_normalized"].append(normalized_name(row["repo_name"]))
        exclusions["repository_keys"].append(repository_key(row["repo_name"]))
        exclusions["api_families"].extend(row.get("api_families", []))
    for key in ("full_names", "owners", "repository_names_normalized", "repository_keys", "api_families"):
        exclusions[key] = sorted(set(exclusions[key]))
    exclusions["artifact"] = "external_java_v3_1_exclusions_pre_response_amendment"
    exclusions["amendment"] = {
        "timing": "After repository acquisition and source-only capacity diagnosis; before response generation, detector execution on external responses, or annotation.",
        "rule": "Exclude any selected repository with fewer than seven eligible prompt records and continue in the original frozen search rank order.",
        "projects": amendments,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(exclusions, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(exclusions["amendment"], indent=2))


if __name__ == "__main__":
    main()
