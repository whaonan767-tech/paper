#!/usr/bin/env python3
"""Compare two Python package-hallucination runs at paired-prompt level."""

from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import random
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_3B = ROOT / "Tests" / "Qwen3B_Pilot100_Python"
DEFAULT_7B = ROOT / "Tests" / "Qwen7B_Pilot100_Python"
DEFAULT_OUTPUT = ROOT / "Tests" / "PythonPromptLevelModelComparison_Run20260804"
DATASETS = ("LLM_LY", "LLM_AT", "SO_LY", "SO_AT")
REGISTRY_LABEL = "registry_missing_candidate"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-3b", type=Path, default=DEFAULT_3B)
    parser.add_argument("--run-7b", type=Path, default=DEFAULT_7B)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--prompts-per-dataset", type=int, default=100)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20_260_804)
    return parser.parse_args()


def parse_list(value: str) -> list[str]:
    text = (value or "").strip()
    if not text:
        return []
    parsed = ast.literal_eval(text)
    return [str(item) for item in parsed] if isinstance(parsed, list) else []


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower, upper = math.floor(position), math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def load_run(run_dir: Path, prompts_per_dataset: int, model_key: str) -> dict[str, dict]:
    package_path = run_dir / "PACKAGE_NAMES.csv"
    label_path = run_dir / "python_hallucination_labels.csv"
    with package_path.open("r", encoding="utf-8-sig", newline="") as handle:
        package_rows = list(csv.DictReader(handle))
    expected = prompts_per_dataset * len(DATASETS)
    if len(package_rows) != expected:
        raise SystemExit(f"{run_dir}: expected {expected} package rows, found {len(package_rows)}")

    missing_by_row: dict[int, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    with label_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row["label"] == REGISTRY_LABEL and row["column"] in {"hallucinated_1", "hallucinated_2"}:
                missing_by_row[int(row["row_index"])][row["column"]] += 1

    records = {}
    for row_index, row in enumerate(package_rows):
        dataset = DATASETS[row_index // prompts_per_dataset]
        local_index = row_index % prompts_per_dataset
        prompt_id = f"{dataset}:{local_index:03d}"
        q1_candidates = len(parse_list(row["valid_1"])) + len(parse_list(row["hallucinated_1"]))
        q2_candidates = len(parse_list(row["valid_2"])) + len(parse_list(row["hallucinated_2"]))
        q1_missing = missing_by_row[row_index]["hallucinated_1"]
        q2_missing = missing_by_row[row_index]["hallucinated_2"]
        records[prompt_id] = {
            "prompt_id": prompt_id,
            "dataset": dataset,
            "local_index": local_index,
            f"{model_key}_q1_candidates": q1_candidates,
            f"{model_key}_q2_candidates": q2_candidates,
            f"{model_key}_candidates": q1_candidates + q2_candidates,
            f"{model_key}_q1_registry_missing": q1_missing,
            f"{model_key}_q2_registry_missing": q2_missing,
            f"{model_key}_registry_missing": q1_missing + q2_missing,
            f"{model_key}_any_registry_missing": (q1_missing + q2_missing) > 0,
        }
    return records


def summarize(rows: list[dict], key: str) -> dict:
    count = len(rows)
    any_count = sum(row[f"{key}_any_registry_missing"] for row in rows)
    candidates = sum(row[f"{key}_candidates"] for row in rows)
    missing = sum(row[f"{key}_registry_missing"] for row in rows)
    return {
        "prompts": count,
        "prompts_with_registry_missing": any_count,
        "prompt_rate": any_count / count,
        "candidate_mentions": candidates,
        "mean_candidates_per_prompt": candidates / count,
        "registry_missing_mentions": missing,
        "mean_registry_missing_per_prompt": missing / count,
        "zero_candidate_prompts": sum(row[f"{key}_candidates"] == 0 for row in rows),
        "q1_candidate_mentions": sum(row[f"{key}_q1_candidates"] for row in rows),
        "q2_candidate_mentions": sum(row[f"{key}_q2_candidates"] for row in rows),
        "q1_registry_missing_mentions": sum(row[f"{key}_q1_registry_missing"] for row in rows),
        "q2_registry_missing_mentions": sum(row[f"{key}_q2_registry_missing"] for row in rows),
    }


def stratified_paired_bootstrap(rows: list[dict], repetitions: int, seed: int) -> dict:
    strata: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        strata[row["dataset"]].append(row)
    rng = random.Random(seed)
    draws = defaultdict(list)
    for _ in range(repetitions):
        sampled = [rng.choice(strata[dataset]) for dataset in DATASETS for _ in strata[dataset]]
        n = len(sampled)
        rate_3b = sum(row["m3_any_registry_missing"] for row in sampled) / n
        rate_7b = sum(row["m7_any_registry_missing"] for row in sampled) / n
        candidates_3b = sum(row["m3_candidates"] for row in sampled) / n
        candidates_7b = sum(row["m7_candidates"] for row in sampled) / n
        draws["rate_3b"].append(rate_3b)
        draws["rate_7b"].append(rate_7b)
        draws["risk_difference_3b_minus_7b"].append(rate_3b - rate_7b)
        draws["candidate_difference_3b_minus_7b"].append(candidates_3b - candidates_7b)
    observed_3b = summarize(rows, "m3")
    observed_7b = summarize(rows, "m7")
    estimates = {
        "rate_3b": observed_3b["prompt_rate"],
        "rate_7b": observed_7b["prompt_rate"],
        "risk_difference_3b_minus_7b": observed_3b["prompt_rate"] - observed_7b["prompt_rate"],
        "candidate_difference_3b_minus_7b": observed_3b["mean_candidates_per_prompt"] - observed_7b["mean_candidates_per_prompt"],
    }
    return {
        name: {
            "estimate": estimates[name],
            "ci_low": percentile(values, 0.025),
            "ci_high": percentile(values, 0.975),
        }
        for name, values in draws.items()
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    run_3b = load_run(args.run_3b.resolve(), args.prompts_per_dataset, "m3")
    run_7b = load_run(args.run_7b.resolve(), args.prompts_per_dataset, "m7")
    if set(run_3b) != set(run_7b):
        raise SystemExit("The two runs do not contain the same prompt keys")
    rows = [{**run_3b[key], **run_7b[key]} for key in sorted(run_3b)]
    for row in rows:
        row["paired_any_difference_3b_minus_7b"] = int(row["m3_any_registry_missing"]) - int(row["m7_any_registry_missing"])
        row["paired_candidate_difference_3b_minus_7b"] = row["m3_candidates"] - row["m7_candidates"]
    summary_3b = summarize(rows, "m3")
    summary_7b = summarize(rows, "m7")
    discordance = {
        "3b_only": sum(row["m3_any_registry_missing"] and not row["m7_any_registry_missing"] for row in rows),
        "7b_only": sum(row["m7_any_registry_missing"] and not row["m3_any_registry_missing"] for row in rows),
        "both": sum(row["m3_any_registry_missing"] and row["m7_any_registry_missing"] for row in rows),
        "neither": sum(not row["m3_any_registry_missing"] and not row["m7_any_registry_missing"] for row in rows),
    }
    bootstrap = stratified_paired_bootstrap(rows, args.bootstrap_repetitions, args.seed)
    payload = {
        "analysis": "paired_prompt_level_rule_stratified_python_comparison",
        "label_source": "deterministic post-labeling rules; not independent human annotation",
        "scope": "Q1 and Q2 package-query mentions combined; pip extraction excluded",
        "models": {"qwen_3b": summary_3b, "qwen_7b": summary_7b},
        "paired_discordance": discordance,
        "bootstrap": {
            "repetitions": args.bootstrap_repetitions,
            "seed": args.seed,
            "resampling_unit": "paired prompt within each of four 100-prompt dataset strata",
            "interval": "two-sided 95% percentile",
            "metrics": bootstrap,
        },
        "results": rows,
    }
    (output_dir / "python_prompt_level_comparison.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with (output_dir / "python_prompt_level_comparison.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    def interval(name: str, percent: bool = True) -> str:
        metric = bootstrap[name]
        scale = 100 if percent else 1
        suffix = "%" if percent else ""
        return f"{scale * metric['estimate']:.1f}{suffix} [{scale * metric['ci_low']:.1f}{suffix}, {scale * metric['ci_high']:.1f}{suffix}]"

    lines = [
        "# Paired Prompt-Level Python Comparison", "",
        "Labels are deterministic rule-based strata, not independent human annotations. Q1 and Q2 are combined; `pip` extraction is excluded.", "",
        "| Model | Prompts with registry-missing candidate | Prompt rate | Candidate mentions | Mean candidates/prompt | Registry-missing mentions |",
        "|---|---:|---:|---:|---:|---:|",
        f"| Qwen2.5-Coder-3B-Instruct | {summary_3b['prompts_with_registry_missing']}/400 | {100*summary_3b['prompt_rate']:.1f}% | {summary_3b['candidate_mentions']} | {summary_3b['mean_candidates_per_prompt']:.3f} | {summary_3b['registry_missing_mentions']} |",
        f"| Qwen2.5-Coder-7B-Instruct | {summary_7b['prompts_with_registry_missing']}/400 | {100*summary_7b['prompt_rate']:.1f}% | {summary_7b['candidate_mentions']} | {summary_7b['mean_candidates_per_prompt']:.3f} | {summary_7b['registry_missing_mentions']} |", "",
        f"- Paired prompt risk difference (3B minus 7B): {interval('risk_difference_3b_minus_7b')}.",
        f"- Mean candidate-count difference per prompt (3B minus 7B): {interval('candidate_difference_3b_minus_7b', percent=False)}.",
        f"- Paired discordance: 3B-only `{discordance['3b_only']}`, 7B-only `{discordance['7b_only']}`, both `{discordance['both']}`, neither `{discordance['neither']}`.",
        f"- Bootstrap: `{args.bootstrap_repetitions}` dataset-stratified paired-prompt resamples, seed `{args.seed}`.",
    ]
    (output_dir / "python_prompt_level_comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
