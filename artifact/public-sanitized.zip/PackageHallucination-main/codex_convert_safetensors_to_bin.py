import argparse
import json
import shutil
from pathlib import Path

import torch
from safetensors import safe_open


COPY_FILES = {
    "config.json",
    "generation_config.json",
    "merges.txt",
    "tokenizer.json",
    "tokenizer_config.json",
    "vocab.json",
}


def convert_shard(src_path, dst_path):
    state = {}
    with safe_open(str(src_path), framework="pt", device="cpu") as handle:
        for key in handle.keys():
            state[key] = handle.get_tensor(key)
    torch.save(state, dst_path)
    return sorted(state)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    source_dir = Path(args.source_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for name in COPY_FILES:
        src = source_dir / name
        if src.exists():
            shutil.copy2(src, output_dir / name)

    safetensor_files = sorted(source_dir.glob("model-*-of-*.safetensors"))
    if not safetensor_files:
        raise FileNotFoundError(f"No sharded safetensors files found in {source_dir}")

    original_index = json.loads((source_dir / "model.safetensors.index.json").read_text(encoding="utf-8"))
    original_weight_map = original_index["weight_map"]
    shard_name_map = {}
    for index, src_path in enumerate(safetensor_files, start=1):
        dst_name = f"pytorch_model-{index:05d}-of-{len(safetensor_files):05d}.bin"
        shard_name_map[src_path.name] = dst_name
        dst_path = output_dir / dst_name
        if dst_path.exists():
            print(f"SKIP existing {dst_path}")
            continue
        print(f"CONVERT {src_path.name} -> {dst_name}", flush=True)
        keys = convert_shard(src_path, dst_path)
        print(f"WROTE {dst_name} tensors={len(keys)} bytes={dst_path.stat().st_size}", flush=True)

    bin_weight_map = {
        key: shard_name_map[value]
        for key, value in original_weight_map.items()
    }
    bin_index = {
        "metadata": original_index.get("metadata", {}),
        "weight_map": bin_weight_map,
    }
    (output_dir / "pytorch_model.bin.index.json").write_text(
        json.dumps(bin_index, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"DONE {output_dir}")


if __name__ == "__main__":
    main()
