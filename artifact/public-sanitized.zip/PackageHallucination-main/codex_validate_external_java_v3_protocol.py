#!/usr/bin/env python3
"""Validate frozen V3 acquisition, prompts, responses, and blind annotation inputs."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-json", type=Path, required=True)
    parser.add_argument("--acquisition-json", type=Path)
    parser.add_argument("--prompts-jsonl", type=Path)
    parser.add_argument("--responses-jsonl", type=Path)
    parser.add_argument("--annotation-input", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    checks = []
    freeze = json.loads(args.freeze_json.read_text(encoding="utf-8"))
    checks.append(("freeze_target_repositories", freeze["protocol"]["repositories"] == 30))
    checks.append(("freeze_target_responses", freeze["protocol"]["responses"] == 200))
    if args.acquisition_json:
        acquisition = json.loads(args.acquisition_json.read_text(encoding="utf-8"))
        selected = acquisition["selected"]
        checks.extend([
            ("acquisition_projects_30", len(selected) == 30),
            ("acquisition_unique_full_names", len({row["full_name"].lower() for row in selected}) == 30),
            ("acquisition_unique_owners", len({row["owner"].lower() for row in selected}) == 30),
            ("acquisition_unique_commits", len({row["commit_sha"] for row in selected}) == 30),
        ])
        families = [family for row in selected for family in row.get("api_families", [])]
        checks.append(("acquisition_unique_api_families", len(families) == len(set(families))))
    prompts = None
    if args.prompts_jsonl:
        prompts = read_jsonl(args.prompts_jsonl)
        counts = collections.Counter(row["task"] for row in prompts)
        project_counts = collections.Counter(row["project_id"] for row in prompts)
        checks.extend([
            ("prompts_200", len(prompts) == 200),
            ("prompts_unique_records", len({row["record_id"] for row in prompts}) == 200),
            ("prompts_30_projects", len(project_counts) == 30),
            ("prompts_arm_100_100", counts == {"natural_code_repair": 100, "dependency_advice": 100}),
            ("prompts_project_quotas", sorted(project_counts.values()) == [6] * 10 + [7] * 20),
            ("prompts_ground_truth_hidden", all(row["ground_truth_import"] not in row["prompt"] for row in prompts)),
        ])
    if args.responses_jsonl:
        responses = read_jsonl(args.responses_jsonl)
        checks.extend([
            ("responses_200", len(responses) == 200),
            ("responses_unique_records", len({row["record_id"] for row in responses}) == 200),
            ("responses_all_nonempty", all(str(row.get("response", "")).strip() for row in responses)),
            ("responses_match_prompts", prompts is None or {row["record_id"] for row in responses} == {row["record_id"] for row in prompts}),
        ])
    if args.annotation_input:
        annotation = json.loads(args.annotation_input.read_text(encoding="utf-8"))
        checks.extend([
            ("annotation_200", annotation["records"] == 200),
            ("annotation_two_annotators", annotation["annotators"] == 2),
            ("annotation_detector_blind", annotation["detector_output_included"] is False),
            ("annotation_truth_blind", annotation["ground_truth_included"] is False),
            ("annotation_a_b_same_records", {row["record_id"] for row in annotation["annotator_a"]} == {row["record_id"] for row in annotation["annotator_b"]}),
            ("annotation_a_b_different_order", [row["record_id"] for row in annotation["annotator_a"]] != [row["record_id"] for row in annotation["annotator_b"]]),
        ])
    report = {"artifact": "external_java_v3_protocol_validation", "status": "pass" if all(value for _, value in checks) else "fail", "checks": [{"name": name, "pass": value} for name, value in checks], "inputs": {key: {"path": str(path), "sha256": sha256(path)} for key, path in vars(args).items() if isinstance(path, Path) and path.is_file()}}
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks": len(checks), "passed": sum(value for _, value in checks)}, indent=2))
    if report["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
