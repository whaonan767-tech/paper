import argparse
import csv
import json
import subprocess
import zipfile
from collections import Counter
from pathlib import Path


ORIGINAL_SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}
VALIDITIES = {"valid", "invalid", "malformed", "uncertain"}
EVALUABLE = {"valid", "invalid"}
PLATFORM_PREFIXES = ("java.", "javax.", "jdk.")
DEFAULT_WINDOWS = [
    ("FM50", "Tests/Java_APIHulBench_Qwen3B_FM50/import_maven_mapping_enhanced.json"),
    ("FM50_Offset50", "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50/import_maven_mapping_enhanced.json"),
    ("FM50_Offset100", "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100/import_maven_mapping_enhanced.json"),
    ("FM50_Offset150_tail", "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150/import_maven_mapping_enhanced.json"),
    ("F50_Offset200_tail", "Tests/Java_APIHulBench_Qwen3B_F50_Offset200/import_maven_mapping_enhanced.json"),
]


def read_csv(path):
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, fieldnames=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def clean(value):
    return (value or "").strip().lower()


def final_validity(row):
    for field in ("adjudicated_validity", "annotation_validity"):
        value = clean(row.get(field, ""))
        if value in VALIDITIES:
            return value
    values = [
        clean(row.get("annotator_a_annotation_validity", "")),
        clean(row.get("annotator_b_annotation_validity", "")),
    ]
    values = [value for value in values if value in VALIDITIES]
    if len(values) == 2 and values[0] == values[1]:
        return values[0]
    return ""


def final_label(row):
    for field in ("adjudicated_label", "annotation_label", "annotator_a_annotation_label"):
        value = clean(row.get(field, ""))
        if value:
            return value
    return ""


def join_audit_rows(audit_dir):
    key_rows = {row["audit_id"]: row for row in read_csv(audit_dir / "java_human_annotation_key.csv")}
    label_rows = read_csv(audit_dir / "java_human_annotation_blind_sheet_two_annotators.csv")
    joined = []
    for row in label_rows:
        key = key_rows.get(row.get("audit_id", ""), {})
        merged = {**key, **row}
        merged["truth_validity"] = final_validity(merged)
        merged["truth_label"] = final_label(merged)
        merged["original_detector_suspicious"] = "1" if key.get("detector_suspicious") == "1" else "0"
        joined.append(merged)
    return joined


def candidate_class_prefixes(import_path):
    import_path = (import_path or "").strip()
    if import_path.endswith(".*"):
        import_path = import_path[:-2]
    parts = [part for part in import_path.split(".") if part and part != "*"]
    return [".".join(parts[:end]) for end in range(len(parts), 1, -1)]


def path_class_name(dotted):
    return dotted.replace(".", "/")


def build_maven_class_index(maven_repo):
    classes = set()
    package_prefixes = set()
    jar_count = 0
    if not maven_repo or not maven_repo.exists():
        return classes, package_prefixes, jar_count
    for jar_path in maven_repo.rglob("*.jar"):
        jar_count += 1
        try:
            with zipfile.ZipFile(jar_path) as archive:
                for name in archive.namelist():
                    if not name.endswith(".class") or name.startswith("META-INF/"):
                        continue
                    class_name = name[:-6]
                    classes.add(class_name)
                    if "/" in class_name:
                        package_prefixes.add(class_name.rsplit("/", 1)[0] + "/")
        except zipfile.BadZipFile:
            continue
    return classes, package_prefixes, jar_count


class Resolver:
    def __init__(self, apihul_root, maven_repo, javap_cmd="javap"):
        self.apihul_root = Path(apihul_root)
        self.maven_classes, self.maven_packages, self.jar_count = build_maven_class_index(Path(maven_repo))
        self.project_file_cache = {}
        self.platform_cache = {}
        self.javap_cmd = javap_cmd

    def normalize_relative(self, value):
        value = (value or "").replace("\\", "/").strip()
        if value.startswith("./"):
            value = value[2:]
        return value

    def project_root(self, row):
        project_path = self.normalize_relative(row.get("project_path", ""))
        if not project_path:
            return None
        path = Path(project_path)
        if path.is_absolute():
            return path
        return self.apihul_root / Path(*project_path.split("/"))

    def project_files(self, row):
        root = self.project_root(row)
        if root is None or not root.exists():
            return set()
        if root not in self.project_file_cache:
            files = set()
            for path in root.rglob("*.java"):
                try:
                    files.add(path.relative_to(root).as_posix())
                except ValueError:
                    continue
            self.project_file_cache[root] = files
        return self.project_file_cache[root]

    def project_class_resolves(self, import_path, row):
        files = self.project_files(row)
        if not files:
            return False, ""
        for dotted in candidate_class_prefixes(import_path):
            suffix = path_class_name(dotted) + ".java"
            if any(path.endswith(suffix) for path in files):
                return True, suffix
        return False, ""

    def maven_class_resolves(self, import_path):
        import_path = (import_path or "").strip()
        if import_path.endswith(".*"):
            package = path_class_name(import_path[:-2]) + "/"
            return package in self.maven_packages, package
        for dotted in candidate_class_prefixes(import_path):
            class_name = path_class_name(dotted)
            if class_name in self.maven_classes:
                return True, class_name
        return False, ""

    def platform_class_resolves(self, import_path):
        if not import_path.startswith(PLATFORM_PREFIXES):
            return None, ""
        if import_path.endswith(".*"):
            return True, import_path[:-2]
        for dotted in candidate_class_prefixes(import_path):
            if dotted not in self.platform_cache:
                result = subprocess.run(
                    [self.javap_cmd, dotted],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=10,
                )
                self.platform_cache[dotted] = result.returncode == 0
            if self.platform_cache[dotted]:
                return True, dotted
        return False, ""


def original_flag(row):
    if row.get("original_detector_suspicious") == "1":
        return True
    return row.get("mapping_status") in ORIGINAL_SUSPICIOUS_STATUSES


def recall_extension_rule(row, resolver):
    if original_flag(row):
        return "", ""
    import_path = (row.get("import_path") or "").strip()
    if not import_path:
        return "", ""

    platform_resolves, platform_evidence = resolver.platform_class_resolves(import_path)
    if platform_resolves is False:
        return "unresolved_platform_class", "javap did not resolve the platform import"

    mapping_status = row.get("mapping_status", "")
    classification = row.get("import_classification", "")
    project_prefix = (row.get("project_package_prefix") or "").strip()
    if (
        mapping_status == "no_external_mapping_needed"
        and classification in {"provided_context_import", "project_local_import"}
        and project_prefix
        and import_path.startswith(project_prefix + ".")
    ):
        resolved, evidence = resolver.project_class_resolves(import_path, row)
        if not resolved:
            return "unresolved_project_context_class", "project source index did not resolve the project/context import"

    if mapping_status in {"mapped_known_prefix", "mapped_maven_class_search"}:
        resolved, evidence = resolver.maven_class_resolves(import_path)
        if not resolved:
            return "unresolved_known_external_class", "local Maven jar class index did not resolve the mapped external import"

    return "", ""


def metric_block(rows, flag_field):
    tp = fp = fn = tn = 0
    for row in rows:
        truth = row.get("truth_validity", "")
        if truth not in EVALUABLE:
            continue
        flagged = row.get(flag_field) == "1"
        if flagged and truth == "invalid":
            tp += 1
        elif flagged and truth == "valid":
            fp += 1
        elif not flagged and truth == "invalid":
            fn += 1
        elif not flagged and truth == "valid":
            tn += 1

    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn, "precision": precision, "recall": recall, "f1": f1}


def fmt(value):
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:.3f}"
    return str(value)


def analyze_audit(rows, resolver):
    analyzed = []
    for row in rows:
        row = dict(row)
        rule, reason = recall_extension_rule(row, resolver)
        row["recall_extension_rule"] = rule
        row["recall_extension_reason"] = reason
        row["enhanced_detector_suspicious"] = "1" if original_flag(row) or rule else "0"
        analyzed.append(row)

    original = metric_block(analyzed, "original_detector_suspicious")
    enhanced = metric_block(analyzed, "enhanced_detector_suspicious")
    added = [row for row in analyzed if row["original_detector_suspicious"] != "1" and row["enhanced_detector_suspicious"] == "1"]
    false_negatives = [
        row for row in analyzed if row["original_detector_suspicious"] != "1" and row["truth_validity"] == "invalid"
    ]
    remaining_false_negatives = [
        row for row in analyzed if row["enhanced_detector_suspicious"] != "1" and row["truth_validity"] == "invalid"
    ]
    new_false_positives = [
        row for row in analyzed if row["original_detector_suspicious"] != "1" and row["enhanced_detector_suspicious"] == "1" and row["truth_validity"] == "valid"
    ]
    payload = {
        "rows_total": len(analyzed),
        "maven_jars_indexed": resolver.jar_count,
        "original_metrics": original,
        "enhanced_metrics": enhanced,
        "delta": {
            "tp": enhanced["tp"] - original["tp"],
            "fp": enhanced["fp"] - original["fp"],
            "fn": enhanced["fn"] - original["fn"],
            "tn": enhanced["tn"] - original["tn"],
            "precision": None if original["precision"] is None or enhanced["precision"] is None else enhanced["precision"] - original["precision"],
            "recall": None if original["recall"] is None or enhanced["recall"] is None else enhanced["recall"] - original["recall"],
            "f1": None if original["f1"] is None or enhanced["f1"] is None else enhanced["f1"] - original["f1"],
        },
        "added_flags": len(added),
        "added_flags_by_rule": dict(Counter(row["recall_extension_rule"] for row in added)),
        "added_true_positives_by_rule": dict(Counter(row["recall_extension_rule"] for row in added if row["truth_validity"] == "invalid")),
        "added_false_positives_by_rule": dict(Counter(row["recall_extension_rule"] for row in new_false_positives)),
        "original_false_negatives": len(false_negatives),
        "remaining_false_negatives": len(remaining_false_negatives),
        "new_false_positives": len(new_false_positives),
    }
    return analyzed, false_negatives, remaining_false_negatives, new_false_positives, payload


def load_full_sweep(root):
    rows = []
    for label, rel_path in DEFAULT_WINDOWS:
        path = root / rel_path
        if not path.exists():
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        for row in payload.get("mapped", []):
            row = dict(row)
            row["window_label"] = label
            row["original_detector_suspicious"] = "1" if row.get("mapping_status") in ORIGINAL_SUSPICIOUS_STATUSES else "0"
            rows.append(row)
    return rows


def analyze_full_sweep(rows, resolver):
    analyzed = []
    for row in rows:
        row = dict(row)
        rule, reason = recall_extension_rule(row, resolver)
        row["recall_extension_rule"] = rule
        row["recall_extension_reason"] = reason
        row["enhanced_detector_suspicious"] = "1" if original_flag(row) or rule else "0"
        analyzed.append(row)
    original_count = sum(1 for row in analyzed if row["original_detector_suspicious"] == "1")
    enhanced_count = sum(1 for row in analyzed if row["enhanced_detector_suspicious"] == "1")
    added = [row for row in analyzed if row["original_detector_suspicious"] != "1" and row["enhanced_detector_suspicious"] == "1"]
    return analyzed, {
        "rows_total": len(analyzed),
        "original_suspicious_rows": original_count,
        "enhanced_suspicious_rows": enhanced_count,
        "added_suspicious_rows": len(added),
        "added_by_rule": dict(Counter(row["recall_extension_rule"] for row in added)),
        "added_by_window": dict(Counter(row["window_label"] for row in added)),
        "added_by_mapping_status": dict(Counter(row["mapping_status"] for row in added)),
    }


def added_candidates_for_probe(rows):
    out = []
    for row in rows:
        if row.get("original_detector_suspicious") == "1" or row.get("enhanced_detector_suspicious") != "1":
            continue
        probe_row = dict(row)
        probe_row["original_mapping_status"] = row.get("mapping_status", "")
        probe_row["mapping_status"] = row.get("recall_extension_rule", "")
        out.append(probe_row)
    return out


def write_markdown(path, audit_metrics, fn_rows, new_fp_rows, full_sweep_metrics):
    original = audit_metrics["original_metrics"]
    enhanced = audit_metrics["enhanced_metrics"]
    delta = audit_metrics["delta"]
    lines = [
        "# Java Recall Extension Audit",
        "",
        "This is a retrospective recall-extension ablation over the completed human-audit sample.",
        "It does not replace the original detector result; it evaluates additional verifiable checks suggested by the false-negative analysis.",
        "",
        "## Audit-Sample Metrics",
        "",
        "| Detector | TP | FP | FN | TN | Precision | Recall | F1 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
        f"| Original | {original['tp']} | {original['fp']} | {original['fn']} | {original['tn']} | {fmt(original['precision'])} | {fmt(original['recall'])} | {fmt(original['f1'])} |",
        f"| + recall extension | {enhanced['tp']} | {enhanced['fp']} | {enhanced['fn']} | {enhanced['tn']} | {fmt(enhanced['precision'])} | {fmt(enhanced['recall'])} | {fmt(enhanced['f1'])} |",
        f"| Delta | {delta['tp']} | {delta['fp']} | {delta['fn']} | {delta['tn']} | {fmt(delta['precision'])} | {fmt(delta['recall'])} | {fmt(delta['f1'])} |",
        "",
        "## Added-Flag Rules",
        "",
        "| Rule | Added flags | Added true positives | Added false positives |",
        "|---|---:|---:|---:|",
    ]
    rules = sorted(set(audit_metrics["added_flags_by_rule"]) | set(audit_metrics["added_true_positives_by_rule"]) | set(audit_metrics["added_false_positives_by_rule"]))
    for rule in rules:
        lines.append(
            f"| `{rule}` | {audit_metrics['added_flags_by_rule'].get(rule, 0)} | "
            f"{audit_metrics['added_true_positives_by_rule'].get(rule, 0)} | "
            f"{audit_metrics['added_false_positives_by_rule'].get(rule, 0)} |"
        )
    lines.extend(
        [
            "",
            "## Original False Negatives",
            "",
            "| Audit id | Rule | Mapping status | Import | Human label |",
            "|---|---|---|---|---|",
        ]
    )
    for row in fn_rows:
        lines.append(
            f"| {row.get('audit_id', '')} | `{row.get('recall_extension_rule', '') or 'remaining_fn'}` | "
            f"`{row.get('mapping_status', '')}` | `{row.get('import_path', '')}` | `{row.get('truth_label', '')}` |"
        )
    if new_fp_rows:
        lines.extend(["", "## New False Positives", "", "| Audit id | Rule | Import | Human label |", "|---|---|---|---|"])
        for row in new_fp_rows:
            lines.append(
                f"| {row.get('audit_id', '')} | `{row.get('recall_extension_rule', '')}` | `{row.get('import_path', '')}` | `{row.get('truth_label', '')}` |"
            )
    lines.extend(
        [
            "",
            "## Full-Sweep Added Flags",
            "",
            f"- Full-sweep rows: `{full_sweep_metrics['rows_total']}`",
            f"- Original suspicious rows: `{full_sweep_metrics['original_suspicious_rows']}`",
            f"- Enhanced suspicious rows: `{full_sweep_metrics['enhanced_suspicious_rows']}`",
            f"- Added suspicious rows: `{full_sweep_metrics['added_suspicious_rows']}`",
            f"- Added by rule: `{full_sweep_metrics['added_by_rule']}`",
            f"- Added by window: `{full_sweep_metrics['added_by_window']}`",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="PackageHallucination-main root")
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--maven-repo", default=None)
    parser.add_argument("--javap", default="javap")
    parser.add_argument("--output-dir", default="Tests/Java_APIHulBench_RecallExtension")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / "Tests/Java_APIHulBench_HumanAudit"
    maven_repo = Path(args.maven_repo) if args.maven_repo else Path(args.apihul_root) / "_validation_cache/maven_repository"
    resolver = Resolver(Path(args.apihul_root), maven_repo, javap_cmd=args.javap)
    output_dir = root / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    audit_rows = join_audit_rows(audit_dir)
    analyzed, fn_rows, remaining_fn_rows, new_fp_rows, audit_metrics = analyze_audit(audit_rows, resolver)
    full_rows = load_full_sweep(root)
    full_analyzed, full_metrics = analyze_full_sweep(full_rows, resolver)

    fieldnames = [
        "audit_id",
        "sample_group",
        "negative_bucket",
        "window_label",
        "candidate_record_id",
        "original_record_id",
        "import_path",
        "mapping_status",
        "import_classification",
        "truth_validity",
        "truth_label",
        "original_detector_suspicious",
        "enhanced_detector_suspicious",
        "recall_extension_rule",
        "recall_extension_reason",
        "annotator_a_annotation_rationale",
    ]
    write_csv(output_dir / "java_recall_extension_audit_rows.csv", analyzed, fieldnames)
    write_csv(output_dir / "java_recall_extension_false_negatives.csv", fn_rows, fieldnames)
    write_csv(output_dir / "java_recall_extension_remaining_false_negatives.csv", remaining_fn_rows, fieldnames)
    write_csv(output_dir / "java_recall_extension_new_false_positives.csv", new_fp_rows, fieldnames)
    write_csv(
        output_dir / "java_recall_extension_full_sweep_rows.csv",
        full_analyzed,
        [
            "window_label",
            "dataset",
            "record_id",
            "original_record_id",
            "source_line",
            "project_path",
            "file_path",
            "import_path",
            "mapping_status",
            "import_classification",
            "original_detector_suspicious",
            "enhanced_detector_suspicious",
            "recall_extension_rule",
            "recall_extension_reason",
        ],
    )
    write_csv(
        output_dir / "java_recall_extension_added_candidates_for_probe.csv",
        added_candidates_for_probe(full_analyzed),
        [
            "window_label",
            "dataset",
            "record_id",
            "original_record_id",
            "source_line",
            "project_path",
            "file_path",
            "import_path",
            "mapping_status",
            "original_mapping_status",
            "import_classification",
            "recall_extension_rule",
            "recall_extension_reason",
        ],
    )
    payload = {
        "audit": audit_metrics,
        "full_sweep": full_metrics,
        "remaining_false_negative_ids": [row.get("audit_id", "") for row in remaining_fn_rows],
        "new_false_positive_ids": [row.get("audit_id", "") for row in new_fp_rows],
    }
    write_json(output_dir / "java_recall_extension_summary.json", payload)
    write_markdown(output_dir / "java_recall_extension_summary.md", audit_metrics, fn_rows, new_fp_rows, full_metrics)
    print(f"original_precision={fmt(audit_metrics['original_metrics']['precision'])}")
    print(f"original_recall={fmt(audit_metrics['original_metrics']['recall'])}")
    print(f"original_f1={fmt(audit_metrics['original_metrics']['f1'])}")
    print(f"enhanced_precision={fmt(audit_metrics['enhanced_metrics']['precision'])}")
    print(f"enhanced_recall={fmt(audit_metrics['enhanced_metrics']['recall'])}")
    print(f"enhanced_f1={fmt(audit_metrics['enhanced_metrics']['f1'])}")
    print(f"added_flags={audit_metrics['added_flags']}")
    print(f"new_false_positives={audit_metrics['new_false_positives']}")
    print(f"full_sweep_added={full_metrics['added_suspicious_rows']}")


if __name__ == "__main__":
    main()
