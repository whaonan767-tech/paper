#!/usr/bin/env python3
"""Reliably capture the already-frozen V3 GitHub search query after transport failures."""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


QUERY = "language:Java fork:false archived:false stars:100..2000 size:<15000"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--pages", type=int, default=5)
    parser.add_argument("--per-page", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=180.0)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    retry = Retry(total=8, connect=8, read=8, backoff_factor=2, status_forcelist=(429, 500, 502, 503, 504), allowed_methods=("GET",))
    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=retry))
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "dependency-audit-research-v3"}
    pages = []
    items = []
    for page in range(1, args.pages + 1):
        path = args.output_dir / f"github_search_page_{page}.json"
        if args.resume and path.is_file():
            payload = json.loads(path.read_text(encoding="utf-8"))
        else:
            response = session.get(
                "https://api.github.com/search/repositories",
                params={"q": QUERY, "sort": "updated", "order": "desc", "per_page": args.per_page, "page": page},
                headers=headers,
                timeout=args.timeout,
            )
            response.raise_for_status()
            payload = response.json()
            path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            time.sleep(2)
        pages.append({"page": page, "path": path.name, "sha256": sha256(path), "items": len(payload.get("items", []))})
        items.extend(payload.get("items", []))
        print(f"PAGE {page}/{args.pages} items={len(payload.get('items', []))}", flush=True)
    snapshot = {
        "artifact": "external_java_v3_github_search_snapshot", "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "query": QUERY, "sort": "updated", "order": "desc", "per_page": args.per_page,
        "transport": "requests with urllib3 retry adapter after two urllib incomplete-read failures and one PowerShell receive failure",
        "pages": pages, "items": items,
    }
    output = args.output_dir / "github_search_snapshot_v3.json"
    output.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"pages": len(pages), "items": len(items), "output": str(output), "sha256": sha256(output)}, indent=2))


if __name__ == "__main__":
    main()
