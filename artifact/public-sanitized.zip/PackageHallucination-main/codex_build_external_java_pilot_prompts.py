#!/usr/bin/env python3
"""Build deterministic masked-import prompts from a prospective project corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


IMPORT_RE = re.compile(r"(?m)^[ \t]*import\s+(?:static\s+)?([A-Za-z_][\w.*]*)\s*;[ \t]*(?:\r?\n|$)")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--acquisition-dir", type=Path, required=True)
    parser.add_argument("--output-jsonl", type=Path, required=True)
    parser.add_argument("--per-project", type=int, default=2)
    parser.add_argument("--seed", default="20260814")
    return parser.parse_args()


def stable_key(seed: str, value: str) -> str:
    return hashlib.sha256(f"{seed}:{value}".encode()).hexdigest()


def main() -> None:
    args = parse_args()
    acquisition_dir = args.acquisition_dir.resolve()
    metadata = json.loads((acquisition_dir / "metadata" / "external_project_acquisition.json").read_text(encoding="utf-8"))
    rows = []
    skipped = []
    for project_index, project in enumerate(metadata["selected"], start=1):
        project_relative = project.get("project_relative_path", f"projects/{project['project_dir']}")
        project_root = acquisition_dir / project_relative
        candidates = []
        for path in project_root.rglob("*.java"):
            relative_parts = path.relative_to(project_root).parts
            if not any(relative_parts[index : index + 3] == ("src", "main", "java") for index in range(len(relative_parts) - 2)):
                continue
            if any(part in {"target", "build", ".git"} for part in relative_parts):
                continue
            if path.name in {"package-info.java", "module-info.java"}:
                continue
            source = path.read_text(encoding="utf-8", errors="replace")
            imports = [match.group(1) for match in IMPORT_RE.finditer(source) if not match.group(1).endswith(".*")]
            if len(imports) < 2 or not 500 <= len(source) <= 12000:
                continue
            relative = path.relative_to(project_root).as_posix()
            candidates.append((stable_key(args.seed, f"{project['full_name']}:{relative}"), path, source, imports))
        candidates.sort(key=lambda item: item[0])
        chosen = candidates[: args.per_project]
        if len(chosen) < args.per_project:
            skipped.append({"project": project["full_name"], "eligible_files": len(candidates)})
        for file_index, (_, path, source, imports) in enumerate(chosen, start=1):
            relative = path.relative_to(project_root).as_posix()
            hidden = min(imports, key=lambda value: stable_key(args.seed, f"{relative}:{value}"))
            masked, replacements = re.subn(
                rf"(?m)^[ \t]*import\s+(?:static\s+)?{re.escape(hidden)}\s*;[ \t]*(?:\r?\n|$)",
                "// [MISSING_IMPORT]\n",
                source,
                count=1,
            )
            if replacements != 1:
                raise AssertionError(f"Could not mask exactly one import in {path}")
            record_id = f"EXT_P{project_index:03d}_{file_index:02d}"
            prompt = (
                "One Java import was replaced by // [MISSING_IMPORT]. Return exactly one Java import statement "
                "and no prose or code fence. Use the fully qualified import needed by the unchanged file.\n\n" + masked
            )
            rows.append(
                {
                    "record_id": record_id,
                    "source_line": len(rows) + 1,
                    "dataset": "prospective_external_java_pilot",
                    "split": "external",
                    "task": "masked_import_exact_one",
                    "project_id": project["full_name"],
                    "project_commit": project["commit_sha"],
                    "project_path": f"{acquisition_dir.name}/{project_relative}",
                    "file_path": f"{acquisition_dir.name}/{project_relative}/{relative}",
                    "ground_truth": f"import {hidden};",
                    "ground_truth_import": hidden,
                    "prompt": prompt,
                }
            )
    args.output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")
    summary = {
        "protocol_version": "v2-multimodule",
        "revision_reason": "V1 scanned only root src/main/java and yielded eligible files in 1/8 projects; V2 recursively discovers module src/main/java trees before any model output is generated.",
        "records": len(rows),
        "projects_with_records": len({row["project_id"] for row in rows}),
        "per_project_target": args.per_project,
        "seed": args.seed,
        "skipped": skipped,
    }
    args.output_jsonl.with_suffix(".summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_jsonl": str(args.output_jsonl), **summary}, indent=2))


if __name__ == "__main__":
    main()
