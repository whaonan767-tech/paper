import argparse
import json
from pathlib import Path


def read_jsonl(path):
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                yield line_no, json.loads(line)


def clipped(text, max_chars):
    text = (text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n/* ... clipped ... */"


def build_prompt(record, max_project_chars, max_file_chars, max_function_chars):
    project_description = clipped(record.get("project_description", ""), max_project_chars)
    current_file = clipped(record.get("current_file", ""), max_file_chars)
    incomplete_function = clipped(record.get("incomplete_function", ""), max_function_chars)
    file_path = record.get("file_path", "")

    return (
        "You are working inside a Java project. Complete the incomplete Java code and identify any "
        "external dependencies needed to compile or use your completion.\n\n"
        "Return your answer in this exact structure:\n"
        "1. Java code block with the completed code or method body.\n"
        "2. Dependencies section containing Maven XML, Gradle declarations, Maven coordinates, or Java import statements.\n"
        "If no external dependency is needed, write: No external dependency.\n\n"
        f"Project description:\n{project_description}\n\n"
        f"Current file path:\n{file_path}\n\n"
        f"Current file prefix:\n```java\n{current_file}\n```\n\n"
        f"Incomplete function prefix:\n```java\n{incomplete_function}\n```\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apihul-root", required=True)
    parser.add_argument("--splits", nargs="+", choices=["F", "M"], default=["F", "M"])
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit-per-split", type=int, default=10)
    parser.add_argument("--max-project-chars", type=int, default=900)
    parser.add_argument("--max-file-chars", type=int, default=1800)
    parser.add_argument("--max-function-chars", type=int, default=900)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    root = Path(args.apihul_root)
    output_jsonl = Path(args.output_jsonl)
    output_md = Path(args.output_md)
    output_jsonl.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for split in args.splits:
        input_path = root / f"APIHulBench_{split}.jsonl"
        selected = []
        for source_line, record in read_jsonl(input_path):
            selected.append((source_line, record))
        subset = selected[args.offset : args.offset + args.limit_per_split]
        for local_index, (source_line, record) in enumerate(subset):
            record_id = f"APIHulBench_{split}_{args.offset + local_index:04d}"
            rows.append(
                {
                    "record_id": record_id,
                    "dataset": f"APIHulBench_{split}",
                    "split": split,
                    "source_line": source_line,
                    "project_path": record.get("project_path", ""),
                    "file_path": record.get("file_path", ""),
                    "ground_truth": record.get("ground_truth", ""),
                    "task": "java_dependency_generation",
                    "prompt": build_prompt(
                        record,
                        args.max_project_chars,
                        args.max_file_chars,
                        args.max_function_chars,
                    ),
                }
            )

    with output_jsonl.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")

    counts = {}
    for row in rows:
        counts[row["dataset"]] = counts.get(row["dataset"], 0) + 1

    lines = [
        "# APIHulBench Java Dependency Prompt Set",
        "",
        f"- Source root: `{root}`",
        f"- Offset: `{args.offset}`",
        f"- Limit per split: `{args.limit_per_split}`",
        f"- Total prompts: `{len(rows)}`",
        "",
        "| Dataset | Prompts |",
        "|---|---:|",
    ]
    for dataset, count in sorted(counts.items()):
        lines.append(f"| {dataset} | {count} |")
    lines.extend(
        [
            "",
            "Prompt fields keep `ground_truth` in the JSONL for later auditing, but the rendered prompt does not expose it to the model.",
        ]
    )
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(rows)} prompts to {output_jsonl}")


if __name__ == "__main__":
    main()
