from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def read_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    ap = argparse.ArgumentParser(description="Validate the new external, baseline-restoration, and cost experiments.")
    ap.add_argument("--root", type=Path, default=None, help="Artifact root; defaults to the parent of this repository.")
    ap.add_argument("--output-dir", type=Path, default=None)
    args = ap.parse_args()
    root = (args.root or Path(__file__).resolve().parents[1]).resolve()
    repo = root / "PackageHallucination-main"
    if not repo.is_dir():
        repo = root / "PackageHallucination-source" / "PackageHallucination-main"
    checks = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append({"name": name, "pass": bool(condition), "detail": detail})

    external = read_json(root / "external_evaluation" / "build_truth_final" / "external_candidate_build_truth_final.json")
    s = external["summary"]
    d = s["detector"]
    check("external_records", s["candidate_rows"] == 16, f"candidate_rows={s['candidate_rows']}")
    check("external_projects", s["projects"] == 8, f"projects={s['projects']}")
    check("external_exact_recoveries", s["exact_recoveries"] == 8, f"exact_recoveries={s['exact_recoveries']}")
    check("external_truth_counts", s["truth_counts"] == {"invalid": 3, "valid": 13}, str(s["truth_counts"]))
    check("external_detector_confusion", (d["tp"], d["fp"], d["fn"], d["tn"]) == (3, 1, 0, 12), str(d))
    check("external_truth_is_source_build_api", external["truth_protocol"]["human_annotation"] is False, str(external["truth_protocol"]))
    check("external_no_uncertain_rows", "uncertain" not in s["truth_counts"], str(s["truth_counts"]))

    mapping = read_json(root / "external_evaluation" / "benchmark" / "mapping_v2" / "mapping_practical_benchmark.json")
    ms = mapping["summary"]
    check("mapping_rows", ms["rows"] == 16, f"rows={ms['rows']}")
    check("mapping_cold_requests", ms["cold_registry_requests"] == 4, f"cold_registry_requests={ms['cold_registry_requests']}")
    check("mapping_warm_requests", ms["warm_registry_requests"] == 0, f"warm_registry_requests={ms['warm_registry_requests']}")
    check("mapping_warm_hit_rate", ms["warm_cache_hit_rate"] == 1.0, f"warm_cache_hit_rate={ms['warm_cache_hit_rate']}")
    check("mapping_class_search_keys", ms["maven_class_search_incremental_query_keys"] == 2, f"new_query_keys={ms['maven_class_search_incremental_query_keys']}")

    sanitizer = read_json(repo / "Tests" / "Java_APIHulBench_SanitizerRealTestProbe_Final_Run20260814" / "sanitizer_real_test_probe_final.json")
    ss = sanitizer["summary"]
    baseline_restoration_pairs = ss.get("baseline_restoration_pairs", ss.get("behavior_preservation_pairs"))
    ss_public = {key: value for key, value in ss.items() if key != "behavior_preservation_pairs"}
    ss_public["baseline_restoration_pairs"] = baseline_restoration_pairs
    check("sanitizer_records", ss["selected_invalid_records"] == 5, f"records={ss['selected_invalid_records']}")
    check("sanitizer_units_projects", (ss["selected_build_units"], ss["selected_projects"]) == (3, 3), str(ss_public))
    check("sanitizer_raw_failures", ss["raw_injected_failures"] == 5, f"raw_injected_failures={ss['raw_injected_failures']}")
    check("sanitizer_pass_pairs", ss["sanitized_passes_with_nonzero_tests"] == 5 and baseline_restoration_pairs == 5, str(ss_public))
    check("sanitizer_zero_failures", ss["sanitized_total_failures"] == 0 and ss["sanitized_total_errors"] == 0, str(ss_public))
    check("sanitizer_unique_baseline_tests", ss["baseline_unique_tests"] == 451, f"baseline_unique_tests={ss['baseline_unique_tests']}")

    generation = read_json(root / "external_evaluation" / "generations" / "qwen3b_v2" / "metadata.json")
    check("external_generation_records", generation["records"] == 16, f"records={generation['records']}")
    responses_path = root / "external_evaluation" / "generations" / "qwen3b_v2" / "responses.jsonl"
    response_rows = [json.loads(line) for line in responses_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    check("external_generation_rows", len(response_rows) == 16, f"response_rows={len(response_rows)}")

    agreement = read_json(root / "external_evaluation_v3" / "annotation" / "merge" / "annotation_agreement.json")
    scored = read_json(root / "external_evaluation_v3" / "results" / "external_v3_scored.json")
    adjudication = read_json(root / "external_evaluation_v3" / "annotation" / "merge" / "annotation_adjudication_audit.json")
    engineering = read_json(root / "external_evaluation_v3" / "build_trial" / "engineering_stop.json")
    modes = scored["uncertain_sensitivity"]
    v1 = modes["exclude"]["v1"]
    v2 = modes["exclude"]["v2"]
    intervals = scored["project_clustered_bootstrap"]["intervals"]
    gate = scored["claim_gate"]
    approx = lambda left, right: abs(float(left) - float(right)) < 1e-12

    check("v3_records_projects", (scored["records"], scored["projects"]) == (200, 30), f"records={scored['records']} projects={scored['projects']}")
    check("v3_invalid_mentions_projects", (scored["invalid_or_malformed_mentions"], scored["projects_with_invalid_or_malformed"]) == (117, 12), str((scored["invalid_or_malformed_mentions"], scored["projects_with_invalid_or_malformed"])))
    check("v3_annotator_mentions", (agreement["annotator_a_mentions"], agreement["annotator_b_mentions"]) == (532, 587), str((agreement["annotator_a_mentions"], agreement["annotator_b_mentions"])))
    check("v3_matched_mentions", agreement["matched_mentions"] == 279, f"matched={agreement['matched_mentions']}")
    check("v3_enumeration_agreement", approx(agreement["mention_set_jaccard"], 0.33214285714285713) and approx(agreement["mention_set_f1"], 0.49865951742627346), str(agreement))
    check("v3_label_agreement", approx(agreement["matched_label_agreement"], 0.8817204301075269) and approx(agreement["cohen_kappa"], 0.805315909667597), str(agreement))
    check("v3_exact_disagreement_rows", (agreement["exact_agreement_rows"], agreement["disagreement_rows"]) == (146, 54), str((agreement["exact_agreement_rows"], agreement["disagreement_rows"])))
    check("v3_truth_inventory", v2["counts"]["ext_tp"] + v2["counts"]["ext_fn"] == 543 and adjudication["adjudicated_label_counts"]["uncertain"] == 262, f"truth={v2['counts']['ext_tp'] + v2['counts']['ext_fn']} uncertain={adjudication['adjudicated_label_counts']['uncertain']}")
    check("v3_v1_extraction", approx(v1["extraction"]["precision"], 0.5813953488372093) and approx(v1["extraction"]["recall"], 0.09208103130755065), str(v1["extraction"]))
    check("v3_v1_end_to_end", approx(v1["end_to_end"]["precision"], 0.8571428571428571) and approx(v1["end_to_end"]["recall"], 0.10256410256410256), str(v1["end_to_end"]))
    check("v3_v2_extraction", approx(v2["extraction"]["precision"], 0.5231958762886598) and approx(v2["extraction"]["recall"], 0.3738489871086556), str(v2["extraction"]))
    check("v3_v2_conditional", approx(v2["conditional_classification"]["precision"], 0.5412844036697247) and approx(v2["conditional_classification"]["recall"], 0.9076923076923077), str(v2["conditional_classification"]))
    check("v3_v2_end_to_end", approx(v2["end_to_end"]["precision"], 0.31891891891891894) and approx(v2["end_to_end"]["recall"], 0.5042735042735043), str(v2["end_to_end"]))
    check("v3_v2_recall_interval", approx(intervals["v2_recall"]["ci_low"], 0.18131696428571428) and approx(intervals["v2_recall"]["ci_high"], 0.8461678832116786), str(intervals["v2_recall"]))
    check("v3_recall_delta_interval", approx(v2["end_to_end"]["recall"] - v1["end_to_end"]["recall"], 0.4017094017094017) and approx(intervals["recall_delta"]["ci_low"], 0.047619047619047616) and approx(intervals["recall_delta"]["ci_high"], 0.7789473684210526), str(intervals["recall_delta"]))
    check("v3_detector_claim_gate", gate["detector_prototype_claim_allowed"] is False and gate["v2_end_to_end_precision_at_least_0_90"] is False and all(gate[key] for key in gate if key not in {"detector_prototype_claim_allowed", "v2_end_to_end_precision_at_least_0_90"}), str(gate))
    check("v3_engineering_baselines", (engineering["baseline_projects"], engineering["baseline_pass_nonzero"], engineering["baseline_pass_zero"], engineering["baseline_failed"]) == (30, 2, 1, 27), str((engineering["baseline_projects"], engineering["baseline_pass_nonzero"], engineering["baseline_pass_zero"], engineering["baseline_failed"])))
    check("v3_engineering_extension", (engineering["extension_screened"], engineering["extension_selected"]) == (386, 0), str((engineering["extension_screened"], engineering["extension_selected"])))
    check("v3_engineering_interventions", engineering["intervention_units_run"] == 0 and engineering["practice_effect_claim_allowed"] is False, str((engineering["intervention_units_run"], engineering["practice_effect_claim_allowed"])))
    check("v3_uncertain_sensitivity", approx(modes["positive"]["v2"]["end_to_end"]["recall"], 0.19525065963060687) and approx(modes["negative"]["v2"]["end_to_end"]["precision"], 0.295), str({"positive": modes["positive"]["v2"]["end_to_end"], "negative": modes["negative"]["v2"]["end_to_end"]}))
    failed = [c for c in checks if not c["pass"]]
    result = {
        "artifact": "new_experiment_validation",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "root": "<ARTIFACT_ROOT>",
        "summary": {"checks": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "checks": checks,
    }
    out = args.output_dir or (repo / "Tests" / ("NewExperimentValidation_" + datetime.now().strftime("%Y%m%d_%H%M%S")))
    out.mkdir(parents=True, exist_ok=True)
    (out / "new_experiment_validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    (out / "new_experiment_validation.md").write_text(
        "# New Experiment Validation\n\n"
        f"- Result: {'PASS' if not failed else 'FAIL'} {len(checks) - len(failed)}/{len(checks)} checks.\n"
        "- Scope: post-freeze protocol trial, prospective 30-repository V1/V2 evaluation, engineering eligibility stop, sanitizer baseline-restoration probe, and mapping cost/cache benchmark.\n"
        "- The 8-repository trial labels are source/build/API-grounded; the 30-repository evaluation uses two independent detector-blind blank sheets.\n\n"
        + "\n".join(f"- [{'PASS' if c['pass'] else 'FAIL'}] {c['name']}: {c['detail']}" for c in checks)
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"output_dir": str(out), **result["summary"]}, ensure_ascii=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
