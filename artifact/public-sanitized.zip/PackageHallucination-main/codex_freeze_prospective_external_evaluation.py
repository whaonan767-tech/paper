#!/usr/bin/env python3
"""Freeze the detector/tool snapshot before acquiring an external project corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
APIM_ROOT = WORKSPACE / "<LOCAL_APIHULBENCH_ROOT>"

FROZEN_FILES = (
    ROOT / "codex_java_dependency_extractor.py",
    ROOT / "codex_classify_java_imports.py",
    ROOT / "codex_map_java_imports_to_maven.py",
    ROOT / "codex_apply_java_dependency_sanitizer.py",
    ROOT / "codex_java_import_build_probe.py",
    ROOT / "codex_java_dependency_generation_runner.py",
    ROOT / "codex_prepare_raw_response_mention_audit.py",
    ROOT / "codex_freeze_prospective_external_evaluation.py",
    ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731" / "full598_candidates_with_audit_status.csv",
    ROOT / "Tests" / "Java_APIHulBench_Full598_HeldoutAudit_Run20260731" / "full598_final_human_truth.csv",
    APIM_ROOT / "outputs" / "build_validation_audit.json",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--model-dir",
        type=Path,
        default=WORKSPACE / "<LOCAL_MODEL_CACHE>" / "Qwen2.5-Coder-3B-Instruct",
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def relative_display(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(WORKSPACE).as_posix()
    except ValueError:
        return resolved.name


def project_inventory() -> list[dict]:
    repositories = APIM_ROOT / "repositories"
    projects = []
    for path in sorted((item for item in repositories.iterdir() if item.is_dir()), key=lambda item: item.name.lower()):
        projects.append({"project_path": f"repositories/{path.name}"})
    return projects


def model_identity(model_dir: Path) -> dict:
    files = []
    for name in ("config.json", "generation_config.json", "model.safetensors.index.json", "tokenizer_config.json"):
        path = model_dir / name
        if not path.exists():
            raise SystemExit(f"Missing model identity file: {path}")
        files.append({"path": f"<LOCAL_MODEL_CACHE>/{model_dir.name}/{name}", "sha256": sha256(path), "size_bytes": path.stat().st_size})
    shards = []
    for path in sorted(model_dir.glob("*.safetensors")):
        shards.append({"name": path.name, "size_bytes": path.stat().st_size})
    return {"directory": f"<LOCAL_MODEL_CACHE>/{model_dir.name}", "identity_files": files, "weight_shards": shards}


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise SystemExit(f"Freeze directory already exists: {output_dir}")
    output_dir.mkdir(parents=True)

    files = []
    for path in FROZEN_FILES:
        if not path.exists():
            raise SystemExit(f"Missing freeze input: {path}")
        files.append({"path": relative_display(path), "sha256": sha256(path), "size_bytes": path.stat().st_size})

    projects = project_inventory()
    project_list_text = "\n".join(row["project_path"] for row in projects) + "\n"
    project_list_path = output_dir / "known_project_paths.txt"
    project_list_path.write_text(project_list_text, encoding="utf-8", newline="\n")

    payload = {
        "artifact": "prospective_external_evaluation_freeze",
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "frozen_before_external_project_acquisition": True,
        "purpose": "Identify the exact detector, extractor, mapper, sanitizer, generation runner, and known-project boundary before any new external corpus is inspected.",
        "known_project_count": len(projects),
        "known_project_paths_sha256": sha256(project_list_path),
        "known_project_paths": projects,
        "model": model_identity(args.model_dir.resolve()),
        "files": files,
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
        },
        "claim_boundary": {
            "existing_97_projects_are_not_external_test_data": True,
            "new_project_outputs_must_be_generated_after_this_freeze": True,
            "human_or_build_grounded_truth_must_be_collected_without_rule_changes": True,
            "no_external_performance_claim_until_truth_is_complete": True,
        },
    }
    json_path = output_dir / "prospective_external_evaluation_freeze.json"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = [
        "# Prospective External-Evaluation Freeze",
        "",
        f"- Frozen at UTC: `{payload['frozen_at_utc']}`.",
        f"- Known local projects: `{len(projects)}`.",
        f"- Known-project list SHA-256: `{payload['known_project_paths_sha256']}`.",
        "- External projects and their model outputs must be acquired after this timestamp.",
        "- Detector/tool rules must not change until external truth is locked.",
        "- Existing projects cannot be relabeled as an external test set.",
        "",
        "## Frozen Files",
        "",
        "| File | SHA-256 |",
        "|---|---|",
    ]
    lines.extend(f"| `{row['path']}` | `{row['sha256']}` |" for row in files)
    (output_dir / "prospective_external_evaluation_freeze.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "known_projects": len(projects), "frozen_files": len(files)}, indent=2))


if __name__ == "__main__":
    main()
