import argparse
import csv
import json
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def read_csv(path):
    return list(csv.DictReader(path.open("r", encoding="utf-8")))


def count_by(rows, key):
    counts = {}
    for row in rows:
        value = row.get(key, "")
        counts[value] = counts.get(value, 0) + 1
    return counts


def summarize(label, rows):
    suspicious_rows = [row for row in rows if row.get("mapping_status") in SUSPICIOUS_MAPPING_STATUSES]
    suspicious_records = {row.get("original_record_id", "") for row in suspicious_rows if row.get("original_record_id", "")}
    return {
        "label": label,
        "records_with_rows": len({row.get("original_record_id", "") for row in rows if row.get("original_record_id", "")}),
        "candidate_rows": len(rows),
        "suspicious_rows": len(suspicious_rows),
        "suspicious_records": len(suspicious_records),
        "mapping_status_counts": count_by(rows, "mapping_status"),
        "suspicious_status_counts": count_by(suspicious_rows, "mapping_status"),
    }


def percent_reduction(before, after):
    if before == 0:
        return 0.0
    return (before - after) / before


def write_markdown(path, output):
    before = output["before"]
    after = output["after"]
    lines = [
        "# Java Registry Feedback Repair Comparison",
        "",
        f"- Targeted records: `{output['targeted_records']}`",
        "",
        "| Metric | Before repair | After repair | Reduction |",
        "|---|---:|---:|---:|",
    ]
    for key, label in [
        ("candidate_rows", "Extracted candidate rows"),
        ("suspicious_rows", "Suspicious import rows"),
        ("suspicious_records", "Records with suspicious imports"),
    ]:
        b = before[key]
        a = after[key]
        lines.append(f"| {label} | {b} | {a} | {percent_reduction(b, a):.3f} |")

    lines.extend(["", "## Before Mapping Status", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(before["mapping_status_counts"].items()):
        lines.append(f"| {status} | {count} |")

    lines.extend(["", "## After Mapping Status", "", "| Status | Count |", "|---|---:|"])
    for status, count in sorted(after["mapping_status_counts"].items()):
        lines.append(f"| {status} | {count} |")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repair-prompts-jsonl", required=True)
    parser.add_argument("--before-mapping-csv", required=True)
    parser.add_argument("--after-mapping-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    repair_records = {row["record_id"] for row in read_jsonl(Path(args.repair_prompts_jsonl))}
    before_all = read_csv(Path(args.before_mapping_csv))
    after_all = read_csv(Path(args.after_mapping_csv))
    before_rows = [row for row in before_all if row.get("original_record_id") in repair_records]
    after_rows = [row for row in after_all if row.get("original_record_id") in repair_records]

    output = {
        "targeted_records": len(repair_records),
        "before": summarize("before", before_rows),
        "after": summarize("after", after_rows),
    }
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(Path(args.output_md), output)
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
