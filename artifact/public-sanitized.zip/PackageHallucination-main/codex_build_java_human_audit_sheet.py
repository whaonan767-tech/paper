import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


WINDOWS = [
    {
        "label": "FM50",
        "prompt_window": "offset=0,F=50,M=50",
        "raw_dir": "Tests/Java_APIHulBench_Qwen3B_FM50",
        "sanitized_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized",
    },
    {
        "label": "FM50_Offset50",
        "prompt_window": "offset=50,F=50,M=50",
        "raw_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50",
        "sanitized_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset50_Sanitized",
    },
    {
        "label": "FM50_Offset100",
        "prompt_window": "offset=100,F=50,M=50",
        "raw_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100",
        "sanitized_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset100_Sanitized",
    },
    {
        "label": "FM50_Offset150_tail",
        "prompt_window": "offset=150,F=50,M=45",
        "raw_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150",
        "sanitized_dir": "Tests/Java_APIHulBench_Qwen3B_FM50_Offset150_Sanitized",
    },
    {
        "label": "F50_Offset200_tail",
        "prompt_window": "offset=200,F=21,M=0",
        "raw_dir": "Tests/Java_APIHulBench_Qwen3B_F50_Offset200",
        "sanitized_dir": "Tests/Java_APIHulBench_Qwen3B_F50_Offset200_Sanitized",
    },
]


FIELDNAMES = [
    "audit_id",
    "sample_group",
    "negative_bucket",
    "window_label",
    "prompt_window",
    "candidate_record_id",
    "original_record_id",
    "source_line",
    "dataset",
    "split",
    "project_path",
    "file_path",
    "project_package_prefix",
    "import_path",
    "import_root",
    "import_classification",
    "mapping_status",
    "mapping_reason",
    "mapped_coordinate",
    "suggested_import_prefix",
    "suggested_project_import",
    "suggested_project_prefix",
    "detector_suspicious",
    "sanitizer_action",
    "sanitizer_removed",
    "sanitizer_edited_import_lines",
    "sanitizer_residual_exact_string",
    "raw_response_excerpt",
    "sanitized_response_excerpt",
    "annotation_label",
    "annotation_validity",
    "annotation_hallucination_type",
    "annotation_deletion_correct",
    "annotation_confidence",
    "annotation_rationale",
    "adjudicated_label",
    "adjudicated_validity",
    "adjudicated_hallucination_type",
    "adjudicated_deletion_correct",
    "adjudicated_notes",
]


BLIND_FIELDNAMES = [
    "audit_id",
    "window_label",
    "prompt_window",
    "candidate_record_id",
    "original_record_id",
    "source_line",
    "dataset",
    "split",
    "project_path",
    "file_path",
    "project_package_prefix",
    "import_path",
    "import_root",
    "raw_response_excerpt",
    "annotation_label",
    "annotation_validity",
    "annotation_hallucination_type",
    "annotation_confidence",
    "annotation_rationale",
]


KEY_FIELDNAMES = [
    "audit_id",
    "sample_group",
    "negative_bucket",
    "window_label",
    "candidate_record_id",
    "original_record_id",
    "import_path",
    "import_classification",
    "mapping_status",
    "mapping_reason",
    "detector_suspicious",
    "sanitizer_action",
    "sanitizer_removed",
    "sanitizer_residual_exact_string",
]


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv_rows(path):
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path):
    rows = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def response_map(path):
    return {row.get("record_id", ""): row for row in read_jsonl(path)}


def compact_text(value, limit=900):
    value = (value or "").replace("\r\n", "\n").replace("\r", "\n")
    value = "\n".join(line.rstrip() for line in value.split("\n"))
    value = value.strip()
    if len(value) <= limit:
        return value
    return value[: limit - 15].rstrip() + " ...[truncated]"


def stable_key(row):
    return "|".join(
        [
            row.get("window_label", ""),
            row.get("original_record_id", ""),
            row.get("candidate_record_id", ""),
            row.get("import_path", ""),
            row.get("mapping_status", ""),
        ]
    )


def stable_sort_key(row):
    digest = hashlib.sha1(stable_key(row).encode("utf-8")).hexdigest()
    return (digest, row.get("window_label", ""), row.get("candidate_record_id", ""))


def output_group_order(sample_group):
    return {
        "positive_detector_flagged": 0,
        "negative_control_unflagged": 1,
        "aux_malformed_extraction": 2,
    }.get(sample_group, 9)


def audit_key(record_id, import_path, mapping_status):
    return f"{record_id}\0{import_path}\0{mapping_status}"


def negative_bucket(row):
    status = row.get("mapping_status", "")
    classification = row.get("import_classification", "")
    import_path = row.get("import_path", "")
    if status == "mapped_maven_class_search":
        return "mapped_maven_class_search"
    if status == "mapped_known_prefix":
        return "mapped_known_external"
    if classification == "platform_import" or import_path.startswith(("java.", "javax.")):
        return "platform_or_standard"
    if status == "no_external_mapping_needed":
        return "project_or_context"
    return "other_unflagged"


def build_rows(root):
    all_rows = []
    for window in WINDOWS:
        raw_dir = root / window["raw_dir"]
        sanitized_dir = root / window["sanitized_dir"]
        mapping_payload = read_json(raw_dir / "import_maven_mapping_enhanced.json")
        audit_payload = read_json(sanitized_dir / "sanitizer_audit.json")
        raw_responses = response_map(raw_dir / "responses.jsonl")
        sanitized_responses = response_map(sanitized_dir / "responses.jsonl")

        audit_rows = {}
        for audit in audit_payload.get("audit_rows", []):
            key = audit_key(
                audit.get("record_id", ""),
                audit.get("import_path", ""),
                audit.get("mapping_status", ""),
            )
            audit_rows[key] = audit

        mapped_rows = list(mapping_payload.get("mapped", []))
        mapped_keys = {
            audit_key(
                mapped.get("original_record_id", ""),
                mapped.get("import_path", ""),
                mapped.get("mapping_status", ""),
            )
            for mapped in mapped_rows
        }
        for csv_row in read_csv_rows(raw_dir / "import_maven_mapping_enhanced.csv"):
            if csv_row.get("mapping_status") != "missing_import":
                continue
            key = audit_key(
                csv_row.get("original_record_id", ""),
                csv_row.get("import_path", ""),
                csv_row.get("mapping_status", ""),
            )
            if key not in mapped_keys:
                mapped_rows.append(csv_row)
                mapped_keys.add(key)

        for mapped in mapped_rows:
            import_path = mapped.get("import_path", "")
            status = mapped.get("mapping_status", "")
            if mapped.get("kind") != "java_import" and status != "missing_import":
                continue
            if not import_path and status != "missing_import":
                continue
            original_record_id = mapped.get("original_record_id", "")
            raw_response = raw_responses.get(original_record_id, {})
            sanitized_response = sanitized_responses.get(original_record_id, {})
            suspicious = status in SUSPICIOUS_MAPPING_STATUSES
            audit = audit_rows.get(audit_key(original_record_id, import_path, status), {})
            bucket = "" if suspicious else negative_bucket(mapped)
            if status == "missing_import":
                sample_group = "aux_malformed_extraction"
            elif suspicious:
                sample_group = "positive_detector_flagged"
            else:
                sample_group = "candidate_unflagged_pool"
            all_rows.append(
                {
                    "audit_id": "",
                    "sample_group": sample_group,
                    "negative_bucket": "" if sample_group == "aux_malformed_extraction" else bucket,
                    "window_label": window["label"],
                    "prompt_window": window["prompt_window"],
                    "candidate_record_id": mapped.get("record_id", ""),
                    "original_record_id": original_record_id,
                    "source_line": mapped.get("source_line", ""),
                    "dataset": mapped.get("dataset", ""),
                    "split": raw_response.get("split", ""),
                    "project_path": mapped.get("project_path", ""),
                    "file_path": mapped.get("file_path", ""),
                    "project_package_prefix": mapped.get("project_package_prefix", ""),
                    "import_path": import_path,
                    "import_root": mapped.get("import_root", ""),
                    "import_classification": mapped.get("import_classification", ""),
                    "mapping_status": status,
                    "mapping_reason": mapped.get("mapping_reason", ""),
                    "mapped_coordinate": mapped.get("mapped_coordinate", ""),
                    "suggested_import_prefix": mapped.get("suggested_import_prefix", ""),
                    "suggested_project_import": mapped.get("suggested_project_import", ""),
                    "suggested_project_prefix": mapped.get("suggested_project_prefix", ""),
                    "detector_suspicious": "1" if suspicious else "0",
                    "sanitizer_action": audit.get("action", "not_targeted"),
                    "sanitizer_removed": "1" if audit.get("action") == "remove_import" else "0",
                    "sanitizer_edited_import_lines": audit.get("edited_import_lines", ""),
                    "sanitizer_residual_exact_string": audit.get("residual_exact_string", ""),
                    "raw_response_excerpt": compact_text(raw_response.get("response", "")),
                    "sanitized_response_excerpt": compact_text(sanitized_response.get("response", "")),
                    "annotation_label": "",
                    "annotation_validity": "",
                    "annotation_hallucination_type": "",
                    "annotation_deletion_correct": "",
                    "annotation_confidence": "",
                    "annotation_rationale": "",
                    "adjudicated_label": "",
                    "adjudicated_validity": "",
                    "adjudicated_hallucination_type": "",
                    "adjudicated_deletion_correct": "",
                    "adjudicated_notes": "",
                }
            )
    return all_rows


def select_negative_controls(pool, target=68):
    quotas = {
        "mapped_maven_class_search": 4,
        "mapped_known_external": 24,
        "platform_or_standard": 20,
        "project_or_context": 20,
    }
    by_bucket = defaultdict(list)
    for row in pool:
        by_bucket[row["negative_bucket"]].append(row)
    for rows in by_bucket.values():
        rows.sort(key=stable_sort_key)

    selected = []
    selected_keys = set()
    for bucket, quota in quotas.items():
        for row in by_bucket.get(bucket, [])[:quota]:
            selected.append(row)
            selected_keys.add(stable_key(row))

    if len(selected) < target:
        leftovers = [row for row in pool if stable_key(row) not in selected_keys]
        leftovers.sort(key=stable_sort_key)
        for row in leftovers[: target - len(selected)]:
            selected.append(row)
            selected_keys.add(stable_key(row))

    selected = selected[:target]
    for row in selected:
        row["sample_group"] = "negative_control_unflagged"
    return selected


def assign_ids(rows):
    rows.sort(key=stable_sort_key)
    for index, row in enumerate(rows, start=1):
        row["audit_id"] = f"JHA-{index:03d}"


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def write_selected_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, rows):
    path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")


def write_summary(path, selected_rows, all_rows):
    positive = [row for row in selected_rows if row["sample_group"] == "positive_detector_flagged"]
    negative = [row for row in selected_rows if row["sample_group"] == "negative_control_unflagged"]
    malformed = [row for row in selected_rows if row["sample_group"] == "aux_malformed_extraction"]
    positive_status = Counter(row["mapping_status"] for row in positive)
    negative_bucket_counts = Counter(row["negative_bucket"] for row in negative)
    negative_status = Counter(row["mapping_status"] for row in negative)
    all_status = Counter(row["mapping_status"] for row in all_rows)
    deletion_actions = Counter(row["sanitizer_action"] for row in positive)

    lines = [
        "# Java Human Annotation Sheet Summary",
        "",
        "This sheet is the entry point for E1/E2: independent ground-truth annotation and sanitizer false-deletion audit.",
        "The blind annotation sheet omits detector labels, mapping statuses, sample groups, and sanitizer actions; use the key only after independent annotations are finished.",
        "",
        "## Sample Counts",
        "",
        f"- Positive detector-flagged rows: {len(positive)}",
        f"- Negative unflagged control rows: {len(negative)}",
        f"- Auxiliary malformed extraction rows: {len(malformed)}",
        f"- Total annotation rows: {len(selected_rows)}",
        f"- Full Java import candidate pool before sampling: {len(all_rows)}",
        "",
        "## Positive Detector-Flagged Mapping Statuses",
        "",
        "| Mapping status | Rows |",
        "|---|---:|",
    ]
    for status, count in sorted(positive_status.items()):
        lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Sanitizer Actions on Positive Rows",
            "",
            "| Action | Rows |",
            "|---|---:|",
        ]
    )
    for action, count in sorted(deletion_actions.items()):
        lines.append(f"| `{action}` | {count} |")

    lines.extend(
        [
            "",
            "## Negative Control Buckets",
            "",
            "| Bucket | Rows |",
            "|---|---:|",
        ]
    )
    for bucket, count in sorted(negative_bucket_counts.items()):
        lines.append(f"| `{bucket}` | {count} |")

    lines.extend(
        [
            "",
            "## Negative Control Mapping Statuses",
            "",
            "| Mapping status | Rows |",
            "|---|---:|",
        ]
    )
    for status, count in sorted(negative_status.items()):
        lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Full Candidate Pool Mapping Statuses",
            "",
            "| Mapping status | Rows |",
            "|---|---:|",
        ]
    )
    for status, count in sorted(all_status.items()):
        lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Intended Metrics After Annotation",
            "",
            "- Detector precision on positives: manually hallucinated positives / 68 detector-flagged rows.",
            "- Estimated false-negative rate on sampled negatives: manually hallucinated negatives / 68 unflagged controls.",
            "- Sanitizer deletion precision: correctly deleted positives / 68 deleted rows.",
            "- False deletion rate: valid deleted positives / 68 deleted rows.",
        "- Agreement: compute Cohen's kappa after two independent annotation columns are filled.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_guidelines(path):
    lines = [
        "# Java Dependency-Hallucination Annotation Guidelines",
        "",
        "Annotate each row independently from the detector label. Use the generated import, project/file context, raw response excerpt, and any registry/project checks you perform during annotation.",
        "Use the blind sheet for first-pass annotation. Do not inspect the key or the detector-status columns until both annotators have completed their labels.",
        "",
        "## annotation_label",
        "",
        "- `valid_platform`: Java/JDK/platform import that should be considered valid.",
        "- `valid_project`: project-local or prompt-context import supported by the target project/context.",
        "- `valid_external`: third-party import with plausible registry-backed dependency evidence.",
        "- `hallucinated_project_namespace`: project-looking import with no supporting project source.",
        "- `hallucinated_external_prefix`: external-looking import with wrong or unsupported dependency prefix.",
        "- `unresolved_unknown`: import remains unsupported after available registry/project evidence.",
        "- `malformed_extraction`: empty, partial, or parser artifact rather than a meaningful import.",
        "- `uncertain`: available evidence is insufficient.",
        "",
        "## annotation_validity",
        "",
        "Use `valid`, `invalid`, `malformed`, or `uncertain`.",
        "",
        "## annotation_hallucination_type",
        "",
        "Use `none`, `project_namespace`, `external_prefix`, `unresolved`, `parser_artifact`, or `uncertain`.",
        "",
        "## annotation_deletion_correct",
        "",
        "For detector-flagged rows removed by the sanitizer, use `yes` when deletion is justified, `no` when the import is valid and deletion is a false deletion, and `uncertain` when evidence is insufficient. For negative controls not targeted by the sanitizer, leave blank or use `not_applicable`.",
        "",
        "## annotation_confidence",
        "",
        "Use `high`, `medium`, or `low`.",
        "",
        "## Required Evidence Notes",
        "",
        "In `annotation_rationale`, record the concrete evidence: registry mapping, project package/source support, Java platform support, namespace typo, or unresolved evidence. Avoid merely copying the detector status.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="PackageHallucination-main root")
    parser.add_argument("--output-dir", default="Tests/Java_APIHulBench_HumanAudit")
    parser.add_argument("--negative-target", type=int, default=68)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    output_dir = root / args.output_dir
    all_rows = build_rows(root)
    positives = [row for row in all_rows if row["sample_group"] == "positive_detector_flagged"]
    negative_pool = [
        row
        for row in all_rows
        if row["sample_group"] == "candidate_unflagged_pool"
        and row["mapping_status"] in {"no_external_mapping_needed", "mapped_known_prefix", "mapped_maven_class_search"}
    ]
    negatives = select_negative_controls(negative_pool, target=args.negative_target)
    malformed = [row for row in all_rows if row["sample_group"] == "aux_malformed_extraction"]
    selected = positives + negatives + malformed
    assign_ids(selected)

    write_csv(output_dir / "java_human_annotation_sheet.csv", selected)
    write_selected_csv(output_dir / "java_human_annotation_blind_sheet.csv", selected, BLIND_FIELDNAMES)
    write_selected_csv(output_dir / "java_human_annotation_key.csv", selected, KEY_FIELDNAMES)
    write_json(output_dir / "java_human_annotation_sheet.json", selected)
    write_summary(output_dir / "java_human_annotation_sheet_summary.md", selected, all_rows)
    write_guidelines(output_dir / "java_human_annotation_guidelines.md")

    print(f"output_dir={output_dir}")
    print(f"positive_detector_flagged={len(positives)}")
    print(f"negative_control_unflagged={len(negatives)}")
    print(f"aux_malformed_extraction={len(malformed)}")
    print(f"annotation_rows={len(selected)}")


if __name__ == "__main__":
    main()
