#!/usr/bin/env python3
"""Freeze every V3 protocol component before external repository acquisition."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
SOURCE_FILES = (
    "codex_java_dependency_extractor.py",
    "codex_classify_java_imports.py",
    "codex_java_dependency_extractor_v2.py",
    "codex_classify_java_mentions_v2.py",
    "codex_map_java_imports_to_maven.py",
    "codex_build_external_v3_exclusions.py",
    "codex_resolve_external_v3_local_owners.py",
    "codex_acquire_external_java_v3.py",
    "codex_build_external_java_v3_prompts.py",
    "codex_java_dependency_generation_runner.py",
    "codex_prepare_external_java_v3_annotation.py",
    "build_external_v3_annotation_workbooks.mjs",
    "export_external_v3_annotation_workbook.mjs",
    "codex_score_external_java_v3.py",
    "codex_external_java_v3_build_trial.py",
    "codex_validate_external_java_v3_protocol.py",
    "test_java_dependency_extractor_v2.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(WORKSPACE.resolve()).as_posix()
    except ValueError:
        return path.name


def model_identity(model: Path) -> dict:
    identity = []
    for name in ("config.json", "generation_config.json", "model.safetensors.index.json", "tokenizer_config.json"):
        path = model / name
        if not path.is_file():
            raise SystemExit(f"Missing model identity file: {path}")
        identity.append({"path": relative(path), "sha256": sha256(path), "size_bytes": path.stat().st_size})
    return {"directory": relative(model), "identity_files": identity, "weight_shards": [{"name": path.name, "size_bytes": path.stat().st_size} for path in sorted(model.glob("*.safetensors"))]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exclusions", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, default=WORKSPACE / "<LOCAL_MODEL_CACHE>" / "Qwen2.5-Coder-3B-Instruct")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output.exists():
        raise SystemExit(f"Freeze directory already exists: {output}")
    exclusions = json.loads(args.exclusions.read_text(encoding="utf-8"))
    files = []
    for name in SOURCE_FILES:
        path = ROOT / name
        if not path.is_file():
            raise SystemExit(f"Missing frozen source file: {path}")
        files.append({"path": relative(path), "sha256": sha256(path), "size_bytes": path.stat().st_size})
    files.append({"path": relative(args.exclusions), "sha256": sha256(args.exclusions), "size_bytes": args.exclusions.stat().st_size})
    payload = {
        "artifact": "prospective_external_java_v3_freeze",
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "frozen_before_external_project_acquisition": True,
        "protocol": {
            "repositories": 30, "responses": 200,
            "prompt_arms": {"natural_code_repair": 100, "dependency_advice": 100},
            "generation": {"model": "Qwen2.5-Coder-3B-Instruct", "quantization": "4bit", "do_sample": False, "max_new_tokens": 512},
            "annotators": 2, "annotation": "independent detector-blind blank sheets followed by adjudication",
            "bootstrap_repetitions": 10_000, "bootstrap_unit": "project", "seed": 20260818,
            "build_trial": {"target_units": 24, "target_projects": 12, "minimum_units": 20, "minimum_projects": 8, "variants": ["RAW", "DELETE", "REPAIR", "ORACLE"]},
        },
        "disjointness_boundary": {
            "local_projects": exclusions["local_project_count"], "pilot_projects": exclusions["pilot_project_count"],
            "mapped_local_full_names": exclusions["mapped_local_full_name_count"],
            "excluded_repository_names": len(exclusions["repository_names_normalized"]),
            "excluded_owners": len(exclusions["owners"]), "excluded_api_families": len(exclusions["api_families"]),
            "exclusions_sha256": sha256(args.exclusions),
        },
        "claim_gates": {
            "detector_prototype": {
                "invalid_or_malformed_mentions_min": 30, "projects_with_invalid_or_malformed_min": 10,
                "external_end_to_end_precision_min": 0.90, "external_end_to_end_recall_min": 0.40,
                "recall_delta_v2_minus_v1_min": 0.15, "recall_delta_project_cluster_ci_low_strictly_above": 0.0,
            },
            "practice_effect": {
                "intervention_units_min": 20, "projects_min": 8,
                "delete_or_repair_vs_raw_project_cluster_ci_low_strictly_above": 0.0,
            },
            "fallback_positioning": "auditing_and_measurement_decision_support",
        },
        "model": model_identity(args.model_dir.resolve()), "files": files,
        "environment": {"python": sys.version, "platform": platform.platform()},
        "integrity_rules": {
            "v1_immutable_comparator": True, "v2_no_changes_after_external_acquisition": True,
            "no_external_labels_before_detector_lock": True, "all_preregistered_records_remain_in_denominators": True,
            "failed_projects_and_uncertain_labels_are_reported": True,
        },
    }
    output.mkdir(parents=True)
    json_path = output / "external_java_v3_freeze.json"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = ["# Prospective External Java V3 Freeze", "", f"- Frozen at UTC: `{payload['frozen_at_utc']}`.", "- Target: `30` repositories and `200` responses (`100 + 100` prompt arms).", f"- Frozen files: `{len(files)}`.", f"- Exclusion boundary SHA-256: `{payload['disjointness_boundary']['exclusions_sha256']}`.", "", "| File | SHA-256 |", "|---|---|"]
    lines.extend(f"| `{row['path']}` | `{row['sha256']}` |" for row in files)
    (output / "external_java_v3_freeze.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(json_path), "frozen_files": len(files), "local_projects": exclusions["local_project_count"]}, indent=2))


if __name__ == "__main__":
    main()
