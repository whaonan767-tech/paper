import argparse
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

try:
    from transformers import BitsAndBytesConfig
except ImportError:  # pragma: no cover
    BitsAndBytesConfig = None


DATASETS = {
    "LLM_Recent": {
        "input_file": "LLM_LY.json",
        "master_file": "LLM_Recent_Master.json",
        "prompt_column": "Prompts",
    },
    "LLM_All_Time": {
        "input_file": "LLM_AT.json",
        "master_file": "LLM_All_Time_Master.json",
        "prompt_column": "Prompts",
    },
    "Stack_Overflow_Recent": {
        "input_file": "SO_LY.json",
        "master_file": "Stack_Overflow_Recent_Master.json",
        "prompt_column": "Questions",
    },
    "Stack_Overflow_All_Time": {
        "input_file": "SO_AT.json",
        "master_file": "Stack_Overflow_All_Time_Master.json",
        "prompt_column": "Questions",
    },
}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def read_prompt(value):
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return next(iter(value.values()))
    return str(value)


def read_jsonl_prompts(path, offset, limit):
    prompts = []
    with open(path, "r", encoding="utf-8") as handle:
        for idx, line in enumerate(handle):
            if idx < offset or not line.strip():
                continue
            prompts.append({"source_index": idx, "prompt": read_prompt(json.loads(line))})
            if len(prompts) >= limit:
                break
    return prompts


def render_messages(tokenizer, messages):
    rendered = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    return tokenizer(rendered, return_tensors="pt")


def generate_text(tokenizer, model, messages, max_new_tokens, generation_args):
    encoded = render_messages(tokenizer, messages).to(model.device)
    input_ids = encoded["input_ids"]
    start = time.perf_counter()
    with torch.inference_mode():
        output = model.generate(
            **encoded,
            max_new_tokens=max_new_tokens,
            eos_token_id=tokenizer.eos_token_id,
            pad_token_id=tokenizer.eos_token_id,
            **generation_args,
        )
    elapsed_ms = (time.perf_counter() - start) * 1000
    text = tokenizer.decode(output[0, input_ids.shape[1] :], skip_special_tokens=True).strip()
    return text if text else "None", elapsed_ms


def build_code_messages(language, prompt):
    return [
        {
            "role": "system",
            "content": (
                f"You are a coding assistant that writes {language} code. "
                f"Return only {language} code. If no code is needed, return None."
            ),
        },
        {"role": "user", "content": prompt},
    ]


def build_package_messages(language, text, mode):
    if mode == 1:
        task = (
            f"List the {language} packages required to run the following generated code. "
            f"Do not explain. Do not write code. "
            f"Return only package names separated by commas, or None if no external package is needed."
        )
    else:
        task = (
            f"What {language} packages would be useful for solving the following programming problem? "
            f"Do not explain. Do not write code. "
            f"Return only package names separated by commas, or None if no external package is needed."
        )
    return [
        {
            "role": "system",
            "content": (
                "You recommend software package dependencies. "
                "Return only comma-separated package names."
            ),
        },
        {"role": "user", "content": f"{task}\n\n{text}"},
    ]


def write_jsonl_line(handle, value):
    json.dump(value, handle, ensure_ascii=False)
    handle.write("\n")
    handle.flush()


def detector_safe_package_response(text):
    stripped = (text or "").strip()
    if stripped.lower() in {"", "none", "n/a", "na", "no", "null"}:
        return "No package required"
    return stripped


def load_model(args):
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    model_kwargs = {
        "device_map": "auto",
        "trust_remote_code": True,
    }
    if args.load_in_4bit:
        if BitsAndBytesConfig is None:
            raise RuntimeError("BitsAndBytesConfig is unavailable but --load-in-4bit was set")
        model_kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True)
    model = AutoModelForCausalLM.from_pretrained(args.model_path, **model_kwargs)
    return tokenizer, model


def generation_args(args):
    if args.do_sample:
        return {
            "do_sample": True,
            "temperature": args.temperature,
            "top_p": args.top_p,
            "top_k": args.top_k,
        }
    return {"do_sample": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--model-label", required=True)
    parser.add_argument("--language", default="Python", choices=["Python", "Javascript"])
    parser.add_argument("--datasets", nargs="*", default=list(DATASETS))
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit-per-dataset", type=int, default=50)
    parser.add_argument("--max-code-tokens", type=int, default=384)
    parser.add_argument("--max-package-tokens", type=int, default=64)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--do-sample", action="store_true")
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--top-k", type=int, default=20)
    args = parser.parse_args()

    root = Path.cwd()
    data_path = root / "Data" / args.language
    output_dir = root / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    selected = [name for name in args.datasets if name in DATASETS]
    if len(selected) != len(args.datasets):
        unknown = sorted(set(args.datasets) - set(DATASETS))
        raise ValueError(f"Unknown dataset(s): {unknown}")

    metadata = {
        "started_at": utc_now(),
        "argv": sys.argv,
        "model_path": args.model_path,
        "model_label": args.model_label,
        "language": args.language,
        "datasets": selected,
        "offset": args.offset,
        "limit_per_dataset": args.limit_per_dataset,
        "max_code_tokens": args.max_code_tokens,
        "max_package_tokens": args.max_package_tokens,
        "load_in_4bit": args.load_in_4bit,
        "generation": generation_args(args),
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    }
    with open(output_dir / "metadata.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)

    tokenizer, model = load_model(args)
    gen_args = generation_args(args)

    raw_path = output_dir / "raw_generations.jsonl"
    with open(raw_path, "w", encoding="utf-8", newline="\n") as raw_handle:
        for dataset_name in selected:
            spec = DATASETS[dataset_name]
            prompts = read_jsonl_prompts(
                data_path / spec["input_file"],
                args.offset,
                args.limit_per_dataset,
            )
            master_path = output_dir / spec["master_file"]
            packages_1_path = output_dir / f"{dataset_name}_packages_1.json"
            packages_2_path = output_dir / f"{dataset_name}_packages_2.json"

            with open(master_path, "w", encoding="utf-8", newline="\n") as master_handle, open(
                packages_1_path, "w", encoding="utf-8", newline="\n"
            ) as p1_handle, open(packages_2_path, "w", encoding="utf-8", newline="\n") as p2_handle:
                for local_index, row in enumerate(prompts):
                    prompt = row["prompt"]
                    code, code_ms = generate_text(
                        tokenizer,
                        model,
                        build_code_messages(args.language, prompt),
                        args.max_code_tokens,
                        gen_args,
                    )

                    if spec["prompt_column"] == "Prompts":
                        master_row = {"Prompts": prompt, "Answers": code}
                    else:
                        master_row = {"Questions": prompt, "Answers": code}
                    write_jsonl_line(master_handle, master_row)
                    write_jsonl_line(
                        raw_handle,
                        {
                            "dataset": dataset_name,
                            "source_index": row["source_index"],
                            "local_index": local_index,
                            "task": "code",
                            "prompt": prompt,
                            "response": code,
                            "elapsed_ms": code_ms,
                        },
                    )

                    package_1, package_1_ms = generate_text(
                        tokenizer,
                        model,
                        build_package_messages(args.language, code, 1),
                        args.max_package_tokens,
                        gen_args,
                    )
                    package_2, package_2_ms = generate_text(
                        tokenizer,
                        model,
                        build_package_messages(args.language, prompt, 2),
                        args.max_package_tokens,
                        gen_args,
                    )

                    write_jsonl_line(p1_handle, detector_safe_package_response(package_1))
                    write_jsonl_line(p2_handle, detector_safe_package_response(package_2))
                    write_jsonl_line(
                        raw_handle,
                        {
                            "dataset": dataset_name,
                            "source_index": row["source_index"],
                            "local_index": local_index,
                            "task": "packages_1",
                            "prompt": code,
                            "response": package_1,
                            "elapsed_ms": package_1_ms,
                        },
                    )
                    write_jsonl_line(
                        raw_handle,
                        {
                            "dataset": dataset_name,
                            "source_index": row["source_index"],
                            "local_index": local_index,
                            "task": "packages_2",
                            "prompt": prompt,
                            "response": package_2,
                            "elapsed_ms": package_2_ms,
                        },
                    )
                    print(
                        f"{dataset_name} {local_index + 1}/{len(prompts)} "
                        f"code={code_ms:.0f}ms pkg1={package_1_ms:.0f}ms pkg2={package_2_ms:.0f}ms",
                        flush=True,
                    )

    metadata["finished_at"] = utc_now()
    metadata["raw_generations"] = str(raw_path)
    with open(output_dir / "metadata.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)
    print(f"Wrote experiment files to {output_dir}")


if __name__ == "__main__":
    main()
