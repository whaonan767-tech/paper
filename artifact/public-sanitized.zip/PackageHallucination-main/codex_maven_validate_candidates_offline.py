import argparse
import csv
import json
from pathlib import Path


PLACEHOLDER_VERSIONS = {
    "",
    "version",
    "<version>",
    "x.y.z",
    "latest",
    "unknown",
}


FIELDNAMES = [
    "artifact_id",
    "coordinate",
    "dataset",
    "error",
    "group_id",
    "import_path",
    "import_root",
    "kind",
    "latest_version",
    "maven_num_found",
    "maven_url",
    "record_id",
    "source_line",
    "task",
    "validation_status",
    "version",
]


def read_rows(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def local_m2_has_coordinate(local_m2, group_id, artifact_id, version):
    artifact_dir = local_m2.joinpath(*group_id.split("."), artifact_id, version)
    if not artifact_dir.exists():
        return False
    return any(artifact_dir.glob("*.pom")) or any(artifact_dir.glob("*.jar"))


def validate_row(row, local_m2):
    out = {field: row.get(field, "") for field in FIELDNAMES}
    kind = row.get("kind", "")
    if kind == "java_import":
        out["validation_status"] = "import_only"
        return out

    group_id = row.get("group_id", "").strip()
    artifact_id = row.get("artifact_id", "").strip()
    version = row.get("version", "").strip()
    if not group_id or not artifact_id or version.lower() in PLACEHOLDER_VERSIONS:
        out["validation_status"] = "missing_coordinate"
        out["error"] = "missing or placeholder coordinate field in generated output"
        return out

    if local_m2_has_coordinate(local_m2, group_id, artifact_id, version):
        out["validation_status"] = "valid_local_m2"
        out["maven_num_found"] = "local"
        return out

    out["validation_status"] = "not_checked_offline"
    out["error"] = "not present in local Maven cache; no external registry query was performed"
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--local-m2", default=str(Path.home() / ".m2" / "repository"))
    args = parser.parse_args()

    rows = read_rows(Path(args.input_csv))
    local_m2 = Path(args.local_m2)
    output_rows = [validate_row(row, local_m2) for row in rows]

    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(output_rows)

    counts = {}
    for row in output_rows:
        status = row["validation_status"]
        counts[status] = counts.get(status, 0) + 1
    output = {
        "input_csv": args.input_csv,
        "local_m2": str(local_m2),
        "rows": len(output_rows),
        "status_counts": counts,
        "note": "Offline validation never treats absence from the local Maven cache as registry absence.",
    }
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
