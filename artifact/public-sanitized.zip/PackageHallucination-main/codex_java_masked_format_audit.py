#!/usr/bin/env python3
"""Audit manifest-format compliance and historical output-length proxies."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from tokenizers import Tokenizer


ROOT = Path(__file__).resolve().parent
TESTS = ROOT / "Tests"
NECESSITY = (
    TESTS
    / "Java_APIHulBench_MaskedSemanticBuild_NecessityFull83_TestCompile_Run20260803"
    / "masked_necessity_probe.json"
)
RUNS = {
    "Qwen2.5-Coder-7B-Instruct": TESTS
    / "Java_APIHulBench_Qwen7B_DepCriticalMasked_Strict_Full117_Run20260730",
    "DeepSeek-Coder-6.7B-Instruct": TESTS
    / "Java_APIHulBench_DeepSeekCoder67B_DepCriticalMasked_Strict_Full117_FastTok1024_Run20260730",
}


JAVA_FENCE = re.compile(r"```(?:java)?\s*\n(.*?)(?:```|\Z)", re.IGNORECASE | re.DOTALL)
DEPENDENCIES_HEADING = re.compile(r"(?im)^\s*(?:#+\s*)?Dependencies\s*:\s*$")
DEPENDENCY_ROW = re.compile(
    r"(?im)^\s*-\s*(?:Maven|Gradle|Import|Project-local|JDK)\s*:\s*\S+"
)
NO_EXTERNAL = re.compile(r"(?im)^\s*(?:-\s*)?No external dependency\.?\s*$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--necessity", type=Path, default=NECESSITY)
    parser.add_argument("--output-dir", type=Path, default=TESTS / "Java_APIHulBench_MaskedFormatAudit_Run20260803")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def candidate_counts(path: Path) -> dict[int, dict[str, int]]:
    counts: dict[int, Counter] = defaultdict(Counter)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            counts[int(row["source_line"])][row["kind"]] += 1
    return {line: dict(values) for line, values in counts.items()}


def code_shape(code: str) -> str:
    if not code:
        return "no_code_fence"
    if re.search(r"(?m)^\s*package\s+[\w.]+\s*;", code):
        return "full_file_or_prefix"
    if re.search(
        r"(?m)^\s*(?:@[\w.()]+\s*)*(?:public|protected|private|static|final|synchronized|abstract|native|default|\s)+[\w<>\[\],.?]+\s+\w+\s*\([^;]*\)\s*(?:\{|$)",
        code,
    ):
        return "method"
    return "fragment"


def balanced_delimiters(code: str) -> bool:
    pairs = {"}": "{", ")": "(", "]": "["}
    stack = []
    in_string = None
    escaped = False
    index = 0
    while index < len(code):
        char = code[index]
        next_char = code[index + 1] if index + 1 < len(code) else ""
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_string:
                in_string = None
            index += 1
            continue
        if char in {'"', "'"}:
            in_string = char
        elif char == "/" and next_char == "/":
            newline = code.find("\n", index + 2)
            index = len(code) if newline < 0 else newline
            continue
        elif char == "/" and next_char == "*":
            end = code.find("*/", index + 2)
            index = len(code) if end < 0 else end + 2
            continue
        elif char in "{([":
            stack.append(char)
        elif char in "})]":
            if not stack or stack.pop() != pairs[char]:
                return False
        index += 1
    return not stack and in_string is None


def summarize(rows: list[dict]) -> dict:
    lengths = [row["output_tokens_reencoded"] for row in rows]
    elapsed = [row["elapsed_ms"] for row in rows]
    return {
        "records": len(rows),
        "java_fence": sum(row["java_fence"] for row in rows),
        "closed_code_fence": sum(row["closed_code_fence"] for row in rows),
        "dependencies_heading": sum(row["dependencies_heading"] for row in rows),
        "recognized_dependency_body": sum(row["recognized_dependency_body"] for row in rows),
        "strict_manifest_format": sum(row["strict_manifest_format"] for row in rows),
        "parseable_import_records": sum(row["parseable_import_count"] > 0 for row in rows),
        "parseable_imports": sum(row["parseable_import_count"] for row in rows),
        "ceiling_proxy_records": sum(row["ceiling_proxy"] for row in rows),
        "balanced_code_blocks": sum(row["balanced_code_block"] for row in rows),
        "code_shape_counts": dict(Counter(row["code_shape"] for row in rows)),
        "output_tokens": {
            "min": min(lengths),
            "median": statistics.median(lengths),
            "mean": statistics.fmean(lengths),
            "max": max(lengths),
        },
        "elapsed_ms": {
            "median": statistics.median(elapsed),
            "mean": statistics.fmean(elapsed),
        },
    }


def rate(count: int, total: int) -> str:
    return f"{count}/{total} ({100 * count / total:.1f}%)"


def main() -> None:
    args = parse_args()
    necessity_path = args.necessity.resolve()
    eligible = {
        row["record_id"]
        for row in json.loads(necessity_path.read_text(encoding="utf-8"))["results"]
        if row["target_failure_evidence"]
    }
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise SystemExit(f"Output directory already exists: {output_dir}")
    output_dir.mkdir(parents=True)

    all_rows = []
    summaries = {}
    run_metadata = {}
    for model, run_dir in RUNS.items():
        run_dir = run_dir.resolve()
        metadata_path = run_dir / "metadata.json"
        responses_path = run_dir / "responses.jsonl"
        candidates_path = run_dir / "candidates.csv"
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        responses = read_jsonl(responses_path)
        candidates = candidate_counts(candidates_path)
        tokenizer = Tokenizer.from_file(str(Path(metadata["model_path"]) / "tokenizer.json"))
        ceiling = int(metadata["max_new_tokens"])
        model_rows = []
        for index, response in enumerate(responses, start=1):
            text = response["response"]
            match = JAVA_FENCE.search(text)
            code = match.group(1).strip() if match else ""
            java_fence = bool(re.search(r"```java\s*\n", text, re.IGNORECASE))
            closed_fence = bool(match and "```" in text[match.start() + 3 :])
            heading = bool(DEPENDENCIES_HEADING.search(text))
            dependency_body = bool(DEPENDENCY_ROW.search(text) or NO_EXTERNAL.search(text))
            token_count = len(tokenizer.encode(text, add_special_tokens=False).ids)
            row = {
                "model": model,
                "record_id": response["record_id"],
                "eligible_build_cohort": response["record_id"] in eligible,
                "max_new_tokens": ceiling,
                "output_tokens_reencoded": token_count,
                "ceiling_proxy": token_count >= ceiling - 2,
                "response_characters": len(text),
                "elapsed_ms": float(response["elapsed_ms"]),
                "java_fence": java_fence,
                "closed_code_fence": closed_fence,
                "dependencies_heading": heading,
                "recognized_dependency_body": dependency_body,
                "strict_manifest_format": java_fence and closed_fence and heading and dependency_body,
                "code_shape": code_shape(code),
                "balanced_code_block": bool(code) and balanced_delimiters(code),
                "parseable_import_count": candidates.get(index, {}).get("java_import", 0),
                "parseable_coordinate_count": sum(
                    count
                    for kind, count in candidates.get(index, {}).items()
                    if "coordinate" in kind
                ),
            }
            model_rows.append(row)
            all_rows.append(row)
        summaries[model] = {
            "all_117": summarize(model_rows),
            "build_eligible_83": summarize(
                [row for row in model_rows if row["eligible_build_cohort"]]
            ),
        }
        run_metadata[model] = {
            "model_path": metadata["model_path"],
            "max_new_tokens": ceiling,
            "include_system_message": metadata.get("include_system_message", True),
            "tokenizer_file_backend": metadata.get("tokenizer_file_backend", False),
            "responses_sha256": sha256(responses_path),
            "metadata_sha256": sha256(metadata_path),
        }

    payload = {
        "analysis": "historical_manifest_format_and_length_audit",
        "important_limitation": (
            "Historical generation did not persist output token IDs or finish reasons. "
            "Token counts are re-encoded from stripped decoded text; ceiling_proxy means "
            "re-encoded length >= max_new_tokens - 2 and is not a recorded finish reason."
        ),
        "comparison_limitation": (
            "The two historical runs used different token ceilings, system-message settings, "
            "and tokenizer loading paths; results describe observed output behavior and do not "
            "identify a model-family dependency-knowledge effect."
        ),
        "necessity_sha256": sha256(necessity_path),
        "runs": run_metadata,
        "summaries": summaries,
    }
    (output_dir / "masked_format_audit.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    fields = list(all_rows[0])
    with (output_dir / "masked_format_audit.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(all_rows)

    lines = [
        "# Historical Manifest-Format and Output-Length Audit",
        "",
        "The runs are not a controlled model-family comparison: Qwen used 512 output tokens with a system message, whereas DeepSeek used 1024 output tokens without that system message and a different tokenizer-loading path.",
        "",
        "Historical generation did not store token IDs or finish reasons. `Ceiling proxy` is a post-hoc re-encoding count within two tokens of the configured ceiling; it must not be reported as a recorded truncation reason.",
        "",
        "## All 117 Records",
        "",
        "| Model | Strict format | Java fence | Closed fence | Dependencies heading | Parseable import record | Ceiling proxy | Median tokens |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for model, scopes in summaries.items():
        values = scopes["all_117"]
        n = values["records"]
        lines.append(
            f"| {model} | {rate(values['strict_manifest_format'], n)} | "
            f"{rate(values['java_fence'], n)} | {rate(values['closed_code_fence'], n)} | "
            f"{rate(values['dependencies_heading'], n)} | "
            f"{rate(values['parseable_import_records'], n)} | "
            f"{rate(values['ceiling_proxy_records'], n)} | {values['output_tokens']['median']:.1f} |"
        )
    lines.extend(
        [
            "",
            "## Build-Eligible 83-Record Cohort",
            "",
            "| Model | Strict format | Balanced code block | Parseable import record | Parseable imports | Ceiling proxy | Median tokens |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for model, scopes in summaries.items():
        values = scopes["build_eligible_83"]
        n = values["records"]
        lines.append(
            f"| {model} | {rate(values['strict_manifest_format'], n)} | "
            f"{rate(values['balanced_code_blocks'], n)} | "
            f"{rate(values['parseable_import_records'], n)} | {values['parseable_imports']} | "
            f"{rate(values['ceiling_proxy_records'], n)} | {values['output_tokens']['median']:.1f} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation Boundary",
            "",
            "- Use `lower observed manifest-format compliance`, not `less format-compliant protocol`.",
            "- Do not attribute between-model differences to dependency knowledge under these non-uniform conditions.",
            "- The updated generation runner now records generated token count, EOS emission, and finish reason for future controlled runs.",
        ]
    )
    (output_dir / "masked_format_audit.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(f"WROTE {output_dir}")


if __name__ == "__main__":
    main()
