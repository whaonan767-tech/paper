import argparse
import csv
import json
from pathlib import Path


SUSPICIOUS_MAPPING_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pct(value):
    return f"{value:.3f}"


def suspicious_rows_from_counts(counts):
    return sum(int(counts.get(status, 0)) for status in SUSPICIOUS_MAPPING_STATUSES)


def comparison_row(label, comparison, note):
    before = comparison["before"]
    after = comparison["after"]
    before_suspicious = before["suspicious_rows"]
    after_suspicious = after["suspicious_rows"]
    reduction = 0.0 if before_suspicious == 0 else (before_suspicious - after_suspicious) / before_suspicious
    return {
        "method": label,
        "targeted_records": comparison["targeted_records"],
        "candidate_rows_before": before["candidate_rows"],
        "candidate_rows_after": after["candidate_rows"],
        "suspicious_rows_before": before_suspicious,
        "suspicious_rows_after": after_suspicious,
        "suspicious_row_reduction": reduction,
        "suspicious_records_before": before["suspicious_records"],
        "suspicious_records_after": after["suspicious_records"],
        "note": note,
    }


def write_csv(path, rows):
    fieldnames = list(rows[0].keys()) if rows else []
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, output):
    original_counts = output["original_mapping_status_counts"]
    sanitized_counts = output["sanitized_mapping_status_counts"]
    mitigation_rows = output["mitigation_rows"]
    build_probe = output.get("build_probe")

    lines = [
        "# Java Dependency Hallucination Extension Summary",
        "",
        "## Detector Taxonomy on FM50",
        "",
        f"- Prompts: `100` Java APIHulBench-derived prompts (`F=50`, `M=50`).",
        f"- Extracted dependency/import candidates: `{output['original_rows']}`.",
        f"- Suspicious import rows after enhanced mapping: `{output['original_suspicious_rows']}`.",
        "",
        "| Mapping status | Count |",
        "|---|---:|",
    ]
    for status, count in sorted(original_counts.items()):
        lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Mitigation Outcomes",
            "",
            "| Method | Target records | Candidate rows | Suspicious rows | Suspicious records | Suspicious row reduction | Note |",
            "|---|---:|---:|---:|---:|---:|---|",
        ]
    )
    for row in mitigation_rows:
        lines.append(
            "| {method} | {targeted} | {cb}->{ca} | {sb}->{sa} | {rb}->{ra} | {reduction} | {note} |".format(
                method=row["method"],
                targeted=row["targeted_records"],
                cb=row["candidate_rows_before"],
                ca=row["candidate_rows_after"],
                sb=row["suspicious_rows_before"],
                sa=row["suspicious_rows_after"],
                rb=row["suspicious_records_before"],
                ra=row["suspicious_records_after"],
                reduction=pct(row["suspicious_row_reduction"]),
                note=row["note"],
            )
        )

    lines.extend(
        [
            "",
            "## Post-Sanitizer Overall Mapping",
            "",
            f"- Extracted dependency/import candidates after deterministic sanitizer: `{output['sanitized_rows']}`.",
            f"- Suspicious import rows after deterministic sanitizer: `{output['sanitized_suspicious_rows']}`.",
            "",
            "| Mapping status | Count |",
            "|---|---:|",
        ]
    )
    for status, count in sorted(sanitized_counts.items()):
        lines.append(f"| `{status}` | {count} |")

    if build_probe:
        paired = build_probe["paired_outcomes"]
        baseline_counts = build_probe["baseline_status_counts"]
        lines.extend(
            [
                "",
                "## Build-Level Import Probe",
                "",
                f"- Probe artifact: `{build_probe['artifact']}`.",
                f"- Baseline build units passing: `{build_probe['baseline_build_units_pass']} / {build_probe['baseline_build_units_total']}`.",
                f"- Baseline-pass target records: `{paired['baseline_pass_records']}`.",
                f"- Raw suspicious imports fail while sanitized imports pass: `{paired['raw_fail_sanitized_pass']}`.",
                f"- Raw suspicious imports still pass and sanitized imports pass: `{paired['raw_pass_sanitized_pass']}`.",
                "",
                "| Baseline status | Count |",
                "|---|---:|",
            ]
        )
        for status, count in sorted(baseline_counts.items()):
            lines.append(f"| `{status}` | {count} |")

    lines.extend(
        [
            "",
            "## Paper-Ready Reading",
            "",
            "- The enhanced detector separates valid context/platform imports, known external libraries, project namespace hallucinations, project namespace typo hallucinations, and wrong external-library prefixes.",
            "- LLM registry-feedback repair is useful but unstable on the hard residual cases: round 1 removes most suspicious imports, while round 2 still repeats forbidden imports.",
            "- The deterministic sanitizer removes all detected suspicious Java import mentions in this FM50 run, giving a clear mitigation baseline to report alongside LLM repair.",
            "- The build-level import probe supports the sanitizer mechanism on the baseline-pass subset: injected suspicious imports break compilation, and the sanitized variant passes.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--original-mapping-json", default="Tests/Java_APIHulBench_Qwen3B_FM50/import_maven_mapping_enhanced.json")
    parser.add_argument("--repair1-json", default="Tests/Java_APIHulBench_Qwen3B_FM50_RegistryRepair/repair_comparison_enhanced.json")
    parser.add_argument("--repair2-json", default="Tests/Java_APIHulBench_Qwen3B_FM50_RegistryRepair_Round2/repair_comparison_enhanced.json")
    parser.add_argument("--sanitizer-json", default="Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/sanitizer_comparison_enhanced.json")
    parser.add_argument("--sanitized-mapping-json", default="Tests/Java_APIHulBench_Qwen3B_FM50_Sanitized/import_maven_mapping_enhanced.json")
    parser.add_argument("--build-probe-json", default="")
    parser.add_argument("--output-json", default="Tests/Java_APIHulBench_MitigationSummary/java_dependency_extension_summary.json")
    parser.add_argument("--output-md", default="Tests/Java_APIHulBench_MitigationSummary/java_dependency_extension_summary.md")
    parser.add_argument("--output-csv", default="Tests/Java_APIHulBench_MitigationSummary/java_dependency_mitigation_table.csv")
    args = parser.parse_args()

    original_mapping = read_json(args.original_mapping_json)
    sanitized_mapping = read_json(args.sanitized_mapping_json)
    repair1 = read_json(args.repair1_json)
    repair2 = read_json(args.repair2_json)
    sanitizer = read_json(args.sanitizer_json)
    build_probe = read_json(args.build_probe_json) if args.build_probe_json else None

    mitigation_rows = [
        comparison_row("LLM repair round 1", repair1, "large reduction, residual hard cases remain"),
        comparison_row("LLM repair round 2", repair2, "unstable on residual cases"),
        comparison_row("deterministic sanitizer", sanitizer, "removes detected suspicious imports"),
    ]
    output = {
        "original_rows": original_mapping["rows"],
        "original_mapping_status_counts": original_mapping["mapping_status_counts"],
        "original_suspicious_rows": suspicious_rows_from_counts(original_mapping["mapping_status_counts"]),
        "sanitized_rows": sanitized_mapping["rows"],
        "sanitized_mapping_status_counts": sanitized_mapping["mapping_status_counts"],
        "sanitized_suspicious_rows": suspicious_rows_from_counts(sanitized_mapping["mapping_status_counts"]),
        "mitigation_rows": mitigation_rows,
        "inputs": {
            "original_mapping_json": args.original_mapping_json,
            "repair1_json": args.repair1_json,
            "repair2_json": args.repair2_json,
            "sanitizer_json": args.sanitizer_json,
            "sanitized_mapping_json": args.sanitized_mapping_json,
            "build_probe_json": args.build_probe_json,
        },
    }
    if build_probe:
        output["build_probe"] = {
            "artifact": args.build_probe_json,
            "baseline_build_units_total": build_probe["summary"]["baseline_build_units_total"],
            "baseline_build_units_pass": build_probe["summary"]["baseline_build_units_pass"],
            "baseline_status_counts": build_probe["summary"]["baseline_status_counts"],
            "paired_outcomes": build_probe["summary"]["paired_outcomes"],
            "variants": build_probe["summary"]["variants"],
        }

    Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(Path(args.output_csv), mitigation_rows)
    write_markdown(Path(args.output_md), output)
    print(json.dumps({"output_md": args.output_md, "original_suspicious_rows": output["original_suspicious_rows"], "sanitized_suspicious_rows": output["sanitized_suspicious_rows"]}, indent=2))


if __name__ == "__main__":
    main()
