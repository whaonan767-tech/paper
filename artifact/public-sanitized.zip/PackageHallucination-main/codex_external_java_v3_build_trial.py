#!/usr/bin/env python3
"""Baseline-screen and execute the four-variant external Java V3 build trial."""

from __future__ import annotations

import argparse
import collections
import json
import math
import os
import random
import re
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from codex_java_dependency_extractor_v2 import extract_candidates


def read_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def clean(value: object) -> str:
    return "" if value is None else str(value).strip()


def normalize(value: object) -> str:
    value = re.sub(r"(?i)^import\s+(?:static\s+)?", "", clean(value).strip("`'\" "))
    return re.sub(r"[;,.)\]}]+$", "", value).lower()


def maven_command(project: Path, configured: str) -> list[str]:
    wrapper = project / "mvnw.cmd"
    return [str(wrapper)] if wrapper.is_file() else [configured]


def test_counts(project: Path) -> dict[str, int]:
    totals = collections.Counter()
    for pattern in ("**/surefire-reports/TEST-*.xml", "**/failsafe-reports/TEST-*.xml"):
        for path in project.glob(pattern):
            try:
                root = ET.parse(path).getroot()
            except (ET.ParseError, OSError):
                continue
            for key in ("tests", "failures", "errors", "skipped"):
                try:
                    totals[key] += int(float(root.attrib.get(key, 0)))
                except ValueError:
                    pass
    return dict(totals)


def classify_failure(text: str, returncode: int, tests: dict[str, int]) -> str:
    lower = text.lower()
    if returncode == 0 and tests.get("tests", 0) > 0:
        return "pass_nonzero_tests"
    if returncode == 0:
        return "pass_zero_tests"
    if "could not resolve" in lower or "failed to read artifact descriptor" in lower:
        return "dependency_resolution"
    if "invalid target release" in lower or "release version" in lower or "unsupported class file" in lower:
        return "toolchain_incompatibility"
    if "compilation failure" in lower or "cannot find symbol" in lower or "package " in lower and " does not exist" in lower:
        return "compilation_failure"
    if "there are test failures" in lower or "tests run:" in lower:
        return "test_failure"
    if "timed out" in lower:
        return "timeout"
    return "other_build_failure"


def run_process(command: list[str], cwd: Path, timeout: int, log: Path) -> dict:
    started = time.perf_counter()
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w", encoding="utf-8", errors="replace") as stream:
        process = subprocess.Popen(
            command, cwd=cwd, text=True, encoding="utf-8", errors="replace",
            stdout=stream, stderr=subprocess.STDOUT, creationflags=creationflags,
        )
        try:
            returncode = process.wait(timeout=timeout)
            timed_out = False
        except subprocess.TimeoutExpired:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdout=stream, stderr=subprocess.STDOUT, text=True, timeout=30,
                )
            else:
                process.kill()
            stream.write("\nTIMED OUT\n")
            stream.flush()
            returncode = 124
            timed_out = True
    elapsed = time.perf_counter() - started
    output = log.read_text(encoding="utf-8", errors="replace")
    downloads = sorted(set(re.findall(r"(?im)^Downloading from [^:]+:\s*(\S+)", output)))
    return {"command": command, "returncode": returncode, "timed_out": timed_out, "elapsed_seconds": elapsed, "download_urls": downloads, "log": log.as_posix()}


def screen(args: argparse.Namespace) -> None:
    metadata = json.loads((args.acquisition_dir / "metadata" / "external_project_acquisition_v3.json").read_text(encoding="utf-8"))
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for index, project in enumerate(metadata["selected"], 1):
        project_root = args.acquisition_dir / project["project_relative_path"]
        cache = output / "maven_cache" / f"p{index:03d}"
        cache.mkdir(parents=True, exist_ok=True)
        result_path = output / "records" / f"p{index:03d}.json"
        if args.resume and result_path.is_file():
            rows.append(json.loads(result_path.read_text(encoding="utf-8")))
            continue
        command = maven_command(project_root, args.maven) + ["-B", "-ntp", f"-Dmaven.repo.local={cache.resolve()}", "test"]
        run = run_process(command, project_root, args.timeout, output / "logs" / f"p{index:03d}_baseline.log")
        tests = test_counts(project_root)
        row = {
            "project_index": index, "project_id": project["full_name"], "project_relative_path": project["project_relative_path"],
            "commit_sha": project["commit_sha"], **run, "tests": tests,
            "failure_category": classify_failure((output / "logs" / f"p{index:03d}_baseline.log").read_text(encoding="utf-8", errors="ignore"), run["returncode"], tests),
            "eligible": run["returncode"] == 0 and tests.get("tests", 0) > 0,
            "cache_path": cache.as_posix(), "measured_network_mode": "online_cache_warmup",
        }
        result_path.parent.mkdir(parents=True, exist_ok=True)
        result_path.write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
        rows.append(row)
        print(f"BASELINE {index}/{len(metadata['selected'])} {project['full_name']} {row['failure_category']} tests={tests.get('tests', 0)}", flush=True)
    summary = {
        "artifact": "external_java_v3_baseline_screen", "projects": len(rows),
        "eligible_projects": sum(row["eligible"] for row in rows), "rows": rows,
        "network_accounting": "Unique Maven download URLs are recorded during the online warm-up; all intervention runs use Maven offline mode with the same per-project cache.",
    }
    (output / "baseline_screen.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"projects": len(rows), "eligible_projects": summary["eligible_projects"]}, indent=2))


def load_decisions(path: Path) -> dict[str, dict[str, str]]:
    import csv
    output: dict[str, dict[str, str]] = collections.defaultdict(dict)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if clean(row.get("detector_decision")).lower() == "flag":
                output[clean(row.get("record_id"))][normalize(row.get("normalized_mention") or row.get("import_path") or row.get("coordinate"))] = clean(row.get("detector_reason"))
    return output


def java_imports(text: str, record_id: str) -> list[str]:
    return [row["import_path"] for row in extract_candidates(text, {"record_id": record_id}) if row["kind"] == "java_import"]


def prepare(args: argparse.Namespace) -> None:
    baselines = json.loads(args.baseline_json.read_text(encoding="utf-8"))["rows"]
    eligible = [row for row in baselines if row["eligible"]][:12]
    if len(eligible) < 8:
        raise SystemExit(f"Only {len(eligible)} baseline-pass nonzero-test projects; at least 8 are required")
    prompts = read_jsonl(args.prompts_jsonl)
    responses = {row["record_id"]: row for row in read_jsonl(args.responses_jsonl)}
    decisions = load_decisions(args.detector_csv)
    prompt_by_project: dict[str, list[dict]] = collections.defaultdict(list)
    for row in prompts:
        if row.get("task") == "natural_code_repair":
            prompt_by_project[row["project_id"]].append(row)
    for rows in prompt_by_project.values():
        rows.sort(key=lambda row: row["record_id"])
    target = 24
    chosen = []
    cursor = collections.Counter()
    while len(chosen) < target:
        progress = False
        for project in eligible:
            rows = prompt_by_project[project["project_id"]]
            index = cursor[project["project_id"]]
            if index < len(rows):
                chosen.append(rows[index])
                cursor[project["project_id"]] += 1
                progress = True
                if len(chosen) == target:
                    break
        if not progress:
            raise SystemExit("Eligible projects do not expose 24 natural-code-repair records")
    units = []
    repair_prompts = []
    for index, prompt in enumerate(chosen, 1):
        response = responses[prompt["record_id"]]
        raw_imports = java_imports(response.get("response", ""), prompt["record_id"])
        flags = decisions.get(prompt["record_id"], {})
        delete_imports = [value for value in raw_imports if normalize(value) not in flags]
        unit_id = f"INT{index:03d}"
        unit = {
            "unit_id": unit_id, "record_id": prompt["record_id"], "project_id": prompt["project_id"],
            "project_relative_path": prompt["project_relative_path"], "relative_file_path": prompt["relative_file_path"],
            "module_pom": prompt["module_pom"], "ground_truth_import": prompt["ground_truth_import"],
            "raw_response": response.get("response", ""), "raw_imports": raw_imports,
            "delete_imports": delete_imports, "flagged_mentions": flags,
        }
        units.append(unit)
        evidence = "\n".join(f"- {value}: {reason}" for value, reason in flags.items()) or "- No candidate was flagged; check the response once for a required import."
        repair_prompts.append({
            "record_id": f"{unit_id}_REPAIR", "dataset": "external_java_v3_build_trial", "split": "repair_once",
            "task": "detector_feedback_import_repair", "project_id": prompt["project_id"],
            "project_path": prompt["project_path"], "file_path": prompt["file_path"],
            "ground_truth": "", "prompt": "Return the corrected Java import statement(s) only, one per line. Do not add prose or code fences. This is the only repair attempt.\n\nOriginal response:\n" + response.get("response", "") + "\n\nDetector evidence:\n" + evidence,
        })
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"artifact": "external_java_v3_intervention_manifest", "units": len(units), "projects": len(set(row["project_id"] for row in units)), "intent_to_treat": True, "rows": units}
    (output / "intervention_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with (output / "repair_prompts.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for row in repair_prompts:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(json.dumps({"units": len(units), "projects": manifest["projects"], "repair_prompts": len(repair_prompts)}, indent=2))


def safe_copy_source(source: Path, destination: Path, work_root: Path) -> None:
    if destination.exists():
        try:
            destination.resolve().relative_to(work_root.resolve())
        except ValueError as error:
            raise RuntimeError(f"Unsafe work cleanup target: {destination}") from error
        shutil.rmtree(destination)
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns(".git", "target", "build", ".gradle"))


def replace_import(source: str, gold: str, imports: list[str]) -> str:
    pattern = re.compile(rf"(?m)^\s*import\s+{re.escape(gold)}\s*;\s*(?:\r?\n|$)")
    replacement = "".join(f"import {value};\n" for value in dict.fromkeys(imports))
    updated, count = pattern.subn(replacement, source, count=1)
    if count != 1:
        raise ValueError(f"Gold import not found exactly once: {gold}")
    return updated


def percentile(values: list[float], p: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * p
    low, high = math.floor(position), math.ceil(position)
    return ordered[low] if low == high else ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def paired_bootstrap(rows: list[dict], comparator: str, repetitions: int, seed: int) -> dict:
    by_project: dict[str, list[dict]] = collections.defaultdict(list)
    for row in rows:
        by_project[row["project_id"]].append(row)
    projects = sorted(by_project)
    rng = random.Random(seed)
    draws = []
    for _ in range(repetitions):
        sampled = [rng.choice(projects) for _ in projects]
        values = [unit for project in sampled for unit in by_project[project]]
        raw = sum(unit["variant_pass"]["RAW"] for unit in values) / len(values)
        compared = sum(unit["variant_pass"][comparator] for unit in values) / len(values)
        draws.append(compared - raw)
    return {"point": sum(row["variant_pass"][comparator] - row["variant_pass"]["RAW"] for row in rows) / len(rows), "ci_low": percentile(draws, 0.025), "ci_high": percentile(draws, 0.975)}


def run_trial(args: argparse.Namespace) -> None:
    manifest = json.loads(args.manifest_json.read_text(encoding="utf-8"))["rows"]
    repair = {row["record_id"].replace("_REPAIR", ""): row for row in read_jsonl(args.repair_responses_jsonl)}
    baseline = {row["project_id"]: row for row in json.loads(args.baseline_json.read_text(encoding="utf-8"))["rows"]}
    output = args.output_dir
    work_root = args.work_root.resolve()
    work_root.mkdir(parents=True, exist_ok=True)
    results = []
    for unit_index, unit in enumerate(manifest, 1):
        repair_row = repair.get(unit["unit_id"], {})
        repair_imports = java_imports(repair_row.get("response", ""), unit["record_id"] + ":repair")
        variants = {"RAW": unit["raw_imports"], "DELETE": unit["delete_imports"], "REPAIR": repair_imports, "ORACLE": [unit["ground_truth_import"]]}
        unit_results = []
        source_project = args.acquisition_dir / unit["project_relative_path"]
        cache = Path(baseline[unit["project_id"]]["cache_path"]).resolve()
        for variant, imports in variants.items():
            result_path = output / "records" / f"{unit['unit_id']}_{variant}.json"
            if args.resume and result_path.is_file():
                unit_results.append(json.loads(result_path.read_text(encoding="utf-8")))
                continue
            work = work_root / unit["unit_id"] / variant
            safe_copy_source(source_project, work, work_root)
            source_file = work / Path(*unit["relative_file_path"].replace("\\", "/").split("/"))
            original = source_file.read_text(encoding="utf-8")
            source_file.write_text(replace_import(original, unit["ground_truth_import"], imports), encoding="utf-8", newline="")
            base_command = maven_command(work, args.maven) + ["-o", "-B", "-ntp", f"-Dmaven.repo.local={cache}"]
            compile_run = run_process(base_command + ["test-compile"], work, args.timeout, output / "logs" / f"{unit['unit_id']}_{variant}_compile.log")
            test_run = run_process(base_command + ["test"], work, args.timeout, output / "logs" / f"{unit['unit_id']}_{variant}_test.log") if compile_run["returncode"] == 0 else {"returncode": -1, "elapsed_seconds": 0.0, "download_urls": [], "log": "not_run_after_compile_failure", "timed_out": False, "command": []}
            tests = test_counts(work)
            row = {
                "unit_id": unit["unit_id"], "record_id": unit["record_id"], "project_id": unit["project_id"],
                "variant": variant, "imports": imports, "compile": compile_run, "test": test_run, "tests": tests,
                "pass_compile_and_nonzero_tests": compile_run["returncode"] == 0 and test_run["returncode"] == 0 and tests.get("tests", 0) > 0,
                "measured_network_mode": "maven_offline", "observed_download_urls": sorted(set(compile_run.get("download_urls", []) + test_run.get("download_urls", []))),
            }
            result_path.parent.mkdir(parents=True, exist_ok=True)
            result_path.write_text(json.dumps(row, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            unit_results.append(row)
            print(f"TRIAL {unit_index}/{len(manifest)} {unit['unit_id']} {variant} pass={row['pass_compile_and_nonzero_tests']}", flush=True)
        results.extend(unit_results)
    by_unit: dict[str, dict] = {}
    for row in results:
        unit = by_unit.setdefault(row["unit_id"], {"unit_id": row["unit_id"], "project_id": row["project_id"], "variant_pass": {}})
        unit["variant_pass"][row["variant"]] = row["pass_compile_and_nonzero_tests"]
    paired_rows = list(by_unit.values())
    differences = {name: paired_bootstrap(paired_rows, name, args.bootstrap_repetitions, args.seed) for name in ("DELETE", "REPAIR")}
    gate = {"units_at_least_20": len(paired_rows) >= 20, "projects_at_least_8": len({row["project_id"] for row in paired_rows}) >= 8, "delete_or_repair_ci_low_above_zero": any(value["ci_low"] > 0 for value in differences.values())}
    gate["practice_effect_claim_allowed"] = all(gate.values())
    summary = {"artifact": "external_java_v3_build_trial", "units": len(paired_rows), "projects": len({row["project_id"] for row in paired_rows}), "variant_runs": len(results), "paired_differences_vs_raw": differences, "claim_gate": gate, "rows": results}
    output.mkdir(parents=True, exist_ok=True)
    (output / "build_trial_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"units": summary["units"], "projects": summary["projects"], "differences": differences, "claim_gate": gate}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    screen_parser = sub.add_parser("screen")
    screen_parser.add_argument("--acquisition-dir", type=Path, required=True)
    screen_parser.add_argument("--output-dir", type=Path, required=True)
    screen_parser.add_argument("--maven", default="mvn")
    screen_parser.add_argument("--timeout", type=int, default=900)
    screen_parser.add_argument("--resume", action="store_true")
    prepare_parser = sub.add_parser("prepare")
    prepare_parser.add_argument("--baseline-json", type=Path, required=True)
    prepare_parser.add_argument("--prompts-jsonl", type=Path, required=True)
    prepare_parser.add_argument("--responses-jsonl", type=Path, required=True)
    prepare_parser.add_argument("--detector-csv", type=Path, required=True)
    prepare_parser.add_argument("--output-dir", type=Path, required=True)
    run_parser = sub.add_parser("run")
    run_parser.add_argument("--manifest-json", type=Path, required=True)
    run_parser.add_argument("--repair-responses-jsonl", type=Path, required=True)
    run_parser.add_argument("--baseline-json", type=Path, required=True)
    run_parser.add_argument("--acquisition-dir", type=Path, required=True)
    run_parser.add_argument("--output-dir", type=Path, required=True)
    run_parser.add_argument("--work-root", type=Path, required=True)
    run_parser.add_argument("--maven", default="mvn")
    run_parser.add_argument("--timeout", type=int, default=900)
    run_parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    run_parser.add_argument("--seed", type=int, default=20260818)
    run_parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    {"screen": screen, "prepare": prepare, "run": run_trial}[args.command](args)


if __name__ == "__main__":
    main()
