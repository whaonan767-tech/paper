import argparse
import csv
import json
from datetime import datetime
from pathlib import Path


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def parse_timestamp(value):
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def rate(valid, hallucinated):
    denom = valid + hallucinated
    return hallucinated / denom if denom else 0.0


def fmt_rate(value):
    return f"{value:.3f}"


def fmt_count_rate(hallucinated, valid):
    return f"{hallucinated}/{valid + hallucinated} ({rate(valid, hallucinated):.3f})"


def duration_minutes(metadata):
    if metadata.get("merged_from"):
        total_seconds = 0.0
        for source in metadata["merged_from"]:
            started = parse_timestamp(source.get("started_at"))
            finished = parse_timestamp(source.get("finished_at"))
            if started and finished:
                total_seconds += (finished - started).total_seconds()
        if total_seconds:
            return total_seconds / 60.0
    started = parse_timestamp(metadata.get("started_at"))
    finished = parse_timestamp(metadata.get("finished_at"))
    if not started or not finished:
        return None
    return (finished - started).total_seconds() / 60.0


def read_run(run_dir):
    run_dir = Path(run_dir)
    summary = load_json(run_dir / "summary.json")
    metadata = summary.get("metadata", {})
    totals = summary.get("totals", {})

    filtered_path = run_dir / "filtered_rates.json"
    if filtered_path.exists():
        filtered = load_json(filtered_path)
        filtered_totals = filtered.get("totals", {})
        filtered_rows = {row["dataset"]: row for row in filtered.get("rows", [])}
    else:
        filtered_totals = {}
        filtered_rows = {}

    raw_h1 = int(totals.get("hallucinated_1", 0))
    raw_h2 = int(totals.get("hallucinated_2", 0))
    valid_1 = int(totals.get("valid_1", 0))
    valid_2 = int(totals.get("valid_2", 0))
    filt_h1 = int(filtered_totals.get("filtered_hallucinated_1", raw_h1))
    filt_h2 = int(filtered_totals.get("filtered_hallucinated_2", raw_h2))

    record = {
        "run_name": run_dir.name,
        "run_dir": str(run_dir),
        "model": metadata.get("model_label", ""),
        "language": metadata.get("language", ""),
        "offset": int(metadata.get("offset", 0)),
        "limit_per_dataset": int(metadata.get("limit_per_dataset", 0)),
        "prompt_rows": int(totals.get("rows_in_package_names", 0)),
        "duration_minutes": duration_minutes(metadata),
        "valid_1": valid_1,
        "raw_hallucinated_1": raw_h1,
        "raw_rate_1": rate(valid_1, raw_h1),
        "filtered_hallucinated_1": filt_h1,
        "filtered_rate_1": rate(valid_1, filt_h1),
        "removed_1": raw_h1 - filt_h1,
        "valid_2": valid_2,
        "raw_hallucinated_2": raw_h2,
        "raw_rate_2": rate(valid_2, raw_h2),
        "filtered_hallucinated_2": filt_h2,
        "filtered_rate_2": rate(valid_2, filt_h2),
        "removed_2": raw_h2 - filt_h2,
    }

    per_dataset = []
    for row in summary.get("rows", []):
        dataset = row["dataset"]
        filtered_row = filtered_rows.get(dataset, {})
        row_valid_1 = int(row.get("valid_1", 0))
        row_valid_2 = int(row.get("valid_2", 0))
        row_raw_h1 = int(row.get("hallucinated_1", 0))
        row_raw_h2 = int(row.get("hallucinated_2", 0))
        row_filt_h1 = int(filtered_row.get("filtered_hallucinated_1", row_raw_h1))
        row_filt_h2 = int(filtered_row.get("filtered_hallucinated_2", row_raw_h2))
        per_dataset.append(
            {
                "run_name": run_dir.name,
                "model": record["model"],
                "dataset": dataset,
                "valid_1": row_valid_1,
                "raw_hallucinated_1": row_raw_h1,
                "raw_rate_1": rate(row_valid_1, row_raw_h1),
                "filtered_hallucinated_1": row_filt_h1,
                "filtered_rate_1": rate(row_valid_1, row_filt_h1),
                "valid_2": row_valid_2,
                "raw_hallucinated_2": row_raw_h2,
                "raw_rate_2": rate(row_valid_2, row_raw_h2),
                "filtered_hallucinated_2": row_filt_h2,
                "filtered_rate_2": rate(row_valid_2, row_filt_h2),
            }
        )

    return record, per_dataset


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path, rows, dataset_rows):
    limits = sorted({row["limit_per_dataset"] for row in rows})
    offsets = sorted({row["offset"] for row in rows})

    lines = [
        "# Model Sensitivity Comparison",
        "",
        "## Total Rates",
        "",
    ]
    if len(limits) == 1 and len(offsets) == 1:
        lines.append(f"- Shared prompt subset: offset `{offsets[0]}`, limit per dataset `{limits[0]}`")
    else:
        lines.append("- Runs use different prompt subsets; compare as descriptive results, not a controlled sensitivity test.")
    lines.extend(
        [
            "",
            "| Run | Model | Prompts | Minutes | Raw Q1 | Filtered Q1 | Raw Q2 | Filtered Q2 |",
            "|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in rows:
        minutes = "" if row["duration_minutes"] is None else f"{row['duration_minutes']:.1f}"
        lines.append(
            "| {run_name} | {model} | {prompt_rows} | {minutes} | {raw_q1} | {filtered_q1} | {raw_q2} | {filtered_q2} |".format(
                run_name=row["run_name"],
                model=row["model"],
                prompt_rows=row["prompt_rows"],
                minutes=minutes,
                raw_q1=fmt_count_rate(row["raw_hallucinated_1"], row["valid_1"]),
                filtered_q1=fmt_count_rate(row["filtered_hallucinated_1"], row["valid_1"]),
                raw_q2=fmt_count_rate(row["raw_hallucinated_2"], row["valid_2"]),
                filtered_q2=fmt_count_rate(row["filtered_hallucinated_2"], row["valid_2"]),
            )
        )

    lines.extend(["", "## Dataset Rates", ""])
    for run_name in [row["run_name"] for row in rows]:
        lines.extend(
            [
                f"### {run_name}",
                "",
                "| Dataset | Raw Q1 | Filtered Q1 | Raw Q2 | Filtered Q2 |",
                "|---|---:|---:|---:|---:|",
            ]
        )
        for row in [item for item in dataset_rows if item["run_name"] == run_name]:
            lines.append(
                "| {dataset} | {raw_q1} | {filtered_q1} | {raw_q2} | {filtered_q2} |".format(
                    dataset=row["dataset"],
                    raw_q1=fmt_count_rate(row["raw_hallucinated_1"], row["valid_1"]),
                    filtered_q1=fmt_count_rate(row["filtered_hallucinated_1"], row["valid_1"]),
                    raw_q2=fmt_count_rate(row["raw_hallucinated_2"], row["valid_2"]),
                    filtered_q2=fmt_count_rate(row["filtered_hallucinated_2"], row["valid_2"]),
                )
            )
        lines.append("")

    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", action="append", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    total_rows = []
    dataset_rows = []
    for run_dir in args.run_dir:
        total_row, per_dataset = read_run(run_dir)
        total_rows.append(total_row)
        dataset_rows.extend(per_dataset)

    output = {"runs": total_rows, "dataset_rows": dataset_rows}
    (output_dir / "model_sensitivity.json").write_text(
        json.dumps(output, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    write_csv(output_dir / "model_sensitivity_totals.csv", total_rows)
    write_csv(output_dir / "model_sensitivity_by_dataset.csv", dataset_rows)
    write_markdown(output_dir / "model_sensitivity.md", total_rows, dataset_rows)
    print(f"Wrote comparison files to {output_dir}")


if __name__ == "__main__":
    main()
