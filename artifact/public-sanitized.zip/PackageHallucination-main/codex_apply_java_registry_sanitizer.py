import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


SUSPICIOUS_STATUSES = {
    "project_namespace_hallucination",
    "project_namespace_typo_hallucination",
    "hallucinated_prefix_with_suggestion",
    "unresolved_after_mapping",
}

SAFE_EXTERNAL_PREFIX_REPAIRS = {
    "org.slf4.": "org.slf4j.",
    "org.ai.timefold.": "ai.timefold.solver.",
}


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            json.dump(row, handle, ensure_ascii=False)
            handle.write("\n")


def grouped_suspicious_rows(mapping_rows, statuses):
    grouped = defaultdict(list)
    for row in mapping_rows:
        if row.get("mapping_status") not in statuses:
            continue
        record_id = row.get("original_record_id", "")
        import_path = row.get("import_path", "")
        if record_id and import_path:
            grouped[record_id].append(row)
    return grouped


def bad_prefix_from_reason(reason):
    match = re.search(r"Matched suspicious prefix `([^`]+)`", reason or "")
    return match.group(1) if match else ""


def replacement_for(row, mode):
    if mode == "remove":
        return ""

    suggested_project_import = row.get("suggested_project_import", "")
    if suggested_project_import:
        return suggested_project_import

    bad_prefix = bad_prefix_from_reason(row.get("mapping_reason", ""))
    suggested_prefix = row.get("suggested_import_prefix", "")
    import_path = row.get("import_path", "")
    if bad_prefix and SAFE_EXTERNAL_PREFIX_REPAIRS.get(bad_prefix) == suggested_prefix:
        return suggested_prefix + import_path[len(bad_prefix) :]

    return ""


def apply_import_edit(text, import_path, replacement):
    line_re = re.compile(
        rf"(?m)^[ \t]*import\s+(static\s+)?{re.escape(import_path)}\s*;?[ \t]*(?:\r?\n|$)"
    )

    edit_kind = "replace_import" if replacement else "remove_import"

    def replace_line(match):
        if not replacement:
            return ""
        static_part = match.group(1) or ""
        return f"import {static_part}{replacement};\n"

    edited, count = line_re.subn(replace_line, text)
    return edited, count, edit_kind


def sanitize_response(row, suspicious_rows, mode):
    text = row.get("response", "")
    actions = []
    for suspicious in suspicious_rows:
        import_path = suspicious.get("import_path", "")
        replacement = replacement_for(suspicious, mode)
        before = text
        text, count, action = apply_import_edit(text, import_path, replacement)
        residual = import_path in text
        actions.append(
            {
                "import_path": import_path,
                "mapping_status": suspicious.get("mapping_status", ""),
                "action": action,
                "replacement": replacement,
                "edited_import_lines": count,
                "residual_exact_string": residual,
            }
        )
        if count == 0 and replacement and import_path in before:
            text = text.replace(import_path, replacement)
            actions[-1]["action"] = "replace_exact_string"
            actions[-1]["edited_import_lines"] = 1
            actions[-1]["residual_exact_string"] = import_path in text
    for action in actions:
        action["residual_exact_string"] = action["import_path"] in text
    out = dict(row)
    out["original_response"] = row.get("response", "")
    out["response"] = text
    out["sanitizer_actions"] = actions
    return out


def write_audit_md(path, audit_rows, output):
    lines = [
        "# Java Registry Sanitizer Audit",
        "",
        f"- Input responses: `{output['input_responses']}`",
        f"- Input mapping: `{output['input_mapping']}`",
        f"- Mode: `{output['mode']}`",
        f"- Records with suspicious imports: `{output['targeted_records']}`",
        f"- Suspicious import actions: `{len(audit_rows)}`",
        "",
        "## Actions",
        "",
        "| Action | Count |",
        "|---|---:|",
    ]
    for action, count in sorted(output["action_counts"].items()):
        lines.append(f"| {action} | {count} |")
    lines.extend(["", "## Statuses", "", "| Mapping status | Count |", "|---|---:|"])
    for status, count in sorted(output["status_counts"].items()):
        lines.append(f"| {status} | {count} |")
    lines.extend(
        [
            "",
            "## Audit Rows",
            "",
            "| Record | Import | Status | Action | Replacement | Edited lines | Residual exact string |",
            "|---|---|---|---|---|---:|---|",
        ]
    )
    for row in audit_rows[:120]:
        lines.append(
            "| `{record}` | `{import_path}` | `{status}` | `{action}` | `{replacement}` | {edited} | `{residual}` |".format(
                record=row["record_id"],
                import_path=row["import_path"],
                status=row["mapping_status"],
                action=row["action"],
                replacement=row["replacement"],
                edited=row["edited_import_lines"],
                residual=row["residual_exact_string"],
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--responses-jsonl", required=True)
    parser.add_argument("--mapping-csv", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--audit-json", required=True)
    parser.add_argument("--audit-md", required=True)
    parser.add_argument("--mode", choices=["remove", "repair"], default="remove")
    parser.add_argument("--statuses", nargs="*", default=sorted(SUSPICIOUS_STATUSES))
    args = parser.parse_args()

    responses = read_jsonl(Path(args.responses_jsonl))
    mapping_rows = list(csv.DictReader(Path(args.mapping_csv).open("r", encoding="utf-8")))
    statuses = set(args.statuses)
    grouped = grouped_suspicious_rows(mapping_rows, statuses)

    sanitized = []
    audit_rows = []
    for row in responses:
        record_id = row.get("record_id", "")
        suspicious_rows = grouped.get(record_id, [])
        if suspicious_rows:
            out = sanitize_response(row, suspicious_rows, args.mode)
            for action in out["sanitizer_actions"]:
                action_row = {"record_id": record_id}
                action_row.update(action)
                audit_rows.append(action_row)
            sanitized.append(out)
        else:
            sanitized.append(dict(row))

    output = {
        "input_responses": args.responses_jsonl,
        "input_mapping": args.mapping_csv,
        "mode": args.mode,
        "targeted_records": len(grouped),
        "statuses": sorted(statuses),
        "action_counts": dict(Counter(row["action"] for row in audit_rows)),
        "status_counts": dict(Counter(row["mapping_status"] for row in audit_rows)),
        "audit_rows": audit_rows,
    }
    write_jsonl(Path(args.output_jsonl), sanitized)
    Path(args.audit_json).write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    write_audit_md(Path(args.audit_md), audit_rows, output)
    print(json.dumps({key: output[key] for key in ["targeted_records", "action_counts", "status_counts"]}, indent=2))


if __name__ == "__main__":
    main()
