import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


VALIDITIES = {"valid", "invalid", "malformed", "uncertain"}
EVALUABLE_VALIDITIES = {"valid", "invalid"}


def read_csv(path):
    if not path or not Path(path).exists():
        return []
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def clean(value):
    return (value or "").strip().lower()


def final_validity(row):
    for field in ("adjudicated_validity", "annotation_validity"):
        value = clean(row.get(field, ""))
        if value in VALIDITIES:
            return value
    annotator_values = [
        clean(row.get("annotator_a_annotation_validity", "")),
        clean(row.get("annotator_b_annotation_validity", "")),
    ]
    annotator_values = [value for value in annotator_values if value in VALIDITIES]
    if len(annotator_values) == 2 and annotator_values[0] == annotator_values[1]:
        return annotator_values[0]
    label = clean(row.get("adjudicated_label", "")) or clean(row.get("annotation_label", ""))
    if not label:
        annotator_labels = [
            clean(row.get("annotator_a_annotation_label", "")),
            clean(row.get("annotator_b_annotation_label", "")),
        ]
        annotator_labels = [value for value in annotator_labels if value]
        if len(annotator_labels) == 2 and annotator_labels[0] == annotator_labels[1]:
            label = annotator_labels[0]
    if label.startswith("valid_"):
        return "valid"
    if label.startswith("hallucinated_") or label in {"unresolved_unknown"}:
        return "invalid"
    if label == "malformed_extraction":
        return "malformed"
    if label == "uncertain":
        return "uncertain"
    return ""


def rate(numerator, denominator):
    if denominator == 0:
        return None
    return numerator / denominator


def metric_block(tp, fp, fn, tn):
    precision = rate(tp, tp + fp)
    recall = rate(tp, tp + fn)
    f1 = None
    if precision is not None and recall is not None and precision + recall:
        f1 = 2 * precision * recall / (precision + recall)
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def cohen_kappa(labels_a, labels_b):
    paired = [(a, b) for a, b in zip(labels_a, labels_b) if a in VALIDITIES and b in VALIDITIES]
    n = len(paired)
    if n == 0:
        return {"n": 0, "observed_agreement": None, "expected_agreement": None, "kappa": None}
    observed = sum(1 for a, b in paired if a == b) / n
    count_a = Counter(a for a, _ in paired)
    count_b = Counter(b for _, b in paired)
    categories = sorted(set(count_a) | set(count_b))
    expected = sum((count_a[cat] / n) * (count_b[cat] / n) for cat in categories)
    kappa = None if expected == 1 else (observed - expected) / (1 - expected)
    return {
        "n": n,
        "observed_agreement": observed,
        "expected_agreement": expected,
        "kappa": kappa,
    }


def gwet_ac1(labels_a, labels_b):
    paired = [(a, b) for a, b in zip(labels_a, labels_b) if a in VALIDITIES and b in VALIDITIES]
    n = len(paired)
    if n == 0:
        return {"n": 0, "observed_agreement": None, "chance_agreement": None, "ac1": None}
    observed = sum(1 for a, b in paired if a == b) / n
    categories = sorted(set(a for a, _ in paired) | set(b for _, b in paired))
    q = len(categories)
    if q <= 1:
        return {"n": n, "observed_agreement": observed, "chance_agreement": 1.0, "ac1": None}
    marginal = {}
    for cat in categories:
        marginal[cat] = (sum(1 for a, b in paired if a == cat) + sum(1 for a, b in paired if b == cat)) / (2 * n)
    chance = sum(p * (1 - p) for p in marginal.values()) / (q - 1)
    ac1 = None if chance == 1 else (observed - chance) / (1 - chance)
    return {"n": n, "observed_agreement": observed, "chance_agreement": chance, "ac1": ac1}


def merge_key(rows, key_rows):
    key_by_id = {row["audit_id"]: row for row in key_rows}
    merged = []
    for row in rows:
        key = key_by_id.get(row.get("audit_id", ""), {})
        merged.append({**key, **row})
    return merged


def audit_metrics(rows):
    rows_with_truth = []
    for row in rows:
        truth = final_validity(row)
        row = dict(row)
        row["truth_validity"] = truth
        if truth:
            rows_with_truth.append(row)

    group_counts = Counter(row.get("sample_group", "") for row in rows)
    truth_counts = Counter(row["truth_validity"] for row in rows_with_truth)
    annotated_by_group = Counter(row.get("sample_group", "") for row in rows_with_truth)

    main_rows = [
        row
        for row in rows_with_truth
        if row.get("sample_group") in {"positive_detector_flagged", "negative_control_unflagged"}
        and row["truth_validity"] in EVALUABLE_VALIDITIES
    ]
    tp = sum(1 for row in main_rows if row.get("sample_group") == "positive_detector_flagged" and row["truth_validity"] == "invalid")
    fp = sum(1 for row in main_rows if row.get("sample_group") == "positive_detector_flagged" and row["truth_validity"] == "valid")
    fn = sum(1 for row in main_rows if row.get("sample_group") == "negative_control_unflagged" and row["truth_validity"] == "invalid")
    tn = sum(1 for row in main_rows if row.get("sample_group") == "negative_control_unflagged" and row["truth_validity"] == "valid")

    removed_positive_rows = [
        row
        for row in rows_with_truth
        if row.get("sample_group") == "positive_detector_flagged"
        and row.get("sanitizer_action") == "remove_import"
        and row["truth_validity"] in EVALUABLE_VALIDITIES
    ]
    correct_deletions = sum(1 for row in removed_positive_rows if row["truth_validity"] == "invalid")
    false_deletions = sum(1 for row in removed_positive_rows if row["truth_validity"] == "valid")

    malformed_rows = [row for row in rows_with_truth if row.get("sample_group") == "aux_malformed_extraction"]
    malformed_confirmed = sum(1 for row in malformed_rows if row["truth_validity"] == "malformed")

    by_mapping_status = defaultdict(Counter)
    for row in rows_with_truth:
        by_mapping_status[row.get("mapping_status", "")][row["truth_validity"]] += 1

    return {
        "rows_total": len(rows),
        "rows_annotated": len(rows_with_truth),
        "configured_sample_group_counts": dict(sorted(group_counts.items())),
        "annotated_by_group": dict(sorted(annotated_by_group.items())),
        "truth_validity_counts": dict(sorted(truth_counts.items())),
        "sample_confusion_matrix": metric_block(tp, fp, fn, tn),
        "sanitizer_deletion_audit": {
            "removed_positive_rows_annotated": len(removed_positive_rows),
            "correct_deletions": correct_deletions,
            "false_deletions": false_deletions,
            "deletion_precision": rate(correct_deletions, len(removed_positive_rows)),
            "false_deletion_rate": rate(false_deletions, len(removed_positive_rows)),
        },
        "aux_malformed_audit": {
            "aux_rows_annotated": len(malformed_rows),
            "confirmed_malformed": malformed_confirmed,
            "confirmed_malformed_rate": rate(malformed_confirmed, len(malformed_rows)),
        },
        "truth_by_mapping_status": {status: dict(counts) for status, counts in sorted(by_mapping_status.items())},
    }


def compare_annotators(path_a, path_b, key_rows, output_dir, output_prefix):
    rows_a = merge_key(read_csv(path_a), key_rows)
    rows_b = merge_key(read_csv(path_b), key_rows)
    by_id_b = {row["audit_id"]: row for row in rows_b}
    paired = []
    labels_a = []
    labels_b = []
    disagreements = []
    for row_a in rows_a:
        row_b = by_id_b.get(row_a.get("audit_id", ""))
        if not row_b:
            continue
        va = final_validity(row_a)
        vb = final_validity(row_b)
        if va not in VALIDITIES or vb not in VALIDITIES:
            continue
        labels_a.append(va)
        labels_b.append(vb)
        paired.append((row_a, row_b, va, vb))
        if va != vb:
            disagreements.append(
                {
                    "audit_id": row_a.get("audit_id", ""),
                    "annotator_a_validity": va,
                    "annotator_b_validity": vb,
                    "sample_group": row_a.get("sample_group", ""),
                    "mapping_status": row_a.get("mapping_status", ""),
                    "import_path": row_a.get("import_path", ""),
                    "a_rationale": row_a.get("annotation_rationale", ""),
                    "b_rationale": row_b.get("annotation_rationale", ""),
                }
            )
    write_csv(
        output_dir / f"{output_prefix}_disagreements.csv",
        [
            "audit_id",
            "annotator_a_validity",
            "annotator_b_validity",
            "sample_group",
            "mapping_status",
            "import_path",
            "a_rationale",
            "b_rationale",
        ],
        disagreements,
    )
    return {
        "paired_rows": len(paired),
        "cohen_kappa": cohen_kappa(labels_a, labels_b),
        "gwet_ac1": gwet_ac1(labels_a, labels_b),
        "disagreements": len(disagreements),
    }


def fmt_rate(value):
    if value is None:
        return "n/a"
    return f"{value:.3f}"


def write_markdown(path, metrics, agreement=None, notice=""):
    cm = metrics["sample_confusion_matrix"]
    deletion = metrics["sanitizer_deletion_audit"]
    malformed = metrics["aux_malformed_audit"]
    lines = [
        "# Java Human Audit Metrics",
        "",
        "These metrics are computed only from filled annotation/adjudication fields.",
    ]
    if notice:
        lines.extend(["", f"Notice: `{notice}`."])
    lines.extend([
        "",
        "## Annotation Coverage",
        "",
        f"- Rows total: {metrics['rows_total']}",
        f"- Rows annotated: {metrics['rows_annotated']}",
        f"- Truth validity counts: `{metrics['truth_validity_counts']}`",
        "",
        "## Detector Metrics on the Stratified Sample",
        "",
        "| Metric | Value |",
        "|---|---:|",
        f"| TP | {cm['tp']} |",
        f"| FP | {cm['fp']} |",
        f"| FN | {cm['fn']} |",
        f"| TN | {cm['tn']} |",
        f"| Precision | {fmt_rate(cm['precision'])} |",
        f"| Recall | {fmt_rate(cm['recall'])} |",
        f"| F1 | {fmt_rate(cm['f1'])} |",
        "",
        "## Sanitizer Deletion Audit",
        "",
        "| Metric | Value |",
        "|---|---:|",
        f"| Removed positives annotated | {deletion['removed_positive_rows_annotated']} |",
        f"| Correct deletions | {deletion['correct_deletions']} |",
        f"| False deletions | {deletion['false_deletions']} |",
        f"| Deletion precision | {fmt_rate(deletion['deletion_precision'])} |",
        f"| False deletion rate | {fmt_rate(deletion['false_deletion_rate'])} |",
        "",
        "## Malformed Extraction Audit",
        "",
        "| Metric | Value |",
        "|---|---:|",
        f"| Auxiliary rows annotated | {malformed['aux_rows_annotated']} |",
        f"| Confirmed malformed | {malformed['confirmed_malformed']} |",
        f"| Confirmed malformed rate | {fmt_rate(malformed['confirmed_malformed_rate'])} |",
    ])
    if agreement:
        lines.extend(
            [
                "",
                "## Inter-Annotator Agreement",
                "",
                "| Metric | Value |",
                "|---|---:|",
                f"| Paired rows | {agreement['paired_rows']} |",
                f"| Disagreements | {agreement['disagreements']} |",
                f"| Cohen kappa | {fmt_rate(agreement['cohen_kappa']['kappa'])} |",
                f"| Gwet AC1 | {fmt_rate(agreement['gwet_ac1']['ac1'])} |",
            ]
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="PackageHallucination-main root")
    parser.add_argument("--audit-dir", default="Tests/Java_APIHulBench_HumanAudit")
    parser.add_argument("--annotations", default=None, help="Filled annotation or adjudication CSV")
    parser.add_argument("--annotator-a", default=None, help="Filled blind CSV from annotator A")
    parser.add_argument("--annotator-b", default=None, help="Filled blind CSV from annotator B")
    parser.add_argument("--output-prefix", default="java_human_annotation_metrics")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    audit_dir = root / args.audit_dir
    key_rows = read_csv(audit_dir / "java_human_annotation_key.csv")
    annotation_path = Path(args.annotations) if args.annotations else audit_dir / "java_human_annotation_sheet.csv"
    rows = merge_key(read_csv(annotation_path), key_rows)
    metrics = audit_metrics(rows)

    agreement = None
    if args.annotator_a and args.annotator_b:
        agreement = compare_annotators(Path(args.annotator_a), Path(args.annotator_b), key_rows, audit_dir, args.output_prefix)

    payload = {"metrics": metrics}
    notice = ""
    if "ai" in args.output_prefix.lower():
        notice = "AI_PREANNOTATION_NOT_HUMAN_GROUND_TRUTH"
        payload["notice"] = notice
    if agreement:
        payload["agreement"] = agreement
    write_json(audit_dir / f"{args.output_prefix}.json", payload)
    write_markdown(audit_dir / f"{args.output_prefix}.md", metrics, agreement=agreement, notice=notice)

    print(f"rows_total={metrics['rows_total']}")
    print(f"rows_annotated={metrics['rows_annotated']}")
    print(f"precision={fmt_rate(metrics['sample_confusion_matrix']['precision'])}")
    print(f"recall={fmt_rate(metrics['sample_confusion_matrix']['recall'])}")
    print(f"f1={fmt_rate(metrics['sample_confusion_matrix']['f1'])}")
    print(f"false_deletion_rate={fmt_rate(metrics['sanitizer_deletion_audit']['false_deletion_rate'])}")


if __name__ == "__main__":
    main()
