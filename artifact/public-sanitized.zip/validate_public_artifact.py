﻿#!/usr/bin/env python3
"""Validate a public sanitized dependency-hallucination artifact tree."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


REDACTED_CREDENTIAL = "<REDACTED_THIRD_PARTY_CREDENTIAL>"
DB_CREDENTIAL_URI = re.compile(
    r"\b(?P<scheme>mongodb(?:\+srv)?|postgres(?:ql)?|mysql|mariadb|redis|rediss|amqp|amqps|mssql|sqlserver|neo4j|bolt)"
    r"://(?P<user>[^:\s/@\\\"'<>]+):(?P<password>[^@\s/\\\"'<>]+)@(?P<rest>[^\\\s\"'<>]+)",
    re.IGNORECASE,
)
CREDENTIAL_ASSIGNMENT = re.compile(
    r"(?P<prefix>(?i:[\"']?(?:password|passwd|pwd|secret_key|client_secret|api_key|access_token|auth_token|secret|"
    r"aws_secret_access_key|aws_access_key_id|aws_session_token)[\"']?\s*[:=]\s*))"
    r"(?P<quote>[\"'])(?P<value>[^\"'\r\n]{3,})(?P=quote)"
)
PRIVATE_KEY_BLOCK = re.compile(
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----",
    re.DOTALL,
)
LOCAL_ABSOLUTE_PATH = re.compile(
    r"(?i)(?:(?<![a-z0-9])[a-z]:[\\/]|(?<![a-z0-9:/])/(?:users|home)/[^/\\\s]+[/\\])"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def is_placeholder_secret(value: str) -> bool:
    normalized = value.strip().strip("\"'").casefold()
    placeholders = {
        "",
        "user",
        "username",
        "password",
        "passwd",
        "pwd",
        "secret",
        "client_secret",
        "api_key",
        "access_token",
        "token",
        "host",
        "port",
        "dbname",
        "db_name",
        "your-password",
        "your_password",
        "your_secret",
        "your_api_key",
        "your_access_token",
        "your_db_password",
        "your_db_user",
        "your_db_host",
        "your_db_port",
        "your_db_name",
        "your-client-secret",
        "your_client_secret",
        "your-client-id",
        "your_client_id",
        "changeme",
        "change_me",
        "placeholder",
        "dummy",
        "example",
        "redacted",
        REDACTED_CREDENTIAL.casefold(),
    }
    if normalized in placeholders:
        return True
    if normalized.startswith(("your_", "your-", "example_", "example-", "dummy_", "dummy-")):
        return True
    if set(normalized) <= {"x", "*"}:
        return True
    if normalized.isdigit() and len(normalized) <= 6:
        return True
    return False


def credential_findings(text: str) -> list[str]:
    findings: list[str] = []
    for match in DB_CREDENTIAL_URI.finditer(text):
        if not (is_placeholder_secret(match.group("user")) and is_placeholder_secret(match.group("password"))):
            findings.append("database_uri_with_user_password")
            break
    for match in CREDENTIAL_ASSIGNMENT.finditer(text):
        if not is_placeholder_secret(match.group("value")):
            findings.append("credential_assignment")
            break
    if PRIVATE_KEY_BLOCK.search(text):
        findings.append("private_key_block")
    return findings


def validate(root: Path) -> dict[str, int | str]:
    manifest_path = root / "PUBLIC_ARTIFACT_MANIFEST.json"
    sums_path = root / "SHA256SUMS"
    if not manifest_path.is_file() or not sums_path.is_file():
        raise AssertionError("PUBLIC_ARTIFACT_MANIFEST.json or SHA256SUMS is missing")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1:
        raise AssertionError("unsupported public manifest schema")
    if manifest.get("core_assertions") != 40 or manifest.get("new_experiment_checks") != 40:
        raise AssertionError("public manifest does not declare the 40+40 check profile")
    if not re.fullmatch(r"[0-9a-f]{64}", str(manifest.get("source_review_zip_sha256", ""))):
        raise AssertionError("public manifest has no valid source review ZIP hash")
    if manifest.get("row_level_data_included") is not False:
        raise AssertionError("public manifest does not exclude row-level data")
    for key in ("raw_prompts_included", "raw_model_responses_included", "row_level_registry_missing_candidate_lists_included", "human_annotation_rows_included"):
        if manifest.get(key) is not False:
            raise AssertionError(f"public manifest does not exclude {key}")

    hash_checks = 0
    for entry in manifest["files"]:
        path = root / entry["path"]
        if not path.is_file():
            raise AssertionError(f"manifest path missing: {entry['path']}")
        if path.stat().st_size != entry["bytes"] or sha256(path) != entry["sha256"]:
            raise AssertionError(f"manifest hash mismatch: {entry['path']}")
        hash_checks += 1
    checksum_paths = set()
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        if relative in checksum_paths:
            raise AssertionError(f"duplicate SHA256SUMS path: {relative}")
        checksum_paths.add(relative)
        path = root / relative
        if not path.is_file() or sha256(path) != expected:
            raise AssertionError(f"SHA256SUMS mismatch: {relative}")
    declared_paths = {entry["path"] for entry in manifest["files"]}
    expected_checksum_paths = declared_paths | {"PUBLIC_ARTIFACT_MANIFEST.json"}
    if checksum_paths != expected_checksum_paths:
        raise AssertionError("SHA256SUMS paths do not exactly match the public manifest")
    actual_paths = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
    expected_paths = expected_checksum_paths | {"SHA256SUMS"}
    if actual_paths != expected_paths:
        extras = sorted(actual_paths - expected_paths)
        missing = sorted(expected_paths - actual_paths)
        raise AssertionError(f"public tree path mismatch: extras={extras[:10]} missing={missing[:10]}")

    aggregate = json.loads((root / "PUBLIC_AGGREGATE_CLAIMS.json").read_text(encoding="utf-8"))
    core = aggregate.get("core", {})
    core_checks = core.get("checks", [])
    if core.get("status") != "pass" or core.get("checks_passed") != 40 or core.get("check_count") != 40:
        raise AssertionError("public aggregate core summary is not 40/40")
    if len(core_checks) != 40 or not all(item.get("status") == "pass" for item in core_checks):
        raise AssertionError("public aggregate has a failed or missing core assertion")
    new_experiments = aggregate.get("new_experiments", {})
    new_checks = new_experiments.get("checks", [])
    if new_experiments.get("status") != "pass" or new_experiments.get("summary") != {"checks": 40, "passed": 40, "failed": 0}:
        raise AssertionError("public aggregate new-experiment summary is not 40/40")
    if len(new_checks) != 40 or not all(item.get("pass") is True for item in new_checks):
        raise AssertionError("public aggregate has a failed or missing new-experiment check")
    if "behavior_preservation" in json.dumps(aggregate).casefold():
        raise AssertionError("public aggregate uses an overbroad behavior-preservation label")

    disclosure_violations = []
    allowed_csv = {"DATA_LICENSE_MATRIX.csv"}
    allowed_json = {"PUBLIC_AGGREGATE_CLAIMS.json", "PUBLIC_ARTIFACT_MANIFEST.json"}
    forbidden_suffixes = {".class", ".jar", ".jsonl", ".pyc", ".pyo", ".safetensors"}
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        lowered = relative.lower()
        if "/tests/" in "/" + lowered or lowered.startswith("tests/"):
            disclosure_violations.append(relative)
        if path.suffix.lower() == ".csv" and relative not in allowed_csv:
            disclosure_violations.append(relative)
        if path.suffix.lower() in {".json", ".jsonl"} and relative not in allowed_json:
            disclosure_violations.append(relative)
        if path.suffix.lower() in forbidden_suffixes:
            disclosure_violations.append(relative)
        if any(token in lowered for token in ("master.json", "responses.jsonl", "annotation", "adjudicat", "disagreement")):
            disclosure_violations.append(relative)
    if disclosure_violations:
        raise AssertionError(f"public disclosure violations: {sorted(set(disclosure_violations))[:20]}")

    credential_hits = []
    local_path_hits = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if path.suffix.lower() in {".bib", ".cmd", ".csv", ".json", ".jsonl", ".md", ".py", ".ps1", ".tex", ".txt", ".yaml", ".yml"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
            findings = credential_findings(text)
            if findings:
                credential_hits.append(f"{path.relative_to(root).as_posix()}: {','.join(sorted(set(findings)))}")
            if LOCAL_ABSOLUTE_PATH.search(text):
                local_path_hits.append(path.relative_to(root).as_posix())
    if credential_hits:
        raise AssertionError("credential findings:\n" + "\n".join(credential_hits[:20]))
    if local_path_hits:
        raise AssertionError("local absolute path findings:\n" + "\n".join(local_path_hits[:20]))

    return {
        "status": "pass",
        "manifest_file_hash_checks": hash_checks,
        "core_assertions": 40,
        "new_experiment_checks": 40,
        "row_level_data_files": 0,
        "credential_findings": 0,
        "local_absolute_path_findings": 0,
        "undeclared_files": 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()
    result = validate(args.root.resolve())
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"VALIDATION FAILED: {error}", file=sys.stderr)
        raise
