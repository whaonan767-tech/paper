# Generation Environment Lock

This file replaces the earlier theoretical `requirements-full.txt`. The
versions below were read directly from the `rag-hallucination` environment on
2026-08-06 and match the versions stored in the model-run metadata.

| Component | Observed value |
|---|---|
| Python | 3.10.20 (64-bit, Windows) |
| PyTorch | 2.11.0+cu128 |
| PyTorch CUDA runtime | 12.8 |
| cuDNN reported by PyTorch | 91900 |
| Transformers | 5.9.0 |
| Accelerate | 1.13.0 |
| BitsAndBytes | 0.50.0 |
| GPU | NVIDIA GeForce RTX 5060 Ti, 16311 MiB |
| NVIDIA driver at final environment audit | 581.57 |

The Qwen and DeepSeek generation metadata independently record Python
3.10.20, PyTorch 2.11.0+cu128, deterministic decoding (`do_sample=false`),
4-bit loading, and the same GPU. `generation_environment.yml` is the frozen
core generation environment. Deterministic statistical recomputation does not
require this environment and uses Python 3.10 or newer with the standard
library only.

CUDA driver and transitive package versions can vary while preserving the
recorded PyTorch CUDA 12.8 runtime. Exact generation equivalence additionally
depends on the model files and configuration hashes in
`MODEL_AND_GENERATION_PROVENANCE.md`.
