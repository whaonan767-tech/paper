#!/usr/bin/env python3
"""Correct XeTeX/dvipdfmx's ambiguous semicolon ToUnicode mapping."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from pypdf import PdfReader, PdfWriter


TARGET = re.compile(rb"<037E>", re.IGNORECASE)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_pdf", type=Path)
    parser.add_argument("output_pdf", type=Path)
    args = parser.parse_args()

    reader = PdfReader(args.input_pdf)
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)

    seen: set[int] = set()
    replacements = 0
    for page in writer.pages:
        fonts = page["/Resources"].get("/Font", {})
        for font_ref in fonts.values():
            font = font_ref.get_object()
            object_id = getattr(font_ref, "idnum", id(font))
            if object_id in seen:
                continue
            seen.add(object_id)
            to_unicode = font.get("/ToUnicode")
            if not to_unicode:
                continue
            stream = to_unicode.get_object()
            data = stream.get_data()
            corrected, count = TARGET.subn(b"<003B>", data)
            if count:
                stream.set_data(corrected)
                replacements += count

    if replacements == 0:
        raise RuntimeError("No U+037E ToUnicode mapping was found.")
    with args.output_pdf.open("wb") as handle:
        writer.write(handle)
    print(f"corrected_mappings={replacements}")


if __name__ == "__main__":
    main()
