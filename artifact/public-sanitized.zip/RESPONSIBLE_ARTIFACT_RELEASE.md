# Responsible Artifact Release

## Review Package

The full archive is intended for confidential editor and peer-review access.
It includes credential-redacted raw generation records and registry-missing
dependency names because those rows are necessary to audit the paper's
classifications and human labels.
Third-party credentials embedded in prompt-bearing source text are replaced
with `<REDACTED_THIRD_PARTY_CREDENTIAL>` before manifest and hash generation.
The archive must not be mirrored or indexed as a public package-name list.

## Public Package

The public companion archive is generated separately from the full review
archive.  It excludes row-level prompt/model-response files, human annotation
rows, row-level registry-missing candidate lists, build logs, and benchmark
project trees.  It keeps the manuscript, study-authored scripts, provenance records,
environment documentation, license notes, and aggregate selected-claim checks.
The machine-readable public aggregate file contains 40 core assertions and 20
separate new-experiment checks, but no row-level inputs from which those values
could be recomputed.

Before any future row-level public release:

1. Replace registry-missing package/import names with stable salted identifiers
   in row-level files while preserving aggregate counts and pairings.
2. Recheck whether previously missing package names have since been registered;
   do not publish a current package-confusion candidate list.
3. Remove prompt-bearing Stack Overflow text unless item-level URLs, author
   attribution, license version, and share-alike obligations are restored.
4. Publish aggregate tables, human-label counts, bootstrap code, and hashes in
   preference to raw candidate names.
5. Keep third-party Java project trees excluded and direct users to the
   APIHulBench authors' official archive.

The review archive and public sanitized archive are therefore distinct release
profiles. Passing review-artifact validation does not authorize public
redistribution of every included datum.
