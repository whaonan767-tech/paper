# Data and License Notes

## PackageHallucination

The local repository is derived from the upstream PackageHallucination
artifact referenced in its README and paper. The upstream README declares the
repository MIT-licensed, but the extracted local snapshot used here does not
contain a root `LICENSE` file. To avoid asserting license text that is absent
from the snapshot, the default anonymous package excludes the upstream
`Data/Python` prompt and registry files. The artifact contains derived run
outputs needed by the paper. Users who need the original prompt/registry data
should obtain it from the upstream repository or its cited Zenodo record under
the terms published there.

## APIHulBench and Project Sources

The Java experiments use prompts and metadata derived from APIHulBench/MARIN.
The benchmark authors publish the benchmark at
`https://github.com/yujiachen99/APIMitigation` and link the project-source
archive at Google Drive file id `12c46In9w9fqJyU-qAAKccMSVycFIszOz`.
The anonymous artifact excludes the original benchmark tree, copied third-party
Java projects, Maven caches, and compiled work directories. The paper does not
redistribute those project trees. `codex_acquire_apihulbench_projects.py`
downloads the authors' archive when `gdown` is installed, extracts it, and
checks the 70 build-relevant directories against expected content hashes.

`Tests/Java_APIHulBench_BuildProvenance_Run20260804` records license-file paths
and hashes when a LICENSE/COPYING/NOTICE document with a conventional document
extension exists in the exact source snapshot. Nineteen of the 70 build-relevant
project snapshots contain no such discoverable file and are marked
`NOT_FOUND_IN_SNAPSHOT`; no license is inferred for those projects. This is why
the source trees are acquired from the benchmark authors rather than repackaged
by this paper. The same manifest records content-addressed project-tree revisions
because the downloaded directories contain no `.git` metadata. The preserved
local verification report confirms that all 70 official-archive directories
match the expected revisions.

## Models and Registries

Qwen2.5-Coder and DeepSeek-Coder weights are not redistributed. Users must
obtain them from their official distributors under the applicable model
licenses. PyPI and Maven validation outputs are preserved as derived factual
lookup results; package-manager caches and downloaded artifacts are excluded.

## Human Labels and Generated Outputs

The anonymous artifact includes the completed annotation sheets, adjudication
records, derived truth labels, and model-generated text required to audit the
reported results. It contains no participant-identifying data; annotator
profiles are limited to the methodological experience information reported in
the manuscript and artifact metadata.
