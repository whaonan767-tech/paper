# Public Sanitized Artifact

This archive is the public-release companion to the confidential peer-review
artifact. It contains the manuscript, study-authored scripts, environment and
model provenance, and aggregate values for 40 core assertions and 40 separate
new-experiment checks. The latter cover the post-freeze external pilot and prospective external V1/V2 evaluation,
baseline-restoration test probe, and mapping runtime/request/cache benchmark.

It intentionally excludes all row-level experiment data, raw prompts, model
responses, row-level registry-missing package/coordinate candidate lists, human
annotation sheets, adjudication files, compiler logs, and third-party project
trees. The manuscript and scripts may still mention a small number of concrete
example imports or package names needed to describe the method. Consequently it
documents and hashes the implementation and aggregate claims, but it cannot
recompute row-level statistics by itself.

The full review artifact may be supplied only through the journal's
confidential editorial system. Public users who need controlled access to the
row-level evidence must obtain authorization from the data contributors and
the applicable third-party data licensors.

To verify the archive, first unzip it into a directory, then run from that
directory:

```powershell
python validate_public_artifact.py --root .
```

The validator also checks the exact 40/40 and 40/40 aggregate-check counts,
rejects undeclared files, and scans text files for credentials and local
absolute paths. Use `PUBLIC_ARTIFACT_MANIFEST.json` and `SHA256SUMS` together
with the validator output to confirm the package contents.
