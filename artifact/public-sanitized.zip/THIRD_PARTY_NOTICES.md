# Third-Party Notices

These notices apply to the confidential peer-review artifact and the public
sanitized companion artifact. The study-authored MIT license does not apply to
the third-party materials listed below.

## PackageHallucination

- Upstream project: the PackageHallucination artifact identified in
  `PackageHallucination-main/UPSTREAM_README.md`.
- The upstream README describes the project as MIT-licensed, but the local
  source snapshot did not contain the upstream license text. The review archive
  therefore does not relicense upstream files and includes only the bounded
  derived outputs and study-authored scripts needed for verification.

## Stack Overflow-Derived Text

- Some preserved credential-redacted raw generation records in the confidential
  review artifact contain prompt text derived from Stack Overflow through the upstream
  PackageHallucination dataset.
- Stack Overflow user contributions are generally available under CC BY-SA;
  the applicable version depends on contribution date.
- The local upstream snapshot does not preserve sufficient item-level URLs and
  author attribution for every copied prompt. Consequently, the eight
  `*Master.json` source-data copies are excluded from this archive, and the raw
  prompt-bearing files must not be republished as a public dataset until
  attribution and share-alike obligations are satisfied.

## APIHulBench and Java Projects

- Benchmark repository: https://github.com/yujiachen99/APIMitigation
- Official project archive id: `12c46In9w9fqJyU-qAAKccMSVycFIszOz`
- Third-party Java project trees are not redistributed. Nineteen of the 70
  build-relevant snapshots have no discoverable LICENSE/COPYING/NOTICE document
  under the study's strict legal-file scan. Reviewers acquire the authors'
  official archive and verify content hashes with
  `codex_acquire_apihulbench_projects.py`.

## Models and Registries

- Qwen2.5-Coder and DeepSeek-Coder model weights are not included. Their
  respective distributor terms apply.
- PyPI/Maven lookup outputs and credential-redacted raw generation records are
  included only in the confidential review artifact for claim verification; no
  broader public-data license is asserted.
