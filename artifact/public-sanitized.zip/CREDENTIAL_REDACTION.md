# Credential Redaction

This submission artifact replaces third-party credentials that appeared inside
prompt-bearing source text with:

`<REDACTED_THIRD_PARTY_CREDENTIAL>`

The redaction is a publication-safety step applied after experiment outputs
were preserved and before the final archive manifest, SHA256SUMS, and
submission-critical recomputation report were generated. Redaction changes
only credential-bearing substrings in 34 prompt/question occurrences and 8
echoed response/answer occurrences. It does not alter extracted candidates,
detector labels, human decisions, aggregate statistics, or manuscript
conclusions.

The redaction targets only secret-bearing material:

- database connection URIs that embed a username and password;
- password, secret, API-key, access-token, or client-secret assignments with a
  non-placeholder value;
- PEM private-key blocks, if any appear in text payloads.

Obvious placeholders such as `your_password`, `YOUR_API_KEY`, `user`,
`password`, `dummy`, `example`, and already redacted values are treated as
non-secret placeholders by the validator. The confidential review artifact
keeps row-level evidence for verification, but it must remain under the
journal's confidential review process. The public sanitized artifact excludes
row-level prompts, responses, labels, and candidate lists.
