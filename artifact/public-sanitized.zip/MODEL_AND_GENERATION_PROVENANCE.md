# Model and Generation Provenance

## Qwen2.5-Coder-3B-Instruct

- Hugging Face repository: `Qwen/Qwen2.5-Coder-3B-Instruct`
- Download metadata revision: `488639f1ff808d1d3d0ba301aef8c11461451ec5`
- `config.json` SHA256: `8f85440a3222d18772e964b1ef0b4b1574a1c5e6260c99aa23fcddd05c28b8ae`
- `generation_config.json` SHA256: `fdaccbcb02f3e1e7914ccb0f69ebe899071ffd27cf825166d823163e156870f2`
- `tokenizer_config.json` SHA256: `959e7f1d9a1b7641a6d6ce05ca97b75c7894fcb66cbe5a040406458fb1128ee4`
- `tokenizer.json` SHA256: `c0382117ea329cdf097041132f6d735924b697924d6f6fc3945713e96ce87539`
- `model.safetensors.index.json` SHA256: `7b85f79fd7612df2e5d7f03d7f92d65c8967f790a331146ca7f45658823060d3`
- `model-00001-of-00002.safetensors` SHA256: `5b684409377e037e5ed75d680a070126e841dab17e8cb9a818868deadf01ab39`
- `model-00002-of-00002.safetensors` SHA256: `8bc5227aae6174eaf0b589fd4fbeb0de046a1fc951a67f2d2538acad811e1068`
- Quantization: `BitsAndBytesConfig(load_in_4bit=True)`; no additional
  Qwen-specific 4-bit parameter was supplied by either runner.
- Decoding: deterministic (`do_sample=false`); Python used 192 code tokens and
  48 package tokens, while the five Java windows used a 384-token cap. Exact
  arguments remain in the preserved run metadata.

## Qwen2.5-Coder-7B-Instruct

- Hugging Face repository: `Qwen/Qwen2.5-Coder-7B-Instruct`
- Download metadata revision: `c03e6d358207e414f1eca0bb1891e29f1db0e242`
- `config.json` SHA256: `c0242402ad6a13b331ea320feea8c7e3776ffb7a4eff0757b9cd667e116d9a28`
- `generation_config.json` SHA256: `1a628a5775bc69cde01c6749a531150ca4d3189652c618a174f7077923acf3b1`
- `tokenizer_config.json` SHA256: `959e7f1d9a1b7641a6d6ce05ca97b75c7894fcb66cbe5a040406458fb1128ee4`
- Quantization: `BitsAndBytesConfig(load_in_4bit=True)`; no additional
  Qwen-specific 4-bit parameter was supplied by the runner.
- Decoding: deterministic (`do_sample=false`); per-protocol token limits are
  preserved in each run's `metadata.json`.

## DeepSeek-Coder-6.7B-Instruct

- Hugging Face repository: `deepseek-ai/deepseek-coder-6.7b-instruct`
- A repository commit was not preserved at download time; the following local
  configuration hashes are the authoritative model-configuration identifiers.
- `config.json` SHA256: `a3a2ce1a623b367d3799fb0c1e1ba12d5b8fa51a8e7abba14d10dd3739cd73e4`
- `generation_config.json` SHA256: `186a63b420f66a03e95a035c488373361bb04833a9b83f4bdbaba70c5c816002`
- `tokenizer_config.json` SHA256: `775f116ff1130a5b5bfc3cfdb594f9fcb5a5dc61d5a11ba92b2a7c078d66b7b7`
- Quantization: 4-bit with `bnb_4bit_compute_dtype=float16`; model dtype
  `float16`, `device_map=auto`, GPU limit 14 GiB, CPU limit 48 GiB.
- Decoding: deterministic (`do_sample=false`), 1024-token cap, no system
  message, tokenizer-file backend.
- Because the DeepSeek repository commit was not preserved, these hashes audit
  the saved local configuration and outputs but cannot guarantee token-for-token
  regeneration from a future repository snapshot.

Model weights are not redistributed. A Qwen-3B rerun must verify both weight
shards and the listed configuration/tokenizer files. Other reruns must verify
the available configuration hashes and use the exact `argv` stored in the
corresponding run metadata.
