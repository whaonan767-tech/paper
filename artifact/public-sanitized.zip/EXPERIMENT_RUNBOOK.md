# Frozen Experiment Runbook

This runbook distinguishes result auditing from expensive reruns. The review
archive ships the complete `codex_*.py` runner/analysis surface used by the
study, preserved prompts and outputs where redistribution permits, and exact
commands in run metadata. It does not ship model weights, Maven caches, or
third-party Java project trees.

## 1. Deterministic result audit

From `PackageHallucination-main`:

```bash
python codex_recompute_submission_core.py
```

Expected terminal result: `PASS 40 checks`.

## 2. Model inference

Create and activate the recorded environment with:

```bash
conda env create --file generation_environment.yml
conda activate dependency-hallucination-generation
```

The environment file supplies the official PyTorch CUDA 12.8 wheel index, so
the `torch==2.11.0+cu128` requirement does not depend on the default package
index. Then obtain model files,
verify the configuration hashes in `MODEL_AND_GENERATION_PROVENANCE.md`, and
replace `<MODEL_ROOT>` below with the verified local directory.

Python Qwen generation uses `codex_package_experiment_runner.py`. The 400
prompts per model are four dataset strata of 100 prompts, executed in chunks;
the exact chunk offsets, limits, token caps, labels, and output paths are
stored in each `summary.json` under `metadata.argv` and `metadata.merged_from`.
For example, the Qwen-7B first chunk is:

```bash
python codex_package_experiment_runner.py --model-path <MODEL_ROOT>/Qwen2.5-Coder-7B-Instruct --model-label Qwen2.5-Coder-7B-Instruct-4bit --language Python --offset 0 --limit-per-dataset 50 --max-code-tokens 192 --max-package-tokens 48 --output-dir Tests/Qwen7B_Pilot50_Python --load-in-4bit
```

Java main generation uses `codex_java_dependency_generation_runner.py`. The
416-record Qwen-7B run is split at offsets 0, 50, ..., 400 with limits 50 (16
for the final chunk), `max-new-tokens=384`, 4-bit loading, local files only,
and deterministic decoding. The corrected structured 83-record command is:

```bash
python codex_java_dependency_generation_runner.py --input-jsonl Tests/Java_APIHulBench_MaskedV3StructuredPrompts_Corrected_Run20260804/prompts.jsonl --model-path <MODEL_ROOT>/Qwen2.5-Coder-7B-Instruct --model-label Qwen2.5-Coder-7B-Instruct-4bit-masked-v3-corrected --output-dir Tests/Java_APIHulBench_Qwen7B_MaskedV3Structured_Corrected_Run20260804 --limit 83 --max-new-tokens 256 --load-in-4bit --local-files-only --no-trust-remote-code --low-cpu-mem-usage
```

The DeepSeek appendix run is:

```bash
python codex_java_dependency_generation_runner.py --input-jsonl Tests/Java_APIHulBench_DependencyCriticalMaskedPrompts_StrictMainTest_Run20260730/prompts.jsonl --model-path <MODEL_ROOT>/deepseek-coder-6.7b-instruct --model-label DeepSeek-Coder-6.7B-Instruct --output-dir Tests/Java_APIHulBench_DeepSeekCoder67B_DepCriticalMasked_Strict_Full117_FastTok1024_Run20260730 --limit 117 --max-new-tokens 1024 --load-in-4bit --quant-compute-dtype float16 --dtype float16 --device-map auto --max-gpu-memory 14GiB --max-cpu-memory 48GiB --local-files-only --low-cpu-mem-usage --use-safetensors true --no-system-message --tokenizer-file-backend
```

The preserved `metadata.json` files are authoritative when a displayed command
and a summary disagree; each contains the exact original `argv` array.

## 3. Java extraction, classification, and mitigation

The original detector snapshot is the exact combination of
`codex_classify_java_imports.py`, `codex_map_java_imports_to_maven.py`, and
`codex_summarize_java_window_expansion.py`. The full frozen provenance table
also hashes `codex_java_recall_extension_audit.py`,
`codex_package_experiment_runner.py`, and
`codex_java_dependency_generation_runner.py`, so the packaged Markdown and JSON
script inventories contain the same six scripts.

Registry/project sanitization and feedback use
`codex_apply_java_registry_sanitizer.py`,
`codex_apply_java_dependency_sanitizer.py`,
`codex_build_java_registry_feedback_prompts.py`, and
`codex_build_java_dependency_feedback_prompts.py`. Every named script is
included in the archive and hashed by `ARTIFACT_MANIFEST_FINAL.json` and
`SHA256SUMS`; the detector scripts are additionally checked against
`java_detector_provenance.json` by the archive validator.

## 4. Compilation protocols

After acquiring the official APIHulBench project archive, verify all 70 trees:

```bash
python codex_acquire_apihulbench_projects.py --verify-only --repositories-dir repositories
```

The compilation protocols are implemented by the shipped scripts:

- `codex_java_import_only_probe.py` and `codex_java_import_build_probe.py` for
  minimal-sentinel and injected-import probes;
- `codex_java_masked_baseline_audit.py`,
  `codex_java_masked_necessity_probe.py`, and
  `codex_java_masked_evidence_build.py` for V0/V1/V2 test-compilation;
- `codex_build_java_masked_v3_prompts.py`,
  `codex_parse_java_masked_v3.py`, `codex_java_masked_v3_build.py`,
  `codex_java_masked_v3_factorial_build.py`,
  `codex_java_masked_test_baseline.py`, and
  `codex_java_masked_v3_test.py` for the structured 2-by-2 and test-eligibility
  probes.

Each build result JSON records the command, selected JDK, module path, timeout,
exit status, and input hashes. Build work directories and dependency caches are
excluded; a fresh rerun may resolve dependencies differently if upstream
repositories have changed.

## 5. Completed raw-response mention audit

The human workbooks are completed and shipped. Re-score the adjudicated
416-response sheet from `PackageHallucination-main` without reopening
annotation:

```powershell
python codex_prepare_raw_response_mention_audit.py --score Tests/Java_APIHulBench_RawMentionHumanAudit_Final_Run20260816/raw_response_mention_audit_merged_final.csv --candidate-truth Tests/Java_APIHulBench_Full598_HeldoutAudit_Run20260731/full598_final_human_truth.csv --output-dir Tests/RawMentionAudit_Recomputed --bootstrap-repetitions 10000 --seed 20260814
```

This regenerates extractor TP/FP/FN, the hybrid-grounded end-to-end result, the
raw-response-only sensitivity result, and project-clustered intervals. The two
completed annotator workbooks and completed adjudication workbook are preserved
for audit; they are not regenerated by this command.

## 6. Post-freeze external pilot

The complete acquisition and inference rerun requires network access, the
recorded Qwen model, and fresh output directories. Let `<RERUN_ROOT>` be the
review-artifact root and place `<ACQUISITION_DIR>` beneath it so the recorded
project and file paths remain artifact-relative. From `<RERUN_ROOT>`:

```powershell
python PackageHallucination-main/codex_freeze_prospective_external_evaluation.py --output-dir <FREEZE_DIR> --model-dir <MODEL_ROOT>/Qwen2.5-Coder-3B-Instruct
python PackageHallucination-main/codex_acquire_external_java_pilot.py --freeze-dir <FREEZE_DIR> --output-dir <ACQUISITION_DIR> --projects 8 --search-size 40 --search-snapshot external_evaluation/metadata/github_search_snapshot.json
python PackageHallucination-main/codex_build_external_java_pilot_prompts.py --acquisition-dir <ACQUISITION_DIR> --output-jsonl <PILOT_DIR>/external_masked_import_prompts.jsonl --per-project 2 --seed 20260814
python PackageHallucination-main/codex_record_external_pilot_protocol.py --acquisition-dir <ACQUISITION_DIR> --original-freeze <FREEZE_DIR>/prospective_external_evaluation_freeze.json --output-dir <PILOT_DIR>/protocol
python PackageHallucination-main/codex_java_dependency_generation_runner.py --input-jsonl <PILOT_DIR>/external_masked_import_prompts.jsonl --model-path <MODEL_ROOT>/Qwen2.5-Coder-3B-Instruct --model-label Qwen2.5-Coder-3B-Instruct-external-pilot --output-dir <PILOT_DIR>/generation --offset 0 --limit 16 --max-new-tokens 64 --dtype float16 --device-map cuda:0 --local-files-only --low-cpu-mem-usage --use-safetensors true
python PackageHallucination-main/codex_java_dependency_extractor.py --input-jsonl <PILOT_DIR>/generation/responses.jsonl --field response --output-json <PILOT_DIR>/analysis/extracted_candidates.json --output-csv <PILOT_DIR>/analysis/extracted_candidates.csv
python PackageHallucination-main/codex_classify_java_imports.py --candidates-csv <PILOT_DIR>/analysis/extracted_candidates.csv --responses-jsonl <PILOT_DIR>/generation/responses.jsonl --prompts-jsonl <PILOT_DIR>/external_masked_import_prompts.jsonl --apihul-root <RERUN_ROOT> --output-csv <PILOT_DIR>/analysis/classified_candidates.csv --output-json <PILOT_DIR>/analysis/classified_candidates.json --output-md <PILOT_DIR>/analysis/classified_candidates.md
python PackageHallucination-main/codex_probe_external_candidate_build_truth.py --prompts-jsonl <PILOT_DIR>/external_masked_import_prompts.jsonl --mapping-json <PILOT_DIR>/analysis/classified_candidates.json --workspace <RERUN_ROOT> --output-dir <PILOT_DIR>/build-truth --work-root <BUILD_WORK_DIR> --maven-settings <MAVEN_SETTINGS> --maven-repository <MAVEN_REPOSITORY> --java-home <JDK17_HOME> --java-version 17 --timeout 900
python codex_finalize_external_pilot_truth.py --input <PILOT_DIR>/build-truth/external_candidate_build_truth.json --output-dir <PILOT_DIR>/build-truth-final
```

The shipped inference arguments are recorded in
`external_evaluation/generations/qwen3b_v2/metadata.json`. Repository
selection excludes normalized name collisions and GitHub records marked as
forks, but it is not owner-, API-family-, or ecosystem-disjoint.

## 7. Baseline-restoration real-test probe

After lawful acquisition and hash verification of the official Java project
trees, run the probe for the five frozen record IDs:

```powershell
python codex_java_sanitizer_real_test_probe.py --run-name <RUN_NAME> --output-root <OUTPUT_ROOT> --work-root <WORK_ROOT> --timeout 900 --record-id APIHulBench_F_0148 --record-id APIHulBench_M_0001 --record-id APIHulBench_M_0106 --record-id APIHulBench_M_0107 --record-id APIHulBench_M_0108
```

If environment-specific reruns are needed, merge only runs whose unchanged
baseline passes with nonzero tests:

```powershell
python codex_merge_java_sanitizer_real_test_probe.py --input <RUN_A>/sanitizer_real_test_probe.json --input <RUN_B>/sanitizer_real_test_probe.json --output-dir <FINAL_OUTPUT_DIR>
```

The primary denominator is five paired records from three projects and 451
unique baseline tests. The stored 1,139 sanitized executions are cumulative
across repeated record-level runs, not 1,139 independent tests.

## 8. Mapping runtime, request, and cache benchmark

Run the three-variant benchmark from `PackageHallucination-main` with an empty
new output directory:

```powershell
python codex_benchmark_java_mapping_pipeline.py --input-csv ../external_evaluation/analysis/classified_candidates.csv --apihul-root <RERUN_ROOT> --output-dir ../external_evaluation/benchmark/mapping-rerun --timeout 30 --sleep 0.05
```

Finally validate all 40 preserved new-experiment claims:

```powershell
python codex_validate_new_experiments.py --root ..
```

Expected result: `PASS 40/40 checks`.
