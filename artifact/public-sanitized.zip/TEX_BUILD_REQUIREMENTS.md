# TeX Build Requirements

The manuscript is built with XeLaTeX.  The tested Windows build uses MiKTeX
with the Libertinus Serif font installed.  A clean Linux build needs equivalent
XeTeX/font support before running the manuscript build.

Minimum TeX components:

- XeTeX / XeLaTeX
- latexmk
- fontspec
- Libertinus fonts, or TeX Gyre Termes as the manuscript fallback
- natbib
- tikz / pgf
- booktabs
- tabularx
- longtable
- multirow
- threeparttable
- xcolor
- hyperref
- placeins

Example Linux setup:

```bash
sudo apt-get update
sudo apt-get install -y texlive-xetex texlive-latex-extra texlive-fonts-extra latexmk fonts-libertinus
```

Build command:

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

The source uses `\IfFontExistsTF` to select Libertinus Serif when present and
TeX Gyre Termes otherwise.  The PDF submitted with the paper should still be
checked with `pdffonts` after compilation to confirm all fonts are embedded.
